"""
Moteur de diagnostic de sol.
Reprend la logique d'AgroScan Pro : pour une culture donnée, compare les 8 mesures
aux seuils optimaux ISRA/CDH et produit un statut par paramètre + un score /8.

- Diagnostic SIMPLIFIÉ (plan gratuit) : statut + plage optimale.
- Diagnostic AVANCÉ (premium/coop)    : ajoute la recommandation agronomique détaillée.

NB : ce fichier embarque un extrait des seuils. En production, on charge la base
complète (29 cultures) depuis la table SQL ou un fichier de données partagé.
"""
from typing import Dict, List, Any

PARAMS = ["Température", "Humidité", "CE", "pH", "Azote", "Phosphore", "Potassium", "Salinité"]

# Seuils [min, max] par culture (extrait — à compléter avec les 29 cultures).
SEUILS = {
    "Tomate":   {"pH": [6, 7], "Humidité": [60, 80], "Température": [18, 30], "CE": [300, 2000],
                 "Azote": [100, 250], "Phosphore": [60, 150], "Potassium": [150, 300], "Salinité": [0, 800]},
    "Oignon":   {"pH": [6, 7.5], "Humidité": [50, 75], "Température": [18, 30], "CE": [300, 1500],
                 "Azote": [80, 200], "Phosphore": [50, 120], "Potassium": [100, 250], "Salinité": [0, 600]},
    "Maïs":     {"pH": [5.8, 7], "Humidité": [50, 80], "Température": [18, 32], "CE": [200, 1500],
                 "Azote": [80, 200], "Phosphore": [50, 120], "Potassium": [100, 250], "Salinité": [0, 600]},
    "Riz":      {"pH": [5, 7], "Humidité": [70, 100], "Température": [20, 35], "CE": [300, 1000],
                 "Azote": [80, 200], "Phosphore": [40, 100], "Potassium": [100, 250], "Salinité": [0, 500]},
    "Arachide": {"pH": [5.8, 7], "Humidité": [40, 70], "Température": [22, 32], "CE": [200, 1500],
                 "Azote": [50, 150], "Phosphore": [30, 80], "Potassium": [80, 200], "Salinité": [0, 600]},
    "Mil":      {"pH": [5.5, 7.5], "Humidité": [20, 60], "Température": [25, 38], "CE": [100, 1000],
                 "Azote": [30, 100], "Phosphore": [20, 60], "Potassium": [60, 150], "Salinité": [0, 800]},
}

# Recommandations avancées (extrait) : (culture, paramètre) -> {bas, ok, haut}
RECOS = {
    ("Tomate", "pH"): {"bas": "Sol acide. Chauler 2-3 sacs/ha. pH<6 cause la pourriture apicale.",
                       "ok": "pH idéal. Maintenir avec compost.",
                       "haut": "Sol basique. Soufre agricole 3-4 sacs/ha."},
    ("Tomate", "Potassium"): {"bas": "Carence K. KCl 2-3 sacs/ha, crucial pour la qualité des fruits.",
                              "ok": "K suffisant. Maintenir.",
                              "haut": "Excès K. Apporter du magnésium si symptômes."},
}


def diagnose(culture: str, measurements: Dict[str, float], advanced: bool = False) -> Dict[str, Any]:
    """Calcule le diagnostic complet pour une culture et un jeu de mesures."""
    seuils = SEUILS.get(culture)
    if not seuils:
        return {"error": f"Culture inconnue : {culture}", "score": 0, "verdict": "—", "detail": []}

    detail, score, filled = [], 0, 0
    for p in PARAMS:
        val = measurements.get(p)
        rng = seuils.get(p, [None, None])
        mn, mx = rng[0], rng[1]
        if val is None:
            status = "wait"
        elif mn is not None and val < mn:
            status = "bas"
        elif mx is not None and val > mx:
            status = "haut"
        else:
            status = "ok"
        if status != "wait":
            filled += 1
        if status == "ok":
            score += 1

        row = {"parametre": p, "valeur": val, "min": mn, "max": mx, "statut": status}
        if advanced and status in ("bas", "ok", "haut"):
            reco = RECOS.get((culture, p))
            if reco:
                row["recommandation"] = reco[status]
        detail.append(row)

    verdict = _verdict(score, filled)
    return {"score": score, "filled": filled, "verdict": verdict, "detail": detail}


def _verdict(score: int, filled: int) -> str:
    if filled == 0:
        return "En attente"
    if score == 8:
        return "Excellent"
    if score >= 6:
        return "Bon"
    if score >= 4:
        return "Moyen"
    return "À corriger"
