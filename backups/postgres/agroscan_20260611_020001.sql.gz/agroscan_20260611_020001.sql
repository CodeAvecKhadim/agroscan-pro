--
-- PostgreSQL database dump
--

\restrict PSx7a4soJ8sZLpd5rzA1ZzNfXd1vD8DkRMrXX4irSOuK93wTFVLnA36d8SbfjPo

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: categoriecoût; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."categoriecoût" AS ENUM (
    'INTRANT',
    'MATERIEL',
    'TRANSPORT',
    'PRESTATION',
    'AUTRE'
);


--
-- Name: categoriereco; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.categoriereco AS ENUM (
    'SOL',
    'FERTILISATION',
    'MALADIE',
    'RAVAGEUR',
    'IRRIGATION',
    'CALENDRIER',
    'RECOLTE',
    'GENERAL'
);


--
-- Name: credit_motif; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.credit_motif AS ENUM (
    'achat',
    'service',
    'remboursement',
    'bonus',
    'ajustement'
);


--
-- Name: disponibiliteeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.disponibiliteeau AS ENUM (
    'PERMANENTE',
    'SAISONNIERE',
    'IRREGULIERE'
);


--
-- Name: erosionsol; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.erosionsol AS ENUM (
    'NULLE',
    'FAIBLE',
    'MODEREE',
    'FORTE',
    'TRES_FORTE'
);


--
-- Name: etatinfrastructure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.etatinfrastructure AS ENUM (
    'BON',
    'MOYEN',
    'MAUVAIS',
    'A_REPARER',
    'HORS_SERVICE'
);


--
-- Name: evolutionsuivi; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.evolutionsuivi AS ENUM (
    'AMELIORATION',
    'STABLE',
    'AGGRAVATION'
);


--
-- Name: methodediagnostic; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.methodediagnostic AS ENUM (
    'RULES_ENGINE',
    'BIBLIOTHEQUE',
    'SYMPTOMES',
    'COMBINEE'
);


--
-- Name: modeconversation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.modeconversation AS ENUM (
    'LIBRE',
    'ANALYSE_PARCELLE',
    'DIAGNOSTIC',
    'PLANIFICATION',
    'BILAN'
);


--
-- Name: niveaualerte; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.niveaualerte AS ENUM (
    'INFO',
    'AVERTISSEMENT',
    'CRITIQUE'
);


--
-- Name: paiement_statut; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.paiement_statut AS ENUM (
    'en_attente',
    'paye',
    'echoue',
    'rembourse'
);


--
-- Name: partieplante; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.partieplante AS ENUM (
    'FEUILLE',
    'TIGE',
    'RACINE',
    'FRUIT',
    'GRAINE',
    'PLANTE_ENTIERE',
    'SOL'
);


--
-- Name: plantype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.plantype AS ENUM (
    'GRATUIT',
    'PREMIUM',
    'COOPERATIVE'
);


--
-- Name: qualiteeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.qualiteeau AS ENUM (
    'BONNE',
    'ACCEPTABLE',
    'TRAITEE_REQUISE',
    'IMPROPRE'
);


--
-- Name: rolemessage; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rolemessage AS ENUM (
    'USER',
    'ASSISTANT',
    'SYSTEM'
);


--
-- Name: service_statut; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_statut AS ENUM (
    'en_attente',
    'en_cours',
    'termine',
    'echoue',
    'annule'
);


--
-- Name: sourcemesure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcemesure AS ENUM (
    'GPS_TERRAIN',
    'DESSIN_CARTE',
    'IMPORT_FICHIER',
    'ESTIMATION'
);


--
-- Name: sourcemeteo; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcemeteo AS ENUM (
    'OPEN_METEO',
    'CAPTEUR',
    'MANUEL'
);


--
-- Name: sourcephoto; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcephoto AS ENUM (
    'TERRAIN',
    'LABORATOIRE',
    'DRONE',
    'SMARTPHONE',
    'AUTRE'
);


--
-- Name: sourceplanificateur; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourceplanificateur AS ENUM (
    'RULES_ENGINE',
    'METEO',
    'GF_ACTIVITE',
    'MANUEL'
);


--
-- Name: sourcepreuve; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcepreuve AS ENUM (
    'SMARTPHONE',
    'DRONE',
    'TABLETTE',
    'AUTRE'
);


--
-- Name: statutactivite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutactivite AS ENUM (
    'PLANIFIE',
    'EN_COURS',
    'TERMINE',
    'ANNULE'
);


--
-- Name: statutconsultation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutconsultation AS ENUM (
    'EN_COURS',
    'ANALYSE',
    'CONFIRME',
    'ARCHIVE'
);


--
-- Name: statutconversation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutconversation AS ENUM (
    'ACTIVE',
    'ARCHIVEE',
    'TERMINEE'
);


--
-- Name: statutdiagnostic; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutdiagnostic AS ENUM (
    'PROBABLE',
    'CONFIRME',
    'EXCLU'
);


--
-- Name: statutparcelle; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutparcelle AS ENUM (
    'ACTIVE',
    'EN_REPOS',
    'EN_PREPARATION',
    'ARCHIVE'
);


--
-- Name: statutplanificateur; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutplanificateur AS ENUM (
    'RECOMMANDE',
    'PLANIFIE',
    'IGNORE',
    'FAIT'
);


--
-- Name: statutreco; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutreco AS ENUM (
    'NOUVELLE',
    'VUE',
    'APPLIQUEE',
    'IGNOREE'
);


--
-- Name: statuttraitement; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statuttraitement AS ENUM (
    'PLANIFIE',
    'APPLIQUE',
    'SKIP'
);


--
-- Name: substatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.substatus AS ENUM (
    'ACTIVE',
    'TRIAL',
    'PAST_DUE',
    'CANCELED',
    'EXPIRED'
);


--
-- Name: texturesol; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.texturesol AS ENUM (
    'SABLEUX',
    'LIMONEUX',
    'ARGILEUX',
    'ARGILO_LIMONEUX',
    'SABLO_LIMONEUX',
    'LIMON_ARGILEUX'
);


--
-- Name: tonassistant; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tonassistant AS ENUM (
    'TECHNIQUE',
    'SIMPLE',
    'PEDAGOGIQUE'
);


--
-- Name: typeactivite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeactivite AS ENUM (
    'SEMIS',
    'PLANTATION',
    'FERTILISATION',
    'TRAITEMENT',
    'IRRIGATION',
    'DESHERBAGE',
    'RECOLTE',
    'AUTRE'
);


--
-- Name: typealerte; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typealerte AS ENUM (
    'METEO',
    'MALADIE',
    'RAVAGEUR',
    'FERTILISATION',
    'IRRIGATION',
    'CALENDRIER',
    'PLANIFICATEUR'
);


--
-- Name: typeconsultation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeconsultation AS ENUM (
    'MALADIE',
    'RAVAGEUR',
    'FERTILISATION'
);


--
-- Name: typeentite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeentite AS ENUM (
    'MALADIE',
    'RAVAGEUR',
    'CARENCE'
);


--
-- Name: typegeometrie; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typegeometrie AS ENUM (
    'POLYGON',
    'POINT',
    'LINESTRING'
);


--
-- Name: typeinfrastructure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeinfrastructure AS ENUM (
    'BATIMENT',
    'HANGAR',
    'SERRE',
    'CLOTURE',
    'PISTE',
    'CANAL',
    'DIGUE',
    'FORAGE',
    'PUITS',
    'RESERVOIR',
    'COMPOSTIERE',
    'AUTRE'
);


--
-- Name: typejournal; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typejournal AS ENUM (
    'OBSERVATION',
    'DECISION',
    'ALERTE',
    'NOTE_TERRAIN',
    'METEO'
);


--
-- Name: typemainoeuvre; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typemainoeuvre AS ENUM (
    'FAMILIALE',
    'SALARIALE',
    'ENTRAIDE',
    'PRESTATAIRE'
);


--
-- Name: typeobservation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeobservation AS ENUM (
    'SYMPTOME',
    'RAVAGEUR_OBSERVE',
    'SOL',
    'METEO',
    'AUTRE'
);


--
-- Name: typepreuve; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typepreuve AS ENUM (
    'PHOTO',
    'VIDEO'
);


--
-- Name: typerapport; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typerapport AS ENUM (
    'DIAGNOSTIC_MALADIE',
    'DIAGNOSTIC_RAVAGEUR',
    'PLAN_FERTILISATION',
    'SUIVI'
);


--
-- Name: typesourceeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typesourceeau AS ENUM (
    'FORAGE',
    'PUITS_TRADITIONNEL',
    'COURS_EAU',
    'MARE_PERMANENTE',
    'MARE_TEMPORAIRE',
    'RESERVOIR',
    'EAU_DE_PLUIE',
    'CANAL_IRRIGATION'
);


--
-- Name: typetraitement; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typetraitement AS ENUM (
    'TRAITEMENT_PHYTO',
    'FERTILISATION',
    'IRRIGATION',
    'MESURE_CULTURALE',
    'RECOLTE',
    'SURVEILLANCE'
);


--
-- Name: userrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.userrole AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER',
    'VIEWER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agro_besoins_eau; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_besoins_eau (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    stade character varying(80) NOT NULL,
    besoin_mm_semaine numeric(5,1),
    sensibilite character varying(20),
    frequence_irrigation character varying(100),
    notes text
);


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_besoins_eau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_besoins_eau_id_seq OWNED BY public.agro_besoins_eau.id;


--
-- Name: agro_besoins_nutritionnels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_besoins_nutritionnels (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    stade character varying(80) NOT NULL,
    azote_kg_ha numeric(6,1),
    phosphore_kg_ha numeric(6,1),
    potassium_kg_ha numeric(6,1),
    calcium_kg_ha numeric(6,1),
    magnesium_kg_ha numeric(6,1),
    engrais_recommandes text,
    moment_application text,
    notes text
);


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_besoins_nutritionnels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_besoins_nutritionnels_id_seq OWNED BY public.agro_besoins_nutritionnels.id;


--
-- Name: agro_calendriers_culturaux; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_calendriers_culturaux (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    zone_agro character varying(40) NOT NULL,
    saison character varying(20) NOT NULL,
    mois_semis_debut integer,
    mois_semis_fin integer,
    mois_recolte_debut integer,
    mois_recolte_fin integer,
    remarques text
);


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_calendriers_culturaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_calendriers_culturaux_id_seq OWNED BY public.agro_calendriers_culturaux.id;


--
-- Name: agro_culture_maladies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_culture_maladies (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    maladie_id integer NOT NULL,
    frequence character varying(20),
    gravite character varying(20),
    stade_sensible character varying(100),
    pertes_estimees character varying(100),
    prevention text,
    traitement text NOT NULL
);


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_culture_maladies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_culture_maladies_id_seq OWNED BY public.agro_culture_maladies.id;


--
-- Name: agro_culture_ravageurs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_culture_ravageurs (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    ravageur_id integer NOT NULL,
    frequence character varying(20),
    gravite character varying(20),
    stade_sensible character varying(100),
    pertes_estimees character varying(100),
    prevention text,
    lutte text NOT NULL
);


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_culture_ravageurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_culture_ravageurs_id_seq OWNED BY public.agro_culture_ravageurs.id;


--
-- Name: agro_cultures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_cultures (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    nom_scientifique character varying(200),
    nom_local character varying(200),
    famille character varying(100),
    categorie character varying(30) NOT NULL,
    icone character varying(10),
    description text,
    actif boolean,
    created_at timestamp without time zone,
    CONSTRAINT ck_culture_categorie CHECK (((categorie)::text = ANY ((ARRAY['grandes_cultures'::character varying, 'maraichage'::character varying, 'arboriculture'::character varying])::text[])))
);


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_cultures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_cultures_id_seq OWNED BY public.agro_cultures.id;


--
-- Name: agro_maladies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_maladies (
    id integer NOT NULL,
    nom character varying(150) NOT NULL,
    nom_scientifique character varying(200),
    pathogene_type character varying(20),
    symptomes text NOT NULL,
    conditions_favorables text,
    created_at timestamp without time zone,
    CONSTRAINT ck_maladie_type CHECK (((pathogene_type)::text = ANY ((ARRAY['fongique'::character varying, 'bacterien'::character varying, 'viral'::character varying, 'parasitaire'::character varying, 'physiologique'::character varying, 'nematode'::character varying])::text[])))
);


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_maladies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_maladies_id_seq OWNED BY public.agro_maladies.id;


--
-- Name: agro_parametres_climatiques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_parametres_climatiques (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    temp_min_c numeric(4,1),
    temp_opt_min_c numeric(4,1),
    temp_opt_max_c numeric(4,1),
    temp_max_c numeric(4,1),
    pluvio_min_mm integer,
    pluvio_opt_mm integer,
    pluvio_max_mm integer,
    altitude_max_m integer,
    ensoleillement_h numeric(3,1),
    ph_min numeric(3,1),
    ph_opt_min numeric(3,1),
    ph_opt_max numeric(3,1),
    ph_max numeric(3,1),
    texture_preferee character varying(100)
);


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_parametres_climatiques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_parametres_climatiques_id_seq OWNED BY public.agro_parametres_climatiques.id;


--
-- Name: agro_ravageurs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_ravageurs (
    id integer NOT NULL,
    nom character varying(150) NOT NULL,
    nom_scientifique character varying(200),
    type_ravageur character varying(20),
    description text,
    symptomes_degats text NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_ravageurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_ravageurs_id_seq OWNED BY public.agro_ravageurs.id;


--
-- Name: agro_recommandations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_recommandations (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    zone_agro character varying(40),
    categorie_reco character varying(50) NOT NULL,
    titre character varying(200) NOT NULL,
    contenu text NOT NULL,
    priorite integer,
    mois_applicable jsonb,
    created_at timestamp without time zone
);


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_recommandations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_recommandations_id_seq OWNED BY public.agro_recommandations.id;


--
-- Name: agro_rendements_reference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_rendements_reference (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    variete_id integer,
    zone_agro character varying(40),
    pratique character varying(20) NOT NULL,
    rendement_min_t_ha numeric(5,2),
    rendement_max_t_ha numeric(5,2),
    rendement_moyen_t_ha numeric(5,2),
    unite character varying(20),
    source character varying(100),
    annee_reference integer
);


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_rendements_reference_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_rendements_reference_id_seq OWNED BY public.agro_rendements_reference.id;


--
-- Name: agro_stades_phenologiques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_stades_phenologiques (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    variete_id integer,
    ordre integer NOT NULL,
    nom_stade character varying(100) NOT NULL,
    jours_debut integer,
    jours_fin integer,
    description text,
    actions_cles jsonb,
    indicateurs_visuels text
);


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_stades_phenologiques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_stades_phenologiques_id_seq OWNED BY public.agro_stades_phenologiques.id;


--
-- Name: agro_varietes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_varietes (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    nom character varying(150) NOT NULL,
    origine character varying(100),
    cycle_min_jours integer,
    cycle_max_jours integer,
    precocite character varying(20),
    tolerance_secheresse boolean,
    tolerance_salinite boolean,
    zones_adaptees jsonb,
    rendement_potentiel_t_ha numeric(5,2),
    notes text
);


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_varietes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_varietes_id_seq OWNED BY public.agro_varietes.id;


--
-- Name: analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer,
    farm_id integer,
    culture character varying,
    region character varying,
    measurements json,
    score integer,
    verdict character varying,
    advanced boolean,
    created_at timestamp without time zone
);


--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: champ_cartographies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_cartographies (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type_geometrie public.typegeometrie NOT NULL,
    coordonnees jsonb NOT NULL,
    projection character varying(20),
    source_mesure public.sourcemesure,
    precision_m double precision,
    date_mesure date,
    actif boolean,
    created_at timestamp with time zone
);


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_cartographies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_cartographies_id_seq OWNED BY public.champ_cartographies.id;


--
-- Name: champ_infrastructures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_infrastructures (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type public.typeinfrastructure NOT NULL,
    nom character varying(200),
    description text,
    longueur_m double precision,
    superficie_m2 double precision,
    capacite double precision,
    unite_capacite character varying(20),
    etat public.etatinfrastructure,
    annee_construction smallint,
    localisation jsonb,
    created_at timestamp with time zone
);


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_infrastructures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_infrastructures_id_seq OWNED BY public.champ_infrastructures.id;


--
-- Name: champ_parcelles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_parcelles (
    id integer NOT NULL,
    org_id integer NOT NULL,
    nom character varying(200) NOT NULL,
    code_parcelle character varying(50),
    type_culture character varying(100),
    culture_id integer,
    zone_agro character varying(50),
    region character varying(100),
    localite character varying(200),
    statut public.statutparcelle NOT NULL,
    description text,
    superficie_m2 double precision,
    superficie_ha double precision,
    perimetre_m double precision,
    centre_lat double precision,
    centre_lon double precision,
    score_completude smallint,
    score_detail jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_parcelles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_parcelles_id_seq OWNED BY public.champ_parcelles.id;


--
-- Name: champ_sols; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_sols (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    date_analyse date,
    texture public.texturesol,
    profondeur_labour_cm smallint,
    pierrosite_pct double precision,
    erosion public.erosionsol,
    "pH_eau" double precision,
    "pH_kcl" double precision,
    matiere_organique double precision,
    azote_total double precision,
    phosphore_assim double precision,
    potassium_echang double precision,
    calcium double precision,
    magnesium double precision,
    sodium double precision,
    cec double precision,
    conductivite_ds_m double precision,
    methode_analyse character varying(100),
    laboratoire character varying(200),
    reference_labo character varying(100),
    observations text,
    created_at timestamp with time zone
);


--
-- Name: champ_sols_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_sols_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_sols_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_sols_id_seq OWNED BY public.champ_sols.id;


--
-- Name: champ_sources_eau; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_sources_eau (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type public.typesourceeau NOT NULL,
    nom character varying(200),
    debit_m3h double precision,
    profondeur_m double precision,
    "pH_eau" double precision,
    conductivite_ds_m double precision,
    qualite public.qualiteeau,
    disponibilite public.disponibiliteeau,
    partage boolean,
    superficie_m2 double precision,
    localisation jsonb,
    created_at timestamp with time zone
);


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_sources_eau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_sources_eau_id_seq OWNED BY public.champ_sources_eau.id;


--
-- Name: credit_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_ledger (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    delta integer NOT NULL,
    motif public.credit_motif NOT NULL,
    solde_apres integer NOT NULL,
    service_request_id bigint,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    cree_le timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_ledger_id_seq OWNED BY public.credit_ledger.id;


--
-- Name: credit_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_purchases (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    credits integer NOT NULL,
    montant_fcfa integer NOT NULL,
    fournisseur text,
    reference text,
    statut public.paiement_statut DEFAULT 'en_attente'::public.paiement_statut NOT NULL,
    ledger_id bigint,
    cree_le timestamp with time zone DEFAULT now() NOT NULL,
    paye_le timestamp with time zone
);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_purchases_id_seq OWNED BY public.credit_purchases.id;


--
-- Name: farms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.farms (
    id integer NOT NULL,
    org_id integer NOT NULL,
    name character varying NOT NULL,
    region character varying,
    locality character varying,
    latitude double precision,
    longitude double precision,
    area_ha double precision,
    created_at timestamp without time zone
);


--
-- Name: farms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.farms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: farms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.farms_id_seq OWNED BY public.farms.id;


--
-- Name: gf_activites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_activites (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    consultation_id integer,
    type public.typeactivite NOT NULL,
    statut public.statutactivite NOT NULL,
    titre character varying(200) NOT NULL,
    description text,
    date_prevue date,
    date_debut timestamp without time zone,
    date_fin timestamp without time zone,
    duree_minutes integer,
    stade_culture character varying(100),
    surface_traitee_ha double precision,
    conditions_meteo jsonb,
    localisation_debut jsonb,
    details jsonb,
    note text,
    created_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: gf_activites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_activites_id_seq OWNED BY public.gf_activites.id;


--
-- Name: gf_couts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_couts (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    categorie public."categoriecoût" NOT NULL,
    sous_categorie character varying(100),
    description character varying(300) NOT NULL,
    quantite double precision,
    unite character varying(30),
    prix_unitaire_fcfa integer,
    montant_total_fcfa integer NOT NULL,
    fournisseur character varying(200),
    date_achat date,
    recu boolean,
    note text,
    created_at timestamp without time zone
);


--
-- Name: gf_couts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_couts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_couts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_couts_id_seq OWNED BY public.gf_couts.id;


--
-- Name: gf_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_journal (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    activite_id integer,
    date_entree date NOT NULL,
    type public.typejournal NOT NULL,
    titre character varying(200),
    contenu text NOT NULL,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: gf_journal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_journal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_journal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_journal_id_seq OWNED BY public.gf_journal.id;


--
-- Name: gf_main_oeuvre; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_main_oeuvre (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typemainoeuvre NOT NULL,
    description character varying(200),
    nb_personnes smallint NOT NULL,
    duree_jours double precision NOT NULL,
    taux_journalier_fcfa integer,
    montant_total_fcfa integer,
    note text,
    created_at timestamp without time zone
);


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_main_oeuvre_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_main_oeuvre_id_seq OWNED BY public.gf_main_oeuvre.id;


--
-- Name: gf_preuves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_preuves (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typepreuve NOT NULL,
    filename character varying(255) NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    duree_secondes smallint,
    taille_ko integer,
    source public.sourcepreuve,
    localisation jsonb,
    horodatage_terrain timestamp without time zone,
    photo_meta jsonb,
    uploaded_at timestamp without time zone
);


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_preuves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_preuves_id_seq OWNED BY public.gf_preuves.id;


--
-- Name: ia_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_config (
    id integer NOT NULL,
    org_id integer NOT NULL,
    langue character varying(10),
    ton public.tonassistant,
    focus_cultures character varying[],
    inclure_meteo boolean,
    inclure_regles boolean,
    inclure_historique_sante boolean,
    inclure_couts boolean,
    updated_at timestamp without time zone
);


--
-- Name: ia_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_config_id_seq OWNED BY public.ia_config.id;


--
-- Name: ia_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_conversations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    titre character varying(200),
    statut public.statutconversation NOT NULL,
    mode public.modeconversation NOT NULL,
    nb_messages integer,
    tokens_total integer,
    contexte_init jsonb,
    mois_periode character varying(7),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_conversations_id_seq OWNED BY public.ia_conversations.id;


--
-- Name: ia_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_feedback (
    id integer NOT NULL,
    org_id integer NOT NULL,
    conversation_id integer NOT NULL,
    message_id integer NOT NULL,
    recommandation_id integer,
    note smallint,
    utile boolean,
    commentaire text,
    amelioration text,
    created_at timestamp without time zone
);


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_feedback_id_seq OWNED BY public.ia_feedback.id;


--
-- Name: ia_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    org_id integer NOT NULL,
    role public.rolemessage NOT NULL,
    contenu text NOT NULL,
    tokens_in integer,
    tokens_out integer,
    modele character varying(60),
    duree_ms integer,
    contexte_inject jsonb,
    regles_codes character varying[],
    created_at timestamp without time zone
);


--
-- Name: ia_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_messages_id_seq OWNED BY public.ia_messages.id;


--
-- Name: ia_recommandations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_recommandations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    conversation_id integer,
    message_id integer,
    parcelle_id integer,
    culture_id integer,
    categorie public.categoriereco NOT NULL,
    priorite smallint,
    titre character varying(200) NOT NULL,
    action text NOT NULL,
    justification text,
    sources jsonb,
    echeance_jours integer,
    statut public.statutreco NOT NULL,
    confiance double precision,
    created_at timestamp without time zone
);


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_recommandations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_recommandations_id_seq OWNED BY public.ia_recommandations.id;


--
-- Name: mt_alertes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_alertes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    type_alerte public.typealerte NOT NULL,
    sous_type character varying(80),
    niveau public.niveaualerte NOT NULL,
    titre character varying(200) NOT NULL,
    message text NOT NULL,
    details jsonb,
    regle_code character varying(20),
    valable_du timestamp without time zone,
    valable_au timestamp without time zone,
    lu boolean,
    lu_le timestamp without time zone,
    action_prise boolean,
    created_at timestamp without time zone
);


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_alertes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_alertes_id_seq OWNED BY public.mt_alertes.id;


--
-- Name: mt_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_conditions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    lat double precision NOT NULL,
    lon double precision NOT NULL,
    zone_agro character varying(40),
    source public.sourcemeteo,
    temp_actuelle double precision,
    temp_min double precision,
    temp_max double precision,
    humidite_rel smallint,
    pluie_mm double precision,
    vent_kmh double precision,
    direction_vent smallint,
    etp_mm double precision,
    code_meteo smallint,
    description_fr character varying(100),
    date_releve date,
    heure_releve timestamp without time zone,
    expire_le timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_conditions_id_seq OWNED BY public.mt_conditions.id;


--
-- Name: mt_config_alertes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_config_alertes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    seuils jsonb,
    alertes_meteo_actives boolean,
    alertes_maladies_actives boolean,
    alertes_ravageurs_actives boolean,
    alertes_fertilisation_actives boolean,
    alertes_irrigation_actives boolean,
    alertes_planificateur_actives boolean,
    heure_envoi_alertes time without time zone,
    updated_at timestamp without time zone
);


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_config_alertes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_config_alertes_id_seq OWNED BY public.mt_config_alertes.id;


--
-- Name: mt_planificateur; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_planificateur (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    activite_id integer,
    date_recommandee date NOT NULL,
    type_activite character varying(50),
    titre character varying(200) NOT NULL,
    priorite smallint,
    raison text,
    fenetre_debut date,
    fenetre_fin date,
    conditions_ok boolean,
    detail_conditions jsonb,
    statut public.statutplanificateur,
    source public.sourceplanificateur,
    genere_le timestamp without time zone,
    expire_le date
);


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_planificateur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_planificateur_id_seq OWNED BY public.mt_planificateur.id;


--
-- Name: mt_previsions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_previsions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    lat double precision NOT NULL,
    lon double precision NOT NULL,
    zone_agro character varying(40),
    source character varying(30),
    horizon_jours smallint NOT NULL,
    donnees jsonb NOT NULL,
    genere_le timestamp without time zone,
    expire_le timestamp without time zone
);


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_previsions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_previsions_id_seq OWNED BY public.mt_previsions.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_cooperative boolean,
    created_at timestamp without time zone
);


--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: parcelles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parcelles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    nom text NOT NULL,
    culture text,
    superficie_ha numeric(10,3),
    superficie_m2 numeric(14,2),
    centre_lat double precision,
    centre_lng double precision,
    contour jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    precision_m numeric(8,1),
    methode text
);


--
-- Name: parcelles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parcelles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parcelles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parcelles_id_seq OWNED BY public.parcelles.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    provider character varying,
    provider_ref character varying,
    amount_ht integer,
    vat integer,
    amount_ttc integer,
    status character varying,
    created_at timestamp without time zone
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: re_declenchements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_declenchements (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    analyse_id integer,
    contexte_entree jsonb,
    resultat jsonb,
    score_confiance double precision,
    declenche_le timestamp with time zone DEFAULT now(),
    acquitte boolean,
    acquitte_le timestamp with time zone
);


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_declenchements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_declenchements_id_seq OWNED BY public.re_declenchements.id;


--
-- Name: re_parametres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_parametres (
    id integer NOT NULL,
    cle character varying(100) NOT NULL,
    valeur jsonb NOT NULL,
    categorie character varying(50),
    description text,
    modifiable_admin boolean,
    updated_at timestamp with time zone
);


--
-- Name: re_parametres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_parametres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_parametres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_parametres_id_seq OWNED BY public.re_parametres.id;


--
-- Name: re_regles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    categorie character varying(30) NOT NULL,
    sous_categorie character varying(50),
    nom character varying(250) NOT NULL,
    description text,
    zones_applicables jsonb,
    stades_applicables jsonb,
    mois_applicables jsonb,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    gravite character varying(20),
    priorite smallint,
    confiance double precision,
    plan_requis character varying(20),
    active boolean,
    source text,
    version character varying(10),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: re_regles_cultures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles_cultures (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    culture_id integer NOT NULL,
    notes text
);


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_cultures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_cultures_id_seq OWNED BY public.re_regles_cultures.id;


--
-- Name: re_regles_entites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles_entites (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    entite_type character varying(20) NOT NULL,
    entite_id integer NOT NULL
);


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_entites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_entites_id_seq OWNED BY public.re_regles_entites.id;


--
-- Name: re_regles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_id_seq OWNED BY public.re_regles.id;


--
-- Name: re_sessions_evaluation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_sessions_evaluation (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    contexte jsonb,
    regles_evaluees integer,
    regles_declenchees integer,
    duree_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_sessions_evaluation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_sessions_evaluation_id_seq OWNED BY public.re_sessions_evaluation.id;


--
-- Name: sc_analyse_economique; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_analyse_economique (
    id integer NOT NULL,
    analyse_id integer NOT NULL,
    superficie_ha double precision,
    rendement_actuel_estime_t_ha double precision,
    rendement_potentiel_t_ha double precision,
    perte_volume_t_ha double precision,
    prix_marche_fcfa_kg double precision,
    perte_potentielle_fcfa_ha double precision,
    cout_correction_estime_fcfa_ha double precision,
    gain_potentiel_fcfa_ha double precision,
    roi_estime double precision,
    created_at timestamp with time zone
);


--
-- Name: sc_analyse_economique_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_analyse_economique_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_analyse_economique_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_analyse_economique_id_seq OWNED BY public.sc_analyse_economique.id;


--
-- Name: sc_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_analyses (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    culture_id integer,
    org_id integer NOT NULL,
    statut character varying(20) NOT NULL,
    analyse_le timestamp with time zone NOT NULL,
    duree_ms integer,
    erreur_message text,
    niveau_donnees smallint NOT NULL,
    score_sante double precision,
    score_vigueur double precision,
    score_hydrique double precision,
    score_fertilite double precision,
    score_maladie double precision,
    score_ravageur double precision,
    etat_general character varying(20),
    contexte_entree jsonb,
    resultat jsonb
);


--
-- Name: sc_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_analyses_id_seq OWNED BY public.sc_analyses.id;


--
-- Name: sc_cartes_precision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_cartes_precision (
    id integer NOT NULL,
    analyse_id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type_carte character varying(20) NOT NULL,
    donnees jsonb NOT NULL,
    resolution_m integer,
    nb_cellules integer,
    created_at timestamp with time zone
);


--
-- Name: sc_cartes_precision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_cartes_precision_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_cartes_precision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_cartes_precision_id_seq OWNED BY public.sc_cartes_precision.id;


--
-- Name: sc_consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_consultations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    type public.typeconsultation NOT NULL,
    statut public.statutconsultation NOT NULL,
    contexte jsonb,
    resume text,
    nb_photos smallint,
    created_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_consultations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_consultations_id_seq OWNED BY public.sc_consultations.id;


--
-- Name: sc_diagnostics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_diagnostics (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    rang smallint NOT NULL,
    entite_type public.typeentite NOT NULL,
    entite_id integer NOT NULL,
    entite_nom character varying(200),
    score_confiance double precision,
    score_rules double precision,
    score_symptomes double precision,
    regles_matches jsonb,
    methode public.methodediagnostic,
    statut public.statutdiagnostic,
    confirme_par integer,
    confirme_le timestamp without time zone,
    note_expert text,
    created_at timestamp without time zone
);


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_diagnostics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_diagnostics_id_seq OWNED BY public.sc_diagnostics.id;


--
-- Name: sc_indices_satellitaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_indices_satellitaires (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    analyse_id integer,
    date_image date NOT NULL,
    date_calcul timestamp with time zone,
    satellite character varying(20),
    ndvi double precision,
    ndre double precision,
    savi double precision,
    evi double precision,
    msavi double precision,
    ndwi double precision,
    couverture_nuages double precision,
    ndvi_label character varying(15),
    ndre_label character varying(15),
    savi_label character varying(15),
    evi_label character varying(15),
    msavi_label character varying(15),
    ndwi_label character varying(15),
    sentinelhub_request_id character varying(100),
    bbox jsonb,
    expire_le timestamp with time zone
);


--
-- Name: sc_indices_satellitaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_indices_satellitaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_indices_satellitaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_indices_satellitaires_id_seq OWNED BY public.sc_indices_satellitaires.id;


--
-- Name: sc_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_observations (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    type public.typeobservation NOT NULL,
    partie_plante public.partieplante,
    valeur jsonb NOT NULL,
    note_terrain text,
    created_at timestamp without time zone
);


--
-- Name: sc_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_observations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_observations_id_seq OWNED BY public.sc_observations.id;


--
-- Name: sc_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_photos (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    observation_id integer,
    source_photo public.sourcephoto,
    filename character varying(255) NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    taille_ko integer,
    photo_meta jsonb,
    uploaded_at timestamp without time zone
);


--
-- Name: sc_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_photos_id_seq OWNED BY public.sc_photos.id;


--
-- Name: sc_previsions_rendement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_previsions_rendement (
    id integer NOT NULL,
    analyse_id integer NOT NULL,
    culture_id integer,
    rendement_estime double precision,
    rendement_potentiel double precision,
    ecart_performance double precision,
    facteurs_limitants jsonb,
    confiance double precision,
    methode character varying(50),
    created_at timestamp with time zone
);


--
-- Name: sc_previsions_rendement_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_previsions_rendement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_previsions_rendement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_previsions_rendement_id_seq OWNED BY public.sc_previsions_rendement.id;


--
-- Name: sc_rapports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_rapports (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typerapport NOT NULL,
    titre character varying(300) NOT NULL,
    url text NOT NULL,
    taille_ko integer,
    genere_par integer,
    genere_le timestamp without time zone,
    telechargements smallint
);


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_rapports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_rapports_id_seq OWNED BY public.sc_rapports.id;


--
-- Name: sc_suivis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_suivis (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    date_suivi date NOT NULL,
    evolution public.evolutionsuivi,
    efficacite smallint,
    note text,
    photo_url text,
    created_at timestamp without time zone
);


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_suivis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_suivis_id_seq OWNED BY public.sc_suivis.id;


--
-- Name: sc_traitements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_traitements (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    diagnostic_id integer,
    priorite smallint,
    type public.typetraitement NOT NULL,
    titre character varying(300) NOT NULL,
    produit character varying(200),
    dose character varying(100),
    frequence character varying(100),
    delai_carence_jours smallint,
    urgence_jours smallint,
    detail text,
    date_application date,
    statut public.statuttraitement,
    applique_le date,
    note text
);


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_traitements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_traitements_id_seq OWNED BY public.sc_traitements.id;


--
-- Name: service_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_requests (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    service_id integer NOT NULL,
    farm_id integer,
    statut public.service_statut DEFAULT 'en_attente'::public.service_statut NOT NULL,
    credits_debites integer DEFAULT 0 NOT NULL,
    entree jsonb DEFAULT '{}'::jsonb NOT NULL,
    resultat jsonb,
    erreur text,
    cree_le timestamp with time zone DEFAULT now() NOT NULL,
    demarre_le timestamp with time zone,
    termine_le timestamp with time zone
);


--
-- Name: service_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_requests_id_seq OWNED BY public.service_requests.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    code text NOT NULL,
    nom text NOT NULL,
    cout_credits integer DEFAULT 10 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    plan public.plantype NOT NULL,
    status public.substatus NOT NULL,
    started_at timestamp without time zone,
    current_period_end timestamp without time zone,
    seats integer,
    auto_renew boolean
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: usage_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_counters (
    id integer NOT NULL,
    org_id integer NOT NULL,
    period character varying,
    analyses_count integer
);


--
-- Name: usage_counters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usage_counters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usage_counters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usage_counters_id_seq OWNED BY public.usage_counters.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    org_id integer NOT NULL,
    full_name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    hashed_password character varying NOT NULL,
    role public.userrole,
    is_active boolean,
    created_at timestamp without time zone,
    account_type text DEFAULT 'particulier'::text NOT NULL,
    profil text DEFAULT 'producteur'::text NOT NULL,
    CONSTRAINT users_account_type_check CHECK ((account_type = ANY (ARRAY['particulier'::text, 'institution'::text]))),
    CONSTRAINT users_profil_check CHECK ((profil = ANY (ARRAY['producteur'::text, 'conseiller'::text, 'admin'::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    user_id integer NOT NULL,
    solde integer DEFAULT 0 NOT NULL,
    maj_le timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT wallets_solde_check CHECK ((solde >= 0))
);


--
-- Name: agro_besoins_eau id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau ALTER COLUMN id SET DEFAULT nextval('public.agro_besoins_eau_id_seq'::regclass);


--
-- Name: agro_besoins_nutritionnels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels ALTER COLUMN id SET DEFAULT nextval('public.agro_besoins_nutritionnels_id_seq'::regclass);


--
-- Name: agro_calendriers_culturaux id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux ALTER COLUMN id SET DEFAULT nextval('public.agro_calendriers_culturaux_id_seq'::regclass);


--
-- Name: agro_culture_maladies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies ALTER COLUMN id SET DEFAULT nextval('public.agro_culture_maladies_id_seq'::regclass);


--
-- Name: agro_culture_ravageurs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs ALTER COLUMN id SET DEFAULT nextval('public.agro_culture_ravageurs_id_seq'::regclass);


--
-- Name: agro_cultures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures ALTER COLUMN id SET DEFAULT nextval('public.agro_cultures_id_seq'::regclass);


--
-- Name: agro_maladies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_maladies ALTER COLUMN id SET DEFAULT nextval('public.agro_maladies_id_seq'::regclass);


--
-- Name: agro_parametres_climatiques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques ALTER COLUMN id SET DEFAULT nextval('public.agro_parametres_climatiques_id_seq'::regclass);


--
-- Name: agro_ravageurs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_ravageurs ALTER COLUMN id SET DEFAULT nextval('public.agro_ravageurs_id_seq'::regclass);


--
-- Name: agro_recommandations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations ALTER COLUMN id SET DEFAULT nextval('public.agro_recommandations_id_seq'::regclass);


--
-- Name: agro_rendements_reference id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference ALTER COLUMN id SET DEFAULT nextval('public.agro_rendements_reference_id_seq'::regclass);


--
-- Name: agro_stades_phenologiques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques ALTER COLUMN id SET DEFAULT nextval('public.agro_stades_phenologiques_id_seq'::regclass);


--
-- Name: agro_varietes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes ALTER COLUMN id SET DEFAULT nextval('public.agro_varietes_id_seq'::regclass);


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: champ_cartographies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies ALTER COLUMN id SET DEFAULT nextval('public.champ_cartographies_id_seq'::regclass);


--
-- Name: champ_infrastructures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures ALTER COLUMN id SET DEFAULT nextval('public.champ_infrastructures_id_seq'::regclass);


--
-- Name: champ_parcelles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles ALTER COLUMN id SET DEFAULT nextval('public.champ_parcelles_id_seq'::regclass);


--
-- Name: champ_sols id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols ALTER COLUMN id SET DEFAULT nextval('public.champ_sols_id_seq'::regclass);


--
-- Name: champ_sources_eau id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau ALTER COLUMN id SET DEFAULT nextval('public.champ_sources_eau_id_seq'::regclass);


--
-- Name: credit_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger ALTER COLUMN id SET DEFAULT nextval('public.credit_ledger_id_seq'::regclass);


--
-- Name: credit_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases ALTER COLUMN id SET DEFAULT nextval('public.credit_purchases_id_seq'::regclass);


--
-- Name: farms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms ALTER COLUMN id SET DEFAULT nextval('public.farms_id_seq'::regclass);


--
-- Name: gf_activites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites ALTER COLUMN id SET DEFAULT nextval('public.gf_activites_id_seq'::regclass);


--
-- Name: gf_couts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts ALTER COLUMN id SET DEFAULT nextval('public.gf_couts_id_seq'::regclass);


--
-- Name: gf_journal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal ALTER COLUMN id SET DEFAULT nextval('public.gf_journal_id_seq'::regclass);


--
-- Name: gf_main_oeuvre id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre ALTER COLUMN id SET DEFAULT nextval('public.gf_main_oeuvre_id_seq'::regclass);


--
-- Name: gf_preuves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves ALTER COLUMN id SET DEFAULT nextval('public.gf_preuves_id_seq'::regclass);


--
-- Name: ia_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config ALTER COLUMN id SET DEFAULT nextval('public.ia_config_id_seq'::regclass);


--
-- Name: ia_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations ALTER COLUMN id SET DEFAULT nextval('public.ia_conversations_id_seq'::regclass);


--
-- Name: ia_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback ALTER COLUMN id SET DEFAULT nextval('public.ia_feedback_id_seq'::regclass);


--
-- Name: ia_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages ALTER COLUMN id SET DEFAULT nextval('public.ia_messages_id_seq'::regclass);


--
-- Name: ia_recommandations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations ALTER COLUMN id SET DEFAULT nextval('public.ia_recommandations_id_seq'::regclass);


--
-- Name: mt_alertes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes ALTER COLUMN id SET DEFAULT nextval('public.mt_alertes_id_seq'::regclass);


--
-- Name: mt_conditions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions ALTER COLUMN id SET DEFAULT nextval('public.mt_conditions_id_seq'::regclass);


--
-- Name: mt_config_alertes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes ALTER COLUMN id SET DEFAULT nextval('public.mt_config_alertes_id_seq'::regclass);


--
-- Name: mt_planificateur id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur ALTER COLUMN id SET DEFAULT nextval('public.mt_planificateur_id_seq'::regclass);


--
-- Name: mt_previsions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions ALTER COLUMN id SET DEFAULT nextval('public.mt_previsions_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: parcelles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles ALTER COLUMN id SET DEFAULT nextval('public.parcelles_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: re_declenchements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements ALTER COLUMN id SET DEFAULT nextval('public.re_declenchements_id_seq'::regclass);


--
-- Name: re_parametres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_parametres ALTER COLUMN id SET DEFAULT nextval('public.re_parametres_id_seq'::regclass);


--
-- Name: re_regles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles ALTER COLUMN id SET DEFAULT nextval('public.re_regles_id_seq'::regclass);


--
-- Name: re_regles_cultures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures ALTER COLUMN id SET DEFAULT nextval('public.re_regles_cultures_id_seq'::regclass);


--
-- Name: re_regles_entites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites ALTER COLUMN id SET DEFAULT nextval('public.re_regles_entites_id_seq'::regclass);


--
-- Name: re_sessions_evaluation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_sessions_evaluation ALTER COLUMN id SET DEFAULT nextval('public.re_sessions_evaluation_id_seq'::regclass);


--
-- Name: sc_analyse_economique id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyse_economique ALTER COLUMN id SET DEFAULT nextval('public.sc_analyse_economique_id_seq'::regclass);


--
-- Name: sc_analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyses ALTER COLUMN id SET DEFAULT nextval('public.sc_analyses_id_seq'::regclass);


--
-- Name: sc_cartes_precision id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_cartes_precision ALTER COLUMN id SET DEFAULT nextval('public.sc_cartes_precision_id_seq'::regclass);


--
-- Name: sc_consultations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations ALTER COLUMN id SET DEFAULT nextval('public.sc_consultations_id_seq'::regclass);


--
-- Name: sc_diagnostics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics ALTER COLUMN id SET DEFAULT nextval('public.sc_diagnostics_id_seq'::regclass);


--
-- Name: sc_indices_satellitaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_indices_satellitaires ALTER COLUMN id SET DEFAULT nextval('public.sc_indices_satellitaires_id_seq'::regclass);


--
-- Name: sc_observations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations ALTER COLUMN id SET DEFAULT nextval('public.sc_observations_id_seq'::regclass);


--
-- Name: sc_photos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos ALTER COLUMN id SET DEFAULT nextval('public.sc_photos_id_seq'::regclass);


--
-- Name: sc_previsions_rendement id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_previsions_rendement ALTER COLUMN id SET DEFAULT nextval('public.sc_previsions_rendement_id_seq'::regclass);


--
-- Name: sc_rapports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports ALTER COLUMN id SET DEFAULT nextval('public.sc_rapports_id_seq'::regclass);


--
-- Name: sc_suivis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis ALTER COLUMN id SET DEFAULT nextval('public.sc_suivis_id_seq'::regclass);


--
-- Name: sc_traitements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements ALTER COLUMN id SET DEFAULT nextval('public.sc_traitements_id_seq'::regclass);


--
-- Name: service_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests ALTER COLUMN id SET DEFAULT nextval('public.service_requests_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: usage_counters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters ALTER COLUMN id SET DEFAULT nextval('public.usage_counters_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: agro_besoins_eau; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_besoins_eau (id, culture_id, stade, besoin_mm_semaine, sensibilite, frequence_irrigation, notes) FROM stdin;
94	21	Tallage	70.0	elevee	Maintien lame d'eau 5 cm en continu	Tout déficit hydrique réduit le nombre de talles fertiles.
93	21	Semis / Repiquage	50.0	critique	Inondation permanente + appoint quotidien	Lame d'eau de 3-5 cm indispensable pour la reprise des plants.
95	21	Montaison / Épiaison	80.0	critique	Lame d'eau 5-8 cm, aucune interruption tolérée	Stress hydrique à ce stade peut réduire le rendement de 40-60%.
96	21	Floraison / Grain laiteux	70.0	elevee	Maintien humidité sol, lame d'eau 3-5 cm	Chaleur excessive + sécheresse cause stérilité des épillets.
97	21	Maturité / Récolte	20.0	faible	Arrêt irrigation 10-15 jours avant récolte	Assèchement contrôlé facilite la mécanisation et réduit les maladies.
98	22	Semis	25.0	critique	Apport unique avant semis pour humidifier le sol	Sol doit être humide sur 30 cm de profondeur pour assurer la germination.
99	22	Croissance végétative	40.0	moyenne	Tous les 5-7 jours en absence de pluie	La plante peut tolérer une courte sécheresse à ce stade.
100	22	Floraison	60.0	critique	Tous les 3-4 jours si pas de pluie	Manque d'eau 10 jours avant/après la floraison = réduction de 50% du rendement.
101	22	Remplissage des grains	50.0	elevee	Tous les 5 jours	Humidité nécessaire pour le remplissage ; réduire progressivement à l'approche de la maturité.
102	22	Maturité / Récolte	10.0	faible	Arrêt 2 semaines avant récolte	Sécheresse finale favorise le séchage sur pied et réduit les maladies de stockage.
103	23	Semis	20.0	critique	Sol doit être humide sur 20 cm à la mise en place	Germination requiert un sol humide ; sécheresse immédiate après semis = échec de levée.
104	23	Croissance végétative	30.0	moyenne	Tous les 7-10 jours en absence de pluie	Culture assez tolérante à ce stade ; éviter l'engorgement.
105	23	Floraison	40.0	elevee	Tous les 5-7 jours	Déficit hydrique à la floraison réduit la nouaison et la pénétration des gynophores.
106	23	Fructification / Grossissement	40.0	elevee	Tous les 5-7 jours	Humidité régulière indispensable pour le développement des gousses.
107	23	Maturité / Récolte	10.0	faible	Arrêt irrigation 2-3 semaines avant récolte	Sol trop humide à la récolte rend l'arrachage difficile et favorise les moisissures.
108	24	Semis	20.0	critique	Dépendant des pluies ; 30 mm au semis indispensables	Culture pluviale ; semer uniquement après pluies suffisantes pour éviter echec levée.
109	24	Tallage	25.0	elevee	Pluies hebdomadaires suffisantes	Période de stress peut réduire le nombre de talles fertiles.
110	24	Montaison	35.0	elevee	Pluies tous les 7-10 jours	Stress à la montaison raccourcit la panicule.
111	24	Épiaison / Floraison	40.0	critique	Pluie ou irrigation tous les 5-7 jours	Stade le plus sensible au déficit hydrique : stérilité des grains si sécheresse.
112	24	Maturité / Récolte	10.0	faible	Sécheresse de fin de saison naturelle	Sécheresse en fin de cycle assure maturation et facilite battage.
113	25	Semis	20.0	critique	Pluie ≥ 25 mm avant semis	Le sorgho est très sensible à la sécheresse à la levée ; sol doit être humide.
114	25	Tallage	30.0	elevee	Pluies tous les 7-10 jours	Tolérance à la sécheresse supérieure au maïs mais sensible au tallage.
115	25	Montaison	35.0	elevee	Pluies tous les 7 jours	Le sorgho entre en quiescence en cas de sécheresse et reprend si la pluie revient.
116	25	Floraison	45.0	critique	Irrigation tous les 5-7 jours si culture irriguée	Stade le plus sensible ; sécheresse à la floraison cause stérilité et panicules vides.
117	25	Maturité / Récolte	10.0	faible	Sécheresse naturelle en fin de saison	Excellente tolérance à la sécheresse terminale ; peut laisser mûrir sur pied.
118	26	Semis	20.0	critique	Sol humide sur 20 cm avant semis	Niébé très sensible à la sécheresse en germination.
119	26	Croissance végétative	25.0	moyenne	Tous les 7-10 jours si pas de pluie	Tolérance modérée à la sécheresse à ce stade.
120	26	Floraison	35.0	elevee	Tous les 5-7 jours	Déficit hydrique à la floraison provoque l'avortement des fleurs.
121	26	Fructification / Remplissage	30.0	elevee	Tous les 7 jours	Humidité nécessaire pour le remplissage des grains.
122	26	Maturité / Récolte	5.0	faible	Arrêt irrigation 10 jours avant récolte	Sol sec favorise la récolte et réduit les moisissures sur gousses.
123	27	Semis	15.0	critique	Sol humide sur 10 cm ; graines très sensibles à la dessiccation	Graines minuscules : une croûte de battance peut empêcher la levée.
124	27	Croissance végétative	25.0	moyenne	Tous les 7-10 jours en absence de pluie	Sésame tolère la sécheresse mais croissance ralentie.
125	27	Floraison	35.0	elevee	Tous les 5-7 jours	Avortement floral si stress hydrique à la floraison.
126	27	Fructification / Remplissage	30.0	moyenne	Tous les 7-10 jours	Excès d'eau cause la pourriture des capsules ; arrêter tôt.
127	27	Maturité / Récolte	5.0	faible	Arrêt total 2-3 semaines avant récolte	Séchage sur pied est indispensable ; pluie tardive cause perte par déhiscence.
128	28	Plantation (bouturage)	25.0	critique	Sol humide impératif les 2-3 premières semaines	Boutures ne peuvent développer des racines qu'en sol humide.
129	28	Croissance végétative	35.0	moyenne	Tous les 7-14 jours en saison sèche	Manioc supporte la sécheresse mais croissance ralentie ; pas adapté aux longues sécheresses.
130	28	Tubérisation active	40.0	elevee	Tous les 7-10 jours en saison sèche	Humidité régulière indispensable pour le remplissage des tubercules.
131	28	Maturation	20.0	faible	Tous les 14 jours, arrêt progressif	Réduction de l'eau concentre l'amidon et facilite l'arrachage.
132	28	Récolte	0.0	faible	Sol légèrement humide facilite l'arrachage	Sol trop sec rend l'arrachage difficile ; sol trop humide cause pourriture.
133	29	Pépinière	20.0	critique	2 fois/jour (matin et soir)	Sol toujours humide mais pas détrempé pour éviter la fonte des semis.
134	29	Repiquage / Reprise	35.0	critique	Tous les jours pendant 7-10 jours	Arrosage copieux immédiatement après repiquage pour favoriser la reprise racinaire.
135	29	Croissance végétative	40.0	moyenne	Tous les 2-3 jours (goutte-à-goutte idéal)	Sol maintenu humide mais non gorgé pour éviter les maladies racinaires.
136	29	Floraison	45.0	elevee	Tous les 2 jours	Stress hydrique à la floraison = chute des fleurs et avortement des fruits.
137	29	Fructification / Grossissement	55.0	elevee	Tous les 2 jours, régulier	Irrégularité d'arrosage cause la BER (nécrose apicale) et l'éclatement des fruits.
138	29	Récolte	35.0	moyenne	Tous les 3 jours	Réduire l'irrigation en fin de cycle pour améliorer la qualité gustative et la conservation.
139	30	Pépinière	25.0	elevee	2 fois/jour (matin et soir)	Sol humide en permanence ; micro-arrosage recommandé pour ne pas déchausser les semis.
140	30	Repiquage / Reprise	40.0	critique	Quotidienne les 7 premiers jours	Reprise racinaire critique ; ne pas laisser sécher le sol.
141	30	Croissance végétative	35.0	elevee	Tous les 3 jours	L'oignon a un système racinaire superficiel ; ne pas laisser le sol se dessécher.
142	30	Formation du bulbe	30.0	elevee	Tous les 3-4 jours	Apport d'eau régulier pour grossissement uniforme ; excès = bulbes mous.
143	30	Maturation / Récolte	5.0	faible	Arrêt 10-15 jours avant récolte	Assèchement contrôlé durcit les bulbes et améliore la conservation.
144	31	Pépinière	20.0	elevee	2 fois/jour	Sol humide permanent ; germination lente du piment (10-15 jours).
145	31	Repiquage / Reprise	30.0	critique	Quotidienne pendant 5-7 jours	Très sensible au stress hydrique à la reprise.
146	31	Croissance végétative	35.0	moyenne	Tous les 3-4 jours	Tolérance à la légère sécheresse en cours de cycle.
147	31	Floraison	40.0	elevee	Tous les 2-3 jours	Stress hydrique à la floraison = chute des fleurs et avortement.
148	31	Fructification et récolte	40.0	elevee	Tous les 3 jours	Réguler l'irrigation pour éviter la pourriture des fruits.
149	32	Semis	20.0	elevee	Tous les 2-3 jours	Sol humide sur 10 cm pour assurer la germination.
150	32	Croissance végétative	35.0	moyenne	Tous les 4-5 jours	Gombo est relativement tolérant à la chaleur et légère sécheresse.
151	32	Floraison et fructification	45.0	elevee	Tous les 3-4 jours	Arrosage régulier pour production continue de fruits tendres ; stress = fibrosité.
152	33	Pépinière	20.0	elevee	2 fois/jour	Substrat toujours humide sans être détrempé.
153	33	Croissance végétative	40.0	moyenne	Tous les 3 jours	Tolérant à la chaleur mais sensible à la sécheresse prolongée.
154	33	Floraison / Fructification	50.0	elevee	Tous les 2-3 jours	Régularité impérative pour éviter la chute des fleurs et la BER.
155	34	Pépinière	15.0	elevee	2 fois/jour (léger)	Humidité constante sans excès pour éviter la fonte des semis.
156	34	Croissance feuillaire	45.0	elevee	Tous les 2-3 jours	Forte demande en eau pendant la phase de croissance feuillaire.
157	34	Formation de la pomme	50.0	critique	Tous les 2 jours	Manque d'eau = pomme petite et peu dense ; excès = pourriture.
158	34	Récolte	20.0	faible	Tous les 5 jours	Réduire l'irrigation avant récolte pour éviter l'éclatement des pommes.
159	35	Semis	20.0	critique	Tous les 2 jours	Sol humide sur 15 cm pour assurer la germination.
160	35	Croissance végétative	35.0	moyenne	Tous les 3 jours	Éviter l'engorgement qui favorise les maladies racinaires.
161	35	Floraison	45.0	elevee	Tous les 2 jours	Stress hydrique à la floraison = avortement et fruits amers.
162	35	Fructification / Récolte	55.0	elevee	Tous les 2 jours, régulier	Régularité cruciale ; variations d'humidité = fruits tordus ou amers.
163	36	Semis	20.0	elevee	Tous les 2-3 jours	Sol humide pour germination ; sécheresse immédiate = échec.
164	36	Croissance végétative	35.0	moyenne	Tous les 4-5 jours	Pastèque tolère mieux la sécheresse que concombre ou tomate.
165	36	Floraison	45.0	elevee	Tous les 3 jours	Manque d'eau = avortement des fruits.
166	36	Grossissement des fruits	55.0	elevee	Tous les 3 jours, puis réduire	Besoins importants pendant le grossissement ; réduire 10 jours avant récolte.
167	36	Maturité / Récolte	15.0	faible	Arrêt 7-10 jours avant récolte	Réduction de l'arrosage améliore le sucre et réduit les risques d'éclatement.
168	37	Floraison	10.0	critique	Stress hydrique intentionnel 4-6 semaines avant floraison souhaitée	Le manque d'eau en novembre-décembre induit la floraison ; arroser uniquement si sécheresse sévère.
169	37	Nouaison	20.0	elevee	Irrigation légère tous les 7-10 jours si pas de pluie	Pluie à la floraison = anthracnose sévère ; préférer les périodes sèches.
170	37	Croissance des fruits	35.0	elevee	Tous les 7 jours en mars-avril (saison sèche)	Déficit hydrique en mars-avril = chute prématurée des fruits.
171	37	Maturité / Récolte	15.0	faible	Réduire l'irrigation 2-3 semaines avant récolte	Concentration des sucres améliorée par légère réduction de l'eau.
172	37	Post-récolte / Entretien	30.0	faible	Pluies d'hivernage suffisantes ; irrigation d'appoint si nécessaire	Saison des pluies couvre la majorité des besoins post-récolte.
173	38	Floraison	5.0	critique	Aucune irrigation (saison sèche) ; naturellement adapté	L'anacarde fleurit en saison sèche naturellement ; pluie à la floraison = anthracnose.
174	38	Nouaison	15.0	elevee	Aucune irrigation en production normale	Stress hydrique modéré toléré ; culture résistante à la sécheresse.
175	38	Maturité / Récolte	20.0	faible	Pluies de fin de saison sèche suffisent	Récolte de mars à mai ; les premières pluies favorisent le grossissement final.
176	38	Post-récolte / Entretien	40.0	faible	Pluies d'hivernage (juin-septembre) suffisantes	Croissance végétative pendant l'hivernage grâce aux pluies.
177	39	Plantation / Levée	40.0	critique	Quotidienne les 2 premières semaines	Enracinement critique ; ne jamais laisser sécher le sol.
178	39	Croissance végétative	60.0	elevee	Tous les 2-3 jours (goutte-à-goutte recommandé)	Banane a les besoins en eau les plus élevés des cultures fruitières au Sénégal.
179	39	Floraison / Formation du régime	70.0	critique	Tous les 2 jours	Manque d'eau à ce stade réduit la taille et le nombre de mains.
180	39	Maturité / Récolte	50.0	elevee	Tous les 3 jours	Maintenir l'irrigation jusqu'à la récolte.
181	40	Pépinière	20.0	elevee	2 fois/jour (modéré)	Très sensible à l'engorgement ; sol humide mais jamais détrempé.
182	40	Croissance végétative	50.0	elevee	Tous les 2-3 jours au goutte-à-goutte	Papaye est exigeante en eau mais INTOLERANTE à l'engorgement = mort du plant.
183	40	Floraison / Fructification	60.0	critique	Tous les 2 jours	Stress hydrique = chute des fruits ; excès = Pythium et pourriture du collet.
184	40	Récolte continue	55.0	elevee	Tous les 2-3 jours toute l'année	Maintenir l'irrigation constante pour une production continue.
\.


--
-- Data for Name: agro_besoins_nutritionnels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_besoins_nutritionnels (id, culture_id, stade, azote_kg_ha, phosphore_kg_ha, potassium_kg_ha, calcium_kg_ha, magnesium_kg_ha, engrais_recommandes, moment_application, notes) FROM stdin;
61	21	total	120.0	30.0	60.0	20.0	10.0	Urée 46% (260 kg/ha), DAP (65 kg/ha), KCl (100 kg/ha)	DAP au semis/repiquage ; Urée en 3 fractions (reprise, tallage actif, épiaison)	Fractionnement obligatoire de l'azote pour limiter les pertes par volatilisation.
62	21	Tallage	40.0	0.0	30.0	0.0	0.0	Urée 46% (87 kg/ha), KCl (50 kg/ha)	À 21-25 jours après repiquage, en début de tallage actif	Application sur sol inondé ; incorporer légèrement pour éviter les pertes.
63	21	Épiaison	40.0	0.0	0.0	0.0	0.0	Urée 46% (87 kg/ha)	10 jours avant épiaison visible (gonflement de la panicule)	Azote panicule critique pour le remplissage des grains et la qualité.
95	32	Croissance végétative	40.0	40.0	40.0	10.0	5.0	NPK 15-15-15 (150 kg/ha)	À J25-30 en couverture autour des plants	Une seule application de NPK suffit pour la phase végétative.
64	22	total	100.0	46.0	60.0	25.0	12.0	DAP (100 kg/ha au semis), Urée 46% (220 kg/ha en 2 fractions), KCl (100 kg/ha)	DAP au semis ; urée 1/2 à V4, 1/2 avant montaison ; KCl au semis	Maïs est très exigeant en azote ; le fractionnement est impératif pour éviter la verse.
65	22	Semis	0.0	46.0	60.0	0.0	0.0	DAP (100 kg/ha) + KCl (100 kg/ha) en fond de poquet	Au moment du semis, en fond de poquet à 5 cm sous la graine	Ne pas mettre l'engrais en contact direct avec la graine (brûlure).
66	22	Croissance végétative (V4)	50.0	0.0	0.0	0.0	0.0	Urée 46% (109 kg/ha)	Stade V4 (4 feuilles bien développées), en couronne autour du plant	Arroser après application pour dissolution et absorption rapide.
67	23	total	20.0	30.0	50.0	30.0	8.0	Phosphate de Thiès (250 kg/ha) ou DAP (65 kg/ha), gypse (100 kg/ha), KCl (80 kg/ha)	Phosphate et gypse au semis ; azote symbolique uniquement si pas d'inoculant	Légumineuse : fixe 80-150 kg N/ha via symbiose ; éviter l'azote minéral qui inhibe la fixation.
68	23	Semis	0.0	30.0	50.0	20.0	0.0	Phosphate de Thiès (250 kg/ha) + KCl (80 kg/ha) + inoculant Rhizobium	En fond de poquet au semis ; inoculant sur la graine avant semis	Le phosphore est l'élément limitant le plus important pour l'arachide au Sénégal.
69	23	Fructification	0.0	0.0	0.0	10.0	0.0	Gypse (CaSO4) 100 kg/ha	Au début de la pénétration des gynophores (J50-60)	Calcium indispensable pour la formation des gousses et la prévention des grains vides.
70	24	total	60.0	20.0	30.0	10.0	5.0	DAP (45 kg/ha) + Urée 46% (130 kg/ha)	DAP au semis ; urée en 2 fractions (démariage J15, tallage J30)	Mil est relativement peu exigeant ; éviter excès d'azote qui favorise la verse.
71	24	Semis	0.0	20.0	15.0	0.0	0.0	DAP (45 kg/ha) ou Phosphate de Thiès (150 kg/ha)	Au semis, enfoui dans le poquet	Le phosphore de Thiès est moins soluble mais moins onéreux ; efficace sur sols acides.
72	24	Tallage	60.0	0.0	15.0	0.0	0.0	Urée 46% (130 kg/ha) en 2 apports	1er apport à J15 après levée, 2e à J30 au tallage actif	Appliquer en couronne à 5-10 cm des plants après une pluie ou irrigation.
73	25	total	80.0	25.0	40.0	15.0	8.0	DAP (55 kg/ha) + Urée 46% (175 kg/ha) + KCl (65 kg/ha)	DAP et KCl au semis ; urée en 2 fractions (J20, J45)	Sorgho plus tolérant que le maïs aux sols pauvres ; la fumure organique est très valorisée.
74	25	Semis	0.0	25.0	40.0	0.0	0.0	DAP (55 kg/ha) ou Phosphate de Thiès (200 kg/ha) + KCl (65 kg/ha)	En fond de poquet au semis	La fumure de fond est essentielle ; le sorgho valorise bien le phosphate naturel de Thiès.
75	25	Tallage actif	80.0	0.0	0.0	0.0	0.0	Urée 46% (175 kg/ha) en 2 apports égaux	1er apport J20 après levée, 2e à J40-45	Appliquer en couronne après pluie ou irrigation pour éviter la volatilisation.
76	26	total	15.0	20.0	30.0	15.0	5.0	Phosphate de Thiès (200 kg/ha) ou DAP (45 kg/ha) + inoculant Rhizobium	Phosphore au semis ; pas d'azote minéral (fixation biologique suffisante)	Légumineuse fixant 50-100 kg N/ha ; l'azote minéral est contre-indiqué.
77	26	Semis	0.0	20.0	30.0	0.0	0.0	DAP (45 kg/ha) + KCl (50 kg/ha) en fond de poquet + inoculant	Au semis, engrais déposé sous la graine	Le phosphore est l'élément limitant le plus fréquent pour le niébé au Sénégal.
78	26	Floraison	0.0	0.0	0.0	15.0	0.0	Pas d'engrais minéral ; surveiller carence en molybdène (Mo)	Application foliaire de molybdate d'ammonium 50 g/ha si carence	La carence en Mo inhibe la fixation d'azote ; important en sols acides.
79	27	total	30.0	15.0	20.0	10.0	5.0	DAP (33 kg/ha) + Urée 46% (65 kg/ha) + KCl (33 kg/ha)	DAP et KCl au semis (fond) ; urée en 1 apport à J20-25	Sésame est peu exigeant en engrais ; excès d'azote favorise la végétation au détriment des graines.
80	27	Semis	0.0	15.0	20.0	0.0	0.0	DAP (33 kg/ha) + KCl (33 kg/ha) incorporés au sol avant semis	Incorporation légère (5 cm) avant semis pour ne pas brûler les graines	Sésame est sensible à la salinité ; ne pas dépasser les doses recommandées.
81	27	Croissance végétative (J20-25)	30.0	0.0	0.0	0.0	0.0	Urée 46% (65 kg/ha)	En couronne à 5-8 cm des plants, après pluie ou irrigation	Apport unique d'azote ; ne pas dépasser pour éviter la verse.
82	28	total	80.0	40.0	120.0	30.0	15.0	NPK 15-15-15 (270 kg/ha) + KCl (170 kg/ha) + Urée 46% (110 kg/ha)	NPK à J30 (plantation) ; KCl et urée complémentaires à J90	Manioc est très exigeant en potassium (K) qui est l'élément le plus exporté par les tubercules.
83	28	Plantation (J30-45)	40.0	40.0	60.0	0.0	0.0	NPK 15-15-15 (270 kg/ha)	À J30-45 après plantation, en couronne à 15-20 cm des plants	Premier apport de fond ; ne pas fertiliser avant J30 pour éviter de brûler les racines naissantes.
84	28	Tubérisation (J90)	40.0	0.0	60.0	0.0	0.0	Urée 46% (87 kg/ha) + KCl (100 kg/ha)	À J90, début de la tubérisation active	Le potassium est critique pour la qualité et le rendement des tubercules.
85	29	total	150.0	60.0	200.0	80.0	25.0	NPK 15-15-15 (300 kg/ha), Urée (200 kg/ha), KNO3 (200 kg/ha), CaNO3 (100 kg/ha)	NPK à la plantation ; Urée en couverture J20 et J40 ; KNO3 à la floraison	Tomate est très exigeante en K et Ca. Carence en Ca = BER (nécrose apicale).
86	29	Plantation	20.0	60.0	50.0	30.0	8.0	DAP (130 kg/ha) + KCl (80 kg/ha) en fond de trou	Au moment du repiquage, dans le trou de plantation	Ne pas mettre en contact direct avec les racines.
87	29	Floraison / Fructification	60.0	0.0	120.0	40.0	10.0	KNO3 (200 kg/ha) + CaNO3 (100 kg/ha) en fertirrigation	En plusieurs fractions à la floraison et au grossissement des fruits	Potassium élevé améliore la coloration, la fermeté et la durée de conservation.
88	30	total	120.0	50.0	120.0	30.0	15.0	NPK 15-15-15 (200 kg/ha), Urée (200 kg/ha), KCl (100 kg/ha)	NPK au repiquage ; Urée à J70 et J90 ; KCl à la formation du bulbe	Réduire l'azote après J100 pour ne pas retarder la bulbification.
89	30	Repiquage	30.0	50.0	30.0	10.0	5.0	NPK 15-15-15 (200 kg/ha)	En fond de billon au moment du repiquage	Base indispensable pour assurer la reprise et la croissance initiale.
90	30	Formation du bulbe	0.0	0.0	60.0	10.0	5.0	KCl (100 kg/ha) en couverture	À J100-110 au début de formation visible du bulbe	Potassium améliore la grosseur, la fermeté et la conservation des bulbes.
91	31	total	100.0	50.0	120.0	40.0	15.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha), KNO3 (150 kg/ha)	NPK à la plantation, Urée à J60, KNO3 à la fructification	Potassium essentiel pour la qualité et la piquant des fruits.
92	31	Plantation	15.0	50.0	30.0	15.0	5.0	DAP (110 kg/ha) + KCl (50 kg/ha)	En fond de trou au moment de la plantation	Phosphore indispensable pour l'enracinement.
93	31	Fructification	30.0	0.0	60.0	15.0	5.0	KNO3 (150 kg/ha) en fertigation	En début de fructification (J85-95)	K et Ca réduisent la chute prématurée des fruits.
94	32	total	80.0	40.0	80.0	20.0	10.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha)	NPK à J30, Urée à J55 en couverture	Gombo est peu exigeant en fertilisation si sol bien préparé avec compost.
96	32	Fructification	30.0	0.0	30.0	5.0	3.0	Urée (65 kg/ha) + KCl (50 kg/ha)	Au début de la fructification (J55) pour prolonger la production	Maintenir la nutrition pour éviter le vieillissement prématuré des plants.
97	33	total	120.0	50.0	130.0	40.0	15.0	NPK 15-15-15 (150 kg/ha), Urée (150 kg/ha), KCl (100 kg/ha)	NPK à la plantation ; Urée à J60 et J90 ; KCl à la fructification	Exigeante en K et Ca comme toutes les solanacées.
98	33	Plantation	20.0	50.0	40.0	15.0	5.0	DAP (110 kg/ha) + KCl (65 kg/ha)	En fond de trou au repiquage	Phosphore pour l'enracinement.
99	33	Fructification	40.0	0.0	60.0	15.0	5.0	Urée (90 kg/ha) + KCl (100 kg/ha)	À J85-95 pour soutenir la fructification continue	Potassium améliore la qualité et la fermeté des fruits.
100	34	total	150.0	60.0	150.0	50.0	20.0	NPK 15-15-15 (200 kg/ha), Urée (220 kg/ha), KCl (100 kg/ha)	NPK à la plantation ; Urée à J45 et J65 ; KCl à J65	Chou est très exigeant en azote et calcium. Carence Ca = brûlures internes (tipburn).
101	34	Plantation	30.0	60.0	50.0	20.0	8.0	NPK 15-15-15 (200 kg/ha) + compost (5 t/ha)	En fond de planche avant repiquage	Compost améliore la structure du sol et la rétention en eau.
102	34	Formation de la pomme	50.0	0.0	80.0	20.0	8.0	Urée (110 kg/ha) + KCl (130 kg/ha) + CaO folaire	À J60-65, début de formation de la pomme	Potassium améliore la densité de la pomme et la durée de conservation.
103	35	total	100.0	50.0	100.0	30.0	12.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha), KCl (80 kg/ha)	NPK à J15 ; Urée à J35 ; KCl à J55	Cucurbitacée peu exigeante mais répondant bien aux apports équilibrés.
104	35	Semis / Croissance	20.0	50.0	30.0	10.0	4.0	NPK 15-15-15 (150 kg/ha)	À J15 en couronne autour des plants	Application précoce pour soutenir la croissance végétative rapide.
105	35	Fructification	30.0	0.0	50.0	10.0	4.0	Urée (65 kg/ha) + KCl (80 kg/ha)	À J50-55 pour soutenir la fructification	Potassium améliore la qualité et réduit l'amertume des fruits.
106	36	total	100.0	60.0	150.0	30.0	15.0	NPK 15-15-15 (200 kg/ha), Urée (100 kg/ha), KCl (130 kg/ha)	NPK au semis ; Urée à J40 ; KCl à J60 pour le sucre	Potassium élevé est essentiel pour la teneur en sucre et la qualité des fruits.
107	36	Semis / Levée	20.0	60.0	50.0	10.0	5.0	NPK 15-15-15 (200 kg/ha) en fond de poquet	Au moment du semis, sous la graine	Base phosphorée pour l'enracinement et le développement initial.
108	36	Grossissement	30.0	0.0	80.0	10.0	5.0	Urée (65 kg/ha) + KCl (130 kg/ha)	À J55-60, début de grossissement rapide des fruits	Apport de K à ce stade = meilleur goût, meilleure conservation.
109	37	total	100.0	40.0	120.0	30.0	20.0	NPK 15-15-15 (500 g/arbre) + KCl (200 g/arbre) + compost (10 kg/arbre)	NPK après la récolte (août) + KCl en janvier pour la floraison	Fertilisation par arbre, pas par hectare. Densité typique : 100-200 arbres/ha.
110	37	Post-récolte (floraison suivante)	60.0	40.0	60.0	15.0	10.0	NPK 15-15-15 (500 g/arbre) + compost (10 kg/arbre) en août-septembre	Après la récolte, pendant la saison des pluies pour bonne absorption	Réserves nutritionnelles construites ici seront mobilisées à la floraison.
111	37	Induction florale	0.0	0.0	40.0	5.0	5.0	KNO3 folaire (2%) + micronutriments en janvier	Application foliaire 2-4 semaines avant floraison souhaitée	KNO3 folaire stimule l'induction florale et améliore la nouaison.
112	38	total	60.0	25.0	80.0	15.0	10.0	NPK 15-15-15 (200 g/arbre) + compost (5 kg/arbre)	En début de saison des pluies (juillet) pour l'absorption maximale	Anacarde peu exigeant en intrants ; sols pauvres tolérés. Éviter excès d'azote.
113	38	Jeune plantation (0-3 ans)	30.0	25.0	30.0	10.0	5.0	NPK 15-15-15 (100 g/plant) + compost (3 kg/plant)	En juillet-août chaque année pendant les 3 premières années	Jeunes plants ont besoin d'un appui en phosphore pour l'enracinement.
114	38	Arbre adulte en production	30.0	0.0	50.0	5.0	5.0	KCl (100 g/arbre) + urée (50 g/arbre) en juillet	Après la récolte, début saison des pluies	Potassium améliore la taille et la qualité des noix.
115	39	total	300.0	60.0	600.0	80.0	40.0	Urée (650 kg/ha/an), DAP (130 kg/ha), KCl (1000 kg/ha/an), compost (20 t/ha)	Fractionné tous les 2 mois ; K est l'élément le plus limitant	Banane est de loin la culture la plus exigeante en potassium. KCl obligatoire.
116	39	Croissance végétative (mensuel)	25.0	5.0	50.0	7.0	3.0	Urée (55 g/plant) + KCl (120 g/plant) par mois	Application mensuelle en ceinture à 50 cm du plant	Fractionnement mensuel obligatoire pour la banane (sol sableux = lixiviation).
117	39	Montaison / Floraison	30.0	0.0	80.0	10.0	5.0	KCl (200 g/plant) + CaNO3 (50 g/plant) à la montaison	Dès le gonflement du cœur (montaison imminente)	Apport de K à ce stade améliore directement le poids du régime.
118	40	total	200.0	80.0	250.0	60.0	30.0	Urée (435 kg/ha/an), DAP (175 kg/ha), KCl (415 kg/ha/an)	Fractionné tous les 2 mois ; K indispensable pour le sucre des fruits	Forte exigence en K et Ca. Fertilisation régulière = production continue.
119	40	Plantation	30.0	80.0	50.0	15.0	8.0	DAP (175 kg/ha) + compost (10 kg/plant) en fond de trou	Au moment de la plantation dans le trou préparé	Phosphore crucial pour l'enracinement rapide après transplantation.
120	40	Fructification (mensuel)	15.0	0.0	20.0	5.0	2.0	Urée (35 g/plant) + KCl (50 g/plant) par mois	Application mensuelle en ceinture à 50 cm du tronc	Maintenir la fertilisation mensuelle pour production continue.
\.


--
-- Data for Name: agro_calendriers_culturaux; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_calendriers_culturaux (id, culture_id, zone_agro, saison, mois_semis_debut, mois_semis_fin, mois_recolte_debut, mois_recolte_fin, remarques) FROM stdin;
69	21	vallee_fleuve	hivernage	7	8	10	11	Culture irriguée ; pépinière en juillet, repiquage août, récolte octobre-novembre.
70	21	vallee_fleuve	contre_saison	1	2	5	6	Deuxième cycle irrigué (saison chaude) ; rendements souvent inférieurs à cause de la chaleur.
71	21	casamance	hivernage	6	7	10	11	Riz pluvial en bas-fonds ; risque de sécheresse en début de cycle.
72	21	senegal_oriental	hivernage	6	7	10	11	Bas-fonds aménagés ; variétés pluviales tolérantes à la sécheresse recommandées.
73	22	bassin_arachidier	hivernage	6	7	9	10	Principal bassin de production ; semis dès premières pluies (60 mm cumulés).
74	22	casamance	hivernage	6	7	10	11	Pluviométrie abondante favorable ; risque de maladies fongiques à surveiller.
75	22	vallee_fleuve	contre_saison	11	1	3	4	Culture irriguée en contre-saison froide ; températures favorables pour le maïs.
76	22	senegal_oriental	hivernage	6	7	10	11	Zone à forte pluviométrie ; bon potentiel de rendement avec intrants.
77	23	bassin_arachidier	hivernage	6	7	9	10	Cœur de la campagne arachidière ; GOANA en juin-juillet avec les premières pluies (30-40 mm).
78	23	zone_sylvopastorale	hivernage	7	7	10	10	Variétés hâtives obligatoires (55-437, Fleur 11) compte tenu de la courte saison des pluies.
79	23	casamance	hivernage	6	7	10	11	Pluviométrie favorable ; variétés semi-tardives à haut rendement possibles.
80	23	senegal_oriental	hivernage	6	7	10	11	Bon potentiel ; risque de cercosporiose lié à l'humidité prolongée.
81	24	bassin_arachidier	hivernage	6	7	9	10	Première culture semée après les pluies ; variétés hâtives pour zone centrale.
82	24	zone_sylvopastorale	hivernage	7	7	10	10	Saison courte ; variétés très hâtives (Souna 3, <85 jours) indispensables.
83	24	casamance	hivernage	6	7	10	11	Variétés Sanio locales tardives possibles grâce à la pluviométrie suffisante.
84	24	senegal_oriental	hivernage	6	7	10	10	Conditions favorables ; compétition avec le sorgho et le maïs pour les terres.
85	25	bassin_arachidier	hivernage	6	7	10	11	En association avec mil ou niébé ; semis après mil en début de saison.
86	25	senegal_oriental	hivernage	6	7	10	11	Zone à fort potentiel ; sorgho en rotation avec maïs ou coton.
87	25	casamance	hivernage	6	7	11	12	Variétés photopériodiques locales à cycle long ; récolte en décembre.
88	25	zone_sylvopastorale	hivernage	7	7	10	11	Variétés hâtives impératives ; sorgho concurrent du mil dans cette zone.
89	26	bassin_arachidier	hivernage	7	8	9	10	Cultivé en rotation ou en association avec l'arachide et le mil.
90	26	niayes	contre_saison	2	4	5	6	Culture irriguée de contre-saison chaude ; marché de légumes frais.
91	26	casamance	hivernage	7	8	10	11	Bon potentiel en Casamance ; associé avec sorgho ou maïs.
92	26	senegal_oriental	hivernage	7	8	10	11	Niébé en fin de rotation après céréales pour régénérer l'azote du sol.
93	27	bassin_arachidier	hivernage	7	8	10	11	Semis après l'arachide ou en rotation ; attendre sol stable après premières pluies.
94	27	senegal_oriental	hivernage	7	8	10	11	Zone en expansion pour le sésame d'export ; bonne adaptation aux sols sableux.
95	27	casamance	hivernage	7	8	10	11	Risque de maladies fongiques élevé en Casamance ; variétés semi-indéhiscentes recommandées.
96	27	zone_sylvopastorale	hivernage	7	7	10	10	Variétés hâtives obligatoires (90 jours) compte tenu de la courte saison pluvieuse.
97	28	casamance	hivernage	5	7	1	4	Plantation dès premières pluies (mai-juin) ; récolte 9-12 mois après en saison sèche.
98	28	senegal_oriental	hivernage	6	7	3	5	Bon potentiel dans les zones humides du Sénégal Oriental ; cycle 10-12 mois.
99	28	niayes	contre_saison	11	1	9	11	Culture irriguée dans les Niayes ; cycle 10 mois avec irrigation régulière.
100	28	bassin_arachidier	hivernage	6	7	3	6	Zone marginale pour le manioc ; variétés tolérantes à la sécheresse (Bocou 1) seulement.
101	29	niayes	saison_seche	10	12	1	4	Principale saison de production ; températures fraîches favorables, faible pression maladies.
102	29	niayes	contre_saison	8	9	11	12	Fin d'hivernage ; forte pression Tuta absoluta et TYLCV. Variétés résistantes obligatoires.
103	29	vallee_fleuve	saison_seche	10	11	1	3	Culture irriguée en saison fraîche ; bons rendements avec intrants.
104	29	casamance	saison_seche	11	12	2	4	Humidité résiduelle favorable ; réduire les fongicides en saison fraîche.
105	30	vallee_fleuve	saison_seche	9	10	2	4	Principale zone de production irriguée ; récolte en saison chaude favorable au séchage.
106	30	niayes	saison_seche	10	11	3	5	Températures fraîches favorables à la bulbification ; humidité à surveiller (mildiou).
107	30	bassin_arachidier	saison_seche	10	11	3	4	Cultivation en contre-saison avec irrigation ; potentiel de développement important.
108	31	niayes	saison_seche	10	11	2	5	Principale saison ; températures favorables, faible pression maladie.
109	31	casamance	hivernage	6	7	10	12	Culture pluviale possible en Casamance ; variétés locales bien adaptées.
110	31	vallee_fleuve	saison_seche	10	11	2	5	Culture irriguée prometteuse ; production hors saison en expansion.
111	32	vallee_fleuve	saison_seche	10	12	1	4	Culture irriguée très profitable ; peu de maladies en saison fraîche.
112	32	bassin_arachidier	hivernage	6	7	8	11	Semis dès les premières pluies ; bonne production sans irrigation.
113	32	niayes	saison_seche	11	1	2	5	Bonne période de production pour l'approvisionnement de Dakar.
114	32	casamance	hivernage	5	7	8	11	Excellent gombo en Casamance avec pluviométrie naturelle ; variétés locales recommandées.
115	33	niayes	saison_seche	9	11	12	4	Principale saison ; températures optimales pour la fructification.
116	33	casamance	hivernage	5	6	8	12	Culture pluviale possible ; forte production en saison humide.
117	33	vallee_fleuve	saison_seche	10	11	1	4	Culture irriguée prometteuse ; développement en cours.
118	34	niayes	saison_seche	10	12	1	4	Saison idéale ; températures fraîches favorables à la pommaison.
119	34	vallee_fleuve	saison_seche	10	11	1	3	Culture irriguée possible ; choisir des variétés tolérantes à la chaleur.
120	35	niayes	saison_seche	10	12	12	3	Saison principale ; faible pression maladies, températures adaptées.
121	35	vallee_fleuve	saison_seche	10	11	12	2	Culture irriguée rentable ; cycle court de 60-70 jours.
122	35	casamance	saison_seche	11	12	1	3	Humidité résiduelle bénéfique ; surveiller mildiou.
123	36	vallee_fleuve	saison_seche	11	2	2	5	Zone principale ; culture irriguée de saison fraîche-chaude.
124	36	niayes	saison_seche	11	1	2	4	Production pour le marché de Dakar ; bonne rentabilité.
125	36	bassin_arachidier	hivernage	7	8	10	11	Culture pluviale possible ; rendements inférieurs mais peu d'intrants.
126	37	casamance	saison_seche	12	2	5	7	Floraison de décembre à février ; récolte mai-juillet selon variété.
127	37	senegal_oriental	saison_seche	12	2	5	7	Zone à haut potentiel ; Amélie dès avril, Kent et Keitt en juin-juillet.
128	37	bassin_arachidier	saison_seche	1	2	4	6	Zone marginale pour la mangue ; variétés hâtives (Amélie) recommandées.
129	38	casamance	saison_seche	11	1	3	5	Principale zone (Ziguinchor, Sédhiou) ; floraison nov-jan, récolte mars-mai.
130	38	senegal_oriental	saison_seche	11	1	3	5	Zone en développement ; Kédougou et Tambacounda à fort potentiel.
131	39	niayes	saison_seche	4	6	2	5	Plantation en avril-juin ; récolte 9-12 mois après avec irrigation permanente.
132	39	casamance	hivernage	6	8	4	7	Plantation en hivernage profite des pluies ; irrigation en saison sèche.
133	39	vallee_fleuve	saison_seche	3	5	1	4	Culture irriguée toute l'année possible ; températures chaudes favorables.
134	40	niayes	saison_seche	10	12	7	12	Plantation en pépinière oct-déc ; récolte continue 9-12 mois après.
135	40	casamance	hivernage	5	7	2	7	Plantation en début d'hivernage ; pluies assurent la croissance initiale.
136	40	vallee_fleuve	saison_seche	9	11	6	11	Culture irriguée toute l'année ; températures chaudes favorables à la croissance.
\.


--
-- Data for Name: agro_culture_maladies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_culture_maladies (id, culture_id, maladie_id, frequence, gravite, stade_sensible, pertes_estimees, prevention, traitement) FROM stdin;
131	38	125	frequente	moyenne	Floraison	15-35%	Soufre préventif avant floraison, bonne aération	Soufre mouillable (Thiovit) 3 kg/ha ou Triadiménol 0,5 kg/ha
67	21	66	tres_frequente	elevee	Tallage et épiaison	20-50% en cas d'épidémie sur panicule	Variétés résistantes (Sahel 108), semis non trop dense, éviter excès d'azote	Tricyclazole (Beam 75WP) 0,6 kg/ha ou Propiconazole (Tilt 250EC) 0,5 L/ha
68	21	67	frequente	moyenne	Tallage à maturité	10-30% si non traité	Semences saines, fumure équilibrée, rotation	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Chlorothalonil 1,5 L/ha
69	21	68	occasionnelle	elevee	Tallage à épiaison	Jusqu'à 50% dans les foyers	Variétés résistantes, plants sains, éviter les blessures	Aucun traitement curatif ; éliminer les plants malades, cuivre préventif
70	21	69	occasionnelle	moyenne	Floraison	5-15% des grains affectés	Semences traitées, rotation, variétés tolérantes	Traitement semences au thirame (Thiram 75WS) 3 g/kg de semences
71	21	70	tres_frequente	elevee	Tallage à épiaison	10-30% en riziculture intensive	Densité modérée, équilibre de la fumure azotée, variétés tolérantes	Azoxystrobine (Amistar 250SC) 0,5 L/ha ou Hexaconazole 0,5 L/ha dès apparition des lésions
72	22	71	frequente	moyenne	Floraison à remplissage des grains	10-30% selon l'intensité	Variétés résistantes, rotation, élimination des résidus de culture	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
73	22	72	frequente	elevee	Remplissage des grains	Jusqu'à 30% + risque toxicologique pour la consommation humaine	Variétés tolérantes, récolte à bonne maturité, séchage rapide	Fongicides au semis (thirame) ; gestion post-récolte (séchage < 14%)
74	22	73	frequente	elevee	Levée à V6	20-80% selon la précocité de l'infection	Semis précoce, variétés résistantes (MSV-R), lutte contre les cicadelles	Pas de traitement curatif ; insecticide sur cicadelles : Lambdacyhalothrine 0,5 L/ha
75	22	74	occasionnelle	moyenne	Floraison	5-20% en foyers	Rotation, élimination des galles avant éclatement, semences saines	Traitement semences au carboxine-thirame ; pas de traitement curatif efficace
76	23	75	tres_frequente	elevee	Croissance végétative à fructification	20-50% de défoliation possible	Rotation cultures, variétés tolérantes, ne pas recycler les semences malades	Chlorothalonil (Bravo 500SC) 1,5 L/ha ou Mancozèbe (Dithane M-45) 2 kg/ha tous les 14 jours
77	23	76	frequente	elevee	Levée à V30	Jusqu'à 100% en cas d'épidémie précoce	Semis précoce groupé, variétés résistantes (RMP 12, Brewer), contrôle des pucerons	Pas de traitement curatif ; insecticide contre pucerons : Imidaclopride (Confidor) 0,3 L/ha
78	23	77	frequente	moyenne	Floraison à fructification	10-25%	Variétés résistantes, rotation, élimination des résidus	Triadiménol (Bayleton 25WP) 0,5 kg/ha ou Propiconazole (Tilt 250EC) 0,5 L/ha
79	23	78	frequente	elevee	Fructification à stockage	5-30% + rejet à l'export pour cause d'aflatoxines	Récolte à temps, séchage rapide sous 14% humidité, stockage hermétique	Biocontrôle : Aflasafe (Aspergillus flavus non-toxigène) ; séchage rapide obligatoire
80	24	79	tres_frequente	elevee	Levée à montaison	30-80% en cas d'épidémie	Variétés résistantes (IBV 8004, ICMV IS 89305), traitement semences au métalaxyl	Métalaxyl (Ridomil 25WP) 2 g/kg semences ; pas de traitement foliaire curatif efficace
81	24	80	frequente	moyenne	Floraison	5-20% des épis	Rotation culturale, semences saines certifiées, éviter de recycler les semences	Traitement semences au carboxine-thirame ou Thiram 75WS (3 g/kg)
82	24	81	occasionnelle	moyenne	Floraison	5-15%	Variétés à floraison courte, semis précoce	Pas de traitement curatif ; retirer les scléroties à la main ; thirame préventif
83	24	82	occasionnelle	faible	Montaison à maturité	5-10%	Variétés tolérantes, rotation	Mancozèbe (Dithane M-45) 2 kg/ha si attaque sévère
84	25	83	tres_frequente	elevee	Tallage à maturité	20-50% en zone humide	Variétés résistantes, rotation, élimination des résidus	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
85	25	84	frequente	moyenne	Floraison	10-30% des épis	Semences certifiées, rotation, élimination des épis atteints	Traitement semences : carboxine (Vitavax 200WP) 3 g/kg ou thirame 75WS 3 g/kg
86	25	85	occasionnelle	moyenne	Levée à montaison	10-30%	Variétés résistantes, traitement semences au métalaxyl	Métalaxyl (Ridomil 25WP) 2 g/kg semences en traitement préventif
87	25	86	frequente	moyenne	Montaison à remplissage	10-25%	Rotation, élimination résidus, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha si attaque précoce
88	26	87	frequente	moyenne	Levée à V10	10-25% à la levée	Sol bien drainé, éviter l'excès d'eau, rotation	Traitement semences au thirame 75WS (3 g/kg) + métalaxyl
89	26	88	frequente	moyenne	Floraison à fructification	10-20%	Variétés tolérantes, rotation, espacement suffisant	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil 1,5 L/ha
90	26	89	frequente	elevee	Croissance végétative	20-60% selon précocité	Variétés résistantes, contrôle des pucerons, semis précoce	Insecticides contre pucerons : Imidaclopride (Confidor) 0,3 L/ha
91	26	90	occasionnelle	moyenne	Fructification	10-30%	Semences saines, rotation de 3 ans	Mancozèbe (Dithane M-45) 2 kg/ha dès apparition des symptômes
92	27	91	frequente	elevee	Croissance végétative à floraison	20-50% en foyers	Rotation 3-4 ans, sol bien drainé, pH > 6, variétés tolérantes (NRCSS 2001)	Pas de traitement curatif ; Trichoderma spp. en biocontrôle préventif
93	27	92	frequente	moyenne	Fructification à maturité	10-25%	Rotation, espacement suffisant, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
94	27	93	occasionnelle	elevee	Tout le cycle	10-40% en sols hydromorphes	Drainage impératif, billonnage, éviter les bas-fonds	Métalaxyl (Ridomil 25WP) 2 g/kg semences ; améliorer le drainage
95	28	94	tres_frequente	elevee	Tout le cycle (infection précoce plus grave)	30-80% selon précocité et variété	Boutures certifiées saines (TME 419, TMS 30572 résistantes), lutte contre mouche blanche	Pas de traitement curatif ; arracher et bruler les plants très atteints ; insecticides contre B. tabaci
96	28	95	frequente	elevee	Croissance végétative en saison humide	20-50% en épidémie	Boutures saines, rotation, variétés résistantes, éviter les blessures	Pas de traitement curatif efficace ; cuivre (Bouillie bordelaise) préventif 0,5%
97	28	96	occasionnelle	elevee	Tubérisation à récolte	20-60% en sols hydromorphes	Drainage impératif, billonnage, ne pas cultiver en bas-fond	Métalaxyl (Ridomil 25WP) en préventif ; améliorer le drainage
98	28	97	frequente	faible	Croissance végétative	5-15%	Espacement suffisant, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha si attaque sévère
99	29	98	tres_frequente	elevee	Croissance végétative à fructification	50-100% si non traité en conditions favorables	Variétés résistantes, éviter mouillage des feuilles, désherbage, rotation	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha ou Chlorothalonil 1,5 L/ha tous les 7-10 jours
100	29	99	frequente	moyenne	Floraison à récolte	10-30%	Rotation, élimination feuilles malades, bonne aération	Azoxystrobine (Amistar 250SC) 1 L/ha ou Iprodione (Rovral 50WP) 1,5 kg/ha
101	29	100	tres_frequente	elevee	Tous stades, surtout levée à floraison	Jusqu'à 100% sur variétés sensibles	Variétés résistantes (Mongal F1, Power Ranger), filets anti-insectes en pépinière	Pas de traitement curatif ; contrôler la mouche blanche : Imidaclopride 0,3 L/ha
102	29	101	frequente	elevee	Croissance végétative	20-80% selon l'infestation du sol	Rotation 3-4 ans, variétés résistantes (F), solarisation du sol	Fongicide sol Thiophanate-méthyl (Pelt 44SC) 2 L/ha ; solarisation en préventif
103	29	102	tres_frequente	elevee	Tout le cycle	30-100% en sols infestés	Rotation 3-4 ans avec céréales ou manioc, solarisation, drainage, chaulage du sol (pH >6,5), pépinière saine	Pas de traitement curatif efficace ; arracher et brûler immédiatement les plants malades ; désinfecter les outils
104	30	103	frequente	elevee	Croissance végétative	20-50%	Éviter mouillage des feuilles, espacement suffisant, variétés tolérantes	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha hebdomadaire
105	30	104	frequente	elevee	Maturité et stockage	20-50% en stockage humide	Séchage soigneux post-récolte, manipulation douce, stockage sec et ventilé	Iprodione (Rovral 50WP) 1,5 kg/ha en préventif ; séchage rigoureux en curatif
106	30	105	frequente	moyenne	Pépinière	30-80% en pépinière si non traité	Substrat sain et drainé, ne pas surirriguer, solarisation du sol de pépinière	Metalaxyl-M (Ridomil Gold 480SL) 0,5 L/ha en arrosage du pied
107	31	106	tres_frequente	elevee	Fructification	20-50% des fruits	Variétés résistantes, ne pas blesser les fruits, rotation	Azoxystrobine (Amistar 250SC) 1 L/ha ou Mancozèbe 2 kg/ha hebdomadaire
108	31	107	frequente	elevee	Tout le cycle	30-70% en cas d'engorgement	Billons surélevés, drainage, rotation, compost	Metalaxyl (Ridomil 72WP) 2 kg/ha en arrosage du pied
109	31	108	frequente	moyenne	Tous stades	15-40%	Semences saines, lutte contre pucerons, éliminer plants malades	Pas de traitement curatif ; insecticide contre pucerons : Imidaclopride 0,3 L/ha
110	31	102	frequente	elevee	Tout le cycle	20-70% en sols infestés	Rotation 3-4 ans avec céréales, solarisation, chaulage du sol	Pas de traitement curatif ; arracher et brûler les plants malades immédiatement
111	32	109	frequente	elevee	Croissance végétative	20-50%	Rotation 3-4 ans, variétés résistantes (Parbhani Kranti), solarisation	Thiophanate-méthyl 2 L/ha en arrosage ; pas de traitement curatif efficace
112	32	110	frequente	elevee	Tous stades	30-70%	Variétés résistantes (Parbhani Kranti), lutte contre aleurodes	Pas de traitement curatif ; insecticide aleurodes : Imidaclopride 0,3 L/ha
113	32	111	occasionnelle	moyenne	Levée	10-40% en conditions défavorables	Semis sur billons surélevés, ne pas surirriguer, rotation	Metalaxyl + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha en arrosage préventif
114	33	112	frequente	elevee	Croissance végétative	20-60% en sols infestés	Rotation 3-4 ans avec céréales, solarisation, variétés tolérantes	Pas de traitement curatif ; prévention par solarisation 6-8 semaines
115	33	99	frequente	moyenne	Floraison à récolte	15-30%	Rotation, bonne aération, retirer feuilles basses malades	Azoxystrobine (Amistar) 1 L/ha ou Mancozèbe 2,5 kg/ha hebdomadaire
116	33	102	frequente	elevee	Croissance végétative à fructification	20-60% en sols infestés	Rotation avec céréales, solarisation, drainage, pépinière sur substrat sain	Pas de traitement curatif ; arracher et brûler les plants malades
117	34	113	tres_frequente	elevee	Croissance feuillaire à formation de la pomme	20-50%	Rotation, aération, éviter mouillage des feuilles	Iprodione (Rovral 50WP) 1,5 kg/ha ou Azoxystrobine 1 L/ha hebdomadaire
118	34	114	occasionnelle	elevee	Repiquage à croissance végétative	50-100% en sols infestés	Rotation longue (5-7 ans), chaulage pour pH > 7.2, drainage	Chaulage préventif (2-3 t/ha de chaux) ; carbendazime au repiquage
119	34	115	frequente	elevee	Croissance à pommaison	20-60%	Semences saines, rotation, éviter blessures, ne pas arroser sur les feuilles	Cuivre (Kocide 101) 3 kg/ha préventif ; pas de traitement curatif
120	35	116	tres_frequente	elevee	Croissance végétative à fructification	30-80%	Variétés tolérantes, éviter mouillage des feuilles, rotation	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha hebdomadaire
121	35	117	frequente	moyenne	Fructification	15-30%	Variétés résistantes (Poinsett 76), bonne aération	Triadiménol (Bayleton 25WP) 0,5 kg/ha ou soufre mouillable 3 kg/ha
122	35	118	frequente	moyenne	Fructification	20-40%	Rotation, semences saines, drainage	Mancozèbe 2,5 kg/ha ou Azoxystrobine 1 L/ha
123	36	119	frequente	elevee	Croissance végétative	20-60% en sols infestés	Rotation 4-5 ans, greffage sur porte-greffe résistant (Cucurbita), solarisation	Thiophanate-méthyl en arrosage ; greffage préventif recommandé
124	36	118	frequente	moyenne	Fructification à maturité	15-35%	Variétés résistantes (Charleston Grey), rotation, drainage	Mancozèbe 2,5 kg/ha ou Azoxystrobine 1 L/ha hebdomadaire
125	36	116	frequente	moyenne	Croissance végétative	20-40%	Variétés tolérantes, espacement, éviter mouillage des feuilles	Ridomil Gold MZ 2,5 kg/ha hebdomadaire
126	37	120	tres_frequente	elevee	Floraison et récolte	20-60% en saison humide	Taille pour aérer le houppier, ne pas irriguer sur les fleurs	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Carbendazime 0,5 kg/ha sur les panicules
127	37	121	tres_frequente	elevee	Floraison	30-80% sur fleurs si épidémie	Taille, aération, soufre préventif avant floraison	Soufre mouillable (Thiovit) 3 kg/ha ou Triadiménol 0,5 kg/ha sur les panicules
128	37	122	occasionnelle	moyenne	Croissance végétative	10-20%	Taille des rameaux malades, cuivre préventif en début de saison des pluies	Cuivre (Kocide 101) 3 kg/ha en pulvérisation ; pas de traitement curatif
129	37	123	tres_frequente	elevee	Toute l'année (pic en saison sèche)	10-40% de perte de production sur arbres adultes ; mort de jeunes plants	Taille sanitaire avec outils désinfectés (hypochlorite 10%), badigeonnage des plaies au mastic fongicide, irrigation en saison sèche	Couper et brûler les rameaux atteints jusqu'au bois sain ; badigeonner les plaies au Carbendazime 0,5% ; pulvérisation de Thiophanate-méthyl 0,5 kg/ha
130	38	124	tres_frequente	elevee	Floraison et nouaison	20-50%	Variétés tolérantes, taille pour aérer, cuivre préventif	Mancozèbe (Dithane M-45) 2,5 kg/ha sur les panicules dès leur apparition
132	38	123	tres_frequente	elevee	Toute l'année (pic fin saison sèche)	15-50% de panicules perdues dans les vergers non entretenus	Taille sanitaire avec désinfection des outils, badigeon au mastic fongicide, gestion de l'Hélopelte vecteur de blessures	Couper et brûler les rameaux malades dès détection ; badigeonner les plaies au Carbendazime ; Thiophanate-méthyl en pulvérisation
133	39	126	frequente	elevee	Tout le cycle	50-100% en sol infesté (race Tropical 4)	Utiliser des vitroplants certifiés, éviter les blessures racinaires, rotation longue	Pas de traitement curatif ; prévention stricte et variétés résistantes obligatoires
134	39	127	tres_frequente	elevee	Tout le cycle	20-50% en l'absence de traitement	Variétés tolérantes, effeuillage préventif des feuilles malades	Propiconazole (Tilt 250EC) 0,5 L/ha ou Carbendazime 0,5 kg/ha tous les 21 jours
135	39	128	frequente	moyenne	Post-récolte	10-30% des fruits	Manipulation soigneuse, emballage protecteur, froid	Bain post-récolte : thiabendazole 0,1% ou eau chaude 52°C pendant 30 sec
136	40	129	tres_frequente	elevee	Tous stades	50-100% sur variétés sensibles	Variétés résistantes (Red Lady F1, Tainung 1), lutte contre pucerons, pépinière protégée	Pas de traitement curatif ; détruire les plants malades ; insecticide contre pucerons
137	40	130	tres_frequente	elevee	Maturité et post-récolte	20-50% en conditions humides	Manipulation soigneuse, emballage protecteur	Bain post-récolte : thiabendazole ou eau chaude (52°C, 20 min) + Mancozèbe en champ
138	40	131	frequente	elevee	Plantation à croissance végétative	30-80% en cas d'inondation	Billons de 30-40 cm, sol très bien drainé, ne jamais planter en bas-fond	Metalaxyl (Ridomil Gold 480SL) 0,5 L/ha en arrosage du pied
\.


--
-- Data for Name: agro_culture_ravageurs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_culture_ravageurs (id, culture_id, ravageur_id, frequence, gravite, stade_sensible, pertes_estimees, prevention, lutte) FROM stdin;
59	21	54	tres_frequente	elevee	Tallage et épiaison	15-40% si non contrôlé	Variétés résistantes, élimination des chaumes après récolte, plants sains	Carbofuran (Furadan 3G) 25 kg/ha en granulés ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
60	21	55	tres_frequente	elevee	Floraison à maturité	30-100% en cas d'invasion	Surveillance, semis groupés pour noyer les dégâts, effarouchement collectif	Effarouchement sonore, filets, guet permanent ; traitement avicide (Queletox) uniquement sur autorisation DGPV
61	21	56	frequente	moyenne	Tallage	10-25%	Drainage temporaire, éviter l'excès d'azote	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Chlorpyrifos-éthyl 1 L/ha
62	21	57	occasionnelle	moyenne	Repiquage à tallage	10-20% en sols infestés	Rotation avec légumineuses, sols bien inondés (réduit les nématodes)	Inondation prolongée avant repiquage ; Carbofuran 3G si forte infestation
63	22	58	tres_frequente	elevee	Levée à V8	20-70% si non traité	Semis précoce, surveillance dès la levée, pièges à phéromones	Emamectin benzoate (Emacot 1.9EC) 0,75 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dans le cornet
64	22	59	frequente	elevee	V4 à floraison	15-40%	Semis précoce, rotation, destruction des résidus de maïs	Carbofuran granulés dans le cornet ou Lambdacyhalothrine 0,5 L/ha en début d'infestation
65	22	60	frequente	elevee	Levée à V6	Dommages indirects via MSV : 20-80%	Variétés résistantes au virus, semis en période moins favorable aux cicadelles	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès apparition des symptômes
66	23	61	tres_frequente	elevee	Levée à floraison	Dommages directs 5-10% + indirects via rosette jusqu'à 100%	Semis précoce, variétés résistantes, rotation	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
67	23	62	frequente	elevee	Tout le cycle	10-30% en sols très infestés	Labour profond, élimination des souches d'arbres, rotation	Chlorpyrifos-éthyl (Dursban 480EC) 2 L/ha en pulvérisation sur le sol avant semis
68	23	63	occasionnelle	moyenne	Fructification	5-20% en foyers	Labour profond pour exposer les larves aux prédateurs, rotation	Carbofuran (Furadan 3G) 25 kg/ha incorporé au sol ; insecticide de sol
69	24	55	tres_frequente	elevee	Épiaison à maturité	30-100% dans les zones d'invasion	Surveillance DGPV, semis groupés, alertes précoces, effarouchement collectif	Effarouchement sonore continu ; traitement avicide (Queletox) uniquement sur autorisation DGPV
70	24	64	tres_frequente	elevee	Tout le cycle	20-80% dans les zones infestées	Variétés résistantes, rotation légumineuses, semences exemptes de Striga	Herbicide Imazapyr (Strigaway) sur semences traitées ; arrachage manuel avant fructification du Striga
71	24	65	frequente	moyenne	Tallage à épiaison	10-30%	Semis précoce, élimination des résidus de culture, variétés résistantes	Décis (Deltaméthrine 2,5EC) 0,5 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
72	25	66	tres_frequente	elevee	Tallage à montaison	15-40%	Semis précoce, destruction des résidus, rotation	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Décis (Deltaméthrine 2,5EC) 0,5 L/ha
73	25	67	occasionnelle	moyenne	Montaison	5-15%	Variétés tolérantes, semis précoce	Chlorpyrifos-éthyl (Dursban 480EC) 1 L/ha ou huile minérale en pulvérisation
74	25	55	tres_frequente	elevee	Floraison à maturité	30-100% en zone d'invasion	Surveillance, semis groupés, effarouchement collectif	Effarouchement continu (6h-19h) ; signalement DGPV pour intervention avicide si nécessaire
75	25	68	tres_frequente	elevee	Floraison (anthèse)	30-50% en zone sahélienne, jusqu'à 100% localement	Semis précoce ou tardif pour décaler la floraison du pic d'adultes, variétés à panicules compactes	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès début épiaison ; surveiller les fleurets à l'anthèse
76	25	69	frequente	elevee	Floraison à maturité	10-30% selon niveau d'infestation	Surveillance des pontes (œufs ronds jaunes sur feuilles), pièges à phéromones sexuelles	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha ; rotation des matières actives
77	26	70	tres_frequente	elevee	Stockage	50-100% des grains en 3 mois si non traité	Séchage à <12% humidité, sacs hermétiques (GrainPro), récolte à sec	Pirimiphos-méthyl (Actellic 2% dust) 2 g/kg ou huile de neem 5 mL/kg ; stockage hermétique
78	26	71	tres_frequente	elevee	Floraison	30-70% des rendements en grains	Semis précoce pour décaler la floraison des pics de thrips	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès apparition ; Décis (Deltaméthrine) 0,5 L/ha
79	26	61	frequente	elevee	Levée à floraison	Dommages directs + indirects via virus : 20-80%	Variétés résistantes, semis précoce, lutte chimique précoce	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine 0,5 L/ha
80	26	72	tres_frequente	elevee	Fructification à maturité	20-50%	Semis précoce, récolte rapide dès maturité, plantes-pièges (sésame)	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Deltaméthrine (Décis 2,5EC) 0,5 L/ha en début fructification
81	26	69	frequente	elevee	Floraison à maturité	10-25%	Surveillance des pontes, pièges à phéromones	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha
82	27	73	frequente	elevee	Floraison à fructification	15-40%	Semis précoce, élimination des résidus, rotation	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Décis (Deltaméthrine 2,5EC) 0,5 L/ha
83	27	74	frequente	moyenne	Croissance végétative à floraison	10-20%	Semis précoce, rotation, prédateurs naturels	Imidaclopride (Confidor 200SL) 0,3 L/ha ou savon insecticide
84	27	75	occasionnelle	moyenne	Croissance végétative en saison sèche	5-15%	Irrigation régulière (acariens prolifèrent en sécheresse), prédateurs	Acaricide : Abamectine (Vertimec 1,8EC) 0,75 L/ha ; huile de neem 5 L/ha
85	28	76	tres_frequente	elevee	Croissance végétative (saison sèche)	20-80% en saison sèche sans lutte biologique	Boutures saines, lutte biologique (Anagyrus lopezi), variétés tolérantes	Parasitoïde Anagyrus lopezi (lutte biologique prioritaire) ; Lambdacyhalothrine 0,5 L/ha si urgence
86	28	77	tres_frequente	elevee	Tout le cycle	Dommages indirects via mosaïque : 30-80%	Variétés résistantes à la mosaïque, boutures saines	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine 0,5 L/ha
87	28	78	frequente	elevee	Croissance végétative en saison sèche	15-40% en saison sèche	Variétés tolérantes (TME 419), prédateurs naturels (Typhlodromalus aripo)	Soufre mouillable 3 kg/ha ou Abamectine (Vertimec 1,8EC) 0,75 L/ha
88	28	62	frequente	moyenne	Plantation à tubérisation	5-20% en sols très infestés	Labour profond, rotation, éviter sols très sableux et secs	Chlorpyrifos-éthyl (Dursban 480EC) 2 L/ha incorporé avant plantation
89	29	79	tres_frequente	elevee	Tous stades	50-100% sans gestion	Pièges à phéromones, filets anti-insectes, surveillance quotidienne	Emamectin benzoate (Proclaim 5WG) 0,3 kg/ha, rotation Chlorantraniliprole (Coragen) 0,25 L/ha
90	29	77	tres_frequente	elevee	Pépinière à floraison	30-100% via virus TYLCV	Filets anti-insectes en pépinière, pièges jaunes englués	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Spiromesifen (Oberon SC) 0,5 L/ha
91	29	80	frequente	moyenne	Floraison	10-30%	Pièges bleus collants, rotation insecticides	Spinosad (Success 480SC) 0,25 L/ha ou Abamectine (Dynamec 1.8EC) 0,5 L/ha
92	29	69	frequente	elevee	Fructification	20-40%	Pièges à phéromones sexuelles (1/ha), surveillance des pontes sur feuilles	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha ; rotation des matières actives
93	30	81	tres_frequente	elevee	Croissance végétative à formation du bulbe	20-40%	Pièges bleus collants, espacement suffisant, éviter stress hydrique	Spinosad (Success 480SC) 0,25 L/ha ou Abamectine 0,5 L/ha ; alterner les matières actives
94	30	82	occasionnelle	moyenne	Repiquage à croissance végétative	5-20% en zones infestées	Rotation, pièges jaunes, bâches blanches répulsives	Chlorpyrifos-éthyl (Dursban 480EC) 1 L/ha en traitement sol au repiquage
95	30	83	frequente	moyenne	Tout le cycle	15-30% en sols très infestés	Rotation avec céréales, solarisation du sol, compost de qualité	Carbofuran (Furadan 3G) 20 kg/ha ou Nématicide biologique (Purpureocillium lilacinum)
96	31	84	tres_frequente	elevee	Floraison	15-30%	Pièges bleus, rotation insecticides	Spinosad (Success) 0,25 L/ha ou Abamectine 0,5 L/ha tous les 7 jours
97	31	75	frequente	moyenne	Croissance à fructification	15-25%	Éviter la sécheresse, favoriser les acariens prédateurs (Phytoseiidae)	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Spiromesifen 0,75 L/ha
98	31	85	frequente	elevee	Pépinière à floraison	10-50% (virus)	Filets anti-insectes en pépinière, pièges jaunes	Imidaclopride (Confidor) 0,3 L/ha ou Pyméthrozine (Chess 50WG) 0,2 kg/ha
99	31	69	frequente	elevee	Fructification	10-30%	Pièges à phéromones, surveillance des pontes	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha
100	32	86	tres_frequente	moyenne	Tous stades	10-25%	Variétés à pilosité foliaire (Clemson Spineless), bonne nutrition	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Dimethoate 1 L/ha
101	32	74	frequente	moyenne	Levée à floraison	10-20%	Favoriser les prédateurs naturels (coccinelles, chrysopes)	Imidaclopride (Confidor) 0,3 L/ha ; insecticides biologiques à base de pyrèthre naturel
102	32	87	frequente	moyenne	Fructification	10-30%	Plantes pièges (sorgho), inspection régulière des fruits	Lambdacyhalothrine (Karaté) 0,5 L/ha en début de fructification
103	33	88	tres_frequente	elevee	Fructification	30-70%	Récolte fréquente, filets insect-proof, pièges à phéromones	Emamectin benzoate (Proclaim 5WG) 0,3 kg/ha ou Chlorantraniliprole 0,25 L/ha
104	33	75	frequente	moyenne	Croissance à fructification	15-25%	Irrigation régulière, favoriser la faune auxiliaire	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Spiromesifen 0,75 L/ha
105	33	74	frequente	moyenne	Tous stades	10-25%	Pièges jaunes, favoriser auxiliaires naturels	Imidaclopride (Confidor) 0,3 L/ha ou pyrèthre naturel en bio
106	34	89	tres_frequente	elevee	Tous stades	30-80% sans gestion	Filets anti-insectes, pièges à phéromones, Bacillus thuringiensis	Bt (Biobit/Dipel) 1 kg/ha ou Emamectin benzoate 0,3 kg/ha ; rotation impérative
107	34	90	frequente	moyenne	Croissance végétative	15-25%	Pièges jaunes, favoriser auxiliaires (coccinelles)	Imidaclopride (Confidor) 0,3 L/ha ou pyréthrine naturelle
108	35	91	tres_frequente	elevee	Fructification	30-70%	Pièges à protéine (attractif), ramassage fruits tombés	Appâts protéinés + Malathion ; Spinosad (Success) 0,25 L/ha sur les pièges
109	35	74	frequente	elevee	Tous stades	15-50% via virus	Pièges jaunes, favoriser auxiliaires	Imidaclopride (Confidor) 0,3 L/ha ou pyrèthre naturel
110	36	91	tres_frequente	elevee	Grossissement des fruits	30-70%	Pièges à protéine (1/500 m²), ramassage fruits tombés	Pièges protéine + Spinosad 0,25 L/ha ; récolter à maturité optimale
111	36	74	frequente	moyenne	Croissance végétative à floraison	10-30%	Pièges jaunes, rotation des cultures	Imidaclopride 0,3 L/ha ou savon insecticide en bio
112	36	75	frequente	moyenne	Croissance à fructification	15-25%	Irrigation régulière, ne pas stresser les plants	Abamectine (Dynamec 1.8EC) 0,5 L/ha
113	37	92	tres_frequente	elevee	Maturité et récolte	30-80% sans gestion ; cause principale de rejet à l'export	Pièges McPhail avec attractif protéiné (1/ha), ramassage fruits tombés	Appâts Spinosad (GF120) + protéine hydrolysée ; Malathion 50EC 1,5 L/ha en dernier recours
114	37	93	frequente	moyenne	Croissance des fruits	10-30%	Favoriser les parasitoïdes naturels (Gyranusoidea tebygi)	Huile minérale (Volck oil) 1,5 L/ha ou Imidaclopride systémique 0,5 L/ha
115	37	94	frequente	elevee	Floraison	30-60% des fleurs	Surveillance dès l'apparition des panicules	Lambdacyhalothrine (Karaté) 0,5 L/ha dès sortie des panicules
116	38	95	tres_frequente	elevee	Floraison et nouaison	30-70% des panicules en forte infestation	Surveillance dès la sortie des panicules, plantation de haies répulsives	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Chlorpyrifos 1 L/ha dès apparition
117	38	96	frequente	moyenne	Croissance des fruits	10-25%	Favoriser les parasitoïdes naturels (Leptomastix dactylopii)	Huile minérale 2% ou Imidaclopride 0,5 L/ha en systémique
118	39	97	tres_frequente	elevee	Tout le cycle	20-50% de perte de vigueur ; mort des plants en forte infestation	Utiliser des rejets propres (éliminer les tissus infectés), pièges à phéromones	Pièges-billots (morceaux de pseudo-tronc attractifs) + Chlorpyrifos 2% sur les pièges
119	39	98	tres_frequente	elevee	Tout le cycle	20-40% en sols infestés	Vitroplants certifiés, rotation, solarisation	Nématicide biologique (Purpureocillium lilacinum) ou Carbofuran (Furadan 3G) 50 kg/ha
120	40	99	tres_frequente	elevee	Maturité / Récolte	20-60%	Pièges McPhail avec attractif, ramassage fruits tombés quotidien	Appâts Spinosad + protéine ; Malathion 50EC 1,5 L/ha en dernier recours
121	40	100	tres_frequente	elevee	Tous stades	50-100% via PRSV	Filets anti-insectes en pépinière, variétés résistantes au PRSV	Imidaclopride (Confidor) 0,3 L/ha ou Pyméthrozine (Chess 50WG) 0,2 kg/ha
122	40	75	frequente	moyenne	Croissance végétative	10-20%	Irrigation régulière ; ne pas stresser les plants	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Soufre mouillable 3 kg/ha
\.


--
-- Data for Name: agro_cultures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_cultures (id, nom, nom_scientifique, nom_local, famille, categorie, icone, description, actif, created_at) FROM stdin;
21	Riz	Oryza sativa L.	Maaro (wolof)	Poaceae	grandes_cultures	🌾	Céréale de base cultivée en irrigué dans la Vallée du Fleuve Sénégal et en pluvial en Casamance. Culture stratégique pour la sécurité alimentaire nationale.	t	2026-06-09 10:15:40.754788
22	Maïs	Zea mays L.	Maïs (wolof: maïs)	Poaceae	grandes_cultures	🌽	Céréale à forte productivité cultivée en hivernage dans tout le Sénégal et en contre-saison irriguée dans la Vallée du Fleuve. Aliment de base et fourrage.	t	2026-06-09 10:15:40.821905
23	Arachide	Arachis hypogaea L.	Gerte (wolof)	Fabaceae	grandes_cultures	🥜	Légumineuse oléagineuse, principale culture de rente du Sénégal. Cultivée dans le Bassin Arachidier, fixe l'azote atmosphérique et enrichit les sols.	t	2026-06-09 10:15:40.857658
24	Mil	Pennisetum glaucum (L.) R.Br.	Souna / Sanio (wolof)	Poaceae	grandes_cultures	🌾	Céréale de sécurité alimentaire par excellence au Sénégal, particulièrement adaptée aux zones semi-arides. Base alimentaire des populations rurales (thiéré, couscous, bouillie).	t	2026-06-09 10:15:40.888183
25	Sorgho	Sorghum bicolor (L.) Moench	Gawri (wolof)	Poaceae	grandes_cultures	🌾	Céréale très résistante à la sécheresse, cultivée dans tout le Sénégal. Aliment de base, fourrage et matière première pour la bière traditionnelle (dolo).	t	2026-06-09 10:15:40.916252
26	Niébé	Vigna unguiculata (L.) Walp.	Niébé (wolof: thiaw)	Fabaceae	grandes_cultures	🫘	Légumineuse polyvalente cultivée pour ses grains (protéines) et ses fanes (fourrage). Culture importante pour la sécurité nutritionnelle et l'amélioration de la fertilité des sols au Sénégal.	t	2026-06-09 10:15:40.949795
27	Sésame	Sesamum indicum L.	Bénéfin / Bissap blanc (wolof: bénéfin)	Pedaliaceae	grandes_cultures	🌱	Oléagineuse rustique à haute valeur commerciale, en forte expansion au Sénégal grâce à la demande à l'export. Culture adaptée aux zones semi-arides et peu exigeante en intrants.	t	2026-06-09 10:15:40.985026
28	Manioc	Manihot esculenta Crantz	Maaniog (wolof)	Euphorbiaceae	grandes_cultures	🌿	Tubercule vivrier de sécurité alimentaire cultivé principalement en Casamance et au Sénégal Oriental. Culture rustique à cycle long, productrice de féculents et de feuilles consommées comme légume.	t	2026-06-09 10:15:41.012745
29	Tomate	Solanum lycopersicum L.	Tomaat (wolof)	Solanaceae	maraichage	🍅	Légume-fruit le plus produit et consommé au Sénégal. Cultivée principalement dans les Niayes et la Vallée du Fleuve. Double usage : consommation fraîche et transformation (concentré, purée). Exportée vers l'Europe depuis les Niayes.	t	2026-06-09 10:15:41.045595
30	Oignon	Allium cepa L.	Seef (wolof)	Alliaceae	maraichage	🧅	Principal légume bulbeux du Sénégal. Produit massivement dans la Vallée du Fleuve (Podor, Dagana, Saint-Louis) et les Niayes. Enjeu national : forte dépendance aux imports hollandais malgré la production locale en plein essor.	t	2026-06-09 10:15:41.082808
31	Piment	Capsicum frutescens L.	Kaani (wolof)	Solanaceae	maraichage	🌶️	Condiment incontournable de la cuisine sénégalaise. Cultivé dans les Niayes, la Casamance et autour des grandes villes. Production fraîche et séchée pour export.	t	2026-06-09 10:15:41.124822
32	Gombo	Abelmoschus esculentus (L.) Moench	Kanja (wolof)	Malvaceae	maraichage	🌿	Légume incontournable de la cuisine sénégalaise (sauces, soupes). Cultivé partout au Sénégal, résistant à la chaleur. Culture facile avec débouchés garantis sur les marchés locaux.	t	2026-06-09 10:15:41.165574
33	Aubergine	Solanum melongena L.	Jaxatu (wolof)	Solanaceae	maraichage	🍆	Légume incontournable de la cuisine sénégalaise (thiéboudienne, mafé). Cultivée toute l'année dans les Niayes et en Casamance. Marché local solide avec demande constante.	t	2026-06-09 10:15:41.190074
34	Chou	Brassica oleracea var. capitata L.	Chou (wolof: chou)	Brassicaceae	maraichage	🥬	Culture maraîchère des Niayes et de la Vallée du Fleuve. Production saisonnière pour les marchés urbains de Dakar et Saint-Louis. Forte sensibilité aux fortes chaleurs ; culture de saison fraîche.	t	2026-06-09 10:15:41.208412
35	Concombre	Cucumis sativus L.	Concombre (wolof)	Cucurbitaceae	maraichage	🥒	Cucurbitacée à croissance rapide cultivée dans les Niayes et la Vallée du Fleuve. Cycle court de 60-75 jours ; rentable pour les maraichers. Marché local en croissance avec consommation fraîche et salade.	t	2026-06-09 10:15:41.228781
36	Pastèque	Citrullus lanatus (Thunb.) Matsum. & Nakai	Faas (wolof)	Cucurbitaceae	maraichage	🍉	Cucurbitacée très appréciée au Sénégal, cultivée en saison chaude. Tolère mieux la chaleur et la sécheresse que les autres cucurbitacées. Marchés locaux et export vers l'Europe depuis la Vallée du Fleuve.	t	2026-06-09 10:15:41.247917
37	Mangue	Mangifera indica L.	Mangoro (wolof)	Anacardiaceae	arboriculture	🥭	Principal fruit d'exportation du Sénégal. Cultivée en Casamance, au Sénégal Oriental et dans les Niayes. Exportée vers l'Europe (Kent, Keitt) de mai à juillet. Culture stratégique pour les revenus des producteurs.	t	2026-06-09 10:15:41.267523
38	Anacarde	Anacardium occidentale L.	Fondé (wolof) / Caju (diola)	Anacardiaceae	arboriculture	🌰	Deuxième culture d'exportation du Sénégal après l'arachide. Cultivé principalement en Casamance et au Sénégal Oriental. Noix de cajou exportée brute vers l'Inde et le Vietnam. Fort potentiel de transformation locale (ITA Dakar).	t	2026-06-09 10:15:41.292226
39	Banane	Musa spp. (groupe AAA)	Banana (wolof)	Musaceae	arboriculture	🍌	Fruit tropical cultivé dans les Niayes (Thiès, Mbour), la Casamance et la Vallée du Fleuve. Production principalement destinée au marché local dakarois. Forte demande avec marché intérieur à développer.	t	2026-06-09 10:15:41.312895
40	Papaye	Carica papaya L.	Papay (wolof)	Caricaceae	arboriculture	🍈	Fruit tropical à croissance rapide cultivé dans les Niayes, la Casamance et la Vallée du Fleuve. Production toute l'année avec plantation de vitroplants. Marché local en forte demande ; potentiel export (papaye verte pour transformation).	t	2026-06-09 10:15:41.334103
\.


--
-- Data for Name: agro_maladies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_maladies (id, nom, nom_scientifique, pathogene_type, symptomes, conditions_favorables, created_at) FROM stdin;
66	Pyriculariose	Pyricularia oryzae	fongique	Taches losangiques gris-brunâtres sur feuilles avec halo jaune ; attaque possible sur cou de panicule (cassure).	Humidité > 90%, températures 20-28°C, excès d'azote, forte rosée nocturne.	2026-06-09 10:15:40.771543
67	Helminthosporiose	Cochliobolus miyabeanus (Helminthosporium oryzae)	fongique	Taches ovales brun-chocolat avec halo jaune sur feuilles ; brunissement des grains.	Températures 25-30°C, forte humidité, sols pauvres en silice.	2026-06-09 10:15:40.788762
68	Bactériose du riz (Flétrissement bactérien)	Xanthomonas oryzae pv. oryzae	bacterien	Jaunissement et flétrissement des feuilles en partant du bord ; liséré ondulé blanc-jaune.	Chaleur, humidité élevée, blessures aux feuilles lors du repiquage.	2026-06-09 10:15:40.792777
69	Charbon des balles	Tilletia barclayana	fongique	Grains transformés en masse de spores noires ; contamination à la floraison.	Humidité élevée à la floraison, températures fraîches.	2026-06-09 10:15:40.795449
70	Rhizoctoniose du riz (gaine)	Rhizoctonia solani (AG1-IA)	fongique	Lésions elliptiques brun-grisâtres sur la gaine foliaire ; pont mycélien entre plants en cours de saison humide.	Chaleur (28-32°C), humidité élevée, forte densité de semis, excès d'azote.	2026-06-09 10:15:40.798234
71	Helminthosporiose du maïs	Exserohilum turcicum	fongique	Grandes taches nécrotiques allongées, brun-grisâtres, sur les feuilles basses puis remontant.	Humidité élevée, températures 20-25°C, rosée prolongée.	2026-06-09 10:15:40.830375
72	Fusariose de l'épi	Fusarium moniliforme / F. graminearum	fongique	Grains roses/blancs avec mycélium cotonneux sur l'épi ; production de fumonisines (mycotoxines).	Chaleur et humidité lors du remplissage, blessures d'insectes.	2026-06-09 10:15:40.838232
73	Striure du maïs	Maize streak virus (MSV)	viral	Stries jaune-vert sur les feuilles, rabougrissement des plants, épis peu garnis.	Présence de cicadelles (Cicadulina mbila) vecteurs, saison sèche.	2026-06-09 10:15:40.841062
74	Charbon commun du maïs	Ustilago maydis	fongique	Galles blanches puis noires (spores) sur les épis, les tiges ou les feuilles.	Températures chaudes (25-30°C), blessures mécaniques.	2026-06-09 10:15:40.843545
75	Cercosporiose (tache de la feuille)	Cercospora arachidicola / Cercosporidium personatum	fongique	Taches circulaires brun-rouge sur feuilles (cercospora précoce) ou taches noires (tardive) causant la défoliation.	Humidité > 80%, températures 25-30°C, densité excessive.	2026-06-09 10:15:40.864112
76	Rosette de l'arachide	Groundnut rosette virus (GRV)	viral	Nanisme des plants, chlorose en mosaïque ou verte, feuilles petites, pas de gousse.	Présence du puceron Aphis craccivora vecteur ; début de saison des pluies.	2026-06-09 10:15:40.87171
77	Rouille de l'arachide	Puccinia arachidis	fongique	Pustules orangées sur la face inférieure des feuilles, taches jaunes en face supérieure.	Humidité élevée, températures 20-28°C.	2026-06-09 10:15:40.874076
78	Pourriture des gousses	Aspergillus flavus (aflatoxines)	fongique	Moisissure verte-jaunâtre sur les gousses ; production d'aflatoxines cancérigènes.	Sécheresse en fin de cycle, température > 30°C, insectes dans le sol.	2026-06-09 10:15:40.876742
79	Mildiou du mil	Sclerospora graminicola	fongique	Chlorose des feuilles, sporulation blanche sur face inférieure, déformation des épis (virescence), nanisme.	Humidité > 85%, températures 25-30°C, sols lourds mal drainés.	2026-06-09 10:15:40.894527
80	Charbon du mil	Moesziomyces penicillariae	fongique	Grains transformés en masses de spores noires, épis inutilisables.	Semences infectées, humidité à la floraison.	2026-06-09 10:15:40.901316
81	Ergot du mil (Maladie du miel)	Claviceps fusiformis	fongique	Exsudat sucré (miellat) sur les fleurs, puis scléroties noires à la place des grains.	Humidité élevée, températures modérées pendant la floraison.	2026-06-09 10:15:40.903561
82	Rouille du mil	Puccinia penniseti	fongique	Pustules orangées sur feuilles et gaines, réduction de la photosynthèse.	Humidité, températures 20-28°C en fin de saison.	2026-06-09 10:15:40.905727
83	Anthracnose du sorgho	Colletotrichum sublineolum	fongique	Taches rouges à pourpres avec centre gris sur feuilles ; attaque possible sur tige et panicule.	Humidité > 80%, températures 28-32°C, blessures.	2026-06-09 10:15:40.923026
84	Charbon couvert du sorgho	Sporisorium sorghi	fongique	Grains transformés en masses de spores noires enveloppées d'une membrane.	Semences infectées, sol humide.	2026-06-09 10:15:40.931093
85	Mildiou du sorgho	Peronosclerospora sorghi	fongique	Chlorose des jeunes feuilles, sporulation blanche, nanisme des plants, panicules déformées.	Humidité élevée, températures fraîches (22-25°C) au démarrage.	2026-06-09 10:15:40.933003
86	Helminthosporiose du sorgho	Exserohilum turcicum / Bipolaris sorghicola	fongique	Grandes taches nécrotiques elliptiques brun-grisâtres sur les feuilles.	Humidité, températures 22-28°C, rosée persistante.	2026-06-09 10:15:40.934799
87	Pourridié / Fonte des semis	Pythium aphanidermatum / Rhizoctonia solani	fongique	Pourriture du collet et des racines chez les jeunes plants ; flétrissement et mort.	Sol trop humide, températures > 30°C, densité excessive.	2026-06-09 10:15:40.957442
88	Cercosporiose du niébé	Cercospora canescens	fongique	Taches angulaires brun-rouge sur feuilles avec halo jaune ; défoliation précoce.	Humidité > 80%, températures 25-30°C.	2026-06-09 10:15:40.966389
89	Mosaïque du niébé	Cowpea mosaic virus (CPMV)	viral	Mosaïque vert clair-vert foncé sur feuilles, déformation foliaire, nanisme.	Pucerons vecteurs (Aphis craccivora), conditions chaudes.	2026-06-09 10:15:40.96881
90	Anthracnose du niébé	Colletotrichum lindemuthianum	fongique	Lésions sombres sur les gousses, tiges et feuilles ; sporulation rose en conditions humides.	Pluies fréquentes, températures 18-24°C.	2026-06-09 10:15:40.971239
91	Flétrissement fusarien du sésame	Fusarium oxysporum f.sp. sesami	fongique	Flétrissement rapide des plants en journée, puis mort irréversible ; vaisseaux brunis à la coupe de la tige.	Sols lourds ou engorgés, températures 27-30°C, pH acide.	2026-06-09 10:15:40.99156
92	Cercosporiose du sésame	Cercospora sesami	fongique	Taches circulaires brun-rougeâtre avec halo jaune sur les feuilles ; défoliation précoce.	Humidité > 80%, températures 25-30°C.	2026-06-09 10:15:40.998785
93	Phytophtora du sésame	Phytophthora parasitica	fongique	Pourriture du collet et des racines en conditions d'engorgement.	Sol imperméable, pluies excessives, mauvais drainage.	2026-06-09 10:15:41.00103
94	Mosaïque africaine du manioc	African Cassava Mosaic Virus (ACMV)	viral	Mosaïque vert clair / vert foncé sur feuilles, déformation foliaire, chlorose, nanisme sévère.	Présence de mouche blanche (Bemisia tabaci) vectrice, boutures infectées.	2026-06-09 10:15:41.018755
95	Bactériose vasculaire du manioc	Xanthomonas phaseoli pv. manihotis	bacterien	Taches angulaires wilt foliaire, exsudat bactérien sur tiges, flétrissement descendant.	Humidité élevée, blessures, variétés sensibles.	2026-06-09 10:15:41.025365
96	Pourriture brune des racines	Phytophthora drechsleri	fongique	Pourriture humide des racines tubéreuses, odeur fermentée, chair brune.	Sol engorgé, drainage insuffisant.	2026-06-09 10:15:41.027904
97	Taches brunes foliaires	Cercospora caribaea	fongique	Taches angulaires brunes sur feuilles, halo jaune, défoliation partielle.	Humidité prolongée, températures 25-30°C.	2026-06-09 10:15:41.030081
98	Mildiou de la tomate	Phytophthora infestans	fongique	Taches huileuses brunes sur feuilles avec duvet blanc en face inférieure ; brunissement des tiges et fruits.	Humidité > 85%, températures 10-24°C, nuits fraîches et rosée.	2026-06-09 10:15:41.052502
99	Alternariose	Alternaria solani	fongique	Taches brunes concentriques (cible) sur feuilles basses, avec halo jaune ; attaque possible sur tiges et fruits.	Températures 25-30°C, humidité alternée, feuillage vieillissant.	2026-06-09 10:15:41.059037
100	Virus TYLCV (jaunissement en cuillère)	Tomato Yellow Leaf Curl Virus	viral	Feuilles enroulées en cuillère vers le haut, jaunissement des bords, rabougrissement.	Forte densité de mouche blanche (Bemisia tabaci) vecteur.	2026-06-09 10:15:41.06182
101	Fusariose vasculaire	Fusarium oxysporum f.sp. lycopersici	fongique	Jaunissement unilatéral du feuillage, flétrissement progressif, brunissement vasculaire à la coupe.	Sols infestés, températures 25-30°C, pH bas.	2026-06-09 10:15:41.064619
102	Flétrissement bactérien	Ralstonia solanacearum	bacterien	Flétrissement soudain du plant entier sans jaunissement préalable ; brunissement vasculaire brun-brique à la coupe de la tige ; exsudat laiteux caractéristique en eau.	Sols chauds (25-35°C), humidité, blessures racinaires par nématodes ou labour, pH bas (<6).	2026-06-09 10:15:41.066987
103	Mildiou de l'oignon	Peronospora destructor	fongique	Feutrage gris-violacé sur feuilles, jaunissement puis nécrose ; plants affaiblis.	Humidité > 80%, températures 13-22°C, rosée nocturne.	2026-06-09 10:15:41.089902
104	Botrytis (pourriture du col)	Botrytis allii	fongique	Pourriture grise du col du bulbe au stockage ; moisissure grise sur les tuniques.	Humidité, blessures mécaniques, récolte avec col humide.	2026-06-09 10:15:41.107586
105	Fonte des semis de l'oignon	Pythium spp. / Rhizoctonia solani	fongique	Plants tombants et pourrissant au collet en pépinière ; jaunissement brutal.	Sol mal drainé, sur-arrosage, densité excessive en pépinière.	2026-06-09 10:15:41.112447
106	Anthracnose du piment	Colletotrichum capsici / C. gloeosporioides	fongique	Taches circulaires brunes à noires sur fruits, aspect pourrissant sur tige.	Humidité > 80%, temps chaud et humide, blessures.	2026-06-09 10:15:41.135071
107	Phytophthora du collet	Phytophthora capsici	fongique	Brunissement et pourriture du collet, flétrissement rapide du plant.	Excès d'humidité au sol, mauvais drainage.	2026-06-09 10:15:41.142881
108	Mosaïque du piment	Pepper mosaic virus (PepMV) / CMV	viral	Feuilles mosaïquées, déformées, fruits tachetés ou déformés.	Pucerons vecteurs, semences infectées.	2026-06-09 10:15:41.148206
109	Fusariose du gombo	Fusarium oxysporum f.sp. vasinfectum	fongique	Jaunissement et flétrissement des feuilles, brunissement vasculaire, mort du plant.	Sols infestés, températures 25-30°C, pH bas.	2026-06-09 10:15:41.172345
110	Mosaïque jaune du gombo	Okra Yellow Vein Mosaic Virus (OYVMV)	viral	Jaunissement en réseau (veinures jaunes), feuilles déformées, fruits malformés.	Bemisia tabaci (aleurode) vecteur ; saison sèche.	2026-06-09 10:15:41.178732
111	Pourriture de la tige (fonte des semis)	Pythium spp. / Rhizoctonia solani	fongique	Brunissement et pourriture du collet en début de levée ; plants tombants.	Excès d'humidité, sol mal drainé, semis trop profonds.	2026-06-09 10:15:41.18091
112	Verticilliose	Verticillium dahliae	fongique	Jaunissement ascendant du feuillage, flétrissement, brunissement vasculaire.	Sol infesté, températures fraîches-modérées (20-28°C).	2026-06-09 10:15:41.19496
113	Alternariose des Brassicacées	Alternaria brassicae / A. brassicicola	fongique	Taches concentriques noires sur feuilles extérieures, pourriture de la pomme en conditions humides.	Humidité > 85%, rosée nocturne, températures 20-25°C.	2026-06-09 10:15:41.213581
114	Hernie du chou	Plasmodiophora brassicae	parasitaire	Galles sur les racines, flétrissement en pleine journée, croissance réduite.	Sol acide (pH < 6.5), sols humides, températures 18-25°C.	2026-06-09 10:15:41.219669
115	Pourriture noire des Brassicacées	Xanthomonas campestris pv. campestris	bacterien	Jaunissement en V à partir des bords foliaires, nervures noires, pourriture interne de la pomme.	Chaleur, humidité, blessures, irrigation par aspersion.	2026-06-09 10:15:41.221672
116	Mildiou des cucurbitacées	Pseudoperonospora cubensis	fongique	Taches angulaires jaunes en face supérieure, feutrage violet en face inférieure.	Humidité > 85%, températures 15-23°C, rosée nocturne.	2026-06-09 10:15:41.233977
117	Oïdium du concombre	Sphaerotheca fuliginea / Erysiphe cichoracearum	fongique	Poudre blanche farineuse sur les feuilles et tiges.	Temps sec et chaud, humidité relative 50-80%.	2026-06-09 10:15:41.239326
118	Anthracnose des cucurbitacées	Colletotrichum lagenarium	fongique	Taches aqueuses puis brunes sur feuilles et fruits ; fruits pourris.	Humidité élevée, températures 22-27°C.	2026-06-09 10:15:41.241121
119	Fusariose vasculaire de la pastèque	Fusarium oxysporum f.sp. niveum	fongique	Flétrissement soudain d'un côté, brunissement vasculaire rouge-brun à la coupe.	Sol infesté, pH acide, températures 25-32°C.	2026-06-09 10:15:41.253672
120	Anthracnose de la mangue	Colletotrichum gloeosporioides	fongique	Taches noires sur feuilles, fleurs et fruits ; pourriture des fruits mûrs.	Humidité élevée à la floraison, pluie pendant la nouaison.	2026-06-09 10:15:41.272146
121	Oïdium de la mangue	Oidium mangiferae	fongique	Poudre blanche sur les panicules florales et les jeunes feuilles ; avortement floral.	Temps sec et chaud, atmosphère humide la nuit, forte rosée.	2026-06-09 10:15:41.277379
122	Bactériose angulaire	Xanthomonas campestris pv. mangiferaeindicae	bacterien	Taches angulaires huileuses sur feuilles, exsudat bactérien, dessèchement.	Pluies et blessures par le vent ou les insectes.	2026-06-09 10:15:41.279254
123	Dieback (dessèchement des rameaux)	Lasiodiplodia theobromae	fongique	Dessèchement progressif des rameaux depuis l'extrémité vers la base ; chancre brun-noir sous l'écorce ; mort descendante des branches.	Blessures (taille, insectes, vent), stress hydrique prononcé, arbres affaiblis, températures élevées.	2026-06-09 10:15:41.281448
124	Anthracnose de l'anacarde	Colletotrichum gloeosporioides	fongique	Taches nécrotiques sur panicules, feuilles et pommes cajou ; dessèchement floral.	Pluies et humidité à la floraison.	2026-06-09 10:15:41.298317
125	Oïdium de l'anacarde	Oidium anacardii	fongique	Poudre blanche sur jeunes feuilles et panicules ; avortement floral.	Temps sec avec humidité nocturne.	2026-06-09 10:15:41.303288
126	Maladie de Panama (Fusariose)	Fusarium oxysporum f.sp. cubense (race 1 et race 4TR)	fongique	Jaunissement des feuilles de l'extérieur vers le centre, brunissement vasculaire rouge à la coupe.	Sol infesté, blessures racinaires, stress hydrique.	2026-06-09 10:15:41.318299
127	Sigatoka noire	Mycosphaerella fijiensis	fongique	Stries brun-noir sur feuilles, nécrose rapide, défoliation sévère réduisant la photosynthèse.	Humidité > 80%, températures 25-28°C, précipitations fréquentes.	2026-06-09 10:15:41.323661
128	Anthracnose post-récolte	Colletotrichum musae	fongique	Taches noires sur fruits mûrs au cours du mûrissage.	Humidité, chaleur, blessures mécaniques.	2026-06-09 10:15:41.325625
129	Ringspot de la papaye (PRSV)	Papaya ringspot virus	viral	Mosaïque des feuilles, anneaux sur les fruits, nanisme, déformation totale.	Pucerons vecteurs (Myzus persicae, Aphis gossypii), saison sèche.	2026-06-09 10:15:41.339515
130	Anthracnose de la papaye	Colletotrichum gloeosporioides	fongique	Lésions circulaires noires sur les fruits mûrs avec cavités en post-récolte.	Humidité élevée, fruits blessés, chaleur.	2026-06-09 10:15:41.345068
131	Pythium (fonte du collet)	Pythium aphanidermatum	fongique	Pourriture et noircissement du collet, flétrissement et mort rapide du plant.	Engorgement du sol, mauvais drainage.	2026-06-09 10:15:41.347385
\.


--
-- Data for Name: agro_parametres_climatiques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_parametres_climatiques (id, culture_id, temp_min_c, temp_opt_min_c, temp_opt_max_c, temp_max_c, pluvio_min_mm, pluvio_opt_mm, pluvio_max_mm, altitude_max_m, ensoleillement_h, ph_min, ph_opt_min, ph_opt_max, ph_max, texture_preferee) FROM stdin;
21	21	15.0	24.0	30.0	38.0	400	1200	2000	1500	7.0	5.0	5.5	6.5	7.5	Argilo-limoneux, imperméable, bien retenant l'eau
22	22	10.0	22.0	32.0	40.0	500	800	1500	1500	8.0	5.5	6.0	7.0	8.0	Limon-sableux à argilo-limoneux, bien drainé
23	23	15.0	25.0	32.0	40.0	400	700	1200	1500	8.0	5.5	6.0	6.8	7.5	Sablo-limoneux, bien drainé, meuble (pénétration des gynophores)
24	24	20.0	28.0	35.0	42.0	250	500	900	1500	8.5	5.0	5.5	7.0	8.0	Sablo-limoneux, bien drainé, tolérance aux sols pauvres
25	25	15.0	27.0	34.0	42.0	300	600	1000	1500	8.0	5.5	6.0	7.5	8.5	Argilo-limoneux à limon-sableux ; tolère les vertisols
26	26	18.0	25.0	35.0	42.0	300	600	1000	1500	8.5	5.5	6.0	7.0	8.0	Limon-sableux à sablo-limoneux, bien drainé
27	27	20.0	28.0	35.0	42.0	300	550	800	1500	9.0	5.5	6.0	7.0	7.5	Limon-sableux bien drainé ; sensible à l'engorgement
28	28	18.0	25.0	32.0	40.0	600	1200	2000	1500	7.5	4.5	5.5	6.5	7.5	Sablo-limoneux à limon-sableux, bien drainé, meuble
29	29	10.0	18.0	27.0	38.0	400	600	1200	1500	8.0	5.5	6.0	6.8	7.5	Limon-sableux à argilo-limoneux, bien drainé, riche en M.O.
30	30	7.0	15.0	25.0	35.0	300	500	900	1500	9.0	6.0	6.2	7.0	7.8	Sablo-limoneux à limoneux, bien drainé, riche en matière organique
31	31	15.0	22.0	30.0	38.0	400	600	1200	1500	8.0	5.5	6.0	6.8	7.5	Limon-sableux à limoneux, bien drainé, riche en M.O.
32	32	20.0	27.0	35.0	42.0	400	700	1500	1500	9.0	6.0	6.5	7.5	8.0	Sablo-limoneux à argilo-limoneux, bien drainé
33	33	17.0	22.0	32.0	40.0	400	600	1200	1500	8.5	5.5	6.0	6.8	7.5	Limon-sableux, bien drainé, riche en matière organique
34	34	5.0	15.0	22.0	32.0	300	500	900	1500	7.0	6.0	6.5	7.0	7.5	Limon-argileux, bien drainé, riche en matière organique
35	35	15.0	22.0	30.0	38.0	400	600	1200	1500	8.0	6.0	6.2	7.0	7.5	Sablo-limoneux, bien drainé, riche en matière organique
36	36	18.0	25.0	35.0	42.0	300	600	1000	1500	9.0	6.0	6.5	7.5	8.0	Sablo-limoneux, bien drainé, sol léger et chaud
37	37	15.0	24.0	35.0	42.0	500	1000	2000	1500	9.0	5.5	6.0	7.0	7.5	Limon-sableux à argilo-limoneux, bien drainé, profond
38	38	10.0	24.0	35.0	42.0	600	1200	2000	1500	9.0	5.0	5.5	6.5	7.5	Sol sablo-limoneux, bien drainé, supporte sols pauvres et latéritiques
39	39	14.0	25.0	35.0	40.0	1000	1500	3000	1500	8.5	5.5	6.0	7.0	7.5	Limon-argileux, bien drainé, riche en matière organique, profond
40	40	15.0	22.0	32.0	38.0	600	1200	2000	1500	9.0	5.5	6.0	6.8	7.5	Limon-sableux, très bien drainé (intolérant à l'engorgement), riche en M.O.
\.


--
-- Data for Name: agro_ravageurs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_ravageurs (id, nom, nom_scientifique, type_ravageur, description, symptomes_degats, created_at) FROM stdin;
54	Foreur de tige du riz	Chilo suppressalis / Diopsis thoracica	insecte	Larves qui percent la tige et détruisent le point de croissance ou la panicule.	Cœur mort (dead heart) au tallage, panicule blanche stérile (white ear) à l'épiaison.	2026-06-09 10:15:40.803928
55	Quelea / Mange-mil	Quelea quelea	oiseau	Oiseau granivore migrateur attaquant en nuées de millions d'individus.	Grains arrachés et broutés sur la panicule ; dégâts massifs en quelques heures.	2026-06-09 10:15:40.806291
56	Hispe du riz	Dicladispa armigera	insecte	Coléoptère dont larves et adultes minent et rognent les feuilles.	Stries blanches longitudinales sur les feuilles ; aspect grillé du feuillage.	2026-06-09 10:15:40.810361
57	Nématode des racines	Meloidogyne graminicola	nematode	Nématode endoparasite formant des galles sur les racines du riz.	Galles sur racines, jaunissement, tallage réduit, plants chétifs.	2026-06-09 10:15:40.812977
58	Chenille légionnaire d'automne	Spodoptera frugiperda	insecte	Lépidoptère invasif (depuis 2016 en Afrique) dont les larves ravagent le cœur de la plante.	Trous dans les feuilles, sciure de bois dans le cornet, destruction du point végétatif.	2026-06-09 10:15:40.846846
59	Foreur de tige du maïs	Busseola fusca / Sesamia calamistis	insecte	Larves qui pénètrent dans la tige et créent des galeries, affaiblissant la plante.	Cœur mort, verse des plants attaqués, galeries dans la tige.	2026-06-09 10:15:40.848968
60	Cicadelle vectrice du MSV	Cicadulina mbila	insecte	Insecte piqueur-suceur qui transmet le Maize Streak Virus.	Stries virales sur les feuilles ; transmission en chaîne de plante à plante.	2026-06-09 10:15:40.851953
61	Puceron noir (Aphis craccivora)	Aphis craccivora	insecte	Puceron noir vecteur du virus de la rosette ; colonies sur les jeunes pousses.	Déformation des feuilles, miellat favorisant la fumagine, transmission virale.	2026-06-09 10:15:40.879302
62	Termites	Macrotermes spp. / Microtermes spp.	insecte	Termites qui attaquent les racines, tiges et gousses souterraines de l'arachide.	Plants flétris puis morts subitement, gousses rongées, galeries de terre sur tiges.	2026-06-09 10:15:40.880906
63	Ver blanc / Hanneton	Pachnoda marginata / Heteronychus spp.	insecte	Larves de coléoptères qui rongent les racines et les gousses dans le sol.	Flétissement des plants, gousses rongées, galeries dans le sol.	2026-06-09 10:15:40.88315
64	Striga (plante parasite)	Striga hermonthica	plante_parasite	Plante parasite hémiholoparasite qui se fixe sur les racines du mil et lui vole eau et nutriments.	Nanisme, jaunissement, plant parasité ne peut atteindre sa maturité ; tiges rouges-violettes du Striga.	2026-06-09 10:15:40.909163
65	Foreur des tiges / Panicules	Coniesta ignefusalis / Heliocheilus albipunctella	insecte	Larves qui pénètrent dans la tige (cœur mort) ou s'attaquent aux panicules.	Cœur mort au tallage, panicules partiellement détruites, galeries dans la tige.	2026-06-09 10:15:40.911343
66	Foreur de tige du sorgho	Busseola fusca	insecte	Larves de noctuelle qui pénètrent dans la tige causant le dépérissement.	Cœur mort (dead heart), tiges avec galeries, cassure de la tige principale.	2026-06-09 10:15:40.937034
67	Cochenille du sorgho	Melanaspis glomerata	insecte	Cochenille diaspididae formant des colonies sur les tiges et les feuilles.	Jaunissement et dessèchement des tiges infestées ; réduction de la croissance.	2026-06-09 10:15:40.938388
68	Cécidomyie du sorgho	Stenodiplosis sorghicola	insecte	Moucheron dont les larves se développent dans les grains en formation, les vidant complètement.	Grains vides (fleurets rouges restants caractéristiques), panicules apparemment saines mais stériles.	2026-06-09 10:15:40.940822
69	Noctuelle américaine (Helicoverpa)	Helicoverpa armigera	insecte	Chenille polyphage attaquant panicules, grains et fruits sur nombreuses cultures ; ravageur mondial majeur.	Perforations et galeries dans grains et panicules ; déjections caractéristiques (boulettes noirâtres).	2026-06-09 10:15:40.944431
70	Bruche du niébé	Callosobruchus maculatus	insecte	Coléoptère dont les larves se développent à l'intérieur des grains stockés.	Trous ronds dans les grains, farine à l'intérieur, grains non comestibles.	2026-06-09 10:15:40.973896
71	Thrips des fleurs	Megalurothrips sjostedti	insecte	Thrips qui se nourrit des fleurs et jeunes gousses du niébé.	Déformation des fleurs, avortement des gousses, rugosité des feuilles.	2026-06-09 10:15:40.975582
72	Punaise du niébé	Clavigralla tomentosicollis / Riptortus dentipes	insecte	Punaises hémiptères perçant les gousses et grains en développement avec leur rostre.	Grains tachetés, déformés ou avortés ; chute prématurée de gousses ; taches noires sur grains séchés.	2026-06-09 10:15:40.978547
73	Punaise du sésame	Antigastra catalaunalis	insecte	Lépidoptère dont les larves minent les feuilles et s'attaquent aux capsules.	Feuilles minées avec passages blancs, capsules percées et vidées.	2026-06-09 10:15:41.003585
74	Puceron du coton (Aphis gossypii)	Aphis gossypii	insecte	Puceron vert-jaune formant des colonies sur les jeunes pousses et fleurs.	Déformation des feuilles et fleurs, fumagine, réduction de la croissance.	2026-06-09 10:15:41.005218
75	Acarien rouge	Tetranychus urticae	acarien	Acarien tisserand formant des toiles sur la face inférieure des feuilles.	Jaunissement et bronzage des feuilles, toiles fines, défoliation en saison sèche.	2026-06-09 10:15:41.007467
76	Cochenille farineuse du manioc	Phenacoccus manihoti	insecte	Cochenille couverte de cire blanche formant des colonies sur les parties terminales.	Déformation des tiges ('queue de rat'), feuilles réduites, nanisme, fumagine.	2026-06-09 10:15:41.033766
77	Mouche blanche (Bemisia tabaci)	Bemisia tabaci	insecte	Aleurode vecteur des virus de la mosaïque africaine ; dommages directs par succion.	Jaunissement foliaire, fumagine, transmission virale (mosaïque).	2026-06-09 10:15:41.03561
78	Acarien vert du manioc	Mononychellus tanajoa	acarien	Acarien inféodé au manioc, proliférant en saison sèche chaude.	Chlorose des jeunes feuilles, déformation et nécrose, bronzage foliaire.	2026-06-09 10:15:41.038162
79	Mineuse de la tomate	Tuta absoluta	insecte	Lépidoptère invasif (depuis 2012 en Afrique de l'Ouest) ravageant tomates sous abris et en plein champ.	Mines blanchâtres dans les feuilles, galeries dans les fruits, attaque des tiges.	2026-06-09 10:15:41.06986
80	Thrips	Frankliniella occidentalis / Thrips tabaci	insecte	Insecte minuscule piqueur-suceur vecteur du TSWV (virus de la bronzure de la tomate).	Déformations florales, cicatrices argentées sur fruits, transmission virale.	2026-06-09 10:15:41.072392
81	Thrips de l'oignon	Thrips tabaci	insecte	Principal ravageur de l'oignon au Sénégal ; insecte minuscule piqueur-suceur.	Rayures argentées sur feuilles, déformation et décoloration, plants affaiblis.	2026-06-09 10:15:41.115453
82	Mouche de l'oignon	Delia antiqua	insecte	Diptère dont les larves creusent les bulbes et les tiges.	Plants flétris, galeries dans les bulbes, pourriture secondaire.	2026-06-09 10:15:41.117204
83	Nématodes des racines	Meloidogyne spp.	nematode	Nématodes endoparasites formant des galles sur les racines de l'oignon.	Plants chétifs, jaunissement, galles sur racines, bulbes petits et difformes.	2026-06-09 10:15:41.119464
84	Thrips du piment	Thrips tabaci / Frankliniella occidentalis	insecte	Insectes minuscules piquant les fleurs et les jeunes fruits.	Avortement floral, cicatrices et déformations sur fruits, transmission virale.	2026-06-09 10:15:41.153647
85	Pucerons verts	Myzus persicae	insecte	Puceron vecteur de nombreux virus du piment.	Enroulement des feuilles, miellat, fumagine, transmission virale.	2026-06-09 10:15:41.156077
86	Jassides (cicadelles)	Empoasca facialis	insecte	Cicadelle piqueur-suceur causant le dessèchement marginal des feuilles.	Bords des feuilles brunis et recroquevillés (tip burn), plants chétifs.	2026-06-09 10:15:41.183555
87	Punaise verte du gombo	Nezara viridula	insecte	Punaise piquant les fruits en développement ; fruits déformés.	Taches liégeuses sur fruits, déformation, chute prématurée.	2026-06-09 10:15:41.185779
88	Doryphore africain de l'aubergine	Leucinodes orbonalis	insecte	Lépidoptère dont les larves percent les fruits de l'aubergine.	Trous d'entrée avec galeries dans les fruits, présence de larves roses.	2026-06-09 10:15:41.20339
89	Teigne du chou	Plutella xylostella	insecte	Lépidoptère dont les larves minent les feuilles et pénètrent dans le cœur de la pomme.	Mines translucides sur feuilles, trous dans les feuilles, dégâts sur la pomme.	2026-06-09 10:15:41.223882
90	Pucerons du chou	Brevicoryne brassicae	insecte	Puceron farieux bleu-vert colonisant la face inférieure des feuilles.	Feuilles déformées et jaunissantes, miellat favorisant la fumagine.	2026-06-09 10:15:41.2252
91	Mouche des cucurbitacées	Bactrocera cucurbitae	insecte	Diptère dont les femelles pondent dans les jeunes fruits.	Fruits perforés, pourriture interne, chute des fruits.	2026-06-09 10:15:41.243319
92	Mouche des fruits de la mangue	Ceratitis cosyra / Bactrocera invadens	insecte	Diptère ravageur majeur ; femelles pondent dans les fruits en maturité.	Fruits piqués, galeries de larves, pourriture interne et chute des fruits.	2026-06-09 10:15:41.284122
93	Cochenilles farineusse	Rastrococcus invadens	insecte	Cochenille envahissante colonisant les fruits et rameaux.	Miellat favorisant la fumagine, fruits collants et noircis, réduction de la vigueur.	2026-06-09 10:15:41.285648
94	Cécidomyie de la mangue	Erosomyia mangiferae	insecte	Moucheron dont les larves ravagent les panicules florales.	Avortement floral massif ; panicules noircissant et tombant.	2026-06-09 10:15:41.287631
95	Hélopelte de l'anacarde	Helopeltis anacardii	insecte	Punaise piqueuse attaquant les jeunes pousses et les fruits en développement.	Lésions nécrotiques noires sur les jeunes fruits, pousses et feuilles.	2026-06-09 10:15:41.306744
96	Cochenille de l'anacarde	Planococcus citri	insecte	Cochenille colonisant les rameaux et les fruits.	Miellat, fumagine noire sur les fruits, réduction de la vigueur.	2026-06-09 10:15:41.308324
97	Charançon du bananier	Cosmopolites sordidus	insecte	Coléoptère dont les larves creusent le pseudo-tronc et le bulbe.	Galeries dans le pseudo-tronc et le rhizome, plant affaibli ou mort.	2026-06-09 10:15:41.327931
98	Nématodes des bananiers	Radopholus similis / Meloidogyne spp.	nematode	Nématodes endoparasites des racines causant pourriture et déracinement.	Racines pourries, plant déraciné par le vent, réduction du régime.	2026-06-09 10:15:41.329307
99	Mouche des fruits	Bactrocera cucurbitae / Ceratitis capitata	insecte	Femelles pondent dans les fruits mûrs ou brécheux.	Fruits piqués avec galeries, pourriture interne, chute prématurée.	2026-06-09 10:15:41.349829
100	Pucerons vecteurs PRSV	Myzus persicae / Aphis gossypii	insecte	Pucerons transmettant le virus PRSV de plante en plante.	Mosaïque virale (PRSV), dégâts directs mineurs mais transmission dévastatrice.	2026-06-09 10:15:41.351187
\.


--
-- Data for Name: agro_recommandations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_recommandations (id, culture_id, zone_agro, categorie_reco, titre, contenu, priorite, mois_applicable, created_at) FROM stdin;
52	21	\N	recolte	Séchage rapide après récolte	Récolter quand 80-85% des grains sont dorés (humidité ≈ 20-22%). Sécher immédiatement sur bâches à l'ombre ou étuve pour atteindre 13-14% d'humidité. Ne pas stocker au-dessus de 14% pour éviter les moisissures.	2	[10, 11, 12, 5, 6]	2026-06-09 10:15:40.817598
49	21	vallee_fleuve	semis_plantation	Repiquage en poquets à densité optimale	Repiquer 2-3 plants âgés de 21-25 jours par poquet, en lignes 20×20 cm. Un repiquage trop tardif ou trop profond réduit le tallage. Planter tôt le matin pour limiter le stress thermique des plants.	1	[7, 8]	2026-06-09 10:15:40.817592
50	21	\N	fertilisation	Fractionnement de l'azote en 3 apports	Apporter l'urée en 3 fois : 1/3 à la reprise (J+7), 1/3 au tallage actif (J+25), 1/3 avant l'épiaison (gonflement). Cette pratique réduit les pertes par volatilisation et évite la verse. Ne jamais appliquer l'urée sur sol sec.	1	[7, 8, 9, 10]	2026-06-09 10:15:40.817596
51	21	\N	protection_phyto	Surveillance précoce de la pyriculariose	Inspecter les feuilles dès le tallage actif. Taches losangiques grises = pyriculariose. Traiter immédiatement au Tricyclazole (Beam 75WP, 0,6 kg/ha). Éviter les excès d'azote qui favorisent l'attaque.	1	[8, 9, 10]	2026-06-09 10:15:40.817597
53	22	\N	protection_phyto	Surveillance quotidienne de la chenille légionnaire	Inspecter le cornet de chaque plant dès la levée. Présence de sciure = larves actives. Traiter dès le début d'infestation (stade L1-L2) avec Emamectin benzoate dans le cornet. Le traitement tardif (larves > L3) est beaucoup moins efficace.	1	[7, 8, 9]	2026-06-09 10:15:40.85415
54	22	\N	semis_plantation	Semis à densité optimale et démariage	Semer 3-4 grains par poquet (80×40 cm) et démarier à 2 plants par poquet au stade V3. La densité optimale est de 55 000 à 65 000 plants/ha. Densité trop forte = verse et maladies fongiques.	1	[6, 7]	2026-06-09 10:15:40.854154
55	22	\N	recolte	Séchage et stockage sous hermétisme	Récolter à maturité physiologique (pointe noire visible). Sécher en épis ou en grains jusqu'à 13% d'humidité. Stocker dans des sacs hermétiques GrainPro ou silos métalliques pour éviter les pertes dues aux charançons et moisissures.	2	[10, 11, 12]	2026-06-09 10:15:40.854155
56	23	bassin_arachidier	semis_plantation	Utiliser des semences certifiées ISRA	Éviter de recycler les semences d'une récolte à l'autre (dégénérescence). Utiliser des semences certifiées des variétés 55-437 ou Fleur 11 disponibles via l'ISRA/FONGS. Traiter les semences au thirame avant semis pour protéger contre les fontes de semis (10 g/kg de semences).	1	[5, 6, 7]	2026-06-09 10:15:40.885454
57	23	\N	recolte	Prévention des aflatoxines par séchage rapide	Récolter au bon stade de maturité (ne pas laisser sur pied en sol sec). Sécher les gousses immédiatement en couche mince à l'air libre pendant 5-7 jours. Stocker à moins de 10% d'humidité dans des sacs hermétiques. Les aflatoxines rendent l'arachide non exportable et dangereuse pour la santé.	1	[9, 10, 11]	2026-06-09 10:15:40.885458
58	23	\N	fertilisation	Inoculation au Rhizobium pour économiser l'azote	Inoculer les semences avec Bradyrhizobium japonicum avant le semis (inoculant disponible à l'ISRA Bambey). Cette pratique apporte jusqu'à 150 kg N/ha gratuitement via la fixation biologique et améliore le rendement de 15-25% sans coût supplémentaire en urée.	2	[6, 7]	2026-06-09 10:15:40.885459
59	24	zone_sylvopastorale	semis_plantation	Semis impératif dès les premières pluies utiles	Dans la zone sylvopastorale, la saison des pluies dure 60-70 jours maximum. Semer dès que 25-30 mm de pluie ont été reçus en 3-4 jours. Utiliser uniquement des variétés hâtives (Souna 3, cycle ≤ 85 jours). Le retard au semis = réduction de 100 kg/ha de rendement par semaine.	1	[6, 7]	2026-06-09 10:15:40.913326
60	24	\N	preparation_terrain	Démariage rigoureux à 2 plants par poquet	Le démariage est une opération cruciale trop souvent négligée. Démarier à 2 plants/poquet au stade 3-4 feuilles (J12-15). Garder les plants les plus vigoureux. Un poquet surdensifié donne des épis chétifs et est plus sensible au mildiou.	1	[7, 8]	2026-06-09 10:15:40.91333
61	24	\N	protection_phyto	Lutte collective contre les oiseaux (Quelea)	Le Quelea quelea ne peut être combattu efficacement qu'à l'échelle villageoise. Organiser un système de guet tournant dès l'épiaison (6h-19h). Utiliser des effrayants sonores, des rubans brillants et des silhouettes de prédateurs. Signaler les invasions à la brigade phytosanitaire (DGPV).	1	[9, 10]	2026-06-09 10:15:40.913331
62	25	\N	preparation_terrain	Labour avant hivernage pour casser la croûte et éliminer les adventices	Un labour profond (20-25 cm) en fin de saison sèche améliore la rétention d'eau et réduit le stock de graines d'adventices. Enfouir les résidus de culture pour réduire la source d'inoculum des maladies (anthracnose, charbon).	2	[4, 5, 6]	2026-06-09 10:15:40.946804
63	25	\N	fertilisation	Valoriser la fumure organique en complément des engrais minéraux	Le sorgho répond bien à la fumure organique (fumier, compost). Apporter 3-5 t/ha de fumier composté avant labour. En complément, 45 kg/ha de DAP au semis + 80 kg/ha d'urée en 2 fractions. La fumure organique améliore la structure du sol et réduit le besoin en engrais minéraux.	1	[5, 6, 7, 8]	2026-06-09 10:15:40.946807
64	25	casamance	semis_plantation	Préserver les variétés locales photopériodiques	Les variétés locales de sorgho photopériodiques de Casamance sont adaptées aux conditions locales (résistance aux maladies, qualité gustative). Les conserver dans les banques de semences communautaires. Les associer avec des variétés améliorées pour diversifier les risques.	2	[6, 7]	2026-06-09 10:15:40.946808
65	26	\N	recolte	Protection des stocks contre les bruches	La bruche du niébé (Callosobruchus) est le principal ennemi du niébé stocké. Récolter les gousses bien sèches, battre et vanner. Sécher les grains à l'air à <12% d'humidité. Stocker immédiatement dans des sacs hermétiques GrainPro ou jerricans + Actellic 2% dust (2 g/kg). Ne jamais stocker sans traitement préventif.	1	[9, 10, 11, 12, 1, 2]	2026-06-09 10:15:40.982493
66	26	\N	protection_phyto	Traitement contre les thrips à la floraison	Les thrips (Megalurothrips sjostedti) sont le ravageur le plus destructeur du niébé. Inspecter les fleurs dès le début de la floraison (insectes minuscules bruns). Traiter avec Karaté 2,5EC (0,5 L/ha) dès les premiers dégâts, de préférence le soir pour préserver les pollinisateurs.	1	[8, 9, 10]	2026-06-09 10:15:40.982497
67	26	\N	semis_plantation	Inoculer les semences avec Rhizobium	L'inoculation des semences de niébé avec Bradyrhizobium japonicum améliore la fixation d'azote de 30-50%. L'inoculant est disponible à l'ISRA Bambey. Enrober les graines humidifiés avec l'inoculant juste avant le semis, à l'ombre pour éviter l'inactivation par le soleil.	2	[7, 8]	2026-06-09 10:15:40.982498
68	27	\N	recolte	Récolte avant déhiscence totale des capsules	Le sésame est très sensible à la déhiscence (ouverture des capsules). Récolter quand 20-30% des capsules basales sont jaunies mais pas encore ouvertes. Couper les plants à la base tôt le matin, les mettre debout en bottes sur des bâches. Ne jamais laisser mûrir complètement sur pied : pertes de 40-60% possibles.	1	[10, 11]	2026-06-09 10:15:41.009564
69	27	\N	semis_plantation	Préparation du lit de semence pour les petites graines	Les graines de sésame sont très petites (0,3 g/1000 graines). Le lit de semence doit être finement émietté, sans mottes, parfaitement nivelé. Mélanger les graines avec 3-5 fois leur volume de sable fin pour faciliter la distribution. Semer en ligne à 45-50 cm, sans dépasser 4-5 kg de graines/ha.	1	[7, 8]	2026-06-09 10:15:41.009567
70	27	\N	preparation_terrain	Drainage impératif pour éviter le flétrissement fusarien	Le sésame est très sensible à l'engorgement. Ne jamais cultiver en bas-fond ou en terrain plat imperméable. Billonner les rangs à 20-25 cm de hauteur pour favoriser le drainage. En sol argileux, faire des planches surélevées. Le flétrissement fusarien qui en résulte est irréversible et très destructeur.	1	[7, 8]	2026-06-09 10:15:41.009568
71	28	casamance	semis_plantation	Utiliser uniquement des boutures certifiées indemnes de mosaïque	La mosaïque africaine est la principale contrainte du manioc. Sélectionner des boutures issues de plants sains (feuilles uniformément vertes, sans mosaïque). Les variétés résistantes TME 419 et TMS 30572 sont disponibles à l'ISRA. Ne jamais utiliser des boutures de plants malades même si elles semblent bonnes.	1	[5, 6, 7]	2026-06-09 10:15:41.042037
72	28	\N	recolte	Transformation rapide après récolte	Les racines de manioc se détériorent en 24-48h après l'arrachage. Planifier la transformation immédiate (gari, attiéké, farine, cossettes séchées). Si stockage en terre non possible : couvrir avec des feuilles de manioc et consommer sous 2-3 jours. La transformation en cossettes séchées (teneur < 14%) est la meilleure option de conservation.	1	[1, 2, 3, 4, 5, 6, 11, 12]	2026-06-09 10:15:41.04204
73	28	\N	fertilisation	Priorité au potassium pour les tubercules	Le potassium (K) est l'élément le plus important pour le manioc. Un apport insuffisant en K réduit le rendement en tubercules et leur teneur en amidon. Apporter KCl (100 kg/ha) à J90 en complément du NPK de fond. Sur sols sableux très pauvres, doubler la dose de KCl pour compenser la lixiviation.	2	[8, 9, 10]	2026-06-09 10:15:41.042041
74	28	\N	protection_phyto	Favoriser la lutte biologique contre la cochenille farineuse	Le parasitoïde Anagyrus lopezi est le principal ennemi naturel de la cochenille farineuse (Phenacoccus manihoti). Éviter les insecticides à large spectre qui éliminent ce parasitoïde. En cas d'infestation sévère, contacter le service de protection des végétaux (DGPV) pour obtenir des lâchers d'Anagyrus lopezi.	2	[1, 2, 3, 4, 11, 12]	2026-06-09 10:15:41.042042
75	29	\N	protection_phyto	Gestion intégrée Tuta absoluta	Installer 1 piège à phéromones par 500 m² dès la plantation. Surveiller quotidiennement les mines sur feuilles. Traiter dès les premiers adultes avec Emamectin benzoate ou Chlorantraniliprole. Alterner les matières actives pour éviter les résistances.	1	[9, 10, 11, 12, 1, 2, 3]	2026-06-09 10:15:41.079786
76	29	\N	fertilisation	Prévention de la nécrose apicale (BER) par apport de calcium	La BER (bout blanc des fruits) est due à une carence en calcium exacerbée par l'irrégularité d'arrosage. Appliquer CaNO3 (150 kg/ha en fertigation) et un fertilisant foliaire à base de chlorure de calcium (0,5%) 2 fois/semaine dès la nouaison.	1	[1, 2, 3, 11, 12]	2026-06-09 10:15:41.079791
77	29	niayes	semis_plantation	Utiliser des variétés résistantes au TYLCV dans les Niayes	Les zones Niayes ont une forte pression de Bemisia tabaci vecteur du TYLCV. Utiliser exclusivement des hybrides F1 avec gène Ty (Mongal, Power Ranger, Padma). Protéger la pépinière avec des filets anti-insectes (50 mesh).	1	[8, 9, 10, 11]	2026-06-09 10:15:41.079792
78	30	vallee_fleuve	semis_plantation	Pépinière soignée = succès de la culture	La qualité de la pépinière détermine 60% du succès. Utiliser un substrat solarisé ou pasteurisé. Semer à densité correcte (8-10 g/m²). Plants trop fins ou malades causent une mauvaise reprise et perte de rendement.	1	[9, 10]	2026-06-09 10:15:41.121808
79	30	\N	recolte	Séchage post-récolte pour éviter les pertes au stockage	Sécher les bulbes 7-10 jours en andains dans le champ après arrachage. Compléter 2-3 semaines en stockage ventilé (hangar avec filets). Humidité des bulbes < 12% avant stockage longue durée. Le mauvais séchage est la 1ère cause de pertes post-récolte au Sénégal.	1	[2, 3, 4, 5]	2026-06-09 10:15:41.121812
80	31	\N	recolte	Récolte et séchage pour le piment sec	Pour la production de piment sec, laisser les fruits atteindre la pleine maturité (rouge vif). Récolter par temps sec. Sécher sur claies ou bâches au soleil pendant 5-10 jours. Humidité finale < 12% avant broyage ou stockage. Le piment sec se conserve 6-12 mois dans des sacs hermétiques à l'abri de l'humidité.	2	[11, 12, 1, 2, 3, 4]	2026-06-09 10:15:41.161743
81	31	\N	protection_phyto	Lutte intégrée contre les thrips	Les thrips sont le ravageur n°1 du piment. Installer des pièges bleus collants (1 piège/100 m²). Traiter dès détection avec Spinosad le matin (moins d'impact sur les pollinisateurs). Alterner avec Abamectine toutes les 2 semaines pour éviter les résistances.	1	[1, 2, 3, 11, 12]	2026-06-09 10:15:41.161747
82	32	\N	recolte	Récolte quotidienne pour maintenir la qualité	Récolter les fruits à 5-8 cm (avant lignification fibreuse). Ne pas dépasser 3-4 jours entre les récoltes. Fruits trop mûrs non récoltés épuisent le plant et réduisent la floraison. Porter des gants pour la récolte (poils irritants sur certaines variétés).	1	[1, 2, 3, 8, 9, 10, 11]	2026-06-09 10:15:41.187796
83	32	\N	semis_plantation	Trempage des semences pour améliorer la germination	Tremper les graines dans l'eau tiède (30°C) pendant 12-24 heures avant semis. Cette technique améliore le taux de germination de 20-30%. Après trempage, semer immédiatement sans laisser sécher les graines.	2	[5, 6, 7, 10, 11, 12]	2026-06-09 10:15:41.187798
84	33	\N	protection_phyto	Surveillance obligatoire du foreur des fruits (Leucinodes)	Leucinodes orbonalis est le ravageur n°1 de l'aubergine au Sénégal. Inspecter tous les fruits lors de chaque récolte. Traiter à l'Emamectin benzoate dès détection. Fruits perforés à éliminer immédiatement pour éviter la propagation.	1	[1, 2, 3, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.206749
85	34	niayes	protection_phyto	Lutte intégrée contre la teigne du chou	Installer des pièges à phéromones (1/500 m²). Appliquer Bacillus thuringiensis (Bt) dès la levée, tous les 7 jours. Réserver l'Emamectin benzoate pour les fortes infestations uniquement. Alterner les matières actives pour lutter contre les résistances (fréquentes chez Plutella).	1	[10, 11, 12, 1, 2, 3]	2026-06-09 10:15:41.226849
86	35	\N	protection_phyto	Lutte contre la mouche des cucurbitacées par pièges	Installer des pièges à protéine-insecticide (1 piège/500 m²) dès la floraison. Ramasser et détruire tous les fruits tombés ou piqués. Ne pas laisser les fruits mûrir sur la plante (source de reproduction). La mouche est la principale raison des pertes post-floraison au Sénégal.	1	[12, 1, 2, 3, 4]	2026-06-09 10:15:41.245615
87	36	\N	recolte	Identifier la maturité de la pastèque sans la couper	Pour déterminer la maturité sans couper le fruit : 1) Vrille la plus proche du fruit complètement sèche = mûr ; 2) Son creux et profond à la percussion (son sourd) ; 3) Face ventrale jaune ou crème ; 4) Queue du fruit légèrement sèche. Ne jamais récolter avec la vrille encore verte.	1	[2, 3, 4, 5, 10, 11]	2026-06-09 10:15:41.265275
88	36	vallee_fleuve	semis_plantation	Préparation profonde du sol pour la pastèque	La pastèque a un système racinaire profond (1-1,5 m). Labourer à 40 cm de profondeur si possible. Incorporer 5 t/ha de compost pour améliorer la capacité de rétention en eau. Billons de 30 cm de hauteur recommandés pour le drainage.	2	[10, 11, 12]	2026-06-09 10:15:41.265279
89	37	\N	protection_phyto	Gestion de la mouche des fruits pour l'export	La mouche des fruits est le principal obstacle à l'export. Installer 1 piège McPhail avec attractif protéiné par ha dès la nouaison. Ramasser et détruire quotidiennement les fruits tombés. Récolter à maturité optimale (brécheux) sans laisser les fruits sur l'arbre. Les mangues destinées à l'export nécessitent un traitement post-récolte (eau chaude 46°C pendant 90 min ou vapeur chaleur) pour certifier l'absence de larves.	1	[4, 5, 6, 7]	2026-06-09 10:15:41.289718
90	37	\N	preparation_terrain	Taille de formation et d'entretien	Tailler immédiatement après la récolte (juillet-août). Supprimer les branches mortes, croisées et les gourmands. Objectif : houppier aéré en gobelet ou vase, hauteur contrôlée à 4-5 m. Enduire les plaies de taille avec de la bouillie bordelaise ou du goudron. Un arbre bien taillé produit plus et est plus facile à traiter.	1	[7, 8]	2026-06-09 10:15:41.289721
91	38	casamance	recolte	Ramassage quotidien pour la qualité des noix	Les noix de cajou tombent naturellement au sol. Ramasser quotidiennement le matin avant la chaleur. Les noix laissées au sol > 24h se détériorent (humidité, insectes). Sécher immédiatement sur claies 3-5 jours à 12-14% humidité avant stockage. Stocker dans des sacs de jute aérés à l'abri de l'humidité et de la pluie.	1	[3, 4, 5]	2026-06-09 10:15:41.310268
92	38	\N	preparation_terrain	Plantation en verger structuré pour augmenter les rendements	La plupart des vergers sénégalais sont des plantations non structurées. Planter en ligne à 10×10 m (100 arbres/ha) avec des clones ISRA (Jumbo 1, B11). Désherber le premier cercle (2 m de rayon) autour de chaque arbre. Les vergers structurés avec clones améliorés produisent 3-5 fois plus que les plantations paysannes non entretenues.	1	[6, 7, 8]	2026-06-09 10:15:41.310271
93	39	\N	semis_plantation	Utiliser des vitroplants certifiés	Les rejets paysans sont souvent infestés par le charançon et les nématodes. Investir dans des vitroplants in vitro certifiés (disponibles à l'ITA Dakar ou ISRA). Le coût plus élevé des vitroplants est compensé par un meilleur départ et une absence de contamination en charançons et nématodes.	1	[4, 5, 6, 7, 8]	2026-06-09 10:15:41.331552
94	39	\N	fertilisation	Potassium obligatoire pour de bons régimes	Le potassium est l'élément le plus limitant pour la banane. Un plant qui manque de K produit des régimes légers avec des doigts courts. Apporter 120 g de KCl par plant chaque mois tout au long du cycle. Sur sol sableux des Niayes, augmenter à 150 g/plant/mois.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.331554
95	40	\N	preparation_terrain	Billons obligatoires pour éviter la mort par engorgement	La papaye meurt en 24-48h d'engorgement du collet (Pythium). Toujours planter sur billons de 30-40 cm de hauteur minimum. En sol argileux ou à nappe phréatique haute, monter à 50-60 cm. Ne jamais planter en bas-fond ou zone inondable.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.353964
96	40	\N	protection_phyto	Gestion du PRSV par les variétés résistantes	Le Papaya Ringspot Virus est la principale menace pour la papaye au Sénégal. Utiliser exclusivement des variétés résistantes (Red Lady F1, Tainung 1). Protéger la pépinière avec des filets anti-insectes pour empêcher les pucerons vecteurs. Arracher et détruire immédiatement tout plant présentant des symptômes de mosaïque.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.353967
\.


--
-- Data for Name: agro_rendements_reference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_rendements_reference (id, culture_id, variete_id, zone_agro, pratique, rendement_min_t_ha, rendement_max_t_ha, rendement_moyen_t_ha, unite, source, annee_reference) FROM stdin;
61	21	\N	\N	subsistance	1.50	3.00	2.20	t/ha	ANSD / DAPSA	2022
62	21	\N	\N	amelioree	3.50	5.50	4.50	t/ha	ISRA / SAED	2022
63	21	\N	vallee_fleuve	intensive	5.50	8.00	6.50	t/ha	SAED / ISRA Saint-Louis	2023
64	22	\N	\N	subsistance	0.80	2.00	1.50	t/ha	ANSD / DAPSA	2022
65	22	\N	\N	amelioree	2.50	4.50	3.50	t/ha	ISRA / ANCAR	2022
66	22	\N	\N	intensive	5.00	8.00	6.00	t/ha	ISRA Bambey / expérimentations	2023
67	23	\N	\N	subsistance	0.50	1.20	0.90	t/ha	ANSD / DAPSA	2022
68	23	\N	\N	amelioree	1.50	2.50	2.00	t/ha	ISRA Bambey	2022
69	23	\N	\N	intensive	2.50	4.00	3.00	t/ha	ISRA / ICRISAT expérimentations	2023
70	24	\N	\N	subsistance	0.40	0.90	0.70	t/ha	ANSD / DAPSA	2022
71	24	\N	\N	amelioree	1.00	2.00	1.50	t/ha	ISRA / ANCAR	2022
72	24	\N	\N	intensive	2.00	3.50	2.50	t/ha	ISRA Bambey / ICRISAT	2023
73	25	\N	\N	subsistance	0.40	1.00	0.70	t/ha	ANSD / DAPSA	2022
74	25	\N	\N	amelioree	1.20	2.50	1.80	t/ha	ISRA / ANCAR	2022
75	25	\N	\N	intensive	2.50	4.50	3.50	t/ha	ISRA Séfa / expérimentations	2023
76	26	\N	\N	subsistance	0.30	0.70	0.50	t/ha	ANSD / DAPSA	2022
77	26	\N	\N	amelioree	0.80	1.50	1.20	t/ha	ISRA / ANCAR	2022
78	26	\N	\N	intensive	1.50	2.50	2.00	t/ha	ISRA Bambey / IITA expérimentations	2023
79	27	\N	\N	subsistance	0.20	0.50	0.35	t/ha	ANSD / DAPSA	2022
80	27	\N	\N	amelioree	0.50	0.90	0.70	t/ha	ISRA / ANCAR	2022
81	27	\N	\N	intensive	0.90	1.50	1.20	t/ha	ISRA / expérimentations NRCSS	2023
82	28	\N	\N	subsistance	5.00	10.00	7.50	t/ha	ANSD / DAPSA	2022
83	28	\N	\N	amelioree	12.00	20.00	16.00	t/ha	ISRA / IITA	2022
84	28	\N	\N	intensive	20.00	35.00	28.00	t/ha	IITA / expérimentations ISRA Séfa	2023
85	29	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD / DAPSA	2022
86	29	\N	\N	amelioree	20.00	40.00	30.00	t/ha	ISRA / ANCAR	2022
87	29	\N	niayes	intensive	50.00	80.00	60.00	t/ha	Marché export Niayes / ISRA CDH	2023
88	30	\N	\N	subsistance	5.00	12.00	8.00	t/ha	ANSD / DAPSA	2022
89	30	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA / SAED	2022
90	30	\N	vallee_fleuve	intensive	25.00	40.00	32.00	t/ha	SAED / ISRA CDH	2023
91	31	\N	\N	subsistance	3.00	8.00	5.00	t/ha	ANSD	2022
92	31	\N	\N	amelioree	8.00	18.00	12.00	t/ha	ISRA CDH	2022
93	31	\N	\N	intensive	18.00	30.00	22.00	t/ha	ISRA CDH / producteurs export	2023
94	32	\N	\N	subsistance	3.00	6.00	4.50	t/ha	ANSD	2022
95	32	\N	\N	amelioree	6.00	12.00	9.00	t/ha	ISRA CDH	2022
96	32	\N	\N	intensive	12.00	20.00	15.00	t/ha	Producteurs Vallée du Fleuve	2023
97	33	\N	\N	subsistance	6.00	12.00	9.00	t/ha	ANSD	2022
98	33	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA CDH	2022
99	33	\N	\N	intensive	25.00	40.00	30.00	t/ha	Producteurs Niayes	2023
100	34	\N	\N	subsistance	10.00	20.00	15.00	t/ha	ANSD	2022
101	34	\N	\N	amelioree	25.00	40.00	32.00	t/ha	ISRA CDH	2022
102	34	\N	niayes	intensive	40.00	60.00	50.00	t/ha	Producteurs export Niayes	2023
103	35	\N	\N	subsistance	5.00	12.00	8.00	t/ha	ANSD	2022
104	35	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA CDH	2022
105	35	\N	\N	intensive	25.00	40.00	30.00	t/ha	Producteurs Niayes	2023
106	36	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD	2022
107	36	\N	\N	amelioree	20.00	35.00	25.00	t/ha	ISRA CDH	2022
108	36	\N	vallee_fleuve	intensive	35.00	55.00	42.00	t/ha	SAED / Producteurs export	2023
109	37	\N	\N	subsistance	3.00	7.00	5.00	t/ha	ANSD / DAPSA	2022
110	37	\N	\N	amelioree	8.00	15.00	12.00	t/ha	ISRA / SODAGRI	2022
111	37	\N	casamance	intensive	15.00	25.00	18.00	t/ha	GIE export / APIX	2023
112	38	\N	\N	subsistance	0.30	0.80	0.50	t/ha	ANSD / DAPSA	2022
113	38	\N	\N	amelioree	1.00	2.00	1.50	t/ha	ISRA Djibélor	2022
114	38	\N	casamance	intensive	2.00	3.50	2.50	t/ha	ISRA / GIE producteurs	2023
115	39	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD	2022
116	39	\N	\N	amelioree	20.00	35.00	28.00	t/ha	ISRA / ANCAR	2022
117	39	\N	niayes	intensive	35.00	55.00	45.00	t/ha	Producteurs Niayes	2023
118	40	\N	\N	subsistance	15.00	30.00	20.00	t/ha	ANSD	2022
119	40	\N	\N	amelioree	35.00	60.00	45.00	t/ha	ISRA / ANCAR	2022
120	40	\N	niayes	intensive	60.00	100.00	80.00	t/ha	Producteurs Niayes (Red Lady F1)	2023
\.


--
-- Data for Name: agro_stades_phenologiques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_stades_phenologiques (id, culture_id, variete_id, ordre, nom_stade, jours_debut, jours_fin, description, actions_cles, indicateurs_visuels) FROM stdin;
106	21	\N	1	Semis / Repiquage	0	7	Semis en pépinière ou repiquage de plants âgés de 21-25 jours.	["Préparer la pépinière avec compost", "Inonder la parcelle avant repiquage", "Repiquer 2-3 plants par poquet à 20×20 cm"]	Grains germés ou plants de 20-25 cm bien racinés.
107	21	\N	2	Levée / Reprise	7	21	Établissement des plants et développement du système racinaire.	["Maintenir lame d'eau de 3-5 cm", "Désherbage manuel si nécessaire", "Apport d'urée (1/3 dose N)"]	Plants debout, 3-4 feuilles bien vertes, pas de jaunissement.
108	21	\N	3	Tallage	21	55	Formation des talles secondaires ; stade critique pour le rendement en grains.	["Apport de 1/3 azote (urée)", "Désherbage chimique (herbicide sélectif graminées)", "Surveiller pyriculariose et foreurs"]	3-5 talles par plant visible, feuillage dense et vert foncé.
109	21	\N	4	Montaison / Épiaison	55	80	Élongation de la tige et sortie de la panicule ; stade très sensible au déficit hydrique.	["Apport final d'azote (1/3 restant)", "Maintenir lame d'eau 5-8 cm", "Traitement fongicide si nécessaire (pyriculariose)"]	Gonflement de la gaine foliaire, sortie progressive de la panicule.
110	21	\N	5	Floraison / Grain laiteux	80	100	Fécondation et remplissage des grains ; sensibilité maximale aux oiseaux.	["Effarouchement des oiseaux (Quelea quelea)", "Maintenir humidité", "Surveiller la noctuelle (Spodoptera)"]	Panicules inclinées, grains laiteux puis dorés, anthères visibles.
111	21	\N	6	Maturité / Récolte	100	115	Grains durs et dorés ; couper l'irrigation 10-15 jours avant récolte.	["Arrêter l'irrigation à maturité laiteuse", "Récolter quand 80-85% des grains sont dorés", "Sécher à 14% humidité avant stockage"]	Panicules courbées, grains durs, feuilles jaunissantes.
112	22	\N	1	Semis	0	5	Dépôt des grains en poquet à 5-7 cm de profondeur dans sol humide.	["Préparer le sol (labour + binage)", "Semer 3-4 grains/poquet en lignes 80×40 cm", "Apport de DAP au fond du poquet"]	Sol humide, grains bien couverts de 5 cm de terre.
113	22	\N	2	Levée	5	14	Émergence des plantules ; stade très sensible aux adventices et aux insectes.	["Démariage à 1-2 plants/poquet à V3", "Désherbage chimique préémergence (Atrazine 2 kg/ha)", "Surveiller les vers gris et foreurs"]	Plantules avec 2-3 feuilles bien ouvertes.
114	22	\N	3	Croissance végétative (V4-V8)	14	45	Développement rapide du feuillage et de la tige ; absorption maximale des nutriments.	["Premier apport urée (50 kg/ha) à V4", "Binage inter-rang", "Surveiller chenille légionnaire (Spodoptera frugiperda)"]	6-8 feuilles larges et vertes, tige commençant à s'élever.
115	22	\N	4	Floraison	45	65	Émission de la panicule mâle (tassel) et des soies femelles ; pollinisation.	["Apport final urée (50 kg/ha) avant montaison", "Irrigation si sécheresse (stade le plus sensible)", "Surveiller foreurs de tiges"]	Panicule mâle au sommet, soies soyeuses rougeâtres aux épis.
116	22	\N	5	Remplissage des grains	65	90	Accumulation des glucides dans les grains ; épi se remplit et pend.	["Maintenir l'humidité du sol", "Surveiller les rongeurs et oiseaux", "Traitement fongicide si helminthosporiose"]	Épis lourds qui s'inclinent, feuilles commençant à jaunir.
117	22	\N	6	Maturité / Récolte	90	110	Grains durs, pointés noirs visibles ; récolte manuelle ou mécanisée.	["Récolter quand humidité grains ≈ 20-22%", "Sécher à 13% avant stockage", "Stocker dans des sacs hermétiques (GrainPro) ou silos métalliques"]	Spathes sèches, grains durs et jaunâtres, feuilles desséchées.
118	23	\N	1	Semis	0	7	Mise en place des graines décortiquées en poquets dans sol meuble et humide.	["Semer 2 graines/poquet à 3-5 cm de profondeur", "Inoculer avec Rhizobium (bradyrhizobium) si première culture", "Apport de Phosphate de Thiès (150 kg/ha) ou DAP en fond"]	Sol bien humide, graines bien couvertes sans compactage de surface.
119	23	\N	2	Levée	7	15	Émergence des cotylédons et premières feuilles ; formation des nodosités commence.	["Démariage à 1 plant par poquet si 2 sont levés", "Désherbage précoce", "Pas d'engrais azoté (fixation symbiotique)"]	Cotylédons verts au sol, premières feuilles trifoliées visibles.
120	23	\N	3	Croissance végétative	15	40	Développement du feuillage et des tiges ; nodosités actives sur les racines.	["Binage léger pour ameublir le sol", "Désherbage si couvrant", "Apport de soufre si nécessaire (20 kg/ha S)"]	Feuilles pennées vert vif, tiges ramifiées, nodosités roses à la base.
121	23	\N	4	Floraison	40	60	Fleurs jaunes autofécondes ; après fécondation, le gynophore s'enfonce en terre.	["Sol meuble autour des plants pour pénétration des gynophores", "Ne pas butter trop fortement", "Surveiller rosette virale (pucerons)"]	Petites fleurs jaunes à l'aisselle des feuilles, gynophores géotropiques.
122	23	\N	5	Fructification / Grossissement	60	90	Développement des gousses dans le sol ; apport en calcium critique.	["Apport de gypse (CaSO4) 100 kg/ha si sol acide", "Maintenir humidité modérée", "Surveiller cercosporiose"]	Gynophores enfoncés dans le sol, gousses en formation visibles à l'arrachage.
123	23	\N	6	Maturité / Récolte	90	110	Gousses mûres avec graines bien formées ; récolter avant les pluies tardives.	["Arracher les plants avant sécheresse totale (graines restent dans gousses)", "Sécher en andains 3-5 jours avant battage", "Stocker à 8-10% humidité pour éviter les aflatoxines"]	Réticulation interne des gousses brune, feuilles jaunissant, graines colorées.
124	24	\N	1	Semis	0	5	Semis en poquets de 5-10 grains à 2-3 cm de profondeur après les premières pluies.	["Attendre cumul pluies ≥ 30 mm sur 3-4 jours", "Semer 5-7 grains/poquet à 80×80 cm ou 1×1 m", "Semer peu profond (2-3 cm) en sol léger"]	Sol humide en surface, grains correctement couverts.
125	24	\N	2	Levée	5	15	Émergence des plantules ; stade critique pour les mauvaises herbes.	["Démariage à 3-4 plants/poquet à J12-15", "Désherbage manuel immédiat", "Pas d'engrais avant démariage"]	Plantules coleoptiles émergeant, feuilles dressées.
126	24	\N	3	Tallage	15	40	Formation des talles ; apport d'azote pour stimuler le tallage utile.	["Démariage définitif à 2 plants/poquet", "Apport urée 50 kg/ha à J20", "Désherbage et binage"]	2-4 talles visibles par plant, feuillage érigé.
127	24	\N	4	Montaison	40	60	Élongation de la tige principale et des talles ; formation du limbe foliaire.	["Surveillance mildiou (Sclerospora)", "Désherbage si mauvaises herbes", "Pas d'apport fertilisant à ce stade"]	Tiges bien dressées, gaine enveloppant la panicule naissante.
128	24	\N	5	Épiaison / Floraison	60	75	Sortie et floraison de l'épi cylindrique (chandelle) ; pollinisation.	["Effarouchement des oiseaux (Quelea, mange-mil)", "Surveiller foreurs de panicules", "Maintenir humidité si possible"]	Épis cylindriques en forme de chandelle, pollen visible.
129	24	\N	6	Maturité / Récolte	75	90	Grains durs et colorés ; récolte par coupe des épis.	["Couper les épis à maturité complète", "Sécher en greniers aérés", "Battre et vanner avant stockage"]	Grains durs de couleur grise-jaunâtre, feuilles desséchées.
130	25	\N	1	Semis	0	7	Semis en poquets après les premières pluies utiles.	["Semer 5-6 grains/poquet à 3-4 cm de profondeur", "Écartement 80×50 cm ou 1×0,5 m", "Apport de DAP ou Phosphate de Thiès en fond de poquet"]	Sol bien humide sur 20 cm, graines bien enfouies.
131	25	\N	2	Levée	7	15	Émergence des plantules ; démariage précoce nécessaire.	["Démariage à 3-4 plants/poquet", "Désherbage manuel ou herbicide sélectif", "Surveiller les attaques de termites"]	Plantules de 5-8 cm, feuilles primaires bien étalées.
132	25	\N	3	Tallage	15	45	Formation de 3-6 talles par poquet ; apport d'azote stimulant.	["Démariage final à 2 plants/poquet à J20", "Apport urée (50 kg/ha) à J20-25", "Désherbage et binage"]	3-5 talles visibles, feuillage dense et érigé.
133	25	\N	4	Montaison	45	70	Élongation de la tige principale et des talles vers la panicule.	["Surveiller le charbon du sorgho", "Binage inter-rang si adventices", "Apport urée complémentaire si carence"]	Tiges dressées de 1-1,5 m, gaines enveloppant la panicule.
134	25	\N	5	Floraison	70	90	Émergence et floraison de la panicule terminale.	["Effarouchement des oiseaux", "Maintenir humidité si stress", "Surveiller les foreurs de panicules"]	Panicule émergée, stigmates et anthères visibles.
135	25	\N	6	Maturité / Récolte	90	120	Grains durs et colorés ; récolte par coupe des panicules.	["Couper les panicules avant sur-maturité", "Sécher 3-5 jours avant battage", "Stocker en grenier aéré ou sacs hermétiques"]	Grains durs, panicule pendante, feuilles basales jaunissantes.
136	26	\N	1	Semis	0	5	Mise en place des graines en poquets dans sol bien ameubli.	["Semer 2-3 grains/poquet à 3-4 cm profondeur", "Écartement 60×40 cm ou 75×50 cm", "Inoculer avec Rhizobium (Bradyrhizobium)"]	Sol humide, graines bien couvertes.
137	26	\N	2	Levée	5	12	Émergence des cotylédons et premières feuilles trifoliées.	["Démariage à 1-2 plants/poquet si nécessaire", "Désherbage précoce (adventices très compétitives)", "Apport de Phosphate de Thiès si non fait"]	Cotylédons bien développés, premières feuilles simples.
138	26	\N	3	Croissance végétative	12	35	Développement du feuillage, des tiges et nodosités actives.	["Binage léger pour aérer le sol", "Contrôle des adventices (très critique)", "Surveiller les thrips sur feuilles terminales"]	Feuilles trifoliées abondantes, tiges volubiles ou érigées selon variété.
139	26	\N	4	Floraison	35	50	Floraison abondante ; fleurs papilionacées blanches-violettes.	["Surveiller les thrips (déformations florales)", "Ne pas appliquer insecticides à cette période (abeilles pollinisatrices)", "Maintenir humidité"]	Nombreuses fleurs blanches-violettes, bourgeonnement abondant.
140	26	\N	5	Fructification / Remplissage	50	65	Développement des gousses ; remplissage en grains.	["Surveiller les bruches (Callosobruchus) sur gousses", "Réduction de l'irrigation en fin de stade", "Surveiller les punaises de gousses"]	Gousses de 15-20 cm pendantes, grains visibles par transparence.
141	26	\N	6	Maturité / Récolte	65	80	Gousses sèches et dorées ; récolte progressive par passages successifs.	["Récolter les gousses mûres à sec", "Battre et vanner immédiatement", "Traiter les grains stockés contre les bruches (Pirimiphos-methyl)"]	Gousses beiges à dorées, grains durs audibles au froissement.
142	27	\N	1	Semis	0	5	Semis en surface ou superficiel (graines très petites) en sol bien préparé.	["Préparer lit de semence fin et nivelé", "Semer en lignes à 45-50 cm entre rangs, mélangé à du sable fin", "Ne pas couvrir les graines (ou très légèrement, 1 cm max)"]	Surface du sol propre et plane, légèrement humide.
143	27	\N	2	Levée	5	12	Émergence des plantules ; démariage indispensable dès ce stade.	["Démariage à 10-15 cm entre plants sur la ligne", "Désherbage manuel précoce (adventices très compétitives)", "Pas d'engorgement toléré"]	Plantules de 3-5 cm, cotylédons bien verts.
144	27	\N	3	Croissance végétative	12	40	Développement rapide de la tige principale et des feuilles.	["Binage et désherbage à J20", "Apport urée légère (20-25 kg/ha) si sol pauvre", "Surveiller les pucerons"]	Tige dressée de 30-50 cm, feuilles opposées bien développées.
145	27	\N	4	Floraison	40	60	Floraison axillaire successive ; fleurs blanches-violacées.	["Surveiller les insectes floricoles (punaises, acariens)", "Maintenir humidité modérée", "Eviter les stress hydriques"]	Fleurs tubulaires blanches-rosées à l'aisselle des feuilles.
146	27	\N	5	Fructification / Remplissage	60	80	Formation et remplissage des capsules ; accumulation d'huile dans les graines.	["Réduire arrosage pour éviter pourriture capsules", "Surveiller la cercosporiose", "Préparer matériel de récolte (bâches)"]	Capsules rectangulaires de 3-4 cm, graines visibles par transparence.
147	27	\N	6	Maturité / Récolte	80	100	Capsules basales commencent à jaunir et s'ouvrir (déhiscence) ; récolte urgente.	["Récolter quand 25-30% des capsules sont jaunies (avant ouverture)", "Couper les plants entiers, mettre en bottes debout sur bâches", "Battre délicatement sur bâche après 5-7 jours de séchage"]	Capsules basales jaunissantes, graines claires dans les capsules.
148	28	\N	1	Plantation (bouturage)	0	10	Plantation de boutures de tiges saines de 20-25 cm en sol humide.	["Sélectionner des tiges saines et indemnes de mosaïque", "Couper en boutures de 25-30 cm avec 5-6 nœuds", "Planter à l'oblique ou à plat selon le système (45° ou horizontal)"]	Boutures bien enfoncées dans sol humide, à 80×80 cm ou 1×1 m.
149	28	\N	2	Établissement / Levée	10	30	Développement des bourgeons, émission des premières feuilles.	["Rebouturage si levée < 80%", "Premier désherbage manuel", "Ne pas fertiliser avant J30"]	Bourgeons verts, premières feuilles palmatisées sur les boutures.
150	28	\N	3	Croissance végétative	30	120	Développement intense du feuillage et de la tige ; début de tubérisation.	["Apport d'engrais NPK à J30-45", "Désherbage 2-3 fois jusqu'à J90 (couverture complète)", "Surveiller cochenille farineuse et mosaïque"]	Plante de 60-150 cm, feuilles palmatisées denses, tige verte.
151	28	\N	4	Tubérisation active	120	240	Accumulation intense d'amidon dans les racines tubéreuses.	["Maintenir humidité régulière en saison sèche", "Surveiller et traiter si nécessaire la cochenille", "Éviter tout stress qui ralentit la tubérisation"]	Racines tubéreuses gonflées visibles au collet, plant compact.
152	28	\N	5	Maturation	240	330	Ralentissement de la croissance foliaire, concentration maximale d'amidon.	["Arrêt de l'irrigation 30 jours avant récolte", "Surveiller la bactériose si zone humide", "Planifier la récolte et la commercialisation"]	Feuilles basales jaunissant, écorce des racines légèrement brunissante.
153	28	\N	6	Récolte	270	365	Arrachage des racines manuellement ou mécaniquement.	["Couper la tige à 30 cm pour faciliter l'arrachage", "Arracher manuellement ou à la charrue", "Transformer rapidement (24-48h) ou stocker entier dans sol"]	Racines bien gonflées de 30-60 cm, chair blanche ou jaune selon variété.
154	29	\N	1	Pépinière	0	25	Semis en pépinière, repiquage en motte à 3-4 feuilles vraies.	["Semer en mini-sillon à 1 cm de profondeur", "Désinfection substrat (Dazomet ou solarisation)", "Traitement préventif contre fonte des semis (Metalaxyl)"]	Plants de 10-15 cm, 3-4 feuilles vraies, tiges droites.
155	29	\N	2	Repiquage / Reprise	25	40	Transplantation en planche, irrigation abondante pour la reprise.	["Repiquer le soir ou par temps couvert", "Densité : 40 000-50 000 plants/ha (50×50 cm)", "Apport DAP en fond de trou (5 g/plant)"]	Plants redressés, nouvelles feuilles vertes = bonne reprise.
156	29	\N	3	Croissance végétative	40	60	Développement rapide du feuillage, taille et palissage.	["Tuteurage / palissage des plants", "Pincement des gourmands (variétés indéterminées)", "Apport NPK 15-15-15 (200 kg/ha)"]	Tiges fortes, feuilles vert foncé, premières fleurs jaunes.
157	29	\N	4	Floraison	60	80	Fleurs jaunes, pollinisation ; stade critique pour la nouaison.	["Surveiller Tuta absoluta (mineuse)", "Apport de calcium folaire (Ca-B) 1 L/ha", "Ne pas stresser en eau"]	Boutons floraux jaunes, puis chute des pétales avec nouaison visible.
158	29	\N	5	Fructification / Grossissement	80	110	Grossissement des fruits, alternance irrigation-fertilisation.	["Irrigation régulière (éviter alternance humidité/sécheresse = BER)", "Apport KNO3 (potasse-azote) 200 kg/ha", "Traitements fongicides hebdomadaires"]	Fruits en croissance, stade vert puis virage couleur selon variété.
159	29	\N	6	Récolte	110	150	Récoltes successives tous les 3-5 jours sur variétés indéterminées.	["Récolter au stade brécheux (virage) pour export", "Récolter bien mûr pour marché local et transformation", "Trier et conditionner en caisses ventilées"]	Fruits colorés (rouge/orange selon variété), peau lisse et ferme.
160	30	\N	1	Pépinière	0	45	Semis dense en pépinière irriguée, plants repiqués à 3-4 feuilles.	["Semer à la volée 8-10 g graines/m² de pépinière", "Ombrage 30% les 10 premiers jours", "Traitement fongicide préventif (Iprodione) contre la fonte"]	Plants de 15-20 cm, diamètre 6-8 mm, 4-6 feuilles tubulaires.
161	30	\N	2	Repiquage / Reprise	45	60	Transplantation en billons ou planches à 10×15 cm, arrosage copieux.	["Couper 1/3 des feuilles et des racines avant repiquage", "Repiquer en ligne, 2-3 cm de profondeur", "Apport NPK 15-15-15 (200 kg/ha) en fond"]	Plants debout, nouvelles feuilles en 7-10 jours.
162	30	\N	3	Croissance végétative	60	100	Développement feuillaire intense, apport azoté fractionné.	["Apport urée (100 kg/ha) à J70", "Désherbage manuel ou herbicide (Métribuzine)", "Surveiller thrips sur les feuilles"]	Feuilles tubulaires dressées, 6-8 feuilles, tige bien formée.
163	30	\N	4	Formation du bulbe	100	135	Transfert des assimilats vers le bulbe ; réduire l'azote et augmenter le K.	["Apport KCl (100 kg/ha)", "Réduire les irrigations", "Stopper l'azote pour éviter le retard de maturation"]	Renflement visible à la base, feuilles commençant à verser.
164	30	\N	5	Maturation / Récolte	135	150	Feuilles versées, col mou, bulbe bien formé ; arrêt irrigation 10 jours avant.	["Arrêter l'irrigation 10-15 jours avant récolte", "Récolter quand 70-80% des feuilles sont versées", "Sécher en andains 7-10 jours avant stockage"]	Feuilles tombées, col du bulbe mou et fermé, bulbe ferme.
165	31	\N	1	Pépinière	0	30	Semis en pépinière, germination lente (10-15 jours), repiquage à 3-4 feuilles.	["Semer en ligne à 1 cm de profondeur", "Maintenir humidité constante", "Ombrage 30% contre la chaleur excessive"]	Plants de 10-12 cm, 3-4 feuilles, tiges droites.
166	31	\N	2	Repiquage / Reprise	30	45	Transplantation en champ, arrosage copieux pour la reprise.	["Densité : 40×40 cm (60 000 plants/ha)", "Apport DAP en fond de trou", "Arrosage matin et soir pendant 5 jours"]	Plants redressés, feuilles brillantes, nouvelles pousses.
167	31	\N	3	Croissance végétative	45	70	Développement de la tige et des ramifications ; formation du squelette.	["Apport NPK 15-15-15 (150 kg/ha)", "Désherbage", "Surveiller pucerons et thrips"]	Tige ramifiée, feuilles vert foncé, sans déformation.
168	31	\N	4	Floraison	70	90	Fleurs blanches pendantes ; autofécondation facilitée.	["Apport urée folaire (1%) pour favoriser la nouaison", "Traitement insecticide contre thrips et acariens", "Ne pas stresser en eau"]	Fleurs blanches, chute des pétales avec petit fruit vert visible.
169	31	\N	5	Fructification et récolte continue	90	150	Récoltes successives de fruits verts (frais) ou laissés à maturité (rouge/séché).	["Récolter tous les 7-10 jours (fruits verts) ou 14-21 jours (fruits rouges)", "Apport KNO3 (150 kg/ha) en fertigation pour prolonger la production", "Traitement contre anthracnose sur fruits"]	Fruits verts brillants ou rouges mûrs selon la destination.
170	32	\N	1	Semis	0	7	Semis direct en poquet, 3-4 grains par poquet, éclaircissage à 2 plants.	["Trempage des graines 12-24h avant semis", "3-4 grains par poquet à 3 cm de profondeur", "Apport DAP en fond de poquet (5 g/poquet)"]	Graines gonflées et germes visibles en 5-7 jours.
171	32	\N	2	Levée / Croissance initiale	7	25	Développement des premières feuilles ; démariage à 1-2 plants/poquet.	["Démariage à 2 plants par poquet (V2-V3)", "Désherbage manuel", "Arrosage tous les 3-4 jours"]	2-4 feuilles vraies lobées, plants vigoureux.
172	32	\N	3	Croissance végétative	25	50	Forte croissance ; apport NPK.	["Apport NPK 15-15-15 (150 kg/ha) à J30", "Buttage léger pour soutenir les tiges", "Surveiller jassides et pucerons"]	Plants de 50-80 cm, feuilles larges et lobées, tiges épaisses.
173	32	\N	4	Floraison et fructification	50	120	Floraison continue axillaire ; récolte des fruits tous les 3-4 jours.	["Récolter à 5-8 cm de longueur (avant lignification)", "Apport urée (50 kg/ha) pour prolonger la production", "Traitement contre jassides si nécessaire"]	Grandes fleurs jaunes à cœur rouge, fruits verts tendres.
174	33	\N	1	Pépinière	0	25	Semis en pépinière ; germination en 7-10 jours.	["Substrat stérile (terreau + compost)", "Ombrage 30% les 2 premières semaines", "Traitement préventif fonte des semis"]	Plants de 12-15 cm, 3-4 feuilles vraies.
175	33	\N	2	Repiquage / Reprise	25	45	Transplantation à 60×50 cm, arrosage immédiat.	["Densité 30 000-35 000 plants/ha", "DAP (5 g) en fond de trou", "Ombrage léger les 3 premiers jours"]	Plants repris, nouvelles feuilles en 7 jours.
176	33	\N	3	Croissance végétative	45	70	Développement rapide ; pincement de l'apex pour ramification.	["NPK 15-15-15 (150 kg/ha) à J55", "Pincement optionnel pour plus de ramifications", "Surveiller acariens et doryphore"]	Tiges épaisses, feuilles larges et pubescentes, vert foncé.
177	33	\N	4	Floraison / Fructification	70	140	Fleurs violettes, fruits en développement continu.	["Récolter dès que le fruit atteint la taille commerciale", "Urée (50 kg/ha) à J90 pour prolonger production", "Traitement insecticide contre doryphore africain"]	Fleurs violettes pendantes, fruits brillants violets.
178	34	\N	1	Pépinière	0	20	Semis en pépinière ; repiquage à 4-6 feuilles.	["Substrat stérile et bien drainé", "Semer à 1 cm de profondeur", "Température optimale 15-20°C en pépinière"]	Plants de 10-12 cm, 4-5 feuilles vraies.
179	34	\N	2	Repiquage / Reprise	20	35	Transplantation à 40×50 cm sur planches préparées avec compost.	["Densité 50 000 plants/ha", "NPK 15-15-15 (200 kg/ha) en fond de planche", "Arrosage copieux après repiquage"]	Plants debout, nouvelles feuilles en 5-7 jours.
180	34	\N	3	Croissance feuillaire	35	60	Développement intensif du feuillage extérieur.	["Urée (100 kg/ha) à J45", "Désherbage", "Surveiller teigne du chou et pucerons"]	Feuilles larges et ondulées, vert foncé brillant.
181	34	\N	4	Formation de la pomme	60	90	Enroulement progressif des feuilles pour former la pomme.	["KCl (100 kg/ha) à J65", "Surveiller la teigne du chou dans le cœur", "Réduire les irrigations progressivement"]	Feuilles internes se repliant, pomme compacte et dense.
182	34	\N	5	Récolte	90	110	Pomme ferme et dense ; récolter avant éclatement.	["Couper la tige à la base, laisser 2-3 feuilles protectrices", "Récolter tôt le matin pour la fraîcheur", "Stocker à l'ombre et au frais"]	Pomme ferme au toucher, feuilles serrées et brillantes.
183	35	\N	1	Semis	0	5	Semis direct en poquet (2-3 graines), germination en 3-5 jours.	["2-3 graines/poquet à 2 cm de profondeur", "Espacement 100×50 cm", "DAP (5 g) en fond de poquet"]	Graines germées, cotylédons sortant.
184	35	\N	2	Croissance végétative	5	30	Développement rapide des tiges rampantes et installation des vrilles.	["Démariage à 1 plant/poquet à V2", "NPK 15-15-15 (150 kg/ha) à J15", "Installer des tuteurs ou filets si culture palissée"]	Tiges rampantes, feuilles lobées vert foncé, vrilles actives.
185	35	\N	3	Floraison	30	45	Fleurs mâles apparaissent d'abord, puis femelles (ovaire visible).	["Apport urée (50 kg/ha) à J35", "Présence d'abeilles pour pollinisation", "Surveiller mouche des cucurbitacées"]	Fleurs jaunes, fleurs femelles avec mini-concombre à la base.
186	35	\N	4	Fructification / Récolte	45	75	Croissance rapide des fruits ; récolter avant surgrossissement.	["Récolter tous les 2-3 jours (avant que les fruits jaunissent)", "KCl (50 kg/ha) à J55 pour prolonger la fructification", "Traitement contre oïdium si nécessaire"]	Fruits verts fermes, 15-25 cm de longueur selon variété.
187	36	\N	1	Semis	0	7	Semis direct en poquet (2-3 graines) sur sol chaud.	["2-3 graines/poquet à 3 cm de profondeur", "Espacement 200×100 cm (5 000 plants/ha)", "DAP (10 g) + compost (500 g) en fond de poquet"]	Germination en 5-7 jours, cotylédons vigoureux.
188	36	\N	2	Croissance végétative	7	35	Développement des tiges rampantes longues.	["Démariage à 1-2 plants/poquet à V2", "NPK 15-15-15 (150 kg/ha) à J20", "Orienter les tiges pour faciliter la circulation"]	Longues tiges rampantes, feuilles profondément lobées.
189	36	\N	3	Floraison	35	55	Fleurs mâles puis femelles ; pollinisation par insectes.	["Urée (80 kg/ha) à J40", "Ne pas traiter pendant la floraison (abeilles)", "Surveiller mouche des cucurbitacées"]	Fleurs jaunes, femelles reconnaissables au mini-fruit à la base.
190	36	\N	4	Grossissement des fruits	55	85	Croissance rapide des fruits ; 1-3 fruits par plant selon la variété.	["KCl (80 kg/ha) à J60 pour améliorer le sucre", "Mettre une planche sous les fruits pour éviter les pourritures", "Réduire l'irrigation à l'approche de la maturité"]	Fruits grossissant rapidement, sarment adjacent à la vrille se desséchant.
191	36	\N	5	Maturité / Récolte	85	100	Fruits mûrs ; reconnaître la maturité par plusieurs signes.	["Vérifier : vrille proche du fruit sèche + son creux = mûr", "Récolter sans blesser le fruit", "Stocker à l'ombre ; bon transport si croûte épaisse"]	Vrille adjacente sèche, face ventrale jaune, son creux à la percussion.
192	37	\N	1	Floraison	0	30	Induction et sortie florale (décembre à février selon zone).	["Favoriser le stress hydrique pré-floraison (arrêt irrigation en novembre)", "Apport de KNO3 foliaire pour induire la floraison", "Traitement préventif anthracnose (cuivre) sur panicules"]	Panicules florales rougeâtres sortant des bourgeons terminaux.
193	37	\N	2	Nouaison	30	60	Fécondation des fleurs et formation des jeunes fruits.	["Traitement insecticide contre les cécidomyies et thrips floraux", "Traitement fongicide contre oïdium (soufre)", "Favoriser la pollinisation (présence d'abeilles)"]	Petits fruits verts (olive) de 1-2 cm après chute des pétales.
194	37	\N	3	Croissance des fruits	60	120	Grossissement progressif des fruits sur 60-70 jours.	["Irrigation si déficit hydrique (mars-avril = saison sèche)", "Apport NPK (200 g/arbre) à J75", "Surveillance mouche des fruits (pièges McPhail)"]	Fruits de 5-10 cm, bien formés, couleur verte.
195	37	\N	4	Maturité / Récolte	120	150	Fruits mûrs selon variété (mai-juillet) ; récolte manuelle avec perche.	["Récolter au stade brécheux pour export (légère teinture jaune-orange)", "Trier, calibrer et emballer rapidement", "Conservation à 12-13°C en chambre froide"]	Fruits lourds, arôme caractéristique, légère coloration selon variété.
196	37	\N	5	Post-récolte / Entretien	150	365	Taille post-récolte, fertilisation et préparation pour la prochaine campagne.	["Taille pour aérer le houppier et réguler la charge", "Apport NPK complet (500 g/arbre) en saison des pluies", "Traitement cuivre préventif en début de saison des pluies"]	Repousse des rameaux feuillés verts après la récolte.
197	38	\N	1	Floraison	0	30	Panicules florales d'octobre à janvier selon la zone.	["Traitement préventif anthracnose sur panicules (cuivre)", "Lutte contre Helopeltis dès apparition des panicules", "Pas d'irrigation (stimule la floraison)"]	Panicules blanches-roses à l'extrémité des rameaux.
198	38	\N	2	Nouaison	30	60	Fructification ; noix et pomme cajou en développement.	["Traitement insecticide contre Helopeltis (piqueur des fruits)", "Traitement fongicide si humidité", "Surveiller oïdium sur jeunes fruits"]	Noix réniforme verte avec pomme cajou (faux-fruit) orangeâtre.
199	38	\N	3	Maturité / Récolte	60	90	Noix mûres tombent naturellement au sol ; ramassage quotidien.	["Ramasser les noix tombées quotidiennement (éviter détérioration)", "Sécher les noix 3-5 jours au soleil", "Stocker dans des sacs aérés à l'abri de l'humidité"]	Pomme cajou rouge-jaune, noix gris-beige, chute naturelle au sol.
200	38	\N	4	Post-récolte / Entretien	90	365	Taille légère, fertilisation en début de saison des pluies.	["Taille légère : supprimer branches mortes et bois parasité", "Fertilisation NPK (200 g/arbre) en juillet", "Entretien sol (désherbage, travail superficiel)"]	Rameaux en repousse végétative verts pendant l'hivernage.
201	39	\N	1	Plantation / Levée	0	30	Plantation par rejets (œilletons) ou vitroplants ; enracinement.	["Choisir des rejets épée de 50-80 cm ou vitroplants sains", "Trou de plantation 60×60×60 cm avec 20 kg compost", "Espacement 2,5×2,5 m à 2,5×3 m"]	Rejet debout, feuilles déployées, pas de jaunissement.
202	39	\N	2	Croissance végétative	30	150	Développement du pseudo-tronc et des feuilles ; tallage sélectif.	["Conserver 1 rejet de succession par plant", "Apport urée (100 g/plant) à J60 et J120", "Irrigation au goutte-à-goutte tous les 2-3 jours"]	Pseudo-tronc épais, 8-10 feuilles ouvertes, rejet de succession visible.
203	39	\N	3	Induction florale / Montaison	150	220	L'apex végétatif se transforme ; hampe florale en cours de formation.	["KCl (200 g/plant) pour soutenir la montaison", "Supprimer les rejets excédentaires", "Vérifier l'état sanitaire (cercosporiose)"]	Gonflement de la gaine supérieure = montaison imminente.
204	39	\N	4	Floraison / Formation du régime	220	270	Sortie du régime et des mains de bananes.	["Tuteurage ou haubanage pour éviter la verse", "Supprimer l'extrémité de la hampe (clocheton) après 6-8 mains", "Envelopper le régime dans un sac plastique bleu (protection et calibrage)"]	Hampe florale sortant, mains de bananes en développement.
205	39	\N	5	Maturité / Récolte	270	365	Récolte du régime vert (stade 3/4 de maturité) avant jaunissement.	["Couper le régime à 3/4 de rondeur des doigts", "Traitement post-récolte : sulfate d'aluminium contre Colletotrichum", "Mûrissage contrôlé à l'éthylène si besoin"]	Doigts bien ronds (3/4), quelques doigts légèrement jaunes.
206	40	\N	1	Pépinière	0	45	Semis en sachets, repiquage à 4 feuilles vraies.	["Semer 2-3 graines par sachet, démarier à 1 plant", "Substrat : terreau + compost (1:1)", "Arrosage modéré pour éviter la fonte des semis"]	Plants de 20-25 cm, 4-6 feuilles, tige droite et robuste.
207	40	\N	2	Plantation / Reprise	45	75	Transplantation sur billons (indispensable) ; reprise en 2-3 semaines.	["Billons de 30-40 cm de hauteur (drainage crucial)", "Espacement 2×2 m à 2,5×2,5 m", "Compost (10 kg/trou) + NPK 15-15-15 (200 g/plant)"]	Plants repris, nouvelles feuilles déployées.
208	40	\N	3	Croissance végétative	75	180	Développement rapide du tronc et des feuilles.	["Urée (50 g/plant) à J90 et J150", "Irrigation au goutte-à-goutte tous les 2-3 jours", "Surveiller Tetranychus et pucerons"]	Tronc de 1-1,5 m, grandes feuilles palmées, pas de jaunissement.
209	40	\N	4	Floraison / Fructification	180	300	Fleurs axillaires ; pour les hermaphrodites, tous les fruits sont fertiles.	["Sur plants dioïques : identifier et conserver 1 plant mâle pour 10 femelles", "KNO3 (100 g/plant) à la floraison", "Surveiller PRSV (pucerons vecteurs)"]	Fruits en spirale sur le tronc, grossissant progressivement.
210	40	\N	5	Récolte continue	300	730	Récolte des fruits mûrs ou verts selon la destination ; production continue.	["Récolter fruits mûrs (jaunes) pour marché local", "Récolter fruits verts pour export/transformation", "Maintenir la fertilisation mensuelle"]	Fruits mûrs : jaune-orange, légèrement mous au toucher.
\.


--
-- Data for Name: agro_varietes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_varietes (id, culture_id, nom, origine, cycle_min_jours, cycle_max_jours, precocite, tolerance_secheresse, tolerance_salinite, zones_adaptees, rendement_potentiel_t_ha, notes) FROM stdin;
78	21	Sahel 108	ISRA / ADRAO	100	110	hative	f	f	["vallee_fleuve"]	7.00	Variété irriguée dominante de la Vallée du Fleuve ; deux cycles par an possibles.
79	21	Sahel 201	ISRA / ADRAO	115	125	semi-tardive	f	t	["vallee_fleuve"]	8.00	Tolérance modérée à la salinité ; adapté aux périmètres irrigués du Delta.
80	21	CG 14	CGIAR / AfricaRice	90	105	hative	t	f	["casamance", "senegal_oriental"]	5.00	Riz pluvial tolérant à la sécheresse ; adapté aux bas-fonds de Casamance.
81	21	Jaya	IRRI / ISRA	110	120	semi-tardive	f	f	["vallee_fleuve", "casamance"]	6.50	Bonne qualité gustative ; appréciée des consommateurs locaux.
82	22	SAMAZ 13	ISRA	90	100	hative	t	f	["bassin_arachidier", "casamance", "senegal_oriental"]	5.00	Variété améliorée ISRA adaptée aux zones semi-arides ; bonne tolérance à la sécheresse.
83	22	APEX 836	SeedCo / importé	100	115	semi-tardive	f	f	["casamance", "senegal_oriental", "vallee_fleuve"]	8.00	Hybride à haut rendement utilisé en culture intensive et irriguée.
84	22	ZM 521	CIMMYT / CGIAR	95	110	semi-tardive	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	6.00	Variété DTMA (Drought Tolerant Maize for Africa) adaptée au stress hydrique.
85	22	Population locale Thiès	local	100	120	semi-tardive	f	f	["bassin_arachidier", "niayes"]	3.00	Variété paysanne à qualité gustative appréciée mais faible rendement.
86	23	55-437	ISRA	90	100	hative	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.50	Variété hâtive ISRA la plus répandue ; adaptée aux zones à pluviométrie incertaine.
87	23	73-33	ISRA	100	110	semi-tardive	f	f	["bassin_arachidier", "casamance", "senegal_oriental"]	3.00	Bonne teneur en huile (48%) ; utilisée pour la confiserie et l'huilerie.
88	23	Fleur 11	ISRA	90	100	hative	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.20	Très bonne tolérance à la sécheresse terminale ; adoptée par les petits producteurs.
89	23	GH 119-20	ICRISAT / ISRA	105	115	semi-tardive	f	f	["casamance", "senegal_oriental"]	3.50	Haut potentiel de rendement pour les zones à pluviométrie suffisante.
90	24	Souna 3	ISRA	75	85	hative	t	f	["bassin_arachidier", "zone_sylvopastorale", "senegal_oriental"]	2.00	Variété hâtive ISRA la plus cultivée ; adaptée à la Sahelisation du bassin arachidier.
91	24	IBV 8004	ICRISAT / ISRA	80	90	hative	t	f	["zone_sylvopastorale", "bassin_arachidier"]	2.50	Variété améliorée ICRISAT ; bonne tolérance mildiou.
92	24	Sanio local	local	120	150	tardive	f	f	["casamance", "senegal_oriental"]	1.50	Variété paysanne tardive (Sanio) ; cycle long adapté aux zones plus humides.
93	24	ICMV IS 89305	ICRISAT	85	95	semi-tardive	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.80	Bonne résistance au mildiou et à la striga ; utilisée dans les programmes ISRA-ICRISAT.
94	25	CE 145-66	ISRA	100	110	semi-tardive	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	3.50	Variété améliorée ISRA à grain blanc ; appréciée pour l'alimentation humaine.
95	25	S 35	ISRA / ICRISAT	95	105	hative	t	f	["zone_sylvopastorale", "bassin_arachidier"]	2.50	Variété hâtive adaptée aux zones à courte saison pluvieuse.
96	25	IRAT 204	CIRAD / ISRA	110	120	semi-tardive	f	f	["casamance", "senegal_oriental"]	4.00	Fort potentiel en zones humides ; utilisation possible pour fourrage.
97	25	Sorgho local Casamance	local	130	160	tardive	f	f	["casamance"]	2.00	Variétés photopériodiques locales à grain rouge ; valeur culturelle forte.
98	26	Melakh	ISRA	58	65	hative	t	f	["bassin_arachidier", "zone_sylvopastorale", "niayes"]	1.50	Variété très hâtive ISRA (60 jours) adaptée aux zones sahéliennes sèches.
99	26	Mouride	ISRA	60	68	hative	t	f	["bassin_arachidier", "senegal_oriental"]	1.80	Bonne tolérance à la sécheresse ; grain blanc apprécié du marché local.
100	26	Ndiambour	ISRA	65	75	semi-tardive	f	f	["bassin_arachidier", "casamance", "senegal_oriental"]	2.00	Bon rendement en grains secs ; résistance aux maladies.
101	26	58-74 (Bambey 21)	ISRA Bambey	70	80	semi-tardive	f	f	["bassin_arachidier", "casamance"]	2.50	Variété ancienne mais encore cultivée pour ses fanes fourragères abondantes.
102	27	Yannik	ISRA	90	100	hative	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	1.00	Variété blanche améliorée ISRA ; teneur en huile élevée (50%). Appréciée à l'export.
103	27	Pakao	ISRA / local	90	105	semi-tardive	t	f	["casamance", "senegal_oriental"]	0.90	Variété adaptée à la Casamance et au Sénégal Oriental ; capsules semi-indéhiscentes.
104	27	Local blanc	local	95	110	semi-tardive	t	f	["bassin_arachidier", "zone_sylvopastorale", "senegal_oriental"]	0.60	Variété paysanne non sélectionnée mais rustique et largement répandue.
105	27	NRCSS 2001	ISRA / ICAR Inde	85	95	hative	t	f	["bassin_arachidier", "senegal_oriental"]	1.20	Variété introduite à haut potentiel ; résistance partielle au flétrissement fusarien.
106	28	TME 419	IITA / ISRA	270	360	semi-tardive	t	f	["casamance", "senegal_oriental"]	25.00	Variété améliorée IITA résistante à la mosaïque africaine ; fort potentiel de rendement.
107	28	TMS 30572	IITA	270	360	semi-tardive	f	f	["casamance", "senegal_oriental"]	30.00	Haut rendement en racines tubéreuses ; bonne tolérance à la mosaïque.
108	28	Kibondondo	local / Casamance	300	365	tardive	f	f	["casamance"]	15.00	Variété locale de Casamance à faible teneur en cyanure ; feuilles très consommées.
109	28	Bocou 1	ISRA / CNRA Côte d'Ivoire	270	330	semi-tardive	t	f	["casamance", "senegal_oriental", "bassin_arachidier"]	20.00	Bonne tolérance à la sécheresse ; adaptée aux zones à pluviométrie variable.
110	29	Mongal F1	Nunhems / importé	70	85	hative	f	f	["niayes", "vallee_fleuve"]	60.00	Hybride F1 très cultivé dans les Niayes ; tolérant TYLCV et mildiou.
111	29	Padma F1	Clause / importé	75	90	hative	f	f	["niayes", "vallee_fleuve", "casamance"]	55.00	Bonne tenue post-récolte ; adapté à l'exportation.
112	29	Caraïbe	Vilmorin / importé	80	95	semi-tardive	f	f	["niayes", "vallee_fleuve"]	50.00	Très cultivé pour la transformation industrielle (concentré de tomate).
113	29	Power Ranger F1	East-West Seed / importé	70	80	hative	f	f	["niayes", "casamance"]	65.00	Tolérant à Tuta absoluta et TYLCV ; haut rendement.
114	30	Violet de Galmi	Niger / ISRA	120	150	semi-tardive	f	f	["vallee_fleuve", "bassin_arachidier"]	25.00	Variété africaine la plus adaptée ; bonne conservation (4-6 mois). Bulbe rouge-violet.
115	30	Bawku	Ghana / local	110	130	hative	f	f	["vallee_fleuve", "niayes"]	20.00	Adapté aux fortes températures ; bonne conservation.
116	30	Gandiol	ISRA / local Saint-Louis	115	135	hative	f	t	["vallee_fleuve"]	22.00	Sélection locale ISRA Saint-Louis ; bonne tolérance à la salinité des sols du delta.
117	30	Wartanieen	Holland / importé	100	115	hative	f	f	["niayes", "vallee_fleuve"]	35.00	Hybride F1 à haut rendement ; mauvaise conservation en condition tropicale.
118	31	Dibangor	local Sénégal	75	90	hative	t	f	["niayes", "bassin_arachidier", "casamance"]	15.00	Variété locale très piquante, très prisée au Sénégal ; bonne adaptation.
119	31	Yolo Wonder	USA / importé	80	95	semi-tardive	f	f	["niayes", "vallee_fleuve"]	25.00	Piment doux gros fruit ; utilisé pour la consommation fraîche en salade.
120	31	Tabasco local	local	90	110	semi-tardive	t	f	["casamance", "bassin_arachidier"]	10.00	Très piquant, fruits rouges utilisés séchés ou en sauce.
121	31	Djakato	Casamance / local	100	120	tardive	f	f	["casamance", "senegal_oriental"]	20.00	Piment de Casamance à fruit moyen, rouge vif, utilisé frais et séché.
122	32	Clemson Spineless	USA / importé	55	65	hative	t	f	["niayes", "vallee_fleuve", "bassin_arachidier"]	12.00	Variété la plus cultivée ; fruits lisses sans épines, facile à récolter.
123	32	Kirikou	local / Afrique de l'Ouest	50	60	hative	t	f	["bassin_arachidier", "casamance", "senegal_oriental"]	8.00	Petits fruits ronds très appréciés en cuisine locale ; bonne adaptation.
124	32	Parbhani Kranti	ICRISAT / Inde	50	60	hative	t	f	["vallee_fleuve", "niayes"]	14.00	Résistant au virus de la mosaïque jaune ; fort potentiel de rendement.
125	32	Local rouge	local	60	75	semi-tardive	t	t	["casamance", "bassin_arachidier"]	7.00	Variété paysanne rustique ; fruits rouges utilisés séchés.
126	33	Longue violette locale	local Sénégal	70	85	hative	t	f	["niayes", "casamance", "bassin_arachidier"]	20.00	Variété locale la plus appréciée ; fruit long violet, chair ferme.
127	33	African Beauty F1	East-West Seed	65	80	hative	f	f	["niayes", "vallee_fleuve"]	35.00	Hybride F1 très productif ; résistant aux nématodes.
128	33	Kalenda F1	Syngenta / importé	70	85	hative	f	f	["niayes", "casamance"]	30.00	Fruit ovale violet foncé brillant ; bonne tenue post-récolte.
129	34	Tropicana F1	Nunhems / importé	70	85	hative	f	f	["niayes", "vallee_fleuve"]	40.00	Hybride F1 tolérant à la chaleur ; adapté au Sénégal.
130	34	Grenadier F1	Clause / importé	80	95	semi-tardive	f	f	["niayes"]	45.00	Pomme dense et lourde ; bonne tenue après récolte.
131	34	Bol d'Or	local / acclimate	85	100	semi-tardive	f	f	["niayes"]	30.00	Pomme ronde jaune-vert ; saveur douce appréciée.
132	35	Marketmore	USA / importé	60	70	hative	f	f	["niayes", "vallee_fleuve"]	25.00	Variété standard très cultivée ; fruits longs vert foncé.
133	35	Poinsett 76	USA / importé	65	75	hative	f	f	["niayes", "casamance"]	22.00	Résistant à l'anthracnose et à l'oïdium ; adapté aux zones humides.
134	35	Ashley	USA / importé	65	75	hative	f	f	["vallee_fleuve", "bassin_arachidier"]	20.00	Tolérant à la chaleur ; bon pour les zones à températures élevées.
135	36	Charleston Grey	USA / importé	85	95	semi-tardive	t	f	["vallee_fleuve", "niayes", "bassin_arachidier"]	30.00	Gros fruits (8-15 kg), très populaire ; tolérant à l'anthracnose.
136	36	Sugar Baby	USA / importé	75	85	hative	t	f	["niayes", "vallee_fleuve", "bassin_arachidier"]	25.00	Petits fruits ronds (3-5 kg) ; chair rouge sucrée, très commercialisable.
137	36	Crimson Sweet	USA / importé	80	90	semi-tardive	f	f	["vallee_fleuve", "niayes"]	35.00	Chair rouge très sucrée ; bonne conservation pour l'export.
138	36	Koloss	Nunhems / importé	80	90	semi-tardive	f	f	["vallee_fleuve"]	45.00	Hybride F1 très productif ; fruits lourds jusqu'à 20 kg.
139	37	Kent	USA / importé	100	120	tardive	t	f	["casamance", "senegal_oriental"]	15.00	Variété export n°1 du Sénégal ; gros fruit orange, chair ferme, peu de fibres.
140	37	Keitt	USA / importé	110	130	tardive	t	f	["casamance", "senegal_oriental"]	18.00	Deuxième variété export ; fruit vert même à maturité, très bonne conservation.
141	37	Amélie	Afrique de l'Ouest / acclimate	80	100	hative	t	f	["casamance", "senegal_oriental", "bassin_arachidier"]	12.00	Première à mûrir (avril-mai) ; marché local, fruit jaune sucré.
142	37	Valencia	Afrique de l'Ouest	90	110	semi-tardive	t	f	["casamance", "bassin_arachidier"]	10.00	Fruit rouge-vert, fibres moyennes, bonne productivité ; marché local.
143	38	Jumbo 1	ISRA	60	75	hative	t	f	["casamance", "senegal_oriental"]	2.50	Sélection ISRA Djibélor ; grosse noix (> 7 g), rendement élevé.
144	38	50-04	ISRA	65	80	semi-tardive	t	f	["casamance", "senegal_oriental"]	2.00	Sélection ISRA adaptée à la Casamance ; bonne tolérance à Helopeltis.
145	38	B11	ISRA Djibélor	65	80	semi-tardive	t	f	["casamance"]	2.20	Clone ISRA à forte productivité ; production régulière sur plusieurs années.
146	38	Local sélectionné	local Casamance	70	90	semi-tardive	t	f	["casamance", "senegal_oriental"]	1.20	Variété paysanne rustique ; noix petite mais adaptée aux conditions locales.
147	39	Grande Naine	Canaries / importé	300	360	semi-tardive	f	f	["niayes", "casamance", "vallee_fleuve"]	40.00	Variété commerciale dominante ; petit régime dense, bonne conservation.
148	39	Williams	Australie / importé	290	340	hative	f	f	["niayes", "casamance"]	45.00	Très productif ; fruits sucrés et aromatiques.
149	39	Gros Michel	Amérique centrale / acclimate	320	380	tardive	f	f	["casamance"]	30.00	Excellent goût mais très sensible à la maladie de Panama (Fusarium).
150	39	Laïtan	local Casamance	280	320	hative	t	f	["casamance", "senegal_oriental"]	20.00	Variété locale résistante ; petit fruit sucré, bonne adaptation.
151	40	Solo Sunrise	Hawaï / importé	270	330	semi-tardive	f	f	["niayes", "casamance", "vallee_fleuve"]	60.00	Variété hermaphrodite (dioïque) ; petits fruits orange intérieur, très sucrés.
152	40	Maradol	Cuba / importé	240	300	hative	f	f	["niayes", "vallee_fleuve", "casamance"]	80.00	Gros fruits (1,5-3 kg), chair orange, très productive ; dominante au Sénégal.
153	40	Red Lady F1	Taiwan / importé	240	280	hative	f	f	["niayes", "casamance"]	100.00	Hybride F1 très productif ; résistant au PRSV (ringspot) ; plant compact.
154	40	Tainung 1	Taiwan / importé	240	290	hative	f	f	["niayes", "vallee_fleuve"]	90.00	Tolérant au PRSV ; fruits ovales, chair ferme pour le transport.
\.


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analyses (id, org_id, user_id, farm_id, culture, region, measurements, score, verdict, advanced, created_at) FROM stdin;
1	1	1	\N	Tomate	THIES	{"Temp\\u00e9rature": 45.0, "Humidit\\u00e9": 14.0, "CE": 23.0, "pH": 6.0, "Azote": 56.0, "Phosphore": 34.0, "Potassium": 40.0, "Salinit\\u00e9": 3.0}	2	À corriger	f	2026-05-31 17:08:33.591079
2	1	1	\N	Piment		{"Temp\\u00e9rature": 34.0, "Humidit\\u00e9": 45.0, "CE": 0.15, "pH": 7.0, "Azote": 56.0, "Phosphore": 67.0, "Potassium": 56.0, "Salinit\\u00e9": 34.0}	3	À corriger	t	2026-06-03 07:24:28.302279
\.


--
-- Data for Name: champ_cartographies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_cartographies (id, parcelle_id, type_geometrie, coordonnees, projection, source_mesure, precision_m, date_mesure, actif, created_at) FROM stdin;
3	3	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.1215, "lon": -16.89}, {"lat": 15.1215, "lon": -16.8882}, {"lat": 15.12, "lon": -16.8882}]	WGS84	GPS_TERRAIN	3	2026-06-01	f	2026-06-09 17:08:35.821894+00
4	3	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.122, "lon": -16.89}, {"lat": 15.122, "lon": -16.8875}, {"lat": 15.12, "lon": -16.8875}, {"lat": 15.12, "lon": -16.89}]	WGS84	\N	\N	\N	t	2026-06-09 17:08:35.834877+00
5	4	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.121, "lon": -16.89}, {"lat": 15.121, "lon": -16.8885}, {"lat": 15.12, "lon": -16.8885}]	WGS84	GPS_TERRAIN	\N	\N	t	2026-06-09 17:11:02.849603+00
6	5	POLYGON	[{"lat": 12.567, "lon": -16.2715}, {"lat": 12.5676, "lon": -16.2715}, {"lat": 12.5676, "lon": -16.2723}, {"lat": 12.567, "lon": -16.2723}, {"lat": 12.567, "lon": -16.2715}]	WGS84	\N	3	\N	t	2026-06-10 05:41:56.268073+00
7	6	POLYGON	[{"lat": 12.5518, "lon": -12.1742}, {"lat": 12.5524, "lon": -12.1742}, {"lat": 12.5524, "lon": -12.1748}, {"lat": 12.5518, "lon": -12.1748}, {"lat": 12.5518, "lon": -12.1742}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.839055+00
8	7	POLYGON	[{"lat": 16.0175, "lon": -16.489}, {"lat": 16.0183, "lon": -16.489}, {"lat": 16.0183, "lon": -16.4902}, {"lat": 16.0175, "lon": -16.4902}, {"lat": 16.0175, "lon": -16.489}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.851136+00
9	8	POLYGON	[{"lat": 13.7703, "lon": -13.667}, {"lat": 13.7711, "lon": -13.667}, {"lat": 13.7711, "lon": -13.6678}, {"lat": 13.7703, "lon": -13.6678}, {"lat": 13.7703, "lon": -13.667}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.859664+00
\.


--
-- Data for Name: champ_infrastructures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_infrastructures (id, parcelle_id, type, nom, description, longueur_m, superficie_m2, capacite, unite_capacite, etat, annee_construction, localisation, created_at) FROM stdin;
3	3	HANGAR	Hangar Principal (révisé)	\N	\N	150	\N	\N	MOYEN	2022	{"lat": 15.1208, "lon": -16.8891}	2026-06-09 17:08:35.855581+00
4	4	CLOTURE	Clôture périmètre	\N	544.4	\N	\N	\N	BON	\N	\N	2026-06-09 17:11:02.858196+00
5	9	HANGAR	Hangar de stockage	\N	\N	\N	\N	\N	BON	2023	null	2026-06-10 13:10:01.480299+00
6	11	HANGAR	Hangar stockage	\N	\N	\N	\N	\N	BON	2023	null	2026-06-10 13:12:48.345472+00
7	13	HANGAR	Hangar Stockage Test	\N	\N	\N	\N	\N	BON	2022	null	2026-06-10 13:49:23.830409+00
8	14	HANGAR	Hangar Stockage Test	\N	\N	\N	\N	\N	BON	2022	null	2026-06-10 13:57:21.028047+00
\.


--
-- Data for Name: champ_parcelles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_parcelles (id, org_id, nom, code_parcelle, type_culture, culture_id, zone_agro, region, localite, statut, description, superficie_m2, superficie_ha, perimetre_m, centre_lat, centre_lon, score_completude, score_detail, created_at, updated_at) FROM stdin;
5	3	Parcelle Basse Casamance — Riz	PARC-003-001	\N	21	casamance	\N	\N	ACTIVE	Rizière en basse Casamance, sol hydromorphe, irrigation naturelle hivernage	5792.7	0.5793	307.1	12.5673	-16.2719	65	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 65, "manquants": ["Source d'eau", "Infrastructures", "Région", "Localité"], "sources_eau": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune source d'eau renseignée"}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Manquant : Région, Localité"}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 05:41:17.568573+00	2026-06-10 05:42:52.983132+00
12	5	Test Fix	PARC-005-005	Papaye	\N	\N	Kédougou	\N	ARCHIVE	\N	\N	\N	\N	\N	\N	13	{"sol": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune analyse sol"}, "total": 13, "manquants": ["Délimitation GPS", "Analyse sol", "Zone agro-écologique", "Source d'eau", "Infrastructures", "Localité"], "sources_eau": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune source d'eau renseignée"}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 53.3, "score": 8, "complete": false, "manquant": "Manquant : Zone agro-écologique"}, "localisation": {"max": 10, "pct": 50.0, "score": 5, "complete": false, "manquant": "Manquant : Localité"}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 13:16:45.658483+00	2026-06-10 13:16:45.776116+00
3	1	Parcelle Validation Complète	PARC-VALID-001	Oignon	\N	vallee_fleuve	Saint-Louis	Podor Centre	ARCHIVE	Parcelle principale de validation V1	32227.8	5.9681	981.5	15.12075	-16.8891	0	\N	2026-06-09 17:08:35.797083+00	2026-06-09 17:08:35.900766+00
8	6	Champ Mais Tambacounda	PARC-006-001	\N	22	senegal_oriental	Tambacounda	Koumpentoum	ACTIVE	Mais hybride BHSO2 hivernage 2026, sol ferrugineux tropical	7685.7	0.7686	350.7	13.7707	-13.6674	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:10:12.216962+00	2026-06-10 06:56:46.526471+00
4	1	Test Persistance Redémarrage	PARC-PERSIST-01	Mil	\N	bassin_arachidier	Kaolack	Nioro du Rip	ACTIVE	\N	17904.4	1.7904	544.4	15.1205	-16.88925	100	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 100, "manquants": [], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-09 17:11:02.835261+00	2026-06-09 17:11:02.886981+00
7	4	Parcelle Oignon Vallee du Fleuve	PARC-004-001	\N	30	vallee_fleuve	Saint-Louis	Podor	ACTIVE	Oignon violet de Galmi contre-saison froide, irrigation fleuve Senegal	11408.9	1.1409	434.4	16.0179	-16.4896	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:10:12.101432+00	2026-06-10 06:56:46.510494+00
9	5	Champ Test Validation	PARC-005-002	Papaye	\N	soudano_sahelien	Kédougou	Village Test	ACTIVE	Parcelle test validation bout-en-bout	\N	\N	\N	\N	\N	75	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 75, "manquants": ["Délimitation GPS"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-10 13:09:37.433119+00	2026-06-10 13:10:01.510447+00
6	5	Verger Papaye — Kédougou	PARC-005-001	\N	40	senegal_oriental	Kédougou	Saraya	ACTIVE	Verger de papayers Maradol en plein hivernage, sol ferrallitique, irrigation par pompe solaire	4344.8	0.4345	263.7	12.5521	-12.1745	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:09:46.624223+00	2026-06-10 06:56:46.488347+00
10	5	X	PARC-005-003	\N	\N	\N	\N	\N	ACTIVE	\N	\N	\N	\N	\N	\N	0	{"sol": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune analyse sol"}, "total": 0, "manquants": ["Délimitation GPS", "Analyse sol", "Culture", "Zone agro-écologique", "Source d'eau", "Infrastructures", "Région", "Localité"], "sources_eau": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune source d'eau renseignée"}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Manquant : Culture, Zone agro-écologique"}, "localisation": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Manquant : Région, Localité"}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 13:09:37.523734+00	2026-06-10 13:09:37.544228+00
11	5	Champ Test Validation	PARC-005-004	Papaye	\N	soudano_sahelien	Kédougou	Village Test	ARCHIVE	Parcelle test E2E	\N	\N	\N	\N	\N	75	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 75, "manquants": ["Délimitation GPS"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-10 13:12:48.269148+00	2026-06-10 13:12:50.38702+00
13	4	TestE2E-Tomate-1781099363	PARC-004-002	Tomate	29	niayes	Dakar	Sangalkam	ACTIVE	\N	\N	\N	\N	\N	\N	50	{"sol": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune analyse sol"}, "total": 50, "manquants": ["Délimitation GPS", "Analyse sol"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-10 13:49:23.771265+00	2026-06-10 13:49:23.839528+00
15	1	Test1	PARC-001-003	Tomate	\N	subguineen	Sédhiou	Salemata	EN_PREPARATION	La parcelle m’appartient	\N	\N	\N	\N	\N	25	{"sol": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune analyse sol"}, "total": 25, "manquants": ["Délimitation GPS", "Analyse sol", "Source d'eau", "Infrastructures"], "sources_eau": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune source d'eau renseignée"}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 15:03:43.451769+00	2026-06-10 15:03:43.499123+00
14	4	TestE2E-Tomate-1781099840	PARC-004-003	Tomate	29	niayes	Dakar	Sangalkam	ACTIVE	\N	\N	\N	\N	\N	\N	75	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 75, "manquants": ["Délimitation GPS"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 0.0, "score": 0, "complete": false, "manquant": "Délimitation GPS manquante"}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-10 13:57:20.961735+00	2026-06-10 13:57:21.036899+00
\.


--
-- Data for Name: champ_sols; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_sols (id, parcelle_id, date_analyse, texture, profondeur_labour_cm, pierrosite_pct, erosion, "pH_eau", "pH_kcl", matiere_organique, azote_total, phosphore_assim, potassium_echang, calcium, magnesium, sodium, cec, conductivite_ds_m, methode_analyse, laboratoire, reference_labo, observations, created_at) FROM stdin;
3	3	2026-04-15	ARGILO_LIMONEUX	\N	\N	FAIBLE	6.8	\N	2.3	1.1	18	0.6	\N	\N	\N	\N	0.4	\N	\N	\N	\N	2026-06-09 17:08:35.842386+00
4	3	2026-01-10	\N	\N	\N	\N	6.2	\N	\N	0.7	10	0.35	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-09 17:08:35.850823+00
5	4	\N	\N	\N	\N	\N	6.5	\N	\N	0.85	11	0.42	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-09 17:11:02.855305+00
6	5	2026-06-01	ARGILO_LIMONEUX	\N	\N	\N	5.8	\N	2.4	1.8	18.5	0.35	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 05:42:52.971809+00
7	8	2026-05-28	SABLO_LIMONEUX	\N	\N	\N	6.2	\N	1.2	0.9	12.5	0.25	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:44.593279+00
8	7	2026-04-10	LIMONEUX	\N	\N	\N	7.1	\N	3.9	2.8	35	0.72	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:44.594496+00
9	6	2026-05-15	\N	\N	\N	\N	5.3	\N	1.8	1.1	8.2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:53.290619+00
10	6	2026-06-01	SABLO_LIMONEUX	\N	\N	\N	5.3	\N	1.8	1.1	8.2	0.18	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:11:34.238522+00
11	9	2026-06-10	SABLO_LIMONEUX	25	\N	FAIBLE	6.2	5.4	1.8	0.9	12.5	0.18	\N	\N	\N	\N	0.4	\N	ISRA Kédougou	\N	Sol typique zone soudano-sahélienne	2026-06-10 13:10:01.112477+00
12	11	2026-06-10	SABLO_LIMONEUX	25	\N	FAIBLE	6.2	5.4	1.8	0.9	12.5	0.18	\N	\N	\N	\N	0.4	\N	ISRA Kédougou	\N	\N	2026-06-10 13:12:48.289243+00
13	14	2026-06-10	ARGILO_LIMONEUX	25	\N	\N	6.5	5.9	2.1	1.8	45	0.35	\N	\N	\N	\N	\N	\N	ISRA Dakar	\N	\N	2026-06-10 13:57:20.980671+00
\.


--
-- Data for Name: champ_sources_eau; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_sources_eau (id, parcelle_id, type, nom, debit_m3h, profondeur_m, "pH_eau", conductivite_ds_m, qualite, disponibilite, partage, superficie_m2, localisation, created_at) FROM stdin;
3	3	FORAGE	Forage FP1 (calibré)	25	45	7.1	0.5	BONNE	PERMANENTE	f	\N	{"lat": 15.1205, "lon": -16.8895}	2026-06-09 17:08:35.868393+00
4	4	PUITS_TRADITIONNEL	Puits central	5	\N	\N	\N	ACCEPTABLE	SAISONNIERE	f	\N	\N	2026-06-09 17:11:02.860649+00
5	6	FORAGE	Forage solaire Saraya	2.5	\N	\N	\N	BONNE	PERMANENTE	f	\N	\N	\N
6	7	CANAL_IRRIGATION	Canal vallée du fleuve Sénégal	15	\N	\N	\N	ACCEPTABLE	PERMANENTE	t	\N	\N	\N
7	8	EAU_DE_PLUIE	Mare temporaire Koumpentoum	8	\N	\N	\N	ACCEPTABLE	SAISONNIERE	t	\N	\N	\N
8	9	FORAGE	\N	3.5	\N	\N	\N	BONNE	PERMANENTE	f	\N	null	2026-06-10 13:10:01.360575+00
9	11	FORAGE	\N	3.5	\N	\N	\N	BONNE	PERMANENTE	f	\N	null	2026-06-10 13:12:48.316816+00
10	13	FORAGE	\N	12	\N	\N	\N	BONNE	PERMANENTE	f	\N	null	2026-06-10 13:49:23.805325+00
11	14	FORAGE	\N	12	\N	\N	\N	BONNE	PERMANENTE	f	\N	null	2026-06-10 13:57:21.00586+00
\.


--
-- Data for Name: credit_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_ledger (id, user_id, delta, motif, solde_apres, service_request_id, meta, cree_le) FROM stdin;
1	1	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-03 16:40:49.739664+00
2	2	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-10 05:30:50.575811+00
3	3	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-10 05:54:09.234435+00
\.


--
-- Data for Name: credit_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_purchases (id, user_id, credits, montant_fcfa, fournisseur, reference, statut, ledger_id, cree_le, paye_le) FROM stdin;
\.


--
-- Data for Name: farms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.farms (id, org_id, name, region, locality, latitude, longitude, area_ha, created_at) FROM stdin;
\.


--
-- Data for Name: gf_activites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_activites (id, org_id, parcelle_id, culture_id, consultation_id, type, statut, titre, description, date_prevue, date_debut, date_fin, duree_minutes, stade_culture, surface_traitee_ha, conditions_meteo, localisation_debut, details, note, created_by, created_at, updated_at) FROM stdin;
3	1	\N	21	\N	RECOLTE	PLANIFIE	Récolte riz hivernage	\N	2026-11-20	\N	\N	\N	\N	\N	{}	{}	{"qualite": "A", "destination": "marché local", "rendement_kg_ha": 4200, "quantite_totale_kg": 10500}	\N	1	2026-06-09 18:36:28.183674	2026-06-09 18:36:28.183676
1	1	\N	21	\N	SEMIS	TERMINE	Semis riz hivernage 2026	Semis direct sur sol préparé 2 semaines avant	2026-07-01	2026-06-09 18:36:28.402298	2026-06-09 18:36:28.439552	240	pré-germination	2.5	{"vent": 5, "temp_air": 28, "pluie_24h": 0, "humidite_rel": 75}	{"lat": 15.553, "lon": -14.213, "precision_m": 5.0}	{"methode": "manuel", "variete": "Sahel 108", "densite_kg_ha": 120, "profondeur_cm": 3}	Semis terminé. Sol bien humide.	1	2026-06-09 18:36:27.991041	2026-06-09 18:36:28.439552
2	1	\N	21	\N	FERTILISATION	ANNULE	Apport urée tallage	\N	2026-08-15	\N	\N	\N	\N	\N	{}	{}	{"K": 0, "N": 46, "P": 0, "methode": "épandage manuel", "produit": "Urée 46%", "dose_kg_ha": 100}	\N	1	2026-06-09 18:36:28.160815	2026-06-09 18:36:28.692481
4	2	\N	\N	\N	AUTRE	PLANIFIE	Test upload	\N	2026-06-10	\N	\N	\N	\N	\N	{}	{}	{}	\N	2	2026-06-10 05:31:46.726671	2026-06-10 05:31:46.726693
5	3	5	\N	\N	SEMIS	PLANIFIE	Semis riz hivernage 2026	Variété Sahel 108, semis direct à la volée, 80 kg/ha	2026-06-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:45:12.001726	2026-06-10 05:45:12.00173
6	3	5	\N	\N	FERTILISATION	PLANIFIE	Apport urée au tallage	Urée 46% à 100 kg/ha en couverture	2026-07-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:45:12.124922	2026-06-10 05:45:12.124926
7	3	5	\N	\N	TRAITEMENT	PLANIFIE	Traitement pyriculariose (tricyclazole)	Tricyclazole 75 WP 0.6 kg/ha, pulvérisation foliaire	2026-06-25	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:46:20.599207	2026-06-10 05:46:20.599211
8	5	6	\N	\N	PLANTATION	PLANIFIE	Plantation papayers Maradol	Repiquage plants 4 mois, espacement 3x3m, 180 plants/ha	2026-04-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.702455	2026-06-10 06:11:49.702458
9	5	6	\N	\N	FERTILISATION	PLANIFIE	Fumure de fond NPK 15-15-15	250 kg/ha NPK 15-15-15 en fond de fosse	2026-04-10	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.837214	2026-06-10 06:11:49.837219
10	5	6	\N	\N	IRRIGATION	PLANIFIE	Irrigation pompe solaire	Irrigation goutte-a-goutte 4L/pied/jour pendant floraison	2026-06-08	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.954664	2026-06-10 06:11:49.954667
11	4	7	\N	\N	SEMIS	PLANIFIE	Semis oignon violet Galmi	Semis en pepiniere, 3 kg semences/ha, irrigation quotidienne	2026-01-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	5	2026-06-10 06:12:59.868601	2026-06-10 06:12:59.868603
12	4	7	\N	\N	PLANTATION	PLANIFIE	Repiquage oignon	Repiquage plants 40-45j, espacement 15x20cm, 330000 plants/ha	2026-02-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	5	2026-06-10 06:12:59.975114	2026-06-10 06:12:59.975116
14	6	8	\N	\N	SEMIS	PLANIFIE	Semis mais BHSO2	Semis poquet 3 graines, espacement 80x40cm, 62500 pieds/ha	2026-06-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.221932	2026-06-10 06:13:00.221935
15	6	8	\N	\N	TRAITEMENT	PLANIFIE	Herbicide pre-levee	Atrazine 500 SC, 2L/ha en pre-levee dans les 3j apres semis	2026-06-22	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.357082	2026-06-10 06:13:00.357086
16	6	8	\N	\N	FERTILISATION	PLANIFIE	Engrais starter DAP	DAP 18-46-0, 150 kg/ha au semis en microdose	2026-06-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.471319	2026-06-10 06:13:00.471322
13	4	7	\N	\N	DESHERBAGE	PLANIFIE	Desherbage manuel 1er passage	Sarclage inter-rang, eliminer concurrence hydrique	2026-03-05	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.090963	2026-06-10 06:13:00.090966
17	5	11	\N	\N	TRAITEMENT	TERMINE	Traitement fongicide papaye	Traitement suite diagnostic maladie	2026-06-12	2026-06-10 13:12:48.563248	2026-06-10 13:12:50.353711	1	\N	0.5	{}	{}	{}	Traitement appliqué, 2 sachets de Mancozèbe dilués dans 20L	4	2026-06-10 13:12:48.530118	2026-06-10 13:12:50.353711
18	5	12	\N	\N	TRAITEMENT	PLANIFIE	Test cout fix	\N	\N	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 13:16:45.681519	2026-06-10 13:16:45.681522
19	4	14	\N	\N	TRAITEMENT	TERMINE	Application fongicide mildiou	Traitement curatif mildiou suite consultation E2E	2026-06-11	2026-06-10 13:57:21.264985	2026-06-10 13:57:21.348024	1	\N	1.5	{}	{}	{}	\N	5	2026-06-10 13:57:21.243592	2026-06-10 13:57:21.348024
\.


--
-- Data for Name: gf_couts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_couts (id, activite_id, org_id, categorie, sous_categorie, description, quantite, unite, prix_unitaire_fcfa, montant_total_fcfa, fournisseur, date_achat, recu, note, created_at) FROM stdin;
2	1	1	MATERIEL	\N	Location tracteur	\N	\N	\N	45000	\N	\N	f	\N	2026-06-09 18:36:28.488513
3	5	3	INTRANT	\N	Semences riz Sahel 108 — 46 kg	46	kg	800	36800	\N	\N	f	\N	2026-06-10 05:46:42.535997
4	6	3	INTRANT	\N	Urée 46% — 58 kg	58	kg	500	29000	\N	\N	f	\N	2026-06-10 05:46:42.649516
5	7	3	INTRANT	\N	Tricyclazole 75 WP — 0.35 kg	0.35	kg	12000	4200	\N	\N	f	\N	2026-06-10 05:46:42.777729
6	12	4	PRESTATION	\N	Main oeuvre repiquage 10 personnes 2 jours	20	jour-personne	3000	60000	\N	\N	f	\N	2026-06-10 06:13:32.084257
7	9	5	INTRANT	\N	NPK 15-15-15	109	kg	450	49050	\N	\N	f	\N	2026-06-10 06:13:32.104613
8	8	5	INTRANT	\N	Plants papayers Maradol 4 mois	80	pieds	500	40000	\N	\N	f	\N	2026-06-10 06:13:32.123455
9	14	6	INTRANT	\N	Semences mais BHSO2 certifiees	25	kg	1200	30000	\N	\N	f	\N	2026-06-10 06:13:32.178252
10	11	4	INTRANT	\N	Semences oignon Galmi certifiees	3.4	kg	8500	28900	\N	\N	f	\N	2026-06-10 06:13:32.184408
11	16	6	INTRANT	\N	DAP 18-46-0	115	kg	600	69000	\N	\N	f	\N	2026-06-10 06:13:32.197031
12	18	5	INTRANT	\N	Fongicide Mancozèbe 80% WP 500g	2	sachets	\N	3500	Agri-Sénégal	\N	f	\N	2026-06-10 13:16:45.746458
13	19	4	INTRANT	\N	Mancozèbe 80 WP 1kg	2	kg	3500	7000	\N	\N	f	\N	2026-06-10 13:57:21.288526
\.


--
-- Data for Name: gf_journal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_journal (id, org_id, parcelle_id, activite_id, date_entree, type, titre, contenu, created_by, created_at) FROM stdin;
1	1	\N	1	2026-07-01	OBSERVATION	Humidité sol satisfaisante	Sol à 70% capacité au champ. Levée prévue J+7. Pas de signe de stress hydrique.	1	2026-06-09 18:36:28.590259
2	1	\N	\N	2026-07-05	ALERTE	Risque foreur de tige	Observation de papillons Chilo suppressalis sur parcelle voisine. Surveillance renforcée.	1	2026-06-09 18:36:28.606082
3	5	12	\N	2026-06-10	OBSERVATION	\N	Test validation — taches foliaires observées sur papaye.	4	2026-06-10 13:16:45.76126
4	4	13	\N	2026-06-10	NOTE_TERRAIN	\N	Traitement fongicide appliqué. Conditions météo favorables.	5	2026-06-10 13:49:24.114133
5	4	14	\N	2026-06-10	NOTE_TERRAIN	\N	Traitement fongicide appliqué. Conditions météo favorables.	5	2026-06-10 13:57:21.325887
\.


--
-- Data for Name: gf_main_oeuvre; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_main_oeuvre (id, activite_id, org_id, type, description, nb_personnes, duree_jours, taux_journalier_fcfa, montant_total_fcfa, note, created_at) FROM stdin;
1	1	1	SALARIALE	Semeurs journaliers	8	2	3500	56000	\N	2026-06-09 18:36:28.544326
2	1	1	FAMILIALE	Aide famille	3	1	0	0	\N	2026-06-09 18:36:28.561852
3	19	4	SALARIALE	\N	3	1	5000	15000	\N	2026-06-10 13:57:21.310435
\.


--
-- Data for Name: gf_preuves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_preuves (id, activite_id, org_id, type, filename, url, thumbnail_url, duree_secondes, taille_ko, source, localisation, horodatage_terrain, photo_meta, uploaded_at) FROM stdin;
1	4	2	PHOTO	d34fd65cb16d42bf84a07373314c27f6.jpg	/uploads/activites/d34fd65cb16d42bf84a07373314c27f6.jpg	\N	\N	0	SMARTPHONE	{}	\N	{"taille_b": 11, "mime_type": "image/jpeg", "hash_sha256": "e854cd7df58701513873cd64d87128f98ee0acac31d340e09fde7cad4e69cdb1", "original_name": "hostname"}	2026-06-10 05:31:46.819066
\.


--
-- Data for Name: ia_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_config (id, org_id, langue, ton, focus_cultures, inclure_meteo, inclure_regles, inclure_historique_sante, inclure_couts, updated_at) FROM stdin;
1	1	fr	PEDAGOGIQUE	{arachide,mil}	t	t	t	t	2026-06-09 19:31:44.933023
2	3	fr	SIMPLE	\N	t	t	t	t	2026-06-10 05:52:08.293929
3	5	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:27.763651
4	4	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:43.467496
5	6	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:43.934825
\.


--
-- Data for Name: ia_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_conversations (id, org_id, user_id, parcelle_id, culture_id, titre, statut, mode, nb_messages, tokens_total, contexte_init, mois_periode, created_at, updated_at) FROM stdin;
2	1	1	4	\N	Test avec parcelle active	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-09 19:31:02.169189	2026-06-09 19:31:02.551231
3	1	1	4	\N	Analyse — Test Persistance Redémarrage	ACTIVE	ANALYSE_PARCELLE	2	0	\N	2026-06	2026-06-09 19:31:28.525996	2026-06-09 19:31:28.582734
1	1	1	3	\N	Test IA	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-09 19:29:34.3245	2026-06-09 19:31:58.485214
4	3	3	5	\N	Conseil riz hivernage 2026	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 05:52:08.126028	2026-06-10 05:53:09.860942
5	3	3	5	\N	Conseil riz hivernage 2026 — V2	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 05:53:41.220799	2026-06-10 05:53:41.417615
10	3	3	\N	\N	Test technique	ACTIVE	LIBRE	4	0	\N	2026-06	2026-06-10 12:47:01.828036	2026-06-10 12:47:02.276073
6	5	4	6	\N	Taches jaunes sur papaye Kedougou	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:27.631831	2026-06-10 13:25:31.418663
7	4	5	7	\N	Thrips oignon Saint-Louis	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:43.363019	2026-06-10 13:25:31.41867
8	6	6	8	\N	Fertilisation mais hivernage Tambacounda	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:43.835284	2026-06-10 13:25:31.418671
9	5	4	6	\N	Analyse complète verger papaye Kedougou	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-10 06:30:05.451556	2026-06-10 13:25:31.418672
11	5	4	11	\N	Conseil traitement papaye	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-10 13:12:50.254068	2026-06-10 13:25:31.418673
12	4	5	13	\N	Test E2E - Conseil traitement mildiou tomate	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 13:49:24.992727	2026-06-10 13:49:25.058331
13	4	5	14	\N	Test E2E - Conseil traitement mildiou tomate	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 13:57:21.89493	2026-06-10 13:57:21.957603
\.


--
-- Data for Name: ia_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_feedback (id, org_id, conversation_id, message_id, recommandation_id, note, utile, commentaire, amelioration, created_at) FROM stdin;
1	1	2	4	\N	4	t	Bonne analyse du sol	Ajouter des recommandations engrais spécifiques	2026-06-09 19:31:44.81985
2	4	13	29	\N	5	\N	Réponse pertinente, merci	\N	2026-06-10 13:57:21.99431
\.


--
-- Data for Name: ia_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_messages (id, conversation_id, org_id, role, contenu, tokens_in, tokens_out, modele, duree_ms, contexte_inject, regles_codes, created_at) FROM stdin;
1	1	1	USER	Quelle est la situation de ma parcelle et que dois-je faire en priorité ?	\N	\N	\N	\N	\N	\N	2026-06-09 19:29:45.420493
2	1	1	ASSISTANT	Je n'ai pas accès à vos données de parcelles pour générer des recommandations. Ajoutez une parcelle dans Mon Champ pour des conseils personnalisés.	0	0	fallback_rules	16	{"regles": 0, "alertes": 0, "parcelles": 0}	\N	2026-06-09 19:29:45.43603
3	2	1	USER	Quelle est la situation de ma parcelle et quelles sont mes priorités ?	\N	\N	\N	\N	\N	\N	2026-06-09 19:31:02.432741
4	2	1	ASSISTANT	**Analyse agronomique pour Test Persistance Redémarrage ()**\n\nZone : bassin_arachidier | Sol : pH 6.5, azote_g_kg 0.8, phosphore_mg_kg 11.0\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	116	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-09 19:31:02.547307
5	3	1	USER	Fais une analyse complète de la parcelle Test Persistance Redémarrage. Identifie les problèmes actuels et donne 3 à 5 recommandations prioritaires.	\N	\N	\N	\N	\N	\N	2026-06-09 19:31:28.540332
6	3	1	ASSISTANT	**Analyse agronomique pour Test Persistance Redémarrage ()**\n\nZone : bassin_arachidier | Sol : pH 6.5, azote_g_kg 0.8, phosphore_mg_kg 11.0\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	41	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-09 19:31:28.581931
8	4	3	USER	Mon riz présente des taches brunes sur les feuilles depuis 10 jours. Environ 20% des plants sont touchés. Que faire ?	\N	\N	\N	\N	\N	\N	2026-06-10 05:53:09.778619
9	4	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\n⚠ **[RAV-RIZ-001] Foreur de tige riz — Conditions favorables tallage** (elevee)\n  • {'titre': 'Risque Foreur tige riz', 'niveau': 'elevee', 'message': 'Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts.'}	0	0	fallback_rules	82	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 05:53:09.860036
10	5	3	USER	Mon riz présente des taches brunes sur les feuilles depuis 10 jours. Environ 20% des plants sont touchés. Que faire ?	\N	\N	\N	\N	\N	\N	2026-06-10 05:53:41.339018
11	5	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\n⚠ **[RAV-RIZ-001] Foreur de tige riz — Conditions favorables tallage** (elevee)\n  • Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts.\n\nRECOMMANDATION : Granulés insecticides au tallage\nACTION : Appliquer : Granulés insecticides au tallage\nPOURQUOI : Règle agronomique RAV-RIZ-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	78	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 05:53:41.41678
12	6	5	USER	Mes papayers ont des taches jaunes sur les feuilles et les fruits sont deformes. 35% des plants sont touches. Cest grave ?	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:27.77246
13	6	5	ASSISTANT	**Analyse agronomique pour Verger Papaye — Kédougou (Papaye)**\n\nZone : senegal_oriental | Sol : pH 5.3, azote_g_kg 1.1, phosphore_mg_kg 8.2, texture sablo_limoneux, matiere_organique_pct 1.8\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	50	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-10 06:14:27.822741
14	7	4	USER	Jai des thrips sur mon oignon, les feuilles sont trouees et argentees. Comment traiter ? Jai 1.1 ha en bulbaison.	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:43.482275
15	7	4	ASSISTANT	**Analyse agronomique pour Parcelle Oignon Vallee du Fleuve (Oignon)**\n\nZone : vallee_fleuve | Sol : pH 7.1, azote_g_kg 2.8, phosphore_mg_kg 35.0, texture limoneux, matiere_organique_pct 3.9\n\n\n⚠ **[FER-OIG-001] Oignon — Carence N croissance-bulbaison** (elevee)\n  • N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite.\n\nRECOMMANDATION : Urée fractionné + arrêt 4 semaines avant récolte\nACTION : Appliquer : Urée fractionné + arrêt 4 semaines avant récolte\nPOURQUOI : Règle agronomique FER-OIG-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	223	{"regles": 0, "alertes": 2, "parcelles": 1}	\N	2026-06-10 06:14:43.705313
16	8	6	USER	Mon sol a peu dazote (0.9 g/kg) et peu de matiere organique (1.2%). Quel programme de fertilisation pour le mais BHSO2 en hivernage ? Budget 150000 FCFA pour 0.77 ha.	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:43.939303
17	8	6	ASSISTANT	**Analyse agronomique pour Champ Mais Tambacounda (Maïs)**\n\nZone : senegal_oriental | Sol : pH 6.2, azote_g_kg 0.9, phosphore_mg_kg 12.5, texture sablo_limoneux, matiere_organique_pct 1.2\n\n\n⚠ **[FER-MAI-001] Maïs — Carence N critique levée** (elevee)\n  • N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé.\n\nRECOMMANDATION : Programme NPK maïs\nACTION : Appliquer : Programme NPK maïs\nPOURQUOI : Règle agronomique FER-MAI-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	40	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 06:14:43.980351
18	9	5	USER	Quels sont les principaux risques pour mon verger de papaye en ce moment ?	\N	\N	\N	\N	\N	\N	2026-06-10 06:30:05.75678
19	9	5	ASSISTANT	**Analyse agronomique pour Verger Papaye — Kédougou (Papaye)**\n\nZone : senegal_oriental | Sol : pH 5.3, azote_g_kg 1.1, phosphore_mg_kg 8.2, texture sablo_limoneux, matiere_organique_pct 1.8\n\n\n⚠ **[MAL-PAP-003] Anthracnose papaye — Humidité maturité fruits** (elevee)\n  • Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte.\n\nRECOMMANDATION : Carbendazime précolte\nACTION : Appliquer : Carbendazime précolte\nPOURQUOI : Règle agronomique MAL-PAP-003 déclenchée\nDÉLAI : 7 jours\n\nRECOMMANDATION : Trempage eau chaude 50°C 20min\nACTION : Appliquer : Trempage eau chaude 50°C 20min\nPOURQUOI : Règle agronomique MAL-PAP-003 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[RAV-PAP-001] Mouche des fruits papaye — Maturation** (elevee)\n  • Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées.\n\nRECOMMANDATION : Appât protéiné GF-120\nACTION : Appliquer : Appât protéiné GF-120\nPOURQUOI : Règle agronomique RAV-PAP-001 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[SOL-PAP-002] Papaye — Carence matière organique** (elevee)\n  • MO 1.8% < seuil 2.0%. Rétention eau et nutrition minérale insuffisantes pour papaye.\n\nRECOMMANDATION : Apport compost mature + fumier\nACTION : Appliquer : Apport compost mature + fumier\nPOURQUOI : Règle agronomique SOL-PAP-002 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[FER-PAP-001] Papaye — Carence N croissance** (elevee)\n  • N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification.\n\nRECOMMANDATION : NPK + Urée mensuel\nACTION : Appliquer : NPK + Urée mensuel\nPOURQUOI : Règle agronomique FER-PAP-001 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[SOL-PAP-001] Papaye — Sol acide pH critique** (elevee)\n  • pH 5.3 < seuil optimal 5.5-7.0. Toxicité Al/Mn, carence Ca-Mg, croissance ralentie.\n\nRECOMMANDATION : Chaulage correctif calcaire dolomitique\nACTION : Appliquer : Chaulage correctif calcaire dolomitique\nPOURQUOI : Règle agronomique SOL-PAP-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	103	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-10 06:30:05.859049
20	10	3	USER	Test de régression — ceci est un message de test automatique.	\N	\N	\N	\N	\N	\N	2026-06-10 12:47:01.849899
21	10	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	276	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 12:47:02.125517
22	10	3	USER	Quelles sont les maladies courantes du riz en hivernage ?	\N	\N	\N	\N	\N	\N	2026-06-10 12:47:02.164328
23	10	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	112	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 12:47:02.27451
24	11	5	USER	Mes plants de papaye ont des taches jaunes sur les feuilles depuis 3 jours. Que faire ?	\N	\N	\N	\N	\N	\N	2026-06-10 13:12:50.272487
25	11	5	ASSISTANT	**Analyse agronomique pour Champ Test Validation ()**\n\nZone : soudano_sahelien | Sol : pH 6.2, azote_g_kg 0.9, phosphore_mg_kg 12.5, texture sablo_limoneux, matiere_organique_pct 1.8\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	47	{"regles": 0, "alertes": 3, "parcelles": 1}	\N	2026-06-10 13:12:50.320313
26	12	4	USER	J'observe des taches brunes sur mes tomates. Quels traitements recommandez-vous contre le mildiou?	\N	\N	\N	\N	\N	\N	2026-06-10 13:49:25.010357
27	12	4	ASSISTANT	**Analyse agronomique pour TestE2E-Tomate-1781099363 (Tomate)**\n\nZone : niayes | Sol : non renseigné\n\n\n⚠ **[MAL-TOM-002] Mildiou tomate — Symptômes actifs** (critique)\n  • Mildiou actif détecté. Intervention curative d'urgence.\n\nRECOMMANDATION : Cymoxanil + Mancozèbe curatif\nACTION : Appliquer : Cymoxanil + Mancozèbe curatif\nPOURQUOI : Règle agronomique MAL-TOM-002 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[RAV-TOM-001] Mineuse tomate — Conditions chaleur modérée** (elevee)\n  • Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement.\n\nRECOMMANDATION : Emamectine ou Chlorantraniliprole\nACTION : Appliquer : Emamectine ou Chlorantraniliprole\nPOURQUOI : Règle agronomique RAV-TOM-001 déclenchée\nDÉLAI : 7 jours\n\nRECOMMANDATION : Pièges phéromone (1/500m²)\nACTION : Appliquer : Pièges phéromone (1/500m²)\nPOURQUOI : Règle agronomique RAV-TOM-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	47	{"regles": 0, "alertes": 4, "parcelles": 1}	\N	2026-06-10 13:49:25.057442
28	13	4	USER	J'observe des taches brunes sur mes tomates. Quels traitements recommandez-vous contre le mildiou?	\N	\N	\N	\N	\N	\N	2026-06-10 13:57:21.912241
29	13	4	ASSISTANT	**Analyse agronomique pour TestE2E-Tomate-1781099840 (Tomate)**\n\nZone : niayes | Sol : pH 6.5, azote_g_kg 1.8, phosphore_mg_kg 45.0, texture argilo_limoneux, matiere_organique_pct 2.1\n\n\n⚠ **[MAL-TOM-002] Mildiou tomate — Symptômes actifs** (critique)\n  • Mildiou actif détecté. Intervention curative d'urgence.\n\nRECOMMANDATION : Cymoxanil + Mancozèbe curatif\nACTION : Appliquer : Cymoxanil + Mancozèbe curatif\nPOURQUOI : Règle agronomique MAL-TOM-002 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[RAV-TOM-001] Mineuse tomate — Conditions chaleur modérée** (elevee)\n  • Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement.\n\nRECOMMANDATION : Emamectine ou Chlorantraniliprole\nACTION : Appliquer : Emamectine ou Chlorantraniliprole\nPOURQUOI : Règle agronomique RAV-TOM-001 déclenchée\nDÉLAI : 7 jours\n\nRECOMMANDATION : Pièges phéromone (1/500m²)\nACTION : Appliquer : Pièges phéromone (1/500m²)\nPOURQUOI : Règle agronomique RAV-TOM-001 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[FER-TOM-001] Tomate — Carence N croissance-floraison** (elevee)\n  • N <100 mg/kg : feuilles vert pâle, floraison réduite, fruits petits.\n\nRECOMMANDATION : Fertigation N ou apport sol\nACTION : Appliquer : Fertigation N ou apport sol\nPOURQUOI : Règle agronomique FER-TOM-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	45	{"regles": 0, "alertes": 5, "parcelles": 1}	\N	2026-06-10 13:57:21.956641
\.


--
-- Data for Name: ia_recommandations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_recommandations (id, org_id, conversation_id, message_id, parcelle_id, culture_id, categorie, priorite, titre, action, justification, sources, echeance_jours, statut, confiance, created_at) FROM stdin;
1	4	12	27	13	\N	GENERAL	3	Cymoxanil + Mancozèbe curatif	Appliquer : Cymoxanil + Mancozèbe curatif	Règle agronomique MAL-TOM-002 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:49:25.064941
2	4	12	27	13	\N	GENERAL	3	Emamectine ou Chlorantraniliprole	Appliquer : Emamectine ou Chlorantraniliprole	Règle agronomique RAV-TOM-001 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:49:25.064944
3	4	12	27	13	\N	SOL	3	Pièges phéromone (1/500m²)	Appliquer : Pièges phéromone (1/500m²)	Règle agronomique RAV-TOM-001 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:49:25.064945
4	4	13	29	14	\N	GENERAL	3	Cymoxanil + Mancozèbe curatif	Appliquer : Cymoxanil + Mancozèbe curatif	Règle agronomique MAL-TOM-002 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:57:21.968157
5	4	13	29	14	\N	GENERAL	3	Emamectine ou Chlorantraniliprole	Appliquer : Emamectine ou Chlorantraniliprole	Règle agronomique RAV-TOM-001 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:57:21.968161
6	4	13	29	14	\N	SOL	3	Pièges phéromone (1/500m²)	Appliquer : Pièges phéromone (1/500m²)	Règle agronomique RAV-TOM-001 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:57:21.968162
7	4	13	29	14	\N	SOL	3	Fertigation N ou apport sol	Appliquer : Fertigation N ou apport sol	Règle agronomique FER-TOM-001 déclenchée	\N	7	NOUVELLE	0.6	2026-06-10 13:57:21.968163
\.


--
-- Data for Name: mt_alertes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_alertes (id, org_id, parcelle_id, culture_id, type_alerte, sous_type, niveau, titre, message, details, regle_code, valable_du, valable_au, lu, lu_le, action_prise, created_at) FROM stdin;
1	3	5	21	RAVAGEUR	insecte	AVERTISSEMENT	Foreur de tige riz — Conditions favorables tallage	Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts. — Recommandation : Granulés insecticides au tallage	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.78, "contexte_meteo": {"temp": 24.2, "humidite": 89, "pluie_mm": 0.0}, "recommandations": ["Granulés insecticides au tallage"]}	RAV-RIZ-001	2026-06-10 05:50:57.905347	\N	f	\N	f	2026-06-10 05:50:57.919745
2	5	6	40	FERTILISATION	azote	INFO	Papaye — Carence N croissance	N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification. — Recommandation : NPK + Urée mensuel	{"gravite": "moyenne", "categorie": "fertilisation", "confiance": 0.72, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["NPK + Urée mensuel"]}	FER-PAP-001	2026-06-10 06:14:14.566158	\N	f	\N	f	2026-06-10 06:14:14.572496
3	4	7	30	METEO	secheresse	AVERTISSEMENT	Risque sécheresse : 7 jours sans pluie prévus	7 jours sans précipitations prévues. Surveiller humidité sol.	{"seuil": 7, "jours_sans_pluie": 7}	\N	2026-06-10 06:14:14.801177	\N	f	\N	f	2026-06-10 06:14:14.801704
4	4	7	30	FERTILISATION	azote	AVERTISSEMENT	Oignon — Carence N croissance-bulbaison	N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite. — Recommandation : Urée fractionné + arrêt 4 semaines avant récolte	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.85, "contexte_meteo": {"temp": 22.6, "humidite": 89, "pluie_mm": 0.0}, "recommandations": ["Urée fractionné + arrêt 4 semaines avant récolte"]}	FER-OIG-001	2026-06-10 06:14:14.838352	\N	f	\N	f	2026-06-10 06:14:14.843392
5	6	8	22	FERTILISATION	azote	AVERTISSEMENT	Maïs — Carence N critique levée	N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé. — Recommandation : Programme NPK maïs	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.9, "contexte_meteo": {"temp": 24.9, "humidite": 96, "pluie_mm": 0.3}, "recommandations": ["Programme NPK maïs"]}	FER-MAI-001	2026-06-10 06:14:15.112528	\N	f	\N	f	2026-06-10 06:14:15.116662
6	5	6	40	MALADIE	fongique	AVERTISSEMENT	Anthracnose papaye — Humidité maturité fruits	Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte. — Recommandation : Carbendazime précolte	{"gravite": "elevee", "categorie": "maladie", "confiance": 0.78, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Carbendazime précolte", "Trempage eau chaude 50°C 20min"]}	MAL-PAP-003	2026-06-10 06:58:47.54582	\N	f	\N	f	2026-06-10 06:58:47.569417
7	5	6	40	RAVAGEUR	insecte	AVERTISSEMENT	Mouche des fruits papaye — Maturation	Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées. — Recommandation : Appât protéiné GF-120	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.85, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Appât protéiné GF-120"]}	RAV-PAP-001	2026-06-10 06:58:47.554003	\N	f	\N	f	2026-06-10 06:58:47.569422
8	5	6	40	FERTILISATION	amendement	AVERTISSEMENT	Papaye — Sol acide pH critique	pH 5.3 < seuil optimal 5.5-7.0. Toxicité Al/Mn, carence Ca-Mg, croissance ralentie. — Recommandation : Chaulage correctif calcaire dolomitique	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.85, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Chaulage correctif calcaire dolomitique"]}	SOL-PAP-001	2026-06-10 06:58:47.561997	\N	f	\N	f	2026-06-10 06:58:47.569423
9	4	13	29	METEO	secheresse	CRITIQUE	Sécheresse critique : 16 jours sans pluie prévus	16 jours consécutifs sans précipitations prévues. Irrigation d'urgence recommandée.	{"seuil": 14, "jours_sans_pluie": 16}	\N	2026-06-10 13:49:24.852061	\N	f	\N	f	2026-06-10 13:49:24.853719
10	4	13	29	RAVAGEUR	insecte	AVERTISSEMENT	Mineuse tomate — Conditions chaleur modérée	Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement. — Recommandation : Emamectine ou Chlorantraniliprole	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.88, "contexte_meteo": {"temp": 26.9, "humidite": 68, "pluie_mm": 0.0}, "recommandations": ["Emamectine ou Chlorantraniliprole", "Pièges phéromone (1/500m²)"]}	RAV-TOM-001	2026-06-10 13:49:24.917906	\N	f	\N	f	2026-06-10 13:49:24.928942
11	4	14	29	METEO	secheresse	CRITIQUE	Sécheresse critique : 16 jours sans pluie prévus	16 jours consécutifs sans précipitations prévues. Irrigation d'urgence recommandée.	{"seuil": 14, "jours_sans_pluie": 16}	\N	2026-06-10 13:57:21.743521	\N	f	\N	f	2026-06-10 13:57:21.745022
12	4	14	29	RAVAGEUR	insecte	AVERTISSEMENT	Mineuse tomate — Conditions chaleur modérée	Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement. — Recommandation : Emamectine ou Chlorantraniliprole	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.88, "contexte_meteo": {"temp": 26.9, "humidite": 68, "pluie_mm": 0.0}, "recommandations": ["Emamectine ou Chlorantraniliprole", "Pièges phéromone (1/500m²)"]}	RAV-TOM-001	2026-06-10 13:57:21.835641	\N	f	\N	f	2026-06-10 13:57:21.848395
13	4	14	29	FERTILISATION	azote	AVERTISSEMENT	Tomate — Carence N croissance-floraison	N <100 mg/kg : feuilles vert pâle, floraison réduite, fruits petits. — Recommandation : Fertigation N ou apport sol	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.88, "contexte_meteo": {"temp": 26.9, "humidite": 68, "pluie_mm": 0.0}, "recommandations": ["Fertigation N ou apport sol"]}	FER-TOM-001	2026-06-10 13:57:21.84193	\N	f	\N	f	2026-06-10 13:57:21.848398
\.


--
-- Data for Name: mt_conditions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_conditions (id, org_id, parcelle_id, lat, lon, zone_agro, source, temp_actuelle, temp_min, temp_max, humidite_rel, pluie_mm, vent_kmh, direction_vent, etp_mm, code_meteo, description_fr, date_releve, heure_releve, expire_le, created_at) FROM stdin;
2	1	3	15.12075	-16.8891	vallee_fleuve	CAPTEUR	32.5	\N	\N	65	0	8	292	0	2	Partiellement nuageux	2026-06-09	2026-06-09 19:04:26.480724	2026-06-09 20:03:57.603161	2026-06-09 19:03:57.716268
6	6	8	13.7707	-13.6674	senegal_oriental	OPEN_METEO	24.9	\N	\N	96	0.3	7.1	207	0	55	Bruine dense	2026-06-10	2026-06-10 06:14:14.161085	2026-06-10 07:14:14.161085	2026-06-10 06:14:14.27567
1	1	4	15.1205	-16.88925	bassin_arachidier	OPEN_METEO	26.7	\N	\N	69	0	9.8	317	0	3	Couvert	2026-06-10	2026-06-10 11:59:20.257598	2026-06-10 12:59:20.257598	2026-06-09 19:02:47.775847
3	3	5	12.5673	-16.2719	casamance	OPEN_METEO	33.8	\N	\N	45	0	8.6	102	0	2	Partiellement nuageux	2026-06-10	2026-06-10 12:47:01.247893	2026-06-10 13:47:01.247893	2026-06-10 05:47:21.973771
7	5	11	12.55	-12.18	soudano_sahelien	CAPTEUR	34.5	22	38	68	0	18	\N	\N	\N	\N	2026-06-10	2026-06-10 13:12:48.599444	2026-06-10 19:12:48.599444	2026-06-10 13:12:48.604231
4	5	6	12.5521	-12.1745	senegal_oriental	OPEN_METEO	30	\N	\N	67	0	5.8	70	0	3	Couvert	2026-06-10	2026-06-10 13:12:48.763904	2026-06-10 14:12:48.763904	2026-06-10 06:14:13.850136
8	5	9	14.13	-15.55	soudano_sahelien	OPEN_METEO	34.5	\N	\N	37	0	3.1	204	0	3	Couvert	2026-06-10	2026-06-10 13:12:49.037383	2026-06-10 14:12:49.037383	2026-06-10 13:12:49.137993
9	5	10	14.13	-15.55	\N	OPEN_METEO	34.5	\N	\N	37	0	3.1	204	0	3	Couvert	2026-06-10	2026-06-10 13:12:49.384566	2026-06-10 14:12:49.384566	2026-06-10 13:12:49.497129
5	4	7	16.0179	-16.4896	vallee_fleuve	OPEN_METEO	27.4	\N	\N	64	0	14.6	274	0	1	Principalement dégagé	2026-06-10	2026-06-10 13:49:24.166582	2026-06-10 14:49:24.166582	2026-06-10 06:14:14.066022
10	4	13	14.7	-17.43	niayes	OPEN_METEO	26.9	\N	\N	68	0	13.8	336	0	3	Couvert	2026-06-10	2026-06-10 13:49:24.310432	2026-06-10 14:49:24.310432	2026-06-10 13:49:24.421181
11	4	14	14.7	-17.43	niayes	OPEN_METEO	26.9	\N	\N	68	0	13.8	336	0	3	Couvert	2026-06-10	2026-06-10 13:57:21.370033	2026-06-10 14:57:21.370033	2026-06-10 13:57:21.476467
\.


--
-- Data for Name: mt_config_alertes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_config_alertes (id, org_id, seuils, alertes_meteo_actives, alertes_maladies_actives, alertes_ravageurs_actives, alertes_fertilisation_actives, alertes_irrigation_actives, alertes_planificateur_actives, heure_envoi_alertes, updated_at) FROM stdin;
1	1	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 25, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-09 19:04:10.578432
2	3	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 05:47:30.222442
3	5	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.396585
4	4	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.680832
5	6	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.966644
\.


--
-- Data for Name: mt_planificateur; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_planificateur (id, org_id, parcelle_id, culture_id, activite_id, date_recommandee, type_activite, titre, priorite, raison, fenetre_debut, fenetre_fin, conditions_ok, detail_conditions, statut, source, genere_le, expire_le) FROM stdin;
1	5	6	40	8	2026-06-10	plantation	Fenêtre optimale : Plantation papayers Maradol le 10/06	3	Conditions favorables : pluie 8mm, vent 20km/h, temp max 32.2°C	2026-06-10	2026-06-24	t	{"temp_ok": true, "pluie_ok": true}	RECOMMANDE	METEO	2026-06-10 13:12:49.67818	2026-06-17
2	5	6	40	9	2026-06-10	fertilisation	Fenêtre optimale : Fumure de fond NPK 15-15-15 le 10/06	3	Conditions favorables : pluie 8mm, vent 20km/h, temp max 32.2°C	2026-06-10	2026-06-24	t	{"vent_ok": true}	RECOMMANDE	METEO	2026-06-10 13:12:49.678183	2026-06-17
3	5	6	40	10	2026-06-11	irrigation	Fenêtre optimale : Irrigation pompe solaire le 11/06	2	Conditions favorables : pluie 3mm, vent 20km/h, temp max 33.9°C	2026-06-10	2026-06-24	t	{"etp_ok": true, "pluie_ok": true}	RECOMMANDE	METEO	2026-06-10 13:12:49.678184	2026-06-17
4	4	7	30	11	2026-06-10	semis	Fenêtre optimale : Semis oignon violet Galmi le 10/06	3	Conditions favorables : pluie 0mm, vent 15km/h, temp max 27.6°C	2026-06-10	2026-06-24	t	{"vent_ok": true, "pluie_ok": true, "temp_min_ok": true}	RECOMMANDE	METEO	2026-06-10 13:49:24.945738	2026-06-17
5	4	7	30	12	2026-06-10	plantation	Fenêtre optimale : Repiquage oignon le 10/06	3	Conditions favorables : pluie 0mm, vent 15km/h, temp max 27.6°C	2026-06-10	2026-06-24	t	{"temp_ok": true, "pluie_ok": true}	RECOMMANDE	METEO	2026-06-10 13:49:24.945741	2026-06-17
6	4	7	30	13	2026-06-10	desherbage	Fenêtre optimale : Desherbage manuel 1er passage le 10/06	3	Conditions favorables : pluie 0mm, vent 15km/h, temp max 27.6°C	2026-06-10	2026-06-24	t	{"vent_ok": true, "pluie_ok": true}	RECOMMANDE	METEO	2026-06-10 13:49:24.945743	2026-06-17
\.


--
-- Data for Name: mt_previsions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_previsions (id, org_id, parcelle_id, lat, lon, zone_agro, source, horizon_jours, donnees, genere_le, expire_le) FROM stdin;
1	1	\N	14.7	-17.43	niayes	open_meteo	7	[{"date": "2026-06-09", "etp_mm": 4.4, "pluie_mm": 0.0, "temp_max": 26.5, "temp_min": 22.4, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-10", "etp_mm": 4.72, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.8, "vent_kmh": 16.9, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.1, "temp_min": 23.5, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-12", "etp_mm": 4.88, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.2, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.91, "pluie_mm": 0.0, "temp_max": 27.3, "temp_min": 23.9, "vent_kmh": 16.9, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.4, "temp_min": 23.6, "vent_kmh": 16.8, "code_meteo": 3, "humidite_pct": 84, "description_fr": "Couvert", "pluie_proba_pct": 3}, {"date": "2026-06-15", "etp_mm": 4.7, "pluie_mm": 1.2, "temp_max": 28.3, "temp_min": 24.8, "vent_kmh": 24.4, "code_meteo": 51, "humidite_pct": 87, "description_fr": "Bruine légère", "pluie_proba_pct": 8}]	2026-06-09 19:02:48.077902	2026-06-10 01:02:48.077902
2	1	4	15.1205	-16.88925	bassin_arachidier	open_meteo	16	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-23", "etp_mm": 5.18, "pluie_mm": 0.0, "temp_max": 30.6, "temp_min": 24.2, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-24", "etp_mm": 5.67, "pluie_mm": 0.0, "temp_max": 30.6, "temp_min": 23.3, "vent_kmh": 23.1, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 6}]	2026-06-09 19:03:20.341509	2026-06-10 01:03:20.341509
3	1	3	15.12075	-16.8891	vallee_fleuve	open_meteo	7	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}]	2026-06-09 19:03:57.775427	2026-06-10 01:03:57.775427
4	1	3	15.12075	-16.8891	vallee_fleuve	open_meteo	14	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}]	2026-06-09 19:04:10.221305	2026-06-10 01:04:10.221305
5	1	4	15.1205	-16.88925	bassin_arachidier	open_meteo	14	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}]	2026-06-09 19:04:10.383501	2026-06-10 01:04:10.383501
6	3	5	12.5673	-16.2719	casamance	open_meteo	3	[{"date": "2026-06-10", "etp_mm": 5.09, "pluie_mm": 0.7, "temp_max": 35.5, "temp_min": 24.2, "vent_kmh": 13.9, "code_meteo": 51, "humidite_pct": 89, "description_fr": "Bruine légère", "pluie_proba_pct": 55}, {"date": "2026-06-11", "etp_mm": 3.66, "pluie_mm": 17.7, "temp_max": 32.1, "temp_min": 24.0, "vent_kmh": 9.2, "code_meteo": 81, "humidite_pct": 96, "description_fr": "Averses modérées", "pluie_proba_pct": 64}, {"date": "2026-06-12", "etp_mm": 3.75, "pluie_mm": 1.2, "temp_max": 33.2, "temp_min": 24.6, "vent_kmh": 14.3, "code_meteo": 53, "humidite_pct": 96, "description_fr": "Bruine modérée", "pluie_proba_pct": 43}]	2026-06-10 05:47:22.077444	2026-06-10 11:47:22.077444
8	5	6	12.5521	-12.1745	senegal_oriental	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 3.54, "pluie_mm": 10.3, "temp_max": 32.1, "temp_min": 24.6, "vent_kmh": 18.7, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 66}, {"date": "2026-06-11", "etp_mm": 4.19, "pluie_mm": 6.3, "temp_max": 32.4, "temp_min": 25.1, "vent_kmh": 10.2, "code_meteo": 81, "humidite_pct": 96, "description_fr": "Averses modérées", "pluie_proba_pct": 77}, {"date": "2026-06-12", "etp_mm": 3.78, "pluie_mm": 0.5, "temp_max": 32.1, "temp_min": 24.6, "vent_kmh": 15.5, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 43}, {"date": "2026-06-13", "etp_mm": 5.17, "pluie_mm": 1.0, "temp_max": 33.3, "temp_min": 24.9, "vent_kmh": 15.9, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 37}, {"date": "2026-06-14", "etp_mm": 3.98, "pluie_mm": 4.5, "temp_max": 32.8, "temp_min": 25.2, "vent_kmh": 9.1, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 56}, {"date": "2026-06-15", "etp_mm": 4.08, "pluie_mm": 0.0, "temp_max": 33.0, "temp_min": 24.8, "vent_kmh": 11.7, "code_meteo": 95, "humidite_pct": 94, "description_fr": "Orage", "pluie_proba_pct": 47}, {"date": "2026-06-16", "etp_mm": 4.19, "pluie_mm": 0.0, "temp_max": 31.5, "temp_min": 23.6, "vent_kmh": 11.2, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 25}]	2026-06-10 06:14:14.404192	2026-06-10 12:14:14.404192
9	4	7	16.0179	-16.4896	vallee_fleuve	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 22.6, "vent_kmh": 15.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 27.8, "temp_min": 23.4, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.59, "pluie_mm": 0.0, "temp_max": 28.9, "temp_min": 23.9, "vent_kmh": 18.3, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 10}, {"date": "2026-06-13", "etp_mm": 5.2, "pluie_mm": 0.0, "temp_max": 28.2, "temp_min": 23.7, "vent_kmh": 20.3, "code_meteo": 1, "humidite_pct": 88, "description_fr": "Principalement dégagé", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.04, "pluie_mm": 0.0, "temp_max": 29.4, "temp_min": 23.6, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 4.63, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 24.2, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-16", "etp_mm": 3.43, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 24.0, "vent_kmh": 15.0, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 0}]	2026-06-10 06:14:14.68837	2026-06-10 12:14:14.68837
10	6	8	13.7707	-13.6674	senegal_oriental	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.67, "pluie_mm": 13.0, "temp_max": 34.2, "temp_min": 24.6, "vent_kmh": 21.7, "code_meteo": 95, "humidite_pct": 96, "description_fr": "Orage", "pluie_proba_pct": 57}, {"date": "2026-06-11", "etp_mm": 4.42, "pluie_mm": 1.3, "temp_max": 35.0, "temp_min": 25.6, "vent_kmh": 17.7, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 34}, {"date": "2026-06-12", "etp_mm": 5.35, "pluie_mm": 0.0, "temp_max": 35.4, "temp_min": 27.3, "vent_kmh": 22.7, "code_meteo": 95, "humidite_pct": 84, "description_fr": "Orage", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 6.79, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 25.7, "vent_kmh": 21.5, "code_meteo": 3, "humidite_pct": 79, "description_fr": "Couvert", "pluie_proba_pct": 10}, {"date": "2026-06-14", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 34.9, "temp_min": 26.4, "vent_kmh": 18.4, "code_meteo": 3, "humidite_pct": 83, "description_fr": "Couvert", "pluie_proba_pct": 18}, {"date": "2026-06-15", "etp_mm": 4.89, "pluie_mm": 5.5, "temp_max": 34.8, "temp_min": 25.6, "vent_kmh": 15.8, "code_meteo": 55, "humidite_pct": 87, "description_fr": "Bruine dense", "pluie_proba_pct": 24}, {"date": "2026-06-16", "etp_mm": 5.08, "pluie_mm": 1.1, "temp_max": 34.5, "temp_min": 24.3, "vent_kmh": 12.6, "code_meteo": 55, "humidite_pct": 100, "description_fr": "Bruine dense", "pluie_proba_pct": 18}]	2026-06-10 06:14:14.974393	2026-06-10 12:14:14.974393
11	1	4	15.1205	-16.88925	bassin_arachidier	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.6, "pluie_mm": 0.0, "temp_max": 27.1, "temp_min": 22.6, "vent_kmh": 17.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.41, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 22.9, "vent_kmh": 18.4, "code_meteo": 3, "humidite_pct": 95, "description_fr": "Couvert", "pluie_proba_pct": 18}, {"date": "2026-06-12", "etp_mm": 4.68, "pluie_mm": 0.0, "temp_max": 28.3, "temp_min": 23.8, "vent_kmh": 18.4, "code_meteo": 2, "humidite_pct": 93, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 10}, {"date": "2026-06-13", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 27.7, "temp_min": 23.3, "vent_kmh": 19.3, "code_meteo": 2, "humidite_pct": 91, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.4, "pluie_mm": 0.0, "temp_max": 31.2, "temp_min": 22.4, "vent_kmh": 24.0, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 4.11, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.9, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 9}, {"date": "2026-06-16", "etp_mm": 3.99, "pluie_mm": 0.0, "temp_max": 28.5, "temp_min": 23.9, "vent_kmh": 14.9, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 10}]	2026-06-10 11:59:29.617407	2026-06-10 17:59:29.617407
7	3	5	12.5673	-16.2719	casamance	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 5.0, "pluie_mm": 1.6, "temp_max": 35.0, "temp_min": 24.3, "vent_kmh": 16.2, "code_meteo": 55, "humidite_pct": 84, "description_fr": "Bruine dense", "pluie_proba_pct": 33}, {"date": "2026-06-11", "etp_mm": 3.02, "pluie_mm": 3.1, "temp_max": 32.2, "temp_min": 24.1, "vent_kmh": 10.3, "code_meteo": 55, "humidite_pct": 95, "description_fr": "Bruine dense", "pluie_proba_pct": 62}, {"date": "2026-06-12", "etp_mm": 4.19, "pluie_mm": 0.5, "temp_max": 34.1, "temp_min": 24.9, "vent_kmh": 15.4, "code_meteo": 53, "humidite_pct": 93, "description_fr": "Bruine modérée", "pluie_proba_pct": 51}, {"date": "2026-06-13", "etp_mm": 5.76, "pluie_mm": 0.0, "temp_max": 35.5, "temp_min": 24.7, "vent_kmh": 15.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-14", "etp_mm": 5.34, "pluie_mm": 0.4, "temp_max": 33.5, "temp_min": 24.3, "vent_kmh": 16.0, "code_meteo": 51, "humidite_pct": 93, "description_fr": "Bruine légère", "pluie_proba_pct": 18}, {"date": "2026-06-15", "etp_mm": 2.83, "pluie_mm": 2.6, "temp_max": 30.8, "temp_min": 24.2, "vent_kmh": 12.3, "code_meteo": 53, "humidite_pct": 96, "description_fr": "Bruine modérée", "pluie_proba_pct": 58}, {"date": "2026-06-16", "etp_mm": 4.55, "pluie_mm": 0.6, "temp_max": 32.9, "temp_min": 24.6, "vent_kmh": 13.2, "code_meteo": 51, "humidite_pct": 99, "description_fr": "Bruine légère", "pluie_proba_pct": 33}]	2026-06-10 12:47:01.385657	2026-06-10 18:47:01.385657
12	5	11	14.13	-15.55	soudano_sahelien	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}]	2026-06-10 13:12:48.621955	2026-06-10 19:12:48.621955
13	5	6	12.5521	-12.1745	senegal_oriental	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 3.44, "pluie_mm": 8.1, "temp_max": 32.2, "temp_min": 24.1, "vent_kmh": 20.1, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 89}, {"date": "2026-06-11", "etp_mm": 5.05, "pluie_mm": 3.1, "temp_max": 33.9, "temp_min": 25.1, "vent_kmh": 20.4, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 67}, {"date": "2026-06-12", "etp_mm": 4.24, "pluie_mm": 6.8, "temp_max": 32.8, "temp_min": 24.6, "vent_kmh": 13.0, "code_meteo": 95, "humidite_pct": 95, "description_fr": "Orage", "pluie_proba_pct": 49}, {"date": "2026-06-13", "etp_mm": 4.31, "pluie_mm": 0.8, "temp_max": 33.1, "temp_min": 25.4, "vent_kmh": 13.2, "code_meteo": 95, "humidite_pct": 88, "description_fr": "Orage", "pluie_proba_pct": 27}, {"date": "2026-06-14", "etp_mm": 4.26, "pluie_mm": 9.6, "temp_max": 33.2, "temp_min": 24.4, "vent_kmh": 13.8, "code_meteo": 95, "humidite_pct": 94, "description_fr": "Orage", "pluie_proba_pct": 63}, {"date": "2026-06-15", "etp_mm": 4.16, "pluie_mm": 0.0, "temp_max": 32.4, "temp_min": 24.2, "vent_kmh": 13.2, "code_meteo": 3, "humidite_pct": 95, "description_fr": "Couvert", "pluie_proba_pct": 51}, {"date": "2026-06-16", "etp_mm": 3.56, "pluie_mm": 0.6, "temp_max": 32.9, "temp_min": 25.0, "vent_kmh": 10.2, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 30}, {"date": "2026-06-17", "etp_mm": 3.32, "pluie_mm": 0.0, "temp_max": 33.2, "temp_min": 25.6, "vent_kmh": 10.7, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 28}, {"date": "2026-06-18", "etp_mm": 4.89, "pluie_mm": 10.5, "temp_max": 35.5, "temp_min": 25.0, "vent_kmh": 7.1, "code_meteo": 95, "humidite_pct": 88, "description_fr": "Orage", "pluie_proba_pct": 25}, {"date": "2026-06-19", "etp_mm": 4.12, "pluie_mm": 2.1, "temp_max": 31.2, "temp_min": 23.6, "vent_kmh": 14.0, "code_meteo": 80, "humidite_pct": 100, "description_fr": "Averses légères", "pluie_proba_pct": 33}, {"date": "2026-06-20", "etp_mm": 4.04, "pluie_mm": 5.1, "temp_max": 32.0, "temp_min": 24.9, "vent_kmh": 14.7, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 33}, {"date": "2026-06-21", "etp_mm": 5.15, "pluie_mm": 0.9, "temp_max": 33.5, "temp_min": 23.4, "vent_kmh": 13.0, "code_meteo": 95, "humidite_pct": 98, "description_fr": "Orage", "pluie_proba_pct": 26}, {"date": "2026-06-22", "etp_mm": 4.21, "pluie_mm": 9.1, "temp_max": 30.9, "temp_min": 24.7, "vent_kmh": 11.4, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 46}, {"date": "2026-06-23", "etp_mm": 4.61, "pluie_mm": 2.3, "temp_max": 31.3, "temp_min": 23.4, "vent_kmh": 11.5, "code_meteo": 80, "humidite_pct": 99, "description_fr": "Averses légères", "pluie_proba_pct": 42}, {"date": "2026-06-24", "etp_mm": 4.35, "pluie_mm": 1.2, "temp_max": 31.2, "temp_min": 24.1, "vent_kmh": 13.4, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 37}, {"date": "2026-06-25", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 33.0, "temp_min": 23.9, "vent_kmh": 10.2, "code_meteo": 95, "humidite_pct": 85, "description_fr": "Orage", "pluie_proba_pct": 33}]	2026-06-10 13:12:48.904035	2026-06-10 19:12:48.904035
14	5	9	14.13	-15.55	soudano_sahelien	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}, {"date": "2026-06-24", "etp_mm": 4.72, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 25.6, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 24}, {"date": "2026-06-25", "etp_mm": 7.45, "pluie_mm": 0.0, "temp_max": 36.4, "temp_min": 26.0, "vent_kmh": 22.9, "code_meteo": 3, "humidite_pct": 64, "description_fr": "Couvert", "pluie_proba_pct": 17}]	2026-06-10 13:12:49.143431	2026-06-10 19:12:49.143431
15	5	11	14.13	-15.55	soudano_sahelien	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}, {"date": "2026-06-24", "etp_mm": 4.72, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 25.6, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 24}, {"date": "2026-06-25", "etp_mm": 7.45, "pluie_mm": 0.0, "temp_max": 36.4, "temp_min": 26.0, "vent_kmh": 22.9, "code_meteo": 3, "humidite_pct": 64, "description_fr": "Couvert", "pluie_proba_pct": 17}]	2026-06-10 13:12:49.270698	2026-06-10 19:12:49.270698
16	5	10	14.13	-15.55	\N	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}, {"date": "2026-06-24", "etp_mm": 4.72, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 25.6, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 24}, {"date": "2026-06-25", "etp_mm": 7.45, "pluie_mm": 0.0, "temp_max": 36.4, "temp_min": 26.0, "vent_kmh": 22.9, "code_meteo": 3, "humidite_pct": 64, "description_fr": "Couvert", "pluie_proba_pct": 17}]	2026-06-10 13:12:49.501827	2026-06-10 19:12:49.501827
17	5	6	12.5521	-12.1745	senegal_oriental	open_meteo	14	[{"date": "2026-06-10", "etp_mm": 3.44, "pluie_mm": 8.1, "temp_max": 32.2, "temp_min": 24.1, "vent_kmh": 20.1, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 89}, {"date": "2026-06-11", "etp_mm": 5.05, "pluie_mm": 3.1, "temp_max": 33.9, "temp_min": 25.1, "vent_kmh": 20.4, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 67}, {"date": "2026-06-12", "etp_mm": 4.24, "pluie_mm": 6.8, "temp_max": 32.8, "temp_min": 24.6, "vent_kmh": 13.0, "code_meteo": 95, "humidite_pct": 95, "description_fr": "Orage", "pluie_proba_pct": 49}, {"date": "2026-06-13", "etp_mm": 4.31, "pluie_mm": 0.8, "temp_max": 33.1, "temp_min": 25.4, "vent_kmh": 13.2, "code_meteo": 95, "humidite_pct": 88, "description_fr": "Orage", "pluie_proba_pct": 27}, {"date": "2026-06-14", "etp_mm": 4.26, "pluie_mm": 9.6, "temp_max": 33.2, "temp_min": 24.4, "vent_kmh": 13.8, "code_meteo": 95, "humidite_pct": 94, "description_fr": "Orage", "pluie_proba_pct": 63}, {"date": "2026-06-15", "etp_mm": 4.16, "pluie_mm": 0.0, "temp_max": 32.4, "temp_min": 24.2, "vent_kmh": 13.2, "code_meteo": 3, "humidite_pct": 95, "description_fr": "Couvert", "pluie_proba_pct": 51}, {"date": "2026-06-16", "etp_mm": 3.56, "pluie_mm": 0.6, "temp_max": 32.9, "temp_min": 25.0, "vent_kmh": 10.2, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 30}, {"date": "2026-06-17", "etp_mm": 3.32, "pluie_mm": 0.0, "temp_max": 33.2, "temp_min": 25.6, "vent_kmh": 10.7, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 28}, {"date": "2026-06-18", "etp_mm": 4.89, "pluie_mm": 10.5, "temp_max": 35.5, "temp_min": 25.0, "vent_kmh": 7.1, "code_meteo": 95, "humidite_pct": 88, "description_fr": "Orage", "pluie_proba_pct": 25}, {"date": "2026-06-19", "etp_mm": 4.12, "pluie_mm": 2.1, "temp_max": 31.2, "temp_min": 23.6, "vent_kmh": 14.0, "code_meteo": 80, "humidite_pct": 100, "description_fr": "Averses légères", "pluie_proba_pct": 33}, {"date": "2026-06-20", "etp_mm": 4.04, "pluie_mm": 5.1, "temp_max": 32.0, "temp_min": 24.9, "vent_kmh": 14.7, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 33}, {"date": "2026-06-21", "etp_mm": 5.15, "pluie_mm": 0.9, "temp_max": 33.5, "temp_min": 23.4, "vent_kmh": 13.0, "code_meteo": 95, "humidite_pct": 98, "description_fr": "Orage", "pluie_proba_pct": 26}, {"date": "2026-06-22", "etp_mm": 4.21, "pluie_mm": 9.1, "temp_max": 30.9, "temp_min": 24.7, "vent_kmh": 11.4, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 46}, {"date": "2026-06-23", "etp_mm": 4.61, "pluie_mm": 2.3, "temp_max": 31.3, "temp_min": 23.4, "vent_kmh": 11.5, "code_meteo": 80, "humidite_pct": 99, "description_fr": "Averses légères", "pluie_proba_pct": 42}]	2026-06-10 13:12:49.707263	2026-06-10 19:12:49.707263
18	5	9	14.13	-15.55	soudano_sahelien	open_meteo	14	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}]	2026-06-10 13:12:49.819127	2026-06-10 19:12:49.819127
19	5	11	14.13	-15.55	soudano_sahelien	open_meteo	14	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}]	2026-06-10 13:12:49.93285	2026-06-10 19:12:49.93285
20	5	10	14.13	-15.55	\N	open_meteo	14	[{"date": "2026-06-10", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 25.5, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.62, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 17.3, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.29, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.26, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.0, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.95, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 15.9, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.42, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 25.9, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.36, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}, {"date": "2026-06-17", "etp_mm": 6.67, "pluie_mm": 0.0, "temp_max": 38.3, "temp_min": 25.0, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 67, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-18", "etp_mm": 6.56, "pluie_mm": 3.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 12.1, "code_meteo": 53, "humidite_pct": 78, "description_fr": "Bruine modérée", "pluie_proba_pct": 4}, {"date": "2026-06-19", "etp_mm": 4.92, "pluie_mm": 0.6, "temp_max": 35.9, "temp_min": 24.5, "vent_kmh": 12.2, "code_meteo": 53, "humidite_pct": 92, "description_fr": "Bruine modérée", "pluie_proba_pct": 8}, {"date": "2026-06-20", "etp_mm": 6.48, "pluie_mm": 0.0, "temp_max": 36.7, "temp_min": 25.2, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-21", "etp_mm": 6.21, "pluie_mm": 0.0, "temp_max": 37.2, "temp_min": 23.8, "vent_kmh": 15.7, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-22", "etp_mm": 6.53, "pluie_mm": 0.0, "temp_max": 36.6, "temp_min": 24.0, "vent_kmh": 15.9, "code_meteo": 2, "humidite_pct": 94, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 15}, {"date": "2026-06-23", "etp_mm": 4.49, "pluie_mm": 5.4, "temp_max": 34.6, "temp_min": 25.6, "vent_kmh": 14.8, "code_meteo": 53, "humidite_pct": 90, "description_fr": "Bruine modérée", "pluie_proba_pct": 22}]	2026-06-10 13:12:50.044581	2026-06-10 19:12:50.044581
21	5	10	14.13	-15.55	\N	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 5.59, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 24.4, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 75, "description_fr": "Couvert", "pluie_proba_pct": 14}, {"date": "2026-06-11", "etp_mm": 5.53, "pluie_mm": 7.5, "temp_max": 36.7, "temp_min": 25.6, "vent_kmh": 19.6, "code_meteo": 80, "humidite_pct": 86, "description_fr": "Averses légères", "pluie_proba_pct": 51}, {"date": "2026-06-12", "etp_mm": 5.25, "pluie_mm": 0.0, "temp_max": 35.7, "temp_min": 26.2, "vent_kmh": 22.8, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 7.23, "pluie_mm": 0.0, "temp_max": 37.6, "temp_min": 24.6, "vent_kmh": 23.6, "code_meteo": 3, "humidite_pct": 72, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-14", "etp_mm": 5.75, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 23.6, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 12}, {"date": "2026-06-15", "etp_mm": 5.4, "pluie_mm": 0.0, "temp_max": 35.9, "temp_min": 25.8, "vent_kmh": 17.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 26}, {"date": "2026-06-16", "etp_mm": 6.37, "pluie_mm": 0.0, "temp_max": 36.3, "temp_min": 25.9, "vent_kmh": 15.2, "code_meteo": 3, "humidite_pct": 81, "description_fr": "Couvert", "pluie_proba_pct": 25}]	2026-06-10 13:23:58.984584	2026-06-10 19:23:58.984584
22	4	13	14.7	-17.43	niayes	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.0, "temp_min": 22.6, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.5, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-12", "etp_mm": 4.39, "pluie_mm": 0.0, "temp_max": 27.7, "temp_min": 23.8, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.97, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 23.5, "vent_kmh": 17.7, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.02, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 23.2, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 3.97, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.8, "vent_kmh": 14.6, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-16", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 24.3, "vent_kmh": 15.3, "code_meteo": 2, "humidite_pct": 91, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 10}]	2026-06-10 13:49:24.470082	2026-06-10 19:49:24.470082
23	4	7	16.0179	-16.4896	vallee_fleuve	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 4.76, "pluie_mm": 0.0, "temp_max": 27.6, "temp_min": 22.4, "vent_kmh": 14.8, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.73, "pluie_mm": 0.0, "temp_max": 28.5, "temp_min": 23.5, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.82, "pluie_mm": 0.0, "temp_max": 29.3, "temp_min": 24.1, "vent_kmh": 18.9, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-13", "etp_mm": 5.12, "pluie_mm": 0.0, "temp_max": 28.1, "temp_min": 23.5, "vent_kmh": 18.3, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.1, "temp_min": 23.2, "vent_kmh": 17.1, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 29.5, "temp_min": 24.3, "vent_kmh": 19.3, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-16", "etp_mm": 4.92, "pluie_mm": 0.0, "temp_max": 29.1, "temp_min": 24.5, "vent_kmh": 18.3, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-17", "etp_mm": 5.31, "pluie_mm": 0.0, "temp_max": 29.6, "temp_min": 23.2, "vent_kmh": 19.3, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-18", "etp_mm": 5.52, "pluie_mm": 0.0, "temp_max": 31.9, "temp_min": 23.8, "vent_kmh": 13.8, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.91, "pluie_mm": 0.0, "temp_max": 28.7, "temp_min": 24.5, "vent_kmh": 17.3, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-20", "etp_mm": 4.88, "pluie_mm": 0.0, "temp_max": 28.5, "temp_min": 23.6, "vent_kmh": 15.2, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 0}, {"date": "2026-06-21", "etp_mm": 5.09, "pluie_mm": 0.0, "temp_max": 29.9, "temp_min": 24.1, "vent_kmh": 13.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-22", "etp_mm": 5.16, "pluie_mm": 0.0, "temp_max": 29.4, "temp_min": 24.9, "vent_kmh": 19.7, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-23", "etp_mm": 4.89, "pluie_mm": 0.0, "temp_max": 28.7, "temp_min": 24.8, "vent_kmh": 21.8, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-24", "etp_mm": 4.85, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 24.0, "vent_kmh": 18.6, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-25", "etp_mm": 5.94, "pluie_mm": 0.0, "temp_max": 29.0, "temp_min": 22.2, "vent_kmh": 25.3, "code_meteo": 3, "humidite_pct": 82, "description_fr": "Couvert", "pluie_proba_pct": 10}]	2026-06-10 13:49:24.602865	2026-06-10 19:49:24.602865
25	4	14	14.7	-17.43	niayes	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.0, "temp_min": 22.6, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.5, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-12", "etp_mm": 4.39, "pluie_mm": 0.0, "temp_max": 27.7, "temp_min": 23.8, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.97, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 23.5, "vent_kmh": 17.7, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.02, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 23.2, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 3.97, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.8, "vent_kmh": 14.6, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-16", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 24.3, "vent_kmh": 15.3, "code_meteo": 2, "humidite_pct": 91, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 10}]	2026-06-10 13:57:21.497536	2026-06-10 19:57:21.497536
26	4	14	14.7	-17.43	niayes	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.0, "temp_min": 22.6, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.5, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-12", "etp_mm": 4.39, "pluie_mm": 0.0, "temp_max": 27.7, "temp_min": 23.8, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.97, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 23.5, "vent_kmh": 17.7, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.02, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 23.2, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 3.97, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.8, "vent_kmh": 14.6, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-16", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 24.3, "vent_kmh": 15.3, "code_meteo": 2, "humidite_pct": 91, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 10}, {"date": "2026-06-17", "etp_mm": 4.86, "pluie_mm": 0.0, "temp_max": 27.2, "temp_min": 24.0, "vent_kmh": 18.5, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 5.08, "pluie_mm": 0.0, "temp_max": 29.0, "temp_min": 23.8, "vent_kmh": 16.4, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.6, "vent_kmh": 13.3, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-20", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 24.3, "vent_kmh": 13.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-21", "etp_mm": 4.7, "pluie_mm": 0.0, "temp_max": 28.3, "temp_min": 23.7, "vent_kmh": 14.0, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-22", "etp_mm": 5.14, "pluie_mm": 0.0, "temp_max": 29.9, "temp_min": 24.1, "vent_kmh": 16.5, "code_meteo": 2, "humidite_pct": 92, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 2}, {"date": "2026-06-23", "etp_mm": 5.21, "pluie_mm": 0.0, "temp_max": 30.0, "temp_min": 25.2, "vent_kmh": 24.1, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-24", "etp_mm": 5.07, "pluie_mm": 0.0, "temp_max": 29.2, "temp_min": 24.6, "vent_kmh": 18.3, "code_meteo": 1, "humidite_pct": 91, "description_fr": "Principalement dégagé", "pluie_proba_pct": 10}, {"date": "2026-06-25", "etp_mm": 4.6, "pluie_mm": 0.0, "temp_max": 24.3, "temp_min": 23.5, "vent_kmh": 24.7, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 5}]	2026-06-10 13:57:21.618221	2026-06-10 19:57:21.618221
24	4	13	14.7	-17.43	niayes	open_meteo	16	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.0, "temp_min": 22.6, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.5, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-12", "etp_mm": 4.39, "pluie_mm": 0.0, "temp_max": 27.7, "temp_min": 23.8, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.97, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 23.5, "vent_kmh": 17.7, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.02, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 23.2, "vent_kmh": 15.6, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 3.97, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.8, "vent_kmh": 14.6, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-16", "etp_mm": 4.62, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 24.3, "vent_kmh": 15.3, "code_meteo": 2, "humidite_pct": 91, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 10}, {"date": "2026-06-17", "etp_mm": 4.86, "pluie_mm": 0.0, "temp_max": 27.2, "temp_min": 24.0, "vent_kmh": 18.5, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 5.08, "pluie_mm": 0.0, "temp_max": 29.0, "temp_min": 23.8, "vent_kmh": 16.4, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 30.3, "temp_min": 24.6, "vent_kmh": 13.3, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-20", "etp_mm": 4.54, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 24.3, "vent_kmh": 13.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-21", "etp_mm": 4.7, "pluie_mm": 0.0, "temp_max": 28.3, "temp_min": 23.7, "vent_kmh": 14.0, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-22", "etp_mm": 5.14, "pluie_mm": 0.0, "temp_max": 29.9, "temp_min": 24.1, "vent_kmh": 16.5, "code_meteo": 2, "humidite_pct": 92, "description_fr": "Partiellement nuageux", "pluie_proba_pct": 2}, {"date": "2026-06-23", "etp_mm": 5.21, "pluie_mm": 0.0, "temp_max": 30.0, "temp_min": 25.2, "vent_kmh": 24.1, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-24", "etp_mm": 5.07, "pluie_mm": 0.0, "temp_max": 29.2, "temp_min": 24.6, "vent_kmh": 18.3, "code_meteo": 1, "humidite_pct": 91, "description_fr": "Principalement dégagé", "pluie_proba_pct": 10}, {"date": "2026-06-25", "etp_mm": 4.6, "pluie_mm": 0.0, "temp_max": 24.3, "temp_min": 23.5, "vent_kmh": 24.7, "code_meteo": 3, "humidite_pct": 86, "description_fr": "Couvert", "pluie_proba_pct": 5}]	2026-06-10 13:49:24.734214	2026-06-10 19:49:24.734214
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, is_cooperative, created_at) FROM stdin;
1	Compte de Khadim thiam	f	2026-05-31 17:07:05.547071
2	Compte de Test User	f	2026-06-09 20:10:05.745357
3	Exploitation Diallo — Casamance	f	2026-06-10 05:40:50.088466
4	Maraîchage Sarr — Vallée du Fleuve	f	2026-06-10 06:09:03.175233
5	Ferme Diallo — Kédougou	f	2026-06-10 06:09:03.176598
6	Exploitation Ndiaye — Tambacounda	f	2026-06-10 06:09:03.199343
7	Compte de Test Producteur Phase0	f	2026-06-10 11:52:11.116124
8	Compte de Test Conseiller Phase0	f	2026-06-10 11:52:37.23746
9	Compte de Mohira Charles	t	2026-06-11 01:29:40.307717
\.


--
-- Data for Name: parcelles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parcelles (id, user_id, nom, culture, superficie_ha, superficie_m2, centre_lat, centre_lng, contour, created_at, precision_m, methode) FROM stdin;
5	1	Ma parcelle	Tomate	0.058	579.00	12.63310439142857	-12.817889054285718	[[12.633003, -12.8177447], [12.6330231, -12.8177351], [12.6330503, -12.8177362], [12.6330748, -12.8177406], [12.6330974, -12.8177502], [12.6331156, -12.817758], [12.6331376, -12.8177688], [12.6331598, -12.817784], [12.6331791, -12.817804], [12.6331943, -12.8178303], [12.6332023, -12.8178507], [12.633206, -12.817872], [12.6332115, -12.8178901], [12.6332159, -12.8179115], [12.6332158, -12.8179394], [12.6332108, -12.8179656], [12.6332034, -12.8179927], [12.6331889, -12.8180146], [12.6331706, -12.8180322], [12.6331525, -12.8180388], [12.633134, -12.8180343], [12.6331136, -12.8180256], [12.6330962, -12.8180094], [12.6330798, -12.8179965], [12.63306, -12.8179888], [12.6330418, -12.8179812], [12.6330238, -12.8179715], [12.6330071, -12.8179514], [12.6329979, -12.8179292], [12.632997, -12.8179006], [12.6330079, -12.8178773], [12.6330156, -12.8178541], [12.6330178, -12.8178323], [12.6330217, -12.8178121], [12.6330268, -12.8177931]]	2026-06-04 13:10:13.696021+00	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, subscription_id, provider, provider_ref, amount_ht, vat, amount_ttc, status, created_at) FROM stdin;
1	1	manuel	TEST-REF-001	5000	900	5900	paid	2026-05-31 17:09:27.756072
2	1	paydunya	PAYDUNYA-IPN-TOKEN-XYZ	5000	900	5900	paid	2026-06-09 15:42:52.449068
3	1	manuel	\N	5000	900	5900	pending	2026-06-09 20:09:57.1702
\.


--
-- Data for Name: re_declenchements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_declenchements (id, regle_id, org_id, parcelle_id, analyse_id, contexte_entree, resultat, score_confiance, declenche_le, acquitte, acquitte_le) FROM stdin;
\.


--
-- Data for Name: re_parametres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_parametres (id, cle, valeur, categorie, description, modifiable_admin, updated_at) FROM stdin;
\.


--
-- Data for Name: re_regles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles (id, code, categorie, sous_categorie, nom, description, zones_applicables, stades_applicables, mois_applicables, conditions, actions, gravite, priorite, confiance, plan_requis, active, source, version, created_at, updated_at) FROM stdin;
1537	IRR-AUB-002	irrigation	stress_hydrique	Stress hydrique aubergine — Fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 12}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Qualité fruits réduite"}, "alertes": [{"titre": "Déficit eau aubergine fructification", "niveau": "elevee", "message": "Stress à fructification = fruits petits, déformés, calibre commercial insuffisant."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière aubergine", "detail": "15-20 mm tous les 5-7 jours. Mulch sol recommandé pour réduire évaporation.", "priorite": 1}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1538	IRR-AUB-003	irrigation	exces_eau	Excès eau aubergine — Verticilliose phytophtora	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Maladies sol humide"}, "alertes": [{"titre": "Excès eau aubergine", "niveau": "elevee", "message": "Sol détrempé = Verticillium dahliae + Phytophtora nicotianae. Flétrissement vasculaire."}], "recommandations": [{"type": "drainage", "titre": "Drainer parcelle aubergine", "detail": "Drainer. Réduire arrosage. Billonner si terrain plat.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1539	IRR-CHO-002	irrigation	besoin_eau	Besoin eau chou — Pommaison	\N	null	["pommaison"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pommaison compromise"}, "alertes": [{"titre": "Eau insuffisante pommaison chou", "niveau": "elevee", "message": "Pommaison = phase critique : manque d'eau = petites têtes, fissures, qualité commerciale perdue."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation abondante pommaison", "detail": "20-25 mm tous les 5-7 jours. Chou consomme 400-500 mm sur cycle complet.", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1540	IRR-CHO-003	irrigation	exces_eau	Excès eau chou — Pourriture collet hernia	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 82}, {"op": "gte", "field": "meteo.pluie_7j", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Hernie + fonte"}, "alertes": [{"titre": "Excès eau chou", "niveau": "elevee", "message": "Sol saturé = hernie (Plasmodiophora brassicae) + fonte semis (Rhizoctonia). Drainer."}], "recommandations": [{"type": "drainage", "titre": "Drainage + chaulage chou", "detail": "Drainer. Chaux vive 1 t/ha si hernie connue. pH >7 réduit Plasmodiophora.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1541	IRR-CON-002	irrigation	stress_hydrique	Stress hydrique concombre — Fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 6.5}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Qualité fruits déclassée"}, "alertes": [{"titre": "Stress hydrique concombre fructification", "niveau": "critique", "message": "ETP > 6.5 + peu de pluie : amertume, fruits recourbés, BER. Production commerciale compromise."}], "recommandations": [{"type": "irrigation", "titre": "Goutte-à-goutte concombre", "detail": "2-3 mm/jour par temps chaud. Concombre = 95% eau. Ne jamais laisser stresser.", "priorite": 1, "urgence_jours": 1}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1542	IRR-CON-003	irrigation	exces_eau	Excès eau concombre — Pourriture pédonculaire	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 35}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pythium/Phytophtora"}, "alertes": [{"titre": "Excès eau concombre", "niveau": "elevee", "message": "Sol saturé + contact feuilles humides = Pythium/Phytophtora. Pourriture pédonculaire rapide."}], "recommandations": [{"type": "drainage", "titre": "Drainer + palissage concombre", "detail": "Élever les fruits du sol. Drainer. Arrêter arrosage foliaire.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1543	IRR-PAP-002	irrigation	stress_hydrique	Stress hydrique papaye — Chute fruits	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Chute prématurée fruits"}, "alertes": [{"titre": "Stress hydrique papaye saison sèche", "niveau": "critique", "message": "Papaye très sensible : 10 jours de stress = chute massive fruits non mûrs."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière papaye saison sèche", "detail": "25-30 mm/semaine minimum. Mulch organique 10 cm = économise 30% eau.", "priorite": 1, "urgence_jours": 2}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1544	IRR-PAP-003	irrigation	exces_eau	Engorgement papaye — Pourriture collet mortelle	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 82}, {"op": "gte", "field": "meteo.pluie_24h", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Pourriture collet mortelle"}, "alertes": [{"titre": "Engorgement papaye — collet menacé", "niveau": "critique", "message": "Papaye en sol saturé > 48h = Pythium mortel. Plante s'effondre en 3-5 jours."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence papaye", "detail": "Drainage immédiat. Mound planting obligatoire en zones à pluies > 1500 mm.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1545	IRR-ANA-002	irrigation	besoin_eau	Irrigation d'appoint anacarde — Floraison saison sèche	\N	null	["floraison"]	[1, 2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 2}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Avortement floral"}, "alertes": [{"titre": "Sécheresse anacarde floraison", "niveau": "elevee", "message": "Anacarde fleurit en saison sèche. Stress à floraison = avortement inflorescences."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation appoint anacarde floraison", "detail": "10-15 mm/semaine si accessible. Arroser au pied, éviter feuilles. Mulch organique.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1546	IRR-ANA-003	irrigation	besoin_eau	Besoin eau anacarde — Nouaison noix	\N	null	["fructification"]	[3, 4, 5]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.etp", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Nouaison compromise"}, "alertes": [{"titre": "ETP élevée nouaison anacarde", "niveau": "elevee", "message": "Nouaison noix cajou = période critique. ETP > 6 + sec = noix avortées, petites."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation appoint nouaison anacarde", "detail": "10-20 mm/semaine si possible. Priorité aux jeunes vergers 1-3 ans.", "priorite": 1}]}	elevee	7	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1547	IRR-BAN-002	irrigation	besoin_eau	Besoin eau banane — Plein été saison sèche	\N	null	null	[11, 12, 1, 2, 3, 4, 5]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.etp", "value": 5.5}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Arrêt croissance saison sèche"}, "alertes": [{"titre": "Banane = forte consommatrice eau", "niveau": "critique", "message": "Banane consomme 1500-2200 mm/an. Saison sèche sans irrigation = perte totale de récolte."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation goutte-à-goutte banane", "detail": "4-6 L/h/plant. 6-8 h/jour si ETP > 5mm. Irrigation localisée au pied optimal.", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1548	IRR-BAN-003	irrigation	exces_eau	Engorgement banane — Saison pluies zone basse	\N	null	null	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 88}, {"op": "gte", "field": "meteo.pluie_7j", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Fusarium + verse"}, "alertes": [{"titre": "Engorgement bananier saison pluies", "niveau": "elevee", "message": "Sol saturé > 5 jours = Fusarium oxysporum f.sp. cubense actif (Panama). Verse aussi possible."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence bananier", "detail": "Drains enterrés 1m profondeur. Sol drainant obligatoire pour bananier durable.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1549	IRR-PAS-002	irrigation	besoin_eau	Besoin eau pastèque — Grossissement fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fruits petits/déformés"}, "alertes": [{"titre": "Eau insuffisante pastèque fructification", "niveau": "elevee", "message": "Pastèque = 95% eau. Stress grossissement = fruits petits, éclatement ou BER."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière pastèque", "detail": "25-30 mm/semaine. Réduire légèrement 10 jours avant récolte pour sucrer. Éviter irrégularité.", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1550	IRR-PAS-003	irrigation	exces_eau	Excès eau pastèque — Fissuration éclatement fruits	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Éclatement fruits"}, "alertes": [{"titre": "Réhumidification brutale pastèque", "niveau": "elevee", "message": "Forte pluie après sec = pression osmotique = éclatement fruits mûrs. Récolter immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte d'urgence fruits à maturité", "detail": "Récolter fruits mûrs dans les 48h après forte pluie pour éviter éclatement.", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1551	IRR-GEN-002	irrigation	general	ETP très élevée — Alerte stress toutes cultures	\N	null	null	[3, 4, 5, 11, 12]	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 8.0}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "ETP extrême"}, "alertes": [{"titre": "ETP extrême > 8 mm/j", "niveau": "critique", "message": "Évapotranspiration > 8 mm/j : toutes cultures en stress potentiel. Irrigation prioritaire cultures sensibles."}], "recommandations": [{"type": "irrigation", "titre": "Priorité irrigation ETP élevée", "detail": "Priorité: 1-Florales/fructification 2-Jeunes plants 3-Cultures valeur haute.", "priorite": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1552	IRR-GEN-003	irrigation	general	Sécheresse prolongée — Déficit hydrique cumulé	\N	null	null	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 2}, {"op": "gte", "field": "meteo.etp", "value": 5.5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Déficit hydrique cumulé"}, "alertes": [{"titre": "Déficit hydrique cumulé critique", "niveau": "elevee", "message": "Déficit > 35 mm/semaine. Stress hydrique généralisé imminent si pas d'irrigation."}], "recommandations": [{"type": "irrigation", "titre": "Déclencher irrigation d'urgence", "detail": "Compenser 50-70% du déficit. Doses fractionnées tôt le matin pour limiter pertes évaporatoires.", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1553	IRR-GEN-004	irrigation	general	Pluie prévue — Report irrigation conseillé	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.4, "libelle": "Gaspillage eau"}, "alertes": [{"titre": "Pluie significative — Reporter irrigation", "niveau": "faible", "message": "Pluie récente ≥ 20 mm : reporter toute irrigation 2-3 jours pour éviter sur-irrigation."}], "recommandations": [{"type": "irrigation", "titre": "Reporter irrigation 2-3 jours", "detail": "Surveiller humidité sol avant de reprendre l'irrigation.", "priorite": 1}]}	faible	3	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1237	MAL-RIZ-001	maladie	fongique	Risque Pyriculariose — Conditions météo favorables	\N	null	["tallage", "montaison", "epiaison"]	[6, 7, 8, 9, 10]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 90}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pyriculariose"}, "alertes": [{"titre": "Risque Pyriculariose élevé", "niveau": "elevee", "message": "Température 24-28°C + HR >90% + pluie : conditions optimales pour Magnaporthe oryzae."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Traitement fongicide préventif Pyriculariose", "produit": "Tricyclazole 75WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 21}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1238	MAL-RIZ-002	maladie	fongique	Pyriculariose — Symptômes observés sur feuilles/cou	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "pyriculariose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_oeil_losange"}, {"op": "contains", "field": "obs.symptomes", "value": "cou_casse"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Pyriculariose"}, "alertes": [{"titre": "Pyriculariose confirmée", "niveau": "critique", "message": "Symptômes actifs détectés. Intervention curative urgente requise."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Traitement curatif Pyriculariose", "produit": "Isoprothiolane 40EC", "priorite": 1, "urgence_jours": 1, "delai_carence_jours": 28}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1239	MAL-RIZ-003	maladie	bacterien	Risque Bactériose — Chaleur + humidité post-pluie	\N	null	["tallage", "montaison", "epiaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Bactériose vasculaire"}, "alertes": [{"titre": "Risque Bactériose du riz", "niveau": "elevee", "message": "Chaleur >28°C + forte humidité + pluies récentes favorisent Xanthomonas oryzae."}], "recommandations": [{"type": "mesure_culturale", "titre": "Réduire azote + éviter blessures mécaniques", "detail": "Éviter excès N. Drainer si possible. Surveiller tallage.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1240	MAL-RIZ-004	maladie	bacterien	Bactériose riz — Symptômes flétrissement	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_bords_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Xanthomonas oryzae"}, "alertes": [{"titre": "Bactériose riz confirmée", "niveau": "critique", "message": "Flétrissement bactérien détecté. Aucun traitement curatif — mesures culturales urgentes."}], "recommandations": [{"type": "mesure_culturale", "titre": "Éliminer plants malades", "detail": "Arracher et bruler plants atteints. Ne pas irriguer par submersion totale.", "priorite": 1}, {"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif sur parcelles voisines", "produit": "Bouillie bordelaise", "priorite": 2, "urgence_jours": 2}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1241	MAL-RIZ-005	maladie	fongique	Risque Helminthosporiose — Humidité prolongée	\N	null	["tallage", "montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose", "niveau": "moyenne", "message": "Humidité élevée prolongée favorise Bipolaris oryzae. Surveiller taches brunes."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide préventif Helminthosporiose", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1242	MAL-RIZ-006	maladie	fongique	Rhizoctoniose — Sol humide + températures chaudes	\N	null	["tallage", "montaison"]	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "sol.humidite", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Rhizoctoniose"}, "alertes": [{"titre": "Risque Rhizoctoniose de la gaine", "niveau": "elevee", "message": "Conditions chaudes et humides favorisent Rhizoctonia solani sur gaines."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Fongicide systémique gaine", "produit": "Validamycine 3SL", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1243	MAL-RIZ-007	maladie	fongique	Charbon des balles — Risque floraison humide	\N	null	["epiaison", "floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "meteo.pluie_24h", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Charbon des balles"}, "alertes": [{"titre": "Risque Charbon des balles", "niveau": "moyenne", "message": "Floraison sous pluie et humidité élevée : risque Tilletia barclayana."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller épis à maturité", "detail": "Inspecter coloration épis. Traitement semences saison suivante.", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1554	IRR-GEN-005	irrigation	general	Sol saturé généralisé — Drainage prioritaire	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 90}, {"op": "gte", "field": "meteo.pluie_7j", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Asphyxie racinaire"}, "alertes": [{"titre": "Sol saturé — Drainage urgent", "niveau": "critique", "message": "Humidité sol > 90% = asphyxie racinaire imminente. Toutes cultures menacées."}], "recommandations": [{"type": "drainage", "titre": "Créer rigoles de drainage urgence", "detail": "Rigoles profondes 30 cm entre rangs. Pompage si nappe remontante.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1244	MAL-MIL-001	maladie	fongique	Risque Mildiou du mil — Levée + pluies	\N	null	["levee", "tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Mildiou du mil"}, "alertes": [{"titre": "Risque Mildiou du mil", "niveau": "elevee", "message": "Pluies fréquentes + humidité >85% : risque élevé Sclerospora graminicola."}], "recommandations": [{"dose": "6 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Métalaxyl", "produit": "Métalaxyl 35FS", "priorite": 1, "urgence_jours": 0}, {"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Pulvérisation Métalaxyl", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 5}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1245	MAL-MIL-002	maladie	fongique	Mildiou mil — Symptômes chlorose/sporulation	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mildiou"}, {"op": "contains", "field": "obs.symptomes", "value": "sporulation_blanche"}, {"op": "contains", "field": "obs.symptomes", "value": "chlorose_mildiou"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Mildiou du mil"}, "alertes": [{"titre": "Mildiou mil confirmé", "niveau": "critique", "message": "Sporulation active détectée. Arracher plants malades immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés", "detail": "Éliminer et enfouir ou bruler. Ne pas composter.", "priorite": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Traitement plants sains voisins", "produit": "Métalaxyl + Mancozèbe", "priorite": 2, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1246	MAL-MIL-003	maladie	fongique	Risque Ergot mil — Floraison humide	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Ergot du mil"}, "alertes": [{"titre": "Risque Ergot du mil", "niveau": "moyenne", "message": "Floraison sous pluie : Claviceps fusiformis peut contaminer fleurs ouvertes."}], "recommandations": [{"type": "surveillance", "titre": "Inspecter épis floraison", "detail": "Rechercher exsudat mielleux. Détruire épis ergotés.", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1247	MAL-MIL-004	maladie	fongique	Risque Charbon mil — Floraison	\N	null	["floraison", "maturation"]	[8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Charbon du mil"}, "alertes": [{"titre": "Risque Charbon du mil", "niveau": "moyenne", "message": "Tokilosporium penicillariae actif en floraison chaude et humide."}], "recommandations": [{"dose": "3 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Thirame saison suivante", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1248	MAL-MIL-005	maladie	fongique	Rouille mil — Surveillance montaison-maturité	\N	null	["montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}], "operator": "AND"}	{"risque": {"score": 0.45, "libelle": "Rouille du mil"}, "alertes": [{"titre": "Risque faible Rouille du mil", "niveau": "faible", "message": "Conditions légèrement favorables à Puccinia penniseti. Surveillance recommandée."}], "recommandations": [{"type": "surveillance", "titre": "Inspecter feuilles pour pustules orangées", "priorite": 1}]}	faible	3	0.55	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1249	MAL-SOR-001	maladie	fongique	Risque Anthracnose sorgho — Chaleur humide	\N	null	["tallage", "montaison", "floraison", "maturation"]	[7, 8, 9, 10]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose"}, "alertes": [{"titre": "Risque Anthracnose du sorgho", "niveau": "elevee", "message": "Colletotrichum sublineolum actif : chaleur 25-35°C + humidité + pluies récentes."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose sorgho", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1250	MAL-SOR-002	maladie	fongique	Anthracnose sorgho — Symptômes taches foliaires	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "anthracnose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_rouges_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Anthracnose"}, "alertes": [{"titre": "Anthracnose sorgho confirmée", "niveau": "elevee", "message": "Taches caractéristiques détectées. Traitement curatif rapide."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Traitement curatif Carbendazime", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1251	MAL-SOR-003	maladie	fongique	Risque Mildiou sorgho — Levée humide	\N	null	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Mildiou du sorgho"}, "alertes": [{"titre": "Risque Mildiou du sorgho", "niveau": "moyenne", "message": "Conditions humides à levée : risque Peronosclerospora sorghi."}], "recommandations": [{"dose": "6 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Métalaxyl", "produit": "Métalaxyl 35FS", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1252	MAL-SOR-004	maladie	fongique	Helminthosporiose sorgho — Chaleur humide montaison	\N	null	["montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose sorgho", "niveau": "moyenne", "message": "Exserohilum turcicum favorisé par chaleur + humidité. Surveiller feuilles inférieures."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1253	MAL-MAI-001	maladie	fongique	Risque Fusariose épi maïs — Humidité floraison	\N	null	["floraison", "remplissage_grains"]	[8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fusariose + mycotoxines"}, "alertes": [{"titre": "Risque Fusariose épi maïs", "niveau": "elevee", "message": "Fusarium moniliforme / verticillioides : conditions humides à floraison = risque élevé de mycotoxines."}], "recommandations": [{"dose": "0,75 L/ha", "type": "traitement_phyto", "titre": "Fongicide soie/épi", "produit": "Tebuconazole 25EC", "priorite": 1, "urgence_jours": 5}, {"type": "mesure_culturale", "titre": "Récolte rapide à maturité", "detail": "Éviter séchage lent au champ. Stocker <14% humidité.", "priorite": 2}]}	elevee	9	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1254	MAL-MAI-002	maladie	viral	Striure maïs — Détection précoce levée à V6	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "striure"}, {"op": "contains", "field": "obs.symptomes", "value": "stries_jaunes_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Striure virale"}, "alertes": [{"titre": "Striure du maïs détectée", "niveau": "elevee", "message": "MSRV transmis par cicadelles. Aucun traitement curatif disponible."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés", "detail": "Éliminer immédiatement pour réduire source virale.", "priorite": 1}, {"dose": "4 g/kg", "type": "traitement_phyto", "titre": "Contrôle vecteur cicadelles", "produit": "Imidaclopride 70WS (semences)", "priorite": 2, "urgence_jours": 0}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1255	MAL-MAI-003	maladie	fongique	Helminthosporiose maïs — Risque chaleur humide	\N	null	["floraison", "remplissage_grains"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 27}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose maïs", "niveau": "moyenne", "message": "Exserohilum turcicum actif en conditions fraîches-humides."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Fongicide foliaire préventif", "produit": "Propiconazole 25EC", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1256	MAL-MAI-004	maladie	fongique	Charbon commun maïs — Risque blessures floraison	\N	null	["floraison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 34}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.58, "libelle": "Charbon commun"}, "alertes": [{"titre": "Risque Charbon commun maïs", "niveau": "moyenne", "message": "Ustilago maydis favorisé par chaleur et écarts de temp. Éviter blessures mécaniques."}], "recommandations": [{"type": "mesure_culturale", "titre": "Enlever galles avant sporulation", "detail": "Couper et enfouir les galles noires avant qu'elles n'éclatent.", "priorite": 1}]}	moyenne	5	0.6	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1257	MAL-ARA-001	maladie	fongique	Risque Cercosporiose arachide — Chaleur humide végétation	\N	null	["croissance_vegetative", "floraison", "fructification"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose arachide", "niveau": "elevee", "message": "Cercospora arachidicola favorisé. Risque de 30-50% perte si non traité."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Cercosporiose arachide", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5, "delai_carence_jours": 14}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1258	MAL-ARA-002	maladie	fongique	Cercosporiose arachide — Taches foliaires observées	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "cercosporiose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_cercospora"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Cercosporiose arachide confirmée", "niveau": "elevee", "message": "Taches confirmées. Traiter immédiatement + programmer 2 applications supplémentaires."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Programme 3 applications Mancozèbe", "detail": "J0 + J14 + J28. Alterner avec Chlorothalonil.", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1259	MAL-ARA-003	maladie	viral	Rosette arachide — Vecteur puceron + symptômes	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "rosette"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Rosette virale"}, "alertes": [{"titre": "Risque Rosette arachide", "niveau": "elevee", "message": "Virus GRAV transmis par Aphis craccivora. Contrôle vecteur urgent."}], "recommandations": [{"dose": "4 g/kg semences", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Imidaclopride 70WS", "priorite": 1, "urgence_jours": 0}, {"type": "mesure_culturale", "titre": "Semis précoce + variétés tolérantes", "detail": "Semis avant pic puceron. Variétés RMP 12 ou ICG 12991.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1260	MAL-ARA-004	maladie	fongique	Pourriture gousses arachide — Sol humide fructification	\N	null	["fructification", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 75}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Pourriture + aflatoxine"}, "alertes": [{"titre": "Risque Pourriture des gousses", "niveau": "elevee", "message": "Sol saturé en fructification : Aspergillus/Pythium peuvent coloniser gousses."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte précoce si pluies continues", "detail": "Ne pas laisser gousses matures dans sol détrempé >2 semaines.", "priorite": 1}, {"type": "mesure_post_recolte", "titre": "Séchage rapide <12% humidité", "detail": "Sécher 3-5 jours au soleil avant stockage pour prévenir aflatoxines.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1261	MAL-NIE-001	maladie	viral	Mosaïque niébé — Vecteur puceron détecté	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Mosaïque virale"}, "alertes": [{"titre": "Risque Mosaïque du niébé", "niveau": "elevee", "message": "CABMV transmis par pucerons. Pas de traitement curatif. Contrôle vecteur immédiat."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Arracher plants malades", "priorite": 2, "urgence_jours": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1262	MAL-NIE-002	maladie	fongique	Anthracnose niébé — Humidité fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose"}, "alertes": [{"titre": "Risque Anthracnose du niébé", "niveau": "moyenne", "message": "Colletotrichum lindemuthianum favorisé à fructification humide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose niébé", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1263	MAL-NIE-003	maladie	fongique	Fonte de semis niébé — Sol humide à levée	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis niébé", "niveau": "moyenne", "message": "Sol détrempé à levée : Pythium/Rhizoctonia peuvent provoquer fonte."}], "recommandations": [{"dose": "3 g/kg", "type": "traitement_semences", "titre": "Traitement semences Thirame", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1264	MAL-NIE-004	maladie	fongique	Cercosporiose niébé — Humidité floraison	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose niébé", "niveau": "moyenne", "message": "Cercospora canescens favorisé en conditions humides à floraison."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil préventif", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1265	MAL-SES-001	maladie	fongique	Flétrissement fusarien sésame — Sol humide chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Flétrissement fusarien sésame", "niveau": "elevee", "message": "Fusarium oxysporum f.sp. sesami actif : sol acide et humide >28°C."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage si pH <6", "detail": "Apporter chaux agricole pour relever pH >6.5.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation 3 ans minimum", "detail": "Éviter retour sésame sur même parcelle <3 ans.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1266	MAL-SES-002	maladie	fongique	Flétrissement fusarien sésame — Symptômes observés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_fusarien"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_base"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Fusariose"}, "alertes": [{"titre": "Fusariose sésame confirmée", "niveau": "critique", "message": "Flétrissement vasculaire irréversible. Aucun traitement curatif."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire plants infectés", "priorite": 1, "urgence_jours": 1}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1267	MAL-SES-003	maladie	fongique	Phytophtora sésame — Excès eau sol lourd	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Phytophtora"}, "alertes": [{"titre": "Risque Phytophtora sésame", "niveau": "elevee", "message": "Engorgement sol : Phytophthora parasitica peut causer pourriture collet."}], "recommandations": [{"type": "mesure_culturale", "titre": "Drainer immédiatement", "priorite": 1, "urgence_jours": 1}, {"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Métalaxyl en préventif", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 3}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1268	MAL-SES-004	maladie	fongique	Cercosporiose sésame — Humidité fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose sésame", "niveau": "moyenne", "message": "Cercospora sesami favorisé en humidité soutenue à fructification."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1269	MAL-MAN-001	maladie	viral	Mosaïque africaine manioc — Détection symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_manioc"}, {"op": "contains", "field": "obs.symptomes", "value": "deformation_feuilles"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Mosaïque africaine (CMD)"}, "alertes": [{"titre": "Mosaïque africaine manioc détectée", "niveau": "critique", "message": "CMD transmise par Bemisia tabaci. Variétés sensibles perdent 20-95% rendement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Utiliser boutures saines certifiées", "detail": "Ne jamais replanter boutures issues de plants malades.", "priorite": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Contrôle mouche blanche", "produit": "Imidaclopride 200SL", "priorite": 2, "urgence_jours": 3}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1270	MAL-MAN-002	maladie	bacterien	Bactériose vasculaire manioc — Saison humide	\N	null	["croissance_vegetative"]	[6, 7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 34}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Bactériose vasculaire"}, "alertes": [{"titre": "Risque Bactériose manioc", "niveau": "elevee", "message": "Saison humide : Xanthomonas axonopodis pv. manihotis actif. Surveiller chancres tiges."}], "recommandations": [{"type": "mesure_culturale", "titre": "Désinfecter outils de coupe", "detail": "Hypochlorite 0,5% entre chaque plant. Ne pas couper par temps de pluie.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Boutures saines + variétés résistantes", "detail": "TMS 30572, TMS 92/0326 tolérantes CBB.", "priorite": 2}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1271	MAL-MAN-003	maladie	fongique	Pourriture brune racines manioc — Sol lourd engorgé	\N	null	["tuberisation", "maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pourriture racinaire"}, "alertes": [{"titre": "Risque Pourriture brune racines manioc", "niveau": "elevee", "message": "Sol saturé : Phytophthora drechsleri peut coloniser racines."}], "recommandations": [{"type": "mesure_culturale", "titre": "Billonner + drainer urgence", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Récolte anticipée si >12 mois", "detail": "Manioc >12 mois en sol hydromorphe : récolter avant pourriture totale.", "priorite": 2}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1272	MAL-MAN-004	maladie	fongique	Taches brunes foliaires manioc — Surveillance	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 35}], "operator": "AND"}	{"risque": {"score": 0.45, "libelle": "Taches brunes foliaires"}, "alertes": [{"titre": "Risque Taches brunes foliaires manioc", "niveau": "faible", "message": "Cercospora henningsii favorisé par humidité. Impact limité si plante vigoureuse."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller défoliation", "detail": "Traitement justifié si >30% feuillage atteint.", "priorite": 1}]}	faible	3	0.55	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1273	MAL-TOM-001	maladie	fongique	Risque Mildiou tomate — Nuits fraîches humides	\N	["niayes"]	["croissance_vegetative", "floraison", "fructification"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Mildiou tomate"}, "alertes": [{"titre": "Risque Mildiou tomate élevé", "niveau": "elevee", "message": "Phytophthora infestans : T°<22°C + HR>88% + rosée. Traitement préventif obligatoire."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Fongicide systémique Mildiou tomate", "produit": "Métalaxyl-M + Mancozèbe (Ridomil Gold)", "priorite": 1, "urgence_jours": 2, "delai_carence_jours": 14}]}	elevee	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1274	MAL-TOM-002	maladie	fongique	Mildiou tomate — Symptômes actifs	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mildiou"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_huileuses_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Mildiou tomate"}, "alertes": [{"titre": "Mildiou tomate confirmé", "niveau": "critique", "message": "Mildiou actif détecté. Intervention curative d'urgence."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe curatif", "produit": "Cymoxanil 4% + Mancozèbe 40% (Curzate-M)", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1275	MAL-TOM-003	maladie	fongique	Alternariose tomate — Chaleur humide floraison-récolte	\N	null	["floraison", "fructification", "maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Alternariose"}, "alertes": [{"titre": "Risque Alternariose tomate", "niveau": "moyenne", "message": "Alternaria solani favorisé en chaleur humide. Surveiller feuilles basses."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil + effeuillage bas", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1555	IRR-GEN-006	irrigation	general	Vent fort + chaleur — Stress combiné évapotranspiration	\N	null	null	[11, 12, 1, 2, 3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 30}, {"op": "gte", "field": "meteo.temp_air", "value": 35}, {"op": "lte", "field": "meteo.humidite_rel", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "ETP explosive harmattan"}, "alertes": [{"titre": "Vent chaud + air sec — ETP explosive", "niveau": "elevee", "message": "Harmattan intense : ETP peut dépasser 10 mm/j. Irrigation 2x/jour jeunes plants si possible."}], "recommandations": [{"type": "irrigation", "titre": "Doubler fréquence irrigation", "detail": "Fractionnement: matin + fin après-midi. Mulch sol obligatoire.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Brise-vent si possible", "detail": "Plantation rangées arbustes = réduit ETP de 20-30%.", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1556	MET-GEN-001	meteo	chaleur	Chaleur extrême >38°C — Cultures légumières	\N	null	null	[4, 5, 6, 10, 11]	{"op": "gte", "field": "meteo.temp_air", "value": 38}	{"risque": {"score": 0.92, "libelle": "Stress thermique critique"}, "alertes": [{"titre": "Chaleur extrême >38°C — cultures légumières", "niveau": "critique", "message": "T° >38°C : avortement fleurs, coup de soleil fruits, arrêt photosynthèse."}], "recommandations": [{"type": "protection", "titre": "Ombrage 30-50% si disponible", "detail": "Filet ombrage ou paillage blanc pour réfléchir chaleur.", "priorite": 1}, {"dose": "15-20 mm", "type": "irrigation", "titre": "Irrigation matin avant 8h", "detail": "Éviter irrigation en pleine chaleur — brûlures.", "priorite": 2, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1557	MET-GEN-002	meteo	chaleur	Chaleur >35°C — Grandes cultures céréales	\N	null	["floraison", "epiaison"]	null	{"op": "gte", "field": "meteo.temp_air", "value": 35}	{"risque": {"score": 0.85, "libelle": "Stress thermique floraison"}, "alertes": [{"titre": "Chaleur >35°C à floraison céréales", "niveau": "elevee", "message": "T° >35°C à floraison : stérilité pollinique + dommages protéines grains."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller taux de remplissage des épis/panicules", "detail": "Si >30% stérilité : noter pour choix variété saison prochaine.", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1558	MET-GEN-003	meteo	chaleur	Vague chaleur prolongée >3j >36°C	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 36}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.etp", "value": 8}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Stress hydro-thermique"}, "alertes": [{"titre": "Vague de chaleur prolongée", "niveau": "critique", "message": "Chaleur + sécheresse + ETP élevée : stress hydro-thermique combiné. Pertes 30-60%."}], "recommandations": [{"type": "irrigation", "titre": "Irrigations fréquentes matin/soir", "priorite": 1, "urgence_jours": 1}, {"type": "protection", "titre": "Paillage mulch pour refroidir sol", "detail": "Paille 10 cm réduit T° sol de 5-8°C.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1559	MET-SEC-001	meteo	secheresse	Sécheresse prolongée — Grandes cultures pluviales	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[7, 8, 9]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "lte", "field": "meteo.pluie_24h", "value": 2}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Sécheresse hivernage"}, "alertes": [{"titre": "Sécheresse prolongée — cultures pluviales", "niveau": "elevee", "message": ">10j sans pluie significative en hivernage : stress sévère. Surveiller flétrissement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Sarclage pour réduire concurrence herbes", "detail": "Sarclage conserve 20-30% humidité sol supplémentaire.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Paillage inter-rangs", "detail": "Tiges de mil ou paille : réduit évaporation 30-40%.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1560	MET-SEC-002	meteo	secheresse	Sécheresse saison sèche — Arbres fruitiers	\N	null	null	[1, 2, 3, 4, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 2}, {"op": "gte", "field": "meteo.temp_air", "value": 33}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Stress hydrique arboriculture"}, "alertes": [{"titre": "Sécheresse saison sèche arbres fruitiers", "niveau": "elevee", "message": "ETP >7mm/j sans pluie : besoins en eau non couverts. Stress durable."}], "recommandations": [{"dose": "30-80 L/arbre/semaine selon âge", "type": "irrigation", "titre": "Irrigation localisée goutte-à-goutte", "priorite": 1}, {"type": "mesure_culturale", "titre": "Paillage organique pied d'arbre", "detail": "Couche 15 cm rayon 1 m autour du tronc.", "priorite": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1561	MET-SEC-003	meteo	secheresse	Début saison sèche — Alerte cultures sensibles	\N	null	null	[10, 11]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "lte", "field": "meteo.pluie_24h", "value": 3}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fin saison pluies"}, "alertes": [{"titre": "Début saison sèche — surveillance récolte", "niveau": "moyenne", "message": "Transition vers saison sèche. Planifier récolte cultures arrivant à maturité."}], "recommandations": [{"type": "planification", "titre": "Estimer date maturité + planifier récolte", "detail": "Arachide : arracher avant sol trop sec (risque gousses cassées).", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1562	MET-PLU-001	meteo	inondation	Pluies torrentielles >80mm/24h — Alerte inondation	\N	null	null	null	{"op": "gte", "field": "meteo.pluie_24h", "value": 80}	{"risque": {"score": 0.92, "libelle": "Inondation + pathogènes sol"}, "alertes": [{"titre": "Pluies torrentielles — risque inondation", "niveau": "critique", "message": ">80mm/24h : asphyxie racinaire, lessivage engrais, maladies fongiques explosives."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence avant 24h", "priorite": 1, "urgence_jours": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide sol préventif après submersion", "produit": "Métalaxyl 25WP", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1276	MAL-TOM-004	maladie	bacterien	Flétrissement bactérien tomate — Sol chaud blessures	\N	null	["croissance_vegetative", "floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "sol.temperature", "value": 25}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Ralstonia solanacearum"}, "alertes": [{"titre": "Risque Flétrissement bactérien tomate", "niveau": "elevee", "message": "Ralstonia solanacearum race 1 : sol chaud et humide optimal. Inspecter collets."}], "recommandations": [{"type": "mesure_culturale", "titre": "Test flétrissement rapide", "detail": "Couper tige : exsudat laiteux = Ralstonia confirmé. Arracher immédiatement.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation 3 ans + pH sol >6.5", "detail": "Solanacées à risque : tomate, piment, aubergine, pomme de terre.", "priorite": 2}]}	elevee	9	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1277	MAL-TOM-005	maladie	bacterien	Flétrissement bactérien tomate — Symptômes confirmés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "exsudat_laiteux"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Ralstonia solanacearum"}, "alertes": [{"titre": "Flétrissement bactérien tomate confirmé", "niveau": "critique", "message": "Ralstonia confirmé. Aucun traitement curatif. Quarantaine parcelle."}], "recommandations": [{"type": "mesure_culturale", "titre": "ARRACHER tous plants malades — urgence", "detail": "Enfouir profondément ou bruler. Ne pas composter.", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Jachère 2 ans + solarisation sol", "detail": "Couvrir sol film plastique transparent 6 semaines saison sèche.", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1278	MAL-TOM-006	maladie	viral	TYLCV tomate — Vecteur aleurode détecté	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "tylcv"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_cuillere"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "TYLCV"}, "alertes": [{"titre": "Risque TYLCV tomate", "niveau": "elevee", "message": "Bemisia tabaci vecteur TYLCV. Contrôle urgent vecteur + filets anti-insectes."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide systémique aleurode", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Filets insect-proof pépinière", "detail": "Mailles 50 mesh. Utiliser variétés Ty1/Ty3 résistantes.", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1279	MAL-TOM-007	maladie	fongique	Fusariose vasculaire tomate — Sol acide chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose vasculaire tomate", "niveau": "elevee", "message": "pH <5.5 + chaleur : conditions optimales Fusarium oxysporum f.sp. lycopersici."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage urgence", "detail": "Porter pH à 6.5-7. Réduire risque Fusarium de 60%.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Variétés résistantes (race 1+2)", "detail": "Chercher mention 'F' (Fusarium) sur sachet semences.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1280	MAL-PIM-001	maladie	fongique	Anthracnose piment — Humidité fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose piment", "niveau": "elevee", "message": "Colletotrichum capsici actif sur fruits humides. Récolte rapide + traitement."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime sur fruits", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1281	MAL-PIM-002	maladie	bacterien	Flétrissement bactérien piment — Sol chaud	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "fletrissement_piment"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Ralstonia"}, "alertes": [{"titre": "Flétrissement bactérien piment confirmé", "niveau": "critique", "message": "Ralstonia solanacearum. Aucun traitement curatif. Arracher immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire — urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1282	MAL-PIM-003	maladie	fongique	Phytophthora piment — Excès eau collet	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Phytophthora capsici"}, "alertes": [{"titre": "Risque Phytophthora du collet piment", "niveau": "elevee", "message": "Sol engorgé : Phytophthora capsici cause pourriture collet et racines."}], "recommandations": [{"type": "mesure_culturale", "titre": "Drainage immédiat", "priorite": 1, "urgence_jours": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fosetyl-Al en préventif", "produit": "Fosetyl-Al 80WP", "priorite": 2, "urgence_jours": 3}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1283	MAL-PIM-004	maladie	viral	Mosaïque piment — Vecteur puceron ou symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_piment"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Virus mosaïque"}, "alertes": [{"titre": "Risque Mosaïque piment", "niveau": "moyenne", "message": "CMV/PVY transmis par pucerons. Contrôle vecteur + plants malades à éliminer."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1284	MAL-AUB-001	maladie	fongique	Verticilliose aubergine — Sol contaminé chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "between", "field": "sol.temperature", "value": 20, "value2": 25}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Verticilliose"}, "alertes": [{"titre": "Risque Verticilliose aubergine", "niveau": "elevee", "message": "Verticillium dahliae actif en sol frais-humide 20-25°C. Surveiller flétrissement diurne."}], "recommandations": [{"type": "mesure_culturale", "titre": "Solarisation sol avant plantation", "detail": "Film plastique transparent 6 semaines. Réduit Verticillium >80%.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Greffe sur porte-greffe résistant", "detail": "Solanum torvum ou S. sisymbriifolium comme porte-greffe.", "priorite": 2}]}	elevee	7	0.72	premium	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1285	MAL-AUB-002	maladie	bacterien	Flétrissement bactérien aubergine — Chaleur sol humide	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "fletrissement_aubergine"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Ralstonia"}, "alertes": [{"titre": "Flétrissement bactérien aubergine", "niveau": "critique", "message": "Ralstonia confirmé. Quarantaine parcelle. Élimination immédiate."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire — urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1286	MAL-AUB-003	maladie	fongique	Alternariose aubergine — Chaleur humide fruits	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 33}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Alternariose"}, "alertes": [{"titre": "Risque Alternariose aubergine", "niveau": "moyenne", "message": "Alternaria alternata favorisé. Surveiller taches nécrotiques fruits."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1287	MAL-CHO-001	maladie	bacterien	Pourriture noire Brassicacées — Chaleur humide	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pourriture noire"}, "alertes": [{"titre": "Risque Pourriture noire chou", "niveau": "elevee", "message": "Xanthomonas campestris pv. campestris : chaleur-humidité-blessures."}], "recommandations": [{"type": "mesure_culturale", "titre": "Désinfecter outils", "priorite": 1, "urgence_jours": 1}, {"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif", "produit": "Oxychlorure de cuivre 50WP", "priorite": 2, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1288	MAL-CHO-002	maladie	fongique	Alternariose Brassicacées — Conditions chaudes humides	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Alternariose Brassicacées"}, "alertes": [{"titre": "Risque Alternariose chou", "niveau": "elevee", "message": "Alternaria brassicae : taches noires sur feuilles et pommes."}], "recommandations": [{"dose": "1,5 kg/ha", "type": "traitement_phyto", "titre": "Iprodione ou Tebuconazole", "produit": "Iprodione 50WP", "priorite": 1, "urgence_jours": 5}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1289	MAL-CHO-003	maladie	parasitaire	Hernie du chou — Sol acide humide repiquage	\N	null	["repiquage", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.5}, {"op": "gte", "field": "sol.humidite", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Hernie du chou"}, "alertes": [{"titre": "Risque Hernie du chou", "niveau": "elevee", "message": "Plasmodiophora brassicae : pH <6.5 + humidité élevée = risque critique."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage urgence avant plantation", "detail": "Porter pH >7.0 avec chaux vive. Réduire risque >70%.", "priorite": 1}, {"dose": "Trempage racines 0,5 L/100L eau", "type": "traitement_phyto", "titre": "Cyazofamide en trempage racines", "produit": "Cyazofamide 10SC", "priorite": 2, "urgence_jours": 0}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1290	MAL-OIG-001	maladie	fongique	Mildiou oignon — Nuits fraîches humides	\N	null	["croissance_vegetative", "bulbaison"]	[12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 12, "value2": 20}, {"op": "gte", "field": "meteo.humidite_rel", "value": 90}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mildiou oignon"}, "alertes": [{"titre": "Risque Mildiou oignon", "niveau": "elevee", "message": "Peronospora destructor : fraîcheur + HR>90% = sporulation nocturne active."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe préventif", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1291	MAL-OIG-002	maladie	fongique	Botrytis oignon — Humidité maturité	\N	null	["maturation", "recolte"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 25}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pourriture du col"}, "alertes": [{"titre": "Risque Botrytis oignon", "niveau": "elevee", "message": "Botrytis allii actif. Récolter par temps sec. Séchage urgence."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte immédiate si pluies prolongées", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_post_recolte", "titre": "Séchage 2-3 semaines avant stockage", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1563	MET-PLU-002	meteo	inondation	Pluies abondantes 7j — Risque maladies fongiques généralisé	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 100}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Épidémie fongique multi-maladies"}, "alertes": [{"titre": "Pluies prolongées — Risque épidémie fongique", "niveau": "elevee", "message": "100mm+/7j + HR>88% : conditions épidémiques Mildiou, Phytophthora, Anthracnose."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Programme fongicide préventif multi-cibles", "produit": "Mancozèbe 80WP + Cymoxanil 4%", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1564	MET-PLU-003	meteo	pluie	Pluie >30mm — Lessivage engrais récents	\N	null	null	null	{"op": "gte", "field": "meteo.pluie_24h", "value": 30}	{"risque": {"score": 0.72, "libelle": "Lessivage N"}, "alertes": [{"titre": "Lessivage engrais après forte pluie", "niveau": "moyenne", "message": ">30mm : lixiviation N (nitrate) + perte 30-50% fertilisants récents."}], "recommandations": [{"type": "fertilisation", "titre": "Réapplication N fractionnée après drainage", "detail": "Attendre 3-5j drainage sol. Réapporter 30-50% dose N initiale.", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1565	MET-VEN-001	meteo	vent	Vent fort >40 km/h — Maïs verse	\N	null	["montaison", "floraison", "remplissage_grains"]	null	{"op": "gte", "field": "meteo.vent", "value": 40}	{"risque": {"score": 0.8, "libelle": "Verse céréales"}, "alertes": [{"titre": "Vent fort — Risque verse céréales", "niveau": "elevee", "message": "Vent >40km/h à montaison : verse possible si tiges faibles (excès azote)."}], "recommandations": [{"type": "mesure_culturale", "titre": "Inspecter après passage vent fort", "detail": "Redresser plants versés dans 24h si encore verts.", "priorite": 1}, {"type": "surveillance", "titre": "Réduire N si tallage excessif pour la suite", "priorite": 2}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1566	MET-VEN-002	meteo	vent	Vent fort >50 km/h — Arbres fruitiers bris branches	\N	null	null	null	{"op": "gte", "field": "meteo.vent", "value": 50}	{"risque": {"score": 0.82, "libelle": "Bris mécaniques + infections"}, "alertes": [{"titre": "Vent violent — Bris branches fruitiers", "niveau": "elevee", "message": "Vent >50km/h : bris branches, chute fruits prématurés, blessures entrées maladies."}], "recommandations": [{"type": "mesure_post_vent", "titre": "Inspecter + protéger blessures", "detail": "Couper bords nets + mastic cicatrisant sur toute coupe.", "priorite": 1, "urgence_jours": 1}, {"dose": "1% badigeon", "type": "traitement_phyto", "titre": "Cuivre sur blessures", "produit": "Bouillie bordelaise", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1567	MET-VEN-003	meteo	vent	Harmattan — Stress combiné vent sec froid	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[12, 1, 2]	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 20}, {"op": "lte", "field": "meteo.humidite_rel", "value": 30}, {"op": "lte", "field": "meteo.temp_air", "value": 22}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Stress harmattan"}, "alertes": [{"titre": "Harmattan — Dessèchement cultures", "niveau": "moyenne", "message": "Vent sec froid <30% HR : dessèchement foliaire rapide + évaporation accrue."}], "recommandations": [{"type": "irrigation", "titre": "Augmenter fréquence irrigation", "detail": "Arroser matin. ETP peut doubler avec harmattan.", "priorite": 1}, {"type": "protection", "titre": "Brise-vent naturel ou filet", "detail": "Rangées sorgho ou branchages en barrière vent dominant.", "priorite": 2}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1568	MET-FRO-001	meteo	froid	Nuits fraîches <15°C — Cultures tropicales	\N	null	null	[12, 1, 2]	{"op": "lte", "field": "meteo.temp_air", "value": 15}	{"risque": {"score": 0.72, "libelle": "Stress froid cultures tropicales"}, "alertes": [{"titre": "Nuits froides <15°C — cultures tropicales", "niveau": "moyenne", "message": "T° <15°C la nuit : fructification ralentie, noircissement Papaye, stress Piment."}], "recommandations": [{"type": "protection", "titre": "Voile de forçage si T° <12°C", "detail": "Agrotextile P17 sur arceaux. Protège jusqu'à -3°C.", "priorite": 1}, {"dose": "3 kg/ha foliaire", "type": "fertilisation", "titre": "Apport potassium + calcium pour renforcer parois cellulaires", "produit": "Nitrate de calcium", "priorite": 2}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1569	MET-FRO-002	meteo	froid	Nuits fraîches <12°C — Favorise Mildiou maraîchage	\N	["niayes"]	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.temp_air", "value": 12}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Sporulation nocturne Mildiou"}, "alertes": [{"titre": "Nuit froide humide — Mildiou favori", "niveau": "elevee", "message": "Nuit <12°C + HR>85% : sporulation Phytophthora/Peronospora maximale."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Traitement anti-mildiou le matin", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1570	MET-HUM-001	meteo	humidite	Humidité très élevée >92% — Alerte maladies fongiques généralisée	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 92}, {"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Conditions épidémiques"}, "alertes": [{"titre": "Humidité >92% — Alerte fongique généralisée", "niveau": "elevee", "message": "HR >92% prolongée : sporulation active pour tous pathogènes fongiques présents."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Programme fongique préventif d'urgence", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1571	MET-HUM-002	meteo	humidite	Humidité très basse <30% — Acariens + stress	\N	null	null	[12, 1, 2, 3]	{"op": "lte", "field": "meteo.humidite_rel", "value": 30}	{"risque": {"score": 0.85, "libelle": "Stress hydrique + acariens"}, "alertes": [{"titre": "Air très sec <30% HR — Acariens + stress hydrique", "niveau": "elevee", "message": "HR <30% : explosions acariens rouges + dessèchement foliaire + ETP doublée."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide préventif", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}, {"type": "irrigation", "titre": "Augmenter fréquence irrigation 20-30%", "priorite": 2, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1572	MET-ETP-001	meteo	etp	ETP très élevée >8mm/j — Stress toutes cultures	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 8}, {"op": "lte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Déficit hydrique rapide"}, "alertes": [{"titre": "ETP très élevée >8mm/j", "niveau": "elevee", "message": "Demande évaporatoire >8mm/j sans pluie : déficit hydrique 1-2 jours max."}], "recommandations": [{"dose": "6-8 mm/j", "type": "irrigation", "titre": "Irrigation compensatoire 0.8 × ETP", "detail": "Coeff. cultural 0.8-1.1 selon stade.", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	premium	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1573	MET-ETP-002	meteo	etp	ETP modérée + sol sec — Alerte précautionnelle	\N	null	["floraison", "remplissage_grains"]	null	{"clauses": [{"op": "between", "field": "meteo.etp", "value": 5, "value2": 8}, {"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Stress hydrique imminent"}, "alertes": [{"titre": "ETP + sol sec — Stress imminent céréales", "niveau": "moyenne", "message": "Bilan hydrique négatif 3-5 jours. Surveiller signes flétrissement."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller flétrissement matinal", "detail": "Si flétrissement à 8h : intervention immédiate.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1574	MET-HIV-001	meteo	saison	Premières pluies hivernage — Alerte Pythium et fonte semis	\N	null	["semis", "levee"]	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 20}, {"op": "gte", "field": "sol.humidite", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Fonte semis début hivernage"}, "alertes": [{"titre": "Premières pluies — Risque fonte semis", "niveau": "moyenne", "message": "Premières pluies intenses : sol froid puis chaud + humide = Pythium/Rhizoctonia actifs."}], "recommandations": [{"dose": "3 g Thirame + 2 g Métalaxyl / kg semences", "type": "traitement_semences", "titre": "Traitement semences préventif obligatoire", "produit": "Thirame 80WP + Métalaxyl 35FS", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1575	MET-CAL-002	meteo	vague_chaleur	Vague chaleur extrême >38°C — tomate piment aubergine	\N	null	["floraison", "fructification"]	[3, 4, 5, 11, 12]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 38}, {"op": "lte", "field": "meteo.humidite_rel", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Stérilité pollen chaleur"}, "alertes": [{"titre": "Vague chaleur > 38°C solanées", "niveau": "critique", "message": ">38°C + air sec : pollen stérile, avortement floral massif tomate/piment/aubergine. Ombrage d'urgence."}], "recommandations": [{"type": "mesure_culturale", "titre": "Ombrage filet 30% solanées", "detail": "Filet ombrage 30-50%. Irrigation 2x/jour matin + soir. Arrêter fertilisation N.", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation fraîche solanées chaleur", "detail": "Eau fraîche matin + soir. Évite stress thermique racinaire.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1576	MET-CAL-003	meteo	vague_chaleur	Chaleur >40°C — Riz stérilité pollen	\N	null	["floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 35}, {"op": "lte", "field": "meteo.humidite_rel", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Spikelet stérilité"}, "alertes": [{"titre": "Chaleur floraison riz critique", "niveau": "critique", "message": ">35°C à floraison riz = spikelet stérilité. 1°C de trop peut faire -10% rendement."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation fraîche floraison riz", "detail": "Maintenir lame d'eau 5-10 cm pour refroidir canopée. Irrigation nocturne si possible.", "priorite": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1577	MET-CAL-004	meteo	vague_chaleur	Chaleur >36°C — Maïs floraison soie	\N	null	["floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 36}, {"op": "lte", "field": "meteo.humidite_rel", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Pollen stérile maïs"}, "alertes": [{"titre": "Chaleur + sécheresse floraison maïs", "niveau": "critique", "message": "T > 36°C + air sec = pollen maïs déshydraté en 1-2h. Soie non fécondée = épis incomplets."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation urgence floraison maïs", "detail": "Irrigation immédiate. Arrosage léger matin sur feuilles pour augmenter HR locale si possible.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1578	MET-CAL-005	meteo	vague_chaleur	Chaleur nuit >25°C — Respiration nocturne cultures céréales	\N	null	null	[3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.temp_min", "value": 25}, {"op": "gte", "field": "meteo.temp_air", "value": 35}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Perte rendement nuits chaudes"}, "alertes": [{"titre": "Nuits chaudes — respiration augmentée céréales", "niveau": "elevee", "message": "Nuits > 25°C = respiration nocturne intense = pertes glucides accumulés. -5 à -15% rendement potentiel."}], "recommandations": [{"type": "mesure_culturale", "titre": "Adapter densité semis saison chaude", "detail": "Réduire densité 10-15% en saison chaude pour diminuer compétition + température canopée.", "priorite": 1}]}	elevee	7	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1579	MET-HAR-001	meteo	harmattan	Harmattan intense — Toutes cultures	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 40}, {"op": "lte", "field": "meteo.humidite_rel", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "ETP extrême Harmattan"}, "alertes": [{"titre": "Harmattan intense — ETP extrême", "niveau": "critique", "message": "Vent > 40 km/h + HR < 20% + T > 32°C = ETP potentielle >10 mm/j. Toutes cultures en stress sévère."}], "recommandations": [{"type": "irrigation", "titre": "Doubler arrosages Harmattan", "detail": "Irrigation 2x/jour minimum. Mulch sol 10 cm. Abri si jeunes plants.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Brise-vent d'urgence", "detail": "Écrans vent temporaires (bâches, paillage vertical) côté vent dominant.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1580	MET-HAR-002	meteo	harmattan	Harmattan modéré — Cultures maraîchères sensibles	\N	null	null	[11, 12, 1, 2]	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 25}, {"op": "lte", "field": "meteo.humidite_rel", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Déshydratation foliaire"}, "alertes": [{"titre": "Harmattan maraîchers — déshydratation feuilles", "niveau": "elevee", "message": "Vent chaud sec = nécrose bords feuilles, fruit déclassé. Filet brise-vent et arrosage plus fréquent."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation fractionnée Harmattan maraîchers", "detail": "3 arrosages/jour si possible. Brise-vent latéral 1,5 m hauteur.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1581	MET-HAR-003	meteo	harmattan	Harmattan — Propagation maladies cryptogamiques ralentie	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.humidite_rel", "value": 25}, {"op": "gte", "field": "meteo.vent", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.3, "libelle": "Risque fongique réduit"}, "alertes": [{"titre": "Harmattan inhibe champignons foliaires", "niveau": "faible", "message": "Air sec < 25% HR = mildiou/botrytis stoppés. Risque fongique faible. Mais vecteurs acariens actifs."}], "recommandations": [{"type": "traitement", "titre": "Réduire fongicides, surveiller acariens", "detail": "Pause fongicides possible. Augmenter surveillance acariens (araignées rouges actives par temps sec).", "priorite": 1}]}	faible	3	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1582	MET-GEL-001	meteo	froid	Températures basses <15°C — Cultures tropicales	\N	null	null	[12, 1, 2]	{"clauses": [{"op": "lte", "field": "meteo.temp_min", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Stress froid tropical"}, "alertes": [{"titre": "Froid nocturne < 15°C solanées/cucurbitacées", "niveau": "elevee", "message": "T < 15°C nuit = ralentissement drastique. T < 10°C = dommages irréversibles solanées/papaye."}], "recommandations": [{"type": "mesure_culturale", "titre": "Protection anti-froid", "detail": "Voiles de forçage nuit. Paillage pour conserver chaleur sol. Reporter transplantation.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1583	MET-GEL-002	meteo	froid	Nuits froides <12°C — Riz blocage photosynthèse	\N	null	["croissance_vegetative", "tallage"]	[12, 1, 2]	{"clauses": [{"op": "lte", "field": "meteo.temp_min", "value": 12}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Ralentissement riz froid"}, "alertes": [{"titre": "Froid nocturne < 12°C — Riz", "niveau": "elevee", "message": "T < 12°C = blocage photosynthèse + tallage réduit. Cycle se rallonge 10-15 jours."}], "recommandations": [{"type": "mesure_culturale", "titre": "Augmenter lame eau riz froid", "detail": "Augmenter lame eau 10-15 cm (tampon thermique). Proscrire urée par temps froid.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1584	MET-BRO-001	meteo	brouillard_humidite	HR >90% nuit prolongée — Botrytis mildiou	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 90}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Botrytis/Mildiou actif"}, "alertes": [{"titre": "HR > 90% — Botrytis/Mildiou imminent", "niveau": "elevee", "message": "HR > 90% + pluie légère = conditions optimales Botrytis cinerea + Phytophthora infestans."}], "recommandations": [{"type": "traitement", "titre": "Fongicide préventif HR élevée", "detail": "Iprodione (Botrytis) ou Mancozèbe/Métalaxyl (Mildiou). Appliquer fenêtre sèche.", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1585	MET-BRO-002	meteo	brouillard_humidite	Rosée matinale prolongée — Cercospora Alternaria	\N	null	["croissance_vegetative", "floraison"]	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Cercospora/Alternaria"}, "alertes": [{"titre": "Rosée prolongée + chaleur — Cercospora", "niveau": "elevee", "message": "HR > 85% + T 22-30°C = rosée matinale = Cercospora arachidicola + Alternaria alternata actifs."}], "recommandations": [{"type": "traitement", "titre": "Fongicide Cercospora arachide", "detail": "Chlorothalonil 1.5 kg/ha ou Tebuconazole 0.5 L/ha. Appliquer tôt matin ou soir sans vent.", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1586	MET-SAI-001	meteo	saison	Début hivernage — Premières pluies (juin-juillet)	\N	null	null	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 30}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Risque faux départ hivernage"}, "alertes": [{"titre": "Début hivernage — fenêtre de semis", "niveau": "moyenne", "message": "Premières pluies significatives. Confirmer hivernage installé avant semis définitif."}], "recommandations": [{"type": "mesure_culturale", "titre": "Attendre 2e pluie significative pour semer", "detail": "Stratégie : attendre 2 pluies ≥ 20mm à 7j intervalle avant semis mil/sorgho/maïs.", "priorite": 1}]}	moyenne	5	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1587	MET-SAI-002	meteo	saison	Fin hivernage précoce — Sécheresse terminaison culture	\N	null	null	[9, 10]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "gte", "field": "meteo.etp", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Cultures non matures fin hivernage"}, "alertes": [{"titre": "Fin hivernage précoce probable", "niveau": "elevee", "message": "Pluies en baisse rapide sept-oct = fin hivernage. Cultures tardives en danger si non matures."}], "recommandations": [{"type": "mesure_culturale", "titre": "Évaluer maturité cultures tardives", "detail": "Estimer jours avant maturité. Si > 30 jours = irrigation complémentaire nécessaire.", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation appoint fin hivernage", "detail": "10-15 mm/semaine pour sécuriser maturation si cultures pas matures.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1588	MET-SAI-003	meteo	saison	Pluies hors saison — Maladies inattendues	\N	null	null	[1, 2, 11, 12]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 15}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Maladies hors saison"}, "alertes": [{"titre": "Pluie hors saison — Risque maladies inattendu", "niveau": "moyenne", "message": "Pluie en saison sèche = cultures non préparées. Maladies fongiques sur cultures sensibles."}], "recommandations": [{"type": "traitement", "titre": "Fongicide préventif pluie hors saison", "detail": "Surveillance accrue 5 jours après pluie hors saison. Fongicide si cultures sensibles.", "priorite": 1}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1589	MET-IDX-001	meteo	indice_combine	Indice FOEW favorable mildiou (T15-20 + HR>80)	\N	null	null	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mildiou FOEW optimal"}, "alertes": [{"titre": "Conditions FOEW favorables au mildiou", "niveau": "elevee", "message": "T 15-22°C + HR > 80% + pluies = fenêtre Phytophtora infestans optimale. Traiter préventivement."}], "recommandations": [{"type": "traitement", "titre": "Fongicide systémique mildiou", "detail": "Métalaxyl-M + Mancozèbe. Répéter 7 jours. Si déjà présent : Dimethomorph.", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1590	MET-IDX-002	meteo	indice_combine	Indice favorable Stemphylium oignon (T20-26 + humidité)	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 26}, {"op": "gte", "field": "meteo.humidite_rel", "value": 78}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Stemphylium/Botrytis oignon"}, "alertes": [{"titre": "Conditions Stemphylium/Botrytis oignon", "niveau": "elevee", "message": "T 20-26 + HR > 78% + pluies = Stemphylium vesicarium + Botrytis allii favorables."}], "recommandations": [{"type": "traitement", "titre": "Fongicide oignon temps humide", "detail": "Chlorothalonil + Iprodione. Ne pas retarder avec symptômes. 7-10 jours intervalle.", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1591	MET-IDX-003	meteo	indice_combine	Indice Cercospora arachide (T25-30 + humidité nuit)	\N	null	["croissance_vegetative", "floraison"]	[8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 30}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Cercospora arachidicola actif"}, "alertes": [{"titre": "Conditions optimales Cercospora arachide", "niveau": "elevee", "message": "T 25-30°C + HR > 80% = conditions parfaites Cercospora arachidicola (cerco précoce)."}], "recommandations": [{"type": "traitement", "titre": "Programme fongicide Cercospora", "detail": "Chlorothalonil 1.5 kg/ha à 30 JAL si non fait, puis tous les 14 jours.", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1592	MET-IDX-004	meteo	indice_combine	Conditions explosion pyriculariose riz (T20-28 + HR>90)	\N	null	["tallage", "montaison", "floraison"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 90}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Blast riz conditions optimales"}, "alertes": [{"titre": "Pyriculariose riz — conditions explosives", "niveau": "critique", "message": "T 20-28°C + HR > 90% + pluies = Magnaporthe oryzae (Blast) en pleine activité. Traitement urgent."}], "recommandations": [{"type": "traitement", "titre": "Fongicide anti-Blast riz urgence", "detail": "Tricyclazole 0.6 kg/ha ou Isoprothiolane 1.5 L/ha. Épiaison: traiter absolument.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1593	MET-SPE-001	meteo	special_culture	Brume sèche + froid — Anacarde avortement floral	\N	null	["floraison"]	[1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.humidite_rel", "value": 25}, {"op": "lte", "field": "meteo.temp_min", "value": 18}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Anthracnose + avortement floral"}, "alertes": [{"titre": "Brume sèche + froid anacarde", "niveau": "elevee", "message": "Harmattan froid (<18°C nuit + < 25% HR) à floraison anacarde = anthracnose + avortement. Surveillance."}], "recommandations": [{"type": "traitement", "titre": "Fongicide anthracnose anacarde", "detail": "Mancozèbe 2 kg/ha à floraison. Répéter à 10 jours si Harmattan persiste.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1594	MET-SPE-002	meteo	special_culture	Pluie floraison mangue — Anthracnose	\N	null	["floraison"]	[1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Anthracnose mangue floraison"}, "alertes": [{"titre": "Pluie floraison mangue — Anthracnose", "niveau": "critique", "message": "Pluie + humidité à floraison mangue = Colletotrichum gloeosporioides. Perte 50-100% récolte."}], "recommandations": [{"type": "traitement", "titre": "Traitement fongicide mangue floraison", "detail": "Mancozèbe + Myclobutanil à l'ouverture des boutons. Répéter 7 jours si pluies continuent.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1595	MET-SPE-003	meteo	special_culture	Forte pluie récolte manioc — Report obligatoire	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 30}, {"op": "gte", "field": "sol.humidite", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Dommages mécaniques récolte"}, "alertes": [{"titre": "Sol détrempé — Reporter récolte manioc", "niveau": "moyenne", "message": "Sol saturé = racines cassent à l'arrachage. Attendre ressuyage 3-5 jours. Qualité amidon non affectée."}], "recommandations": [{"type": "mesure_culturale", "titre": "Attendre ressuyage sol 3-5 jours", "detail": "Reporter récolte. Tracteur inutilisable sol gorgé. Perte qualité = non.", "priorite": 1}]}	moyenne	5	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1596	MET-SPE-004	meteo	special_culture	Pluie récolte arachide — Report séchage	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 15}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Aflatoxines récolte humide"}, "alertes": [{"titre": "Pluie récolte arachide — Aflatoxines", "niveau": "elevee", "message": "Humidité à récolte + stockage humide = Aspergillus flavus → aflatoxines. Problème santé public."}], "recommandations": [{"type": "mesure_culturale", "titre": "Séchage arachide immédiat", "detail": "Sécher gousses < 8% humidité avant stockage. Séchage solaire 3-5 jours min.", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1597	MET-VAR-001	meteo	variabilite	El Niño annoncé — Déficit pluies anticipé	\N	null	null	[4, 5, 6]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}, {"op": "gte", "field": "meteo.etp", "value": 7.0}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Saison déficitaire anticipée"}, "alertes": [{"titre": "Indicateurs saison sèche prolongée", "niveau": "elevee", "message": "Indicateurs début saison défavorables. Préférer variétés précoces. Prévoir irrigation."}], "recommandations": [{"type": "mesure_culturale", "titre": "Adapter choix variétés", "detail": "Variétés précoces 75-80 jours (mil, sorgho). Densité réduite. Mulch préventif.", "priorite": 1}, {"type": "irrigation", "titre": "Sécuriser source eau saison", "detail": "Inventorier disponibilité eau. Priorité aux cultures à haute valeur économique.", "priorite": 2}]}	elevee	7	0.68	premium	t	\N	1.0	2026-06-10 16:30:58.063023+00	\N
1598	CAL-RIZ-001	calendrier	semis	Riz — Fenêtre de semis vallee du fleuve	\N	["vallee_fleuve"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Décalage calendrier"}, "alertes": [{"titre": "Fenêtre semis riz hivernage", "niveau": "moyenne", "message": "Juin-juillet : période optimale semis riz hivernage. Viser avant 15 juillet."}], "recommandations": [{"type": "planification", "titre": "Semis avant 15 juillet", "detail": "Semis tardif >15 juillet : récolte sous pluies + risque Pyriculariose épiaison.", "priorite": 1}, {"type": "semis", "titre": "Variétés 90-110 jours recommandées", "detail": "Sahel 108, Sahel 305 (IR), NERICA L34.", "priorite": 2}]}	moyenne	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1599	CAL-RIZ-002	calendrier	recolte	Riz — Alerte récolte retardée — risque pertes	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pertes récolte retardée"}, "alertes": [{"titre": "Riz mûr — Récolte urgente avant pluies", "niveau": "elevee", "message": "Riz à maturité sous pluies : égrenage, germination sur pied, Fusariose épis."}], "recommandations": [{"type": "recolte", "titre": "Récolter dans les 5-7 jours", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1600	CAL-MIL-001	calendrier	semis	Mil — Fenêtre semis hivernage	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Décalage semis"}, "alertes": [{"titre": "Fenêtre semis mil", "niveau": "moyenne", "message": "Juillet : après première pluie ≥20mm. Semis tardif >31 juillet réduit rendement 30%."}], "recommandations": [{"type": "semis", "titre": "Semer 48h après première pluie ≥20mm", "detail": "Densité 1-2 graines/poquet, écartement 1m×1m. Démariage à 3 plants.", "priorite": 1}, {"type": "planification", "titre": "Variété Souna 3 ou IBV8004 recommandée", "priorite": 2}]}	moyenne	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1601	CAL-MIL-002	calendrier	fertilisation	Mil — Fenêtre apport urée microdosage J21	\N	null	["levee"]	[7, 8]	{"clauses": [{"op": "between", "field": "culture.jours_semis", "value": 18, "value2": 25}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Fenêtre fertilisation manquée"}, "alertes": [{"titre": "J21 mil — Apport urée microdosage", "niveau": "moyenne", "message": "21 jours après semis : fenêtre critique apport urée microdosage (2g/poquet)."}], "recommandations": [{"dose": "2 g/poquet = 17 kg/ha", "type": "fertilisation", "titre": "Microdosage urée 2g/poquet maintenant", "detail": "Appliquer dans le poquet après pluie. Technique ISSATROP validée ICRISAT.", "produit": "Urée 46%", "priorite": 1}]}	moyenne	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1602	CAL-SOR-001	calendrier	semis	Sorgho — Fenêtre semis hivernage	\N	null	null	[6, 7]	{"op": "in", "field": "culture.mois", "value": [6, 7]}	{"risque": {"score": 0.5, "libelle": "Fenêtre semis"}, "alertes": [{"titre": "Fenêtre semis sorgho", "niveau": "faible", "message": "Juin-juillet : semis optimal. Variétés photosensibles après 15 juillet OK."}], "recommandations": [{"type": "semis", "titre": "Semer après cumul 20mm", "detail": "CE 145-66, Framida ou Faourou selon zone.", "priorite": 1}]}	faible	5	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1603	CAL-MAI-001	calendrier	semis	Maïs — Semis précoce recommandé	\N	null	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Calendrier semis"}, "alertes": [{"titre": "Fenêtre semis maïs — semis précoce", "niveau": "moyenne", "message": "Maïs : floraison doit éviter pic chaleur août. Semis juin idéal."}], "recommandations": [{"type": "semis", "titre": "Semer fin juin - début juillet", "detail": "Éviter semis après 20 juillet : floraison tombera en pic chaleur-sécheresse août.", "priorite": 1}]}	moyenne	6	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1604	CAL-MAI-002	calendrier	recolte	Maïs — Récolte et séchage rapide mycotoxines	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mycotoxines"}, "alertes": [{"titre": "Maïs mûr — Risque mycotoxines si séchage tardif", "niveau": "elevee", "message": "Humidité élevée à récolte : Fusarium + Aspergillus = aflatoxines + fumonisines."}], "recommandations": [{"type": "recolte", "titre": "Récolter à 20-25% humidité grain", "priorite": 1, "urgence_jours": 5}, {"type": "post_recolte", "titre": "Sécher sous 14% humidité en 48h", "priorite": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1605	CAL-ARA-001	calendrier	semis	Arachide — Fenêtre semis critique	\N	["bassin_arachidier"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Calendrier semis"}, "alertes": [{"titre": "Fenêtre semis arachide", "niveau": "moyenne", "message": "Semis idéal après 20mm. Arachide 90j : semis avant 10 juillet nécessaire."}], "recommandations": [{"type": "semis", "titre": "Semer sous 48h après pluie ≥20mm", "detail": "Préparer semences traitées (Thirame + Rhizobium). Densité 15kg/ha gousses décortiquées.", "priorite": 1}]}	moyenne	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1606	CAL-ARA-002	calendrier	recolte	Arachide — Maturité arracher avant sol trop sec	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Pertes arrachage sol sec"}, "alertes": [{"titre": "Arachide mûre — Arracher avant sol trop sec", "niveau": "elevee", "message": "Sol sec = gousses se détachent au sol = pertes arrachage 15-25%."}], "recommandations": [{"type": "recolte", "titre": "Arracher dans 7-10 jours", "detail": "Sol doit être légèrement humide. Ramasser immédiatement les gousses tombées.", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1607	CAL-TOM-001	calendrier	semis	Tomate — Fenêtre semis pépinière Niayes	\N	["niayes"]	null	[9, 10, 11]	{"op": "in", "field": "culture.mois", "value": [9, 10, 11]}	{"risque": {"score": 0.45, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis tomate Niayes", "niveau": "faible", "message": "Sept-nov : température optimale pour pépinière tomate. Repiquage 30j après semis."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 25-30 jours avant repiquage", "detail": "Substrat stérilisé. Traitement semences Thirame. Filet 50 mesh TYLCV.", "priorite": 1}]}	faible	5	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1608	CAL-TOM-002	calendrier	fertilisation	Tomate — Fenêtre apport K fructification	\N	null	["floraison"]	null	{"op": "eq", "field": "culture.stade", "value": "floraison"}	{"risque": {"score": 0.65, "libelle": "Fertilisation non adaptée stade"}, "alertes": [{"titre": "Tomate floraison — Augmenter K dès maintenant", "niveau": "moyenne", "message": "À floraison : passer ratio N:K de 2:1 à 1:2. Qualité et conservation fruits."}], "recommandations": [{"dose": "80 kg K₂O/ha restant + réduction N 50%", "type": "fertilisation", "titre": "Augmenter K — réduire N", "produit": "Sulfate de potasse K₂SO₄ 50%", "priorite": 1}]}	moyenne	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1609	CAL-TOM-003	calendrier	recolte	Tomate — Récolte précoce si forte pluie	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 60}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "in", "field": "culture.stade", "value": ["fructification", "maturation"]}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pertes pluie récolte"}, "alertes": [{"titre": "Tomate mûrissante — Récolte avant pourriture", "niveau": "elevee", "message": "Pluies + humidité : fissuration fruits + Botrytis + Anthracnose accélérés."}], "recommandations": [{"type": "recolte", "titre": "Récolter fruits mûrs dans 3-5 jours", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1610	CAL-OIG-001	calendrier	semis	Oignon — Semis pépinière optimal	\N	["niayes", "vallee_fleuve"]	null	[10, 11]	{"op": "in", "field": "culture.mois", "value": [10, 11]}	{"risque": {"score": 0.45, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis oignon en pépinière", "niveau": "faible", "message": "Oct-nov : période optimale pépinière oignon pour culture jan-avril."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 40-45 jours", "detail": "Semer dense 1 g/m² pépinière. Repiquage plants 3 feuilles. Densité 500 000 plants/ha.", "priorite": 1}]}	faible	4	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1611	CAL-OIG-002	calendrier	recolte	Oignon — Maturité — épiderme couché	\N	null	["maturation"]	[3, 4, 5]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Fenêtre récolte"}, "alertes": [{"titre": "Oignon mûr — Récolte dans fenêtre optimale", "niveau": "moyenne", "message": "Épiderme couché >70% : récolter en 7-10 jours par temps sec."}], "recommandations": [{"type": "recolte", "titre": "Arracher + sécher 3 semaines au champ", "detail": "Laisser en andains 15-20 jours. Sol sec. Conservation >6 mois.", "priorite": 1}]}	moyenne	6	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1612	CAL-CHO-001	calendrier	semis	Chou — Fenêtre semis saison fraîche	\N	["niayes"]	null	[10, 11, 12]	{"op": "in", "field": "culture.mois", "value": [10, 11, 12]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis chou — saison fraîche", "niveau": "faible", "message": "Oct-déc : T° optimale Brassicacées. Repiquage 30j après semis pépinière."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière + repiquage 4-6 feuilles", "detail": "Variétés Gloria, Copenhagen. Densité 40 000 plants/ha.", "priorite": 1}]}	faible	4	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1613	CAL-PIM-001	calendrier	semis	Piment — Pépinière saison fraîche Niayes	\N	["niayes"]	null	[9, 10, 11]	{"op": "in", "field": "culture.mois", "value": [9, 10, 11]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre pépinière piment", "niveau": "faible", "message": "Sept-nov : T° favorable piment. Cycle 75-90 jours. Repiquage 6-8 feuilles."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 35-40 jours sous filet anti-insectes", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1614	CAL-CON-001	calendrier	semis	Concombre — Semis début saison froide	\N	["niayes"]	null	[10, 11, 12, 1, 2]	{"op": "in", "field": "culture.mois", "value": [10, 11, 12, 1, 2]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis concombre Niayes", "niveau": "faible", "message": "Oct-fév : T° 20-28°C optimale concombre. Cycle 50-60 jours."}], "recommandations": [{"type": "semis", "titre": "Semis en place après préparation sol", "detail": "2 graines/poquet 2cm profondeur. Démarier à 1 plant. Paillage plastique noir recommandé.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1615	CAL-PAS-001	calendrier	semis	Pastèque — Fenêtre semis optimale	\N	["niayes", "vallee_fleuve"]	null	[11, 12, 1, 2]	{"op": "in", "field": "culture.mois", "value": [11, 12, 1, 2]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis pastèque", "niveau": "faible", "message": "Nov-fév : T° 22-30°C idéale. Cycle 75-90 jours. Éviter pluies à maturité."}], "recommandations": [{"type": "semis", "titre": "2-3 graines/poquet + retrait à 1 plant", "detail": "Paillage plastique + drip recommandé production intensive.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1616	CAL-GOB-001	calendrier	semis	Gombo — Semis double saison possible	\N	null	null	[4, 5, 9, 10]	{"op": "in", "field": "culture.mois", "value": [4, 5, 9, 10]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis gombo", "niveau": "faible", "message": "Avr-mai (irrigué) ou sept-oct : deux fenêtres possibles. Cycle 60-75j."}], "recommandations": [{"type": "semis", "titre": "Tremper graines 24h avant semis", "detail": "Accélère germination 30-40%. Densité 25 000 plants/ha.", "priorite": 1}]}	faible	4	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1617	CAL-MAG-001	calendrier	taille	Mangue — Taille post-récolte recommandée	\N	null	null	[6, 7, 8]	{"op": "in", "field": "culture.mois", "value": [6, 7, 8]}	{"risque": {"score": 0.5, "libelle": "Fenêtre taille"}, "alertes": [{"titre": "Fenêtre taille post-récolte mangue", "niveau": "faible", "message": "Juillet-août : tailler immédiatement après récolte. Favorise végétation + floraison N+1."}], "recommandations": [{"type": "taille", "titre": "Taille d'éclaircissement + retrait bois mort", "detail": "Couper 20-30% de la couronne. Ouvrir vers l'intérieur. Protéger coupes.", "priorite": 1}, {"dose": "badigeon 1%", "type": "traitement_phyto", "titre": "Cuivre sur coupes fraîches", "produit": "Oxychlorure de cuivre", "priorite": 2}]}	faible	5	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1618	CAL-MAG-002	calendrier	fertilisation	Mangue — Fertilisation floraison J-30	\N	null	null	[1, 2]	{"op": "in", "field": "culture.mois", "value": [1, 2]}	{"risque": {"score": 0.65, "libelle": "Fertilisation manquée pré-floraison"}, "alertes": [{"titre": "Mangue — Fertilisation pré-floraison", "niveau": "moyenne", "message": "30j avant floraison : apport K + micronutriments pour qualité floraison."}], "recommandations": [{"dose": "2 kg/arbre sol + 3 L/ha foliaire", "type": "fertilisation", "titre": "NPK + micronutriments foliaires", "produit": "NPK 0-10-40 + bore 0.1%", "priorite": 1}]}	moyenne	6	0.75	premium	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1619	CAL-ANA-001	calendrier	recolte	Anacarde — Fenêtre récolte noix cajou	\N	null	null	[3, 4, 5]	{"op": "in", "field": "culture.mois", "value": [3, 4, 5]}	{"risque": {"score": 0.75, "libelle": "Perte qualité noix cajou"}, "alertes": [{"titre": "Récolte anacarde — Ramassage quotidien", "niveau": "moyenne", "message": "Mars-mai : ramasser noix TOUS LES JOURS. Noix au sol >48h perdent qualité."}], "recommandations": [{"type": "recolte", "titre": "Ramassage quotidien noix tombées", "detail": "Sécher sous 3% humidité dans 48h. Stocker en sacs aérés, lieu sec.", "priorite": 1}]}	moyenne	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1620	CAL-BAN-001	calendrier	recolte	Banane — Coupe régimes avant maturité terrain	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Perte post-récolte accélérée"}, "alertes": [{"titre": "Banane mûrissante — Couper régimes urgence", "niveau": "elevee", "message": "T° chaude + humidité : jaunissement rapide + Anthracnose post-récolte accéléré."}], "recommandations": [{"type": "recolte", "titre": "Couper régimes à 3/4 couleur jaune", "detail": "Mûrissage en chambre préférable. Chaîne froide 13°C si export.", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1621	CAL-PAP-001	calendrier	recolte	Papaye — Récolte fréquente continue	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Surmaturation pertes"}, "alertes": [{"titre": "Papaye mûrissante — Récolte 3x/semaine", "niveau": "moyenne", "message": "En chaleur : papaye passe de verte à mûre en 2-3j. Pertes si non récoltée."}], "recommandations": [{"type": "recolte", "titre": "Récolter 3 fois par semaine minimum", "detail": "Cueillir à 10% jaune. Mûrir à l'ombre à température ambiante.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1622	CAL-MAN-001	calendrier	recolte	Manioc — Récolte avant engorgement saison pluies	\N	null	null	[5, 6]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [5, 6]}, {"op": "gte", "field": "culture.jours_semis", "value": 270}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Pourriture racines saison pluies"}, "alertes": [{"titre": "Manioc >9 mois — Récolter avant hivernage", "niveau": "moyenne", "message": "Manioc >9 mois : récolter avant retour pluies (pourriture) ou poursuivre jusqu'à 18 mois max."}], "recommandations": [{"type": "planification", "titre": "Décider : récolter mai-juin OU laisser jusqu'à 15-18 mois en sol drainé", "detail": "Sol hydromorphe : récolter impérativement avant pluies.", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1623	CAL-NIE-001	calendrier	semis	Niébé — Double semis possible	\N	null	null	[7, 8]	{"op": "in", "field": "culture.mois", "value": [7, 8]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis niébé", "niveau": "faible", "message": "Juil-août : semis principal. Variétés 60-75j recommandées pour double culture."}], "recommandations": [{"type": "semis", "titre": "Traitement semences Rhizobium + Thirame", "detail": "2-3 graines/poquet. Écartement 60×60cm. Inoculant Bradyrhizobium indispensable.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1624	CAL-NIE-002	calendrier	recolte	Niébé — Récolte gousses sèches avant pluies	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pertes récolte pluie"}, "alertes": [{"titre": "Niébé mûr — Récolter avant pluie", "niveau": "elevee", "message": "Gousses sèches sous pluie : égrenage + Bruche accélérée. Récolter immédiatement."}], "recommandations": [{"type": "recolte", "titre": "Récolter et battre dans 3-5 jours", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1625	CAL-SES-001	calendrier	recolte	Sésame — Récolte avant ouverture capsules	\N	null	["maturation"]	[10, 11]	{"op": "eq", "field": "culture.stade", "value": "maturation"}	{"risque": {"score": 0.88, "libelle": "Égrenage spontané = perte totale"}, "alertes": [{"titre": "Sésame mûr — Récolter avant égrenage", "niveau": "elevee", "message": "Capsules sésame s'ouvrent SPONTANÉMENT. Récolter quand 1/3 bas commence à jaunir."}], "recommandations": [{"type": "recolte", "titre": "Couper tiges + sécher en fagots retournés 7-10j", "detail": "Sécher debout en gerbes à l'ombre. Battre sur bâche.", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1626	CAL-ARA-003	calendrier	semis	Fenêtre optimale semis arachide hâtif	\N	null	null	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 25}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 33}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité semis"}, "alertes": [{"titre": "Fenêtre optimale semis arachide", "niveau": "faible", "message": "Pluies installées + T 25-33°C = fenêtre idéale semis arachide. Cycle 90-110 jours pour maturité avant fin hivernage."}], "recommandations": [{"type": "semis", "titre": "Semer arachide maintenant — variétés 90j", "detail": "Variétés 90j : Fleur 11, 73-33. Densité 165,000 plants/ha (40×15 cm). Traitement semences Thirame.", "priorite": 1}]}	faible	2	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1627	CAL-ARA-004	calendrier	stade_critique	Arachide — Stade gynophore (35-45 JAL)	\N	null	["floraison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Phase gynophore"}, "alertes": [{"titre": "Stade gynophore arachide — Actions requises", "niveau": "moyenne", "message": "Gynophore formé = phase critique. Ne pas travailler sol. Humidité sol obligatoire."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arrêter travaux sol sous arachide", "detail": "Zéro sarclage profond après gynophore. Binage superficiel max. Sol meuble obligatoire.", "priorite": 1}, {"type": "fertilisation", "titre": "Apport Ca gynophore", "detail": "20-30 kg/ha gypse ou CaCO3 si Ca sol < 3 meq/100g. Critique pour remplissage gousses.", "priorite": 2}]}	moyenne	6	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1628	CAL-SOR-003	calendrier	semis	Semis sorgho — Fenêtre optimale hivernage	\N	null	null	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité semis"}, "alertes": [{"titre": "Fenêtre semis sorgho", "niveau": "faible", "message": "Pluies installées. Sorgho : semis dès 20mm cumulé sur 7j. Variétés 90-120 jours selon zone."}], "recommandations": [{"type": "semis", "titre": "Semer sorgho en ligne", "detail": "Sorgho : 75×25 cm, 2-3 graines/poquet, éclaircissage à 2 plants/poquet à 15 JAL. 5-8 kg/ha semences.", "priorite": 1}]}	faible	2	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1629	CAL-SOR-004	calendrier	stade_critique	Sorgho — Épiaison (60-70 JAL) stade zéro tolérance	\N	null	["epiaison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Stade vulnérable"}, "alertes": [{"titre": "Épiaison sorgho — protection active requise", "niveau": "elevee", "message": "Épiaison sorgho = stade zéro tolérance stress + oiseaux granivores (Quelea). Surveiller intensément."}], "recommandations": [{"type": "surveillance", "titre": "Surveillance quotidienne oiseaux épiaison", "detail": "Dès épiaison : gardiennage, fils brillants, repulsifs. Quelea = perte totale en 48h.", "priorite": 1}, {"type": "irrigation", "titre": "Priorité irrigation épiaison", "detail": "20-25 mm si pluie < 10mm/7j. Critique pour remplissage grains.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1630	CAL-NIE-003	calendrier	semis	Semis niébé — Dérobé après céréale	\N	null	null	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 27}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité semis dérobé"}, "alertes": [{"titre": "Fenêtre semis niébé dérobé", "niveau": "faible", "message": "Août-sept = niébé dérobé après mil/sorgho. Variétés 60-75 jours pour récolte avant fin hivernage."}], "recommandations": [{"type": "semis", "titre": "Semer niébé 60j comme dérobée", "detail": "IT90K-372-1-2 ou IT97K-556-6 (60-65j). 75×25 cm, 2 plants/poquet. Ne pas dépasser fin août.", "priorite": 1}]}	faible	2	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1631	CAL-NIE-004	calendrier	stade_critique	Niébé — Floraison 30-40 JAL protection insectes	\N	null	["floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Insectes floraison"}, "alertes": [{"titre": "Floraison niébé — Insectes piqueurs-suceurs", "niveau": "elevee", "message": "Floraison niébé = attaque thrips + punaises (Clavigralla). Protection insecticide requise."}], "recommandations": [{"type": "traitement", "titre": "Traitement insecticide floraison niébé", "detail": "Lambda-cyhalothrine 0.3 L/ha ou Dimethoate 0.5 L/ha. Traiter soir (préserver pollinisateurs).", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1632	CAL-SES-003	calendrier	semis	Semis sésame — Fenêtre stricte début hivernage	\N	null	null	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}, {"op": "between", "field": "meteo.temp_air", "value": 27, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.25, "libelle": "Risque semis tardif"}, "alertes": [{"titre": "Fenêtre semis sésame — Semer immédiatement", "niveau": "faible", "message": "Sésame = fenêtre semis courte juin-juillet. Semis tardif (août+) = cycle non terminé avant fin pluies."}], "recommandations": [{"type": "semis", "titre": "Semis sésame en lignes espacées", "detail": "30×15 cm. Graines superficielles 1-2 cm. 3-5 kg/ha. Ne pas enfouir profond. Sol meuble impératif.", "priorite": 1}]}	faible	3	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1633	CAL-SES-004	calendrier	stade_critique	Sésame — Récolte avant déhiscence capsules	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "lte", "field": "meteo.humidite_rel", "value": 50}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pertes déhiscence capsules"}, "alertes": [{"titre": "Sésame — Récolte urgente anti-déhiscence", "niveau": "elevee", "message": "Sésame mûr + temps sec chaud = capsules s'ouvrent = pertes 30-50%. Récolter quand 2/3 des capsules jaunes."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte sésame à maturité 2/3", "detail": "Couper base, botter, laisser sécher en bottes debout 5-7 jours. Battre sur bâche.", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1634	CAL-GOM-003	calendrier	stade_critique	Gombo — Récolte capsules tous les 2-3 jours	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Déclassement capsules fibreuses"}, "alertes": [{"titre": "Gombo — Récolter tous les 2-3 jours", "niveau": "elevee", "message": "Capsule gombo devient fibreuse en 3-4 jours par temps chaud. Récolte quotidienne = qualité prime."}], "recommandations": [{"type": "mesure_culturale", "titre": "Programme récolte gombo 2-3j", "detail": "Récolter quand capsule 5-8 cm (avant lignification). T chaud > 30°C = récolte tous les 2 jours.", "priorite": 1}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1635	CAL-CHO-003	calendrier	semis	Pépinière chou — Saison fraîche obligatoire	\N	null	null	[10, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.temp_min", "value": 22}, {"op": "lte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité pépinière"}, "alertes": [{"titre": "Fenêtre pépinière chou (saison fraîche)", "niveau": "faible", "message": "Saison fraîche = conditions optimales chou. Démarrer pépinière maintenant pour transplantation 3 semaines."}], "recommandations": [{"type": "semis", "titre": "Pépinière chou sous ombrage", "detail": "Semis en pépinière sous 30% ombrage. Substrat enrichi. Transplanter à 4-5 feuilles vraies. Arroser 2x/jour.", "priorite": 1}]}	faible	2	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1636	CAL-CHO-004	calendrier	stade_critique	Chou — Pommaison stade décisif rendement	\N	null	["pommaison"]	null	{"clauses": [{"op": "lte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Tête petite si stress"}, "alertes": [{"titre": "Pommaison chou — Actions décisives", "niveau": "elevee", "message": "Pommaison = 3-4 semaines décisives. Tout stress ici = petite tête. Eau + engrais K + protection Teigne."}], "recommandations": [{"type": "fertilisation", "titre": "Engrais K pommaison chou", "detail": "KCl 60 kg/ha en couronne. Potassium = qualité tête, densité, conservation.", "priorite": 1}, {"type": "traitement", "titre": "Surveiller Teigne Plutella pommaison", "detail": "Inspection hebdomadaire cœur chou. BT ou spinosad si chenilles présentes.", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1637	CAL-CON-003	calendrier	stade_critique	Concombre — Récolte précoce anti-jaunissement	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Arrêt production si non récolté"}, "alertes": [{"titre": "Concombre — Récolter avant jaunissement", "niveau": "elevee", "message": "Concombre laissé sur pied après maturité = jaunit en 2 jours + stoppe production. Récolte tous les 2 jours."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte concombre 2x/semaine", "detail": "Récolter quand fruit atteint calibre commercial (15-20 cm). Enlever tous fruits jaunes.", "priorite": 1}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1638	CAL-PAP-003	calendrier	semis	Pépinière papaye — Présaison sèche	\N	null	null	[10, 11]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité pépinière"}, "alertes": [{"titre": "Fenêtre pépinière papaye — Oct-Nov", "niveau": "faible", "message": "Pépinière papaye oct-nov = transplantation jan-fév = premières fleurs juillet. Cycle 8-10 mois."}], "recommandations": [{"type": "semis", "titre": "Pépinière papaye en sachet", "detail": "3 graines/sachet. Germination 15-20 jours. Conserver 1 plant/sachet. Transplanter à 25-30 cm hauteur.", "priorite": 1}]}	faible	2	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1639	CAL-PAP-004	calendrier	stade_critique	Papaye — Détermination sexe à 4-6 feuilles	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Sex ratio critique"}, "alertes": [{"titre": "Sélection sexe papaye à 4-6 feuilles", "niveau": "moyenne", "message": "À 4-6 feuilles vraies: visibles fleurs au collet. Conserver 1 femelle + 1 mâle/10 plants."}], "recommandations": [{"type": "mesure_culturale", "titre": "Sélection plants papaye 4-6 feuilles", "detail": "Identifier sexe. Arracher mâles sauf 1/10. Hermaphrodite (Solo) = conserver tous. Couper excédents.", "priorite": 1}]}	moyenne	5	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1640	CAL-PAS-003	calendrier	semis	Semis pastèque — Saison fraîche contre-saison	\N	null	null	[10, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.temp_air", "value": 32}, {"op": "gte", "field": "meteo.temp_min", "value": 18}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Opportunité semis contre-saison"}, "alertes": [{"titre": "Fenêtre semis pastèque contre-saison", "niveau": "faible", "message": "Oct-déc = pastèque contre-saison possible avec irrigation. T < 32°C = qualité optimale fruits."}], "recommandations": [{"type": "semis", "titre": "Semis pastèque avec paillage", "detail": "Poquet 200×100 cm. 2-3 graines/poquet. Paillage plastique multigolve. Irriguer 2x/semaine.", "priorite": 1}]}	faible	2	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1641	CAL-PAS-004	calendrier	stade_critique	Pastèque — Taille filet et limitation fruits	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Fruits trop petits sans taille"}, "alertes": [{"titre": "Taille pastèque — limiter à 2-3 fruits/plant", "niveau": "moyenne", "message": "Sans taille : 10+ fruits petits. Avec taille à 2-3 fruits : calibre XL valeur export."}], "recommandations": [{"type": "mesure_culturale", "titre": "Limitation fruits pastèque", "detail": "Conserver 2-3 fruits/plant sur tige principale. Supprimer tiges latérales excédentaires à 2-3 feuilles.", "priorite": 1}]}	moyenne	5	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1642	CAL-ANA-003	calendrier	stade_critique	Anacarde — Taille formation après récolte	\N	null	null	[5, 6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.4, "libelle": "Entretien productivité"}, "alertes": [{"titre": "Taille formation anacarde juin-juil", "niveau": "moyenne", "message": "Post-récolte = fenêtre taille anacarde. Tailler tiges mortes, branches mal formées, crosses."}], "recommandations": [{"type": "mesure_culturale", "titre": "Taille entretien anacardier", "detail": "Supprimer branches mortes, gourmands, branches < 1.5 m sol. Cicatriser coupes avec bouillie bordelaise.", "priorite": 1}]}	moyenne	4	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1643	CAL-ANA-004	calendrier	stade_critique	Anacarde — Fertilisation pré-floraison (oct-nov)	\N	null	null	[10, 11]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Floraison sans réserves nutritives"}, "alertes": [{"titre": "Anacarde — Fertiliser avant floraison", "niveau": "moyenne", "message": "Oct-nov = dernières pluies = fenêtre fertilisation de fond avant floraison (janv-fév)."}], "recommandations": [{"type": "fertilisation", "titre": "Fertilisation anacardier pré-floraison", "detail": "NPK 10-10-20 ou fumure organique 20 kg/arbre en couronne. Couvrir zone racinaire.", "priorite": 1}]}	moyenne	5	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1644	CAL-BAN-003	calendrier	stade_critique	Banane — Gaine florale émergence	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Dommages régime"}, "alertes": [{"titre": "Gaine florale bananier — Actions urgentes", "niveau": "elevee", "message": "Émergence régime = stade critique. Enfumer fleur pour protéger. Tuteur si vent > 30 km/h prévu."}], "recommandations": [{"type": "mesure_culturale", "titre": "Ensachage régime banane", "detail": "Sac plastique bleu UV sur régime dès émergence = +15% calibre, protection insectes/froid.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Écimage inflorescence mâle", "detail": "Couper bourgeon mâle après dernière main = économie photosynthèse vers fruits.", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1645	CAL-BAN-004	calendrier	stade_critique	Banane — Rejets sélection monoculme	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 24}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Compétition rejets"}, "alertes": [{"titre": "Gestion rejets bananier — Sélection", "niveau": "moyenne", "message": "Bananier produit 8-15 rejets/an. Sans sélection = compétition = régimes petits. Conserver 1-2 rejets/cépée."}], "recommandations": [{"type": "mesure_culturale", "titre": "Éliminer rejets excédentaires", "detail": "Conserver 1 rejet sword-sucker tous les 4-5 mois. Couper autres à la base (bêche profonde).", "priorite": 1}]}	moyenne	4	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1646	CAL-MAG-003	calendrier	stade_critique	Mangue — Induction florale stress hydrique contrôlé	\N	null	null	[10, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "lte", "field": "meteo.temp_min", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Induction florale normale"}, "alertes": [{"titre": "Stress sec + froid = induction florale mangue", "niveau": "faible", "message": "Sec + nuits fraîches = induction florale naturelle. Ne pas irriguer 4-6 semaines. Floraison prévue janv-fév."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arrêt irrigation induction florale mangue", "detail": "Arrêt total arrosage oct-nov. Stimule induction florale. Reprendre à l'ouverture des boutons.", "priorite": 1}]}	faible	2	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1647	CAL-MAG-004	calendrier	stade_critique	Mangue — Thinning manuel grossissement fruits	\N	null	["fructification"]	[3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Fruits sous-calibrés"}, "alertes": [{"titre": "Thinning fruits mangue — Qualité export", "niveau": "moyenne", "message": "Limiter à 2-3 fruits/panicule = mangues calibre export. Sans thinning = 15+ petits fruits."}], "recommandations": [{"type": "mesure_culturale", "titre": "Thinning mangue à noix pois", "detail": "Au stade 'petite noix' (2-3 cm) = conserver 2-3 fruits/panicule. Calibre >350g = valeur marchande.", "priorite": 1}]}	moyenne	5	0.72	premium	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1648	CAL-RIZ-003	calendrier	stade_critique	Riz — Repiquage timing précis	\N	null	null	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 27}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Retard repiquage"}, "alertes": [{"titre": "Fenêtre repiquage riz — 21-25 JAL", "niveau": "moyenne", "message": "Repiquage optimal à 21-25 jours après semis pépinière. Au-delà 30j = perte tallage potentiel."}], "recommandations": [{"type": "semis", "titre": "Repiquer riz avant 25 JAL", "detail": "2-3 talles/poquet. Profondeur 2-3 cm. Espacement 20×20 cm. Ne pas repiquer > 30 JAL.", "priorite": 1}]}	moyenne	5	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1649	CAL-RIZ-004	calendrier	stade_critique	Riz — Retrait eau 10 jours avant récolte	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Récolte sol portant"}, "alertes": [{"titre": "Retrait eau riz — J-10 avant récolte", "niveau": "elevee", "message": "Retirer eau 10-14 jours avant récolte = sol portant pour machines + grains mûrs uniformément."}], "recommandations": [{"type": "irrigation", "titre": "Arrêt irrigation riz maturation", "detail": "Fermer arrivée eau 10-14 jours avant récolte estimée. Ressuyage sol = qualité grains + efficacité récolte.", "priorite": 1}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1650	CAL-MAI-003	calendrier	stade_critique	Maïs — Éclaircissage et démariage	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Compétition plants"}, "alertes": [{"titre": "Démariage maïs — 10-15 JAL", "niveau": "elevee", "message": "Maïs doit être démarié à 10-15 JAL. Conserver 1 plant vigoureux/poquet. Au-delà = concurrence racines."}], "recommandations": [{"type": "mesure_culturale", "titre": "Démariage maïs 10-15 JAL", "detail": "Conserver 1 plant/poquet (75×25 cm) ou 2 plants/poquet (75×40 cm). Conserver le plus vigoureux.", "priorite": 1}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1651	CAL-MAI-004	calendrier	stade_critique	Maïs — Buttage contre verse	\N	null	["tallage"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Verse si non butté"}, "alertes": [{"titre": "Buttage maïs — stade 5-7 feuilles", "niveau": "elevee", "message": "Butter maïs à 5-7 feuilles = stabilité contre verse + favorise racines adventives."}], "recommandations": [{"type": "mesure_culturale", "titre": "Butter maïs avec terre de labour", "detail": "Ramener terre au pied 8-10 cm hauteur. Combiner avec 2e apport urée. Outil : daba ou buttoir tracteur.", "priorite": 1}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1652	CAL-GEN-003	calendrier	general	Retard semis > 4 semaines — Perte potentiel rendement	\N	null	null	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.temp_air", "value": 27}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Retard fenêtre semis"}, "alertes": [{"titre": "Retard semis — Fenêtre se ferme", "niveau": "elevee", "message": "Août = fenêtre semis qui se ferme. Chaque semaine de retard = -5-10% potentiel rendement céréales."}], "recommandations": [{"type": "semis", "titre": "Semer maintenant variétés précoces", "detail": "Variétés 75-90 jours obligatoires si semis après mi-août. Ne pas dépasser 15 août pour mil/sorgho principal.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1653	CAL-GEN-004	calendrier	general	Rotation annuelle — Rappel anti-répétition culture	\N	null	null	null	{"clauses": [{"op": "eq", "field": "culture_precedent", "value": "present"}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Pathogènes sol par répétition"}, "alertes": [{"titre": "Rotation — Éviter même famille", "niveau": "moyenne", "message": "Répétition même culture ou même famille = accumulation pathogènes sols. Rotation minimum 2 ans conseillée."}], "recommandations": [{"type": "planification", "titre": "Rotation recommandée", "detail": "Alterner: Légumineuses → Céréales → Maraîchers. Solanées max 1/3 ans. Niébé enrichit sol N.", "priorite": 1}]}	moyenne	4	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1654	CAL-GEN-005	calendrier	general	Association culturale — Complémentarité nutritive	\N	null	null	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.25, "libelle": "Opportunité association"}, "alertes": [{"titre": "Association culturale recommandée", "niveau": "faible", "message": "Petite exploitation = associer Maïs + Niébé ou Sorgho + Arachide = complémentarité N + couverture sol."}], "recommandations": [{"type": "planification", "titre": "Associations productives AgroScan", "detail": "Maïs + Niébé (1:1) : Niébé fixe N, ombrage réduit adventices. Sorgho + Arachide : même logique.", "priorite": 1}]}	faible	2	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.255746+00	\N
1655	REN-RIZ-001	rendement	risque_rendement	Riz — Risque rendement élevé — Multiple stress	\N	null	["tallage", "montaison", "epiaison"]	null	{"clauses": [{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "lte", "field": "sol.azote", "value": 80}], "operator": "AND"}, {"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Rendement réduit riz"}, "alertes": [{"titre": "Risque rendement riz — actions correctrices urgentes", "niveau": "elevee", "message": "Combinaison de facteurs limitants : rendement potentiel réduit de 30-50%."}], "recommandations": [{"type": "fertilisation", "titre": "Corriger N + chaulage si pH<5.5", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation d'urgence si stress hydrique", "priorite": 2}]}	elevee	9	0.82	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1656	REN-RIZ-002	rendement	optimisation	Riz — Conditions optimales rendement maximum	\N	null	["tallage", "montaison"]	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 6.0, "value2": 7.0}, {"op": "gte", "field": "sol.azote", "value": 100}, {"op": "gte", "field": "sol.phosphore", "value": 15}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Risque faible"}, "alertes": [{"titre": "Conditions optimales riz — Maintenir", "niveau": "faible", "message": "Sol et eau en conditions idéales. Maintenir programme actuel."}], "recommandations": [{"type": "surveillance", "titre": "Maintenir surveillance maladies uniquement", "detail": "Sol OK. Focus sur Pyriculariose en tallage.", "priorite": 1}]}	faible	3	0.85	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1657	REN-MAI-001	rendement	risque_rendement	Maïs — Risque rendement — Carence N + stress eau floraison	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 80}, {"op": "lte", "field": "sol.humidite", "value": 45}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement maïs très bas"}, "alertes": [{"titre": "Double stress maïs floraison — Risque récolte très faible", "niveau": "critique", "message": "Carence N + stress hydrique simultanés à floraison : rendement <50% potentiel."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation immédiate 40-50mm", "priorite": 1, "urgence_jours": 1}, {"type": "fertilisation", "titre": "Urée foliaire 2% si sol trop sec pour incorporer", "priorite": 2}]}	critique	10	0.88	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1658	REN-MIL-001	rendement	risque_rendement	Mil — Risque rendement — Striga + sol pauvre	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "striga"}, {"op": "lte", "field": "sol.phosphore", "value": 8}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement quasi nul"}, "alertes": [{"titre": "Mil — Striga + carence P = récolte quasi nulle", "niveau": "critique", "message": "Striga + sol très pauvre : rendement <200 kg/ha possible. Intervention radicale."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher Striga AVANT floraison", "priorite": 1, "urgence_jours": 3}, {"dose": "1 cuillère/poquet", "type": "fertilisation", "titre": "DAP en microdosage urgence", "produit": "DAP 18-46-0", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1659	REN-ARA-001	rendement	risque_rendement	Arachide — Risque rendement — Aflatoxine gousses	\N	null	["fructification", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Aflatoxine rendement commercial"}, "alertes": [{"titre": "Arachide — Risque aflatoxine élevé", "niveau": "elevee", "message": "Chaud + humide à fructification : Aspergillus flavus produit aflatoxines. Valorisation commerciale à risque."}], "recommandations": [{"type": "recolte", "titre": "Récolter dès maturité sans délai", "priorite": 1, "urgence_jours": 7}, {"type": "post_recolte", "titre": "Séchage rapide <12% humidité", "detail": "Délai max 48h entre arrachage et séchage.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1660	REN-SOR-001	rendement	risque_rendement	Sorgho — Risque rendement — Cécidomyie + pluie floraison	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "contains", "field": "obs.ravageurs", "value": "cecidomyie"}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Rendement grains nul"}, "alertes": [{"titre": "Cécidomyie + humidité floraison sorgho", "niveau": "elevee", "message": "Combinaison Cécidomyie + conditions humides : pertes grains jusqu'à 100% sur panicule."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Malathion début floraison urgence", "produit": "Malathion 57EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1661	REN-NIE-001	rendement	risque_rendement	Niébé — Risque rendement — Bruche + stockage	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Perte totale stockage"}, "alertes": [{"titre": "Risque Bruche niébé — Perte stockage", "niveau": "elevee", "message": "Callosobruchus maculatus : 100% graines trouées en 3 mois si non traité."}], "recommandations": [{"dose": "3 comprimés/tonne", "type": "post_recolte", "titre": "Traitement stockage Phosphine OU huile neem", "produit": "Phosphure d'aluminium", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1662	REN-TOM-001	rendement	risque_rendement	Tomate — Risque rendement — BER + Mildiou + stress eau	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 60}, {"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Perte récolte tomate"}, "alertes": [{"titre": "Tomate — Triple stress fructification", "niveau": "critique", "message": "Carence K + stress hydrique + humidité élevée = BER + Mildiou + chute fleurs simultanés."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière urgence", "priorite": 1, "urgence_jours": 1}, {"type": "fertilisation", "titre": "K₂SO₄ + nitrate calcium foliaire", "priorite": 2}, {"type": "traitement_phyto", "titre": "Fongicide Mildiou", "priorite": 3, "urgence_jours": 2}]}	critique	10	0.88	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1663	REN-OIG-001	rendement	risque_rendement	Oignon — Risque rendement — Bulbes petits conservation faible	\N	null	["bulbaison"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 60}, {"op": "lte", "field": "sol.azote", "value": 60}, {"op": "lte", "field": "sol.humidite", "value": 45}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Faible rendement commercial oignon"}, "alertes": [{"titre": "Oignon — Carence NPK + stress hydrique bulbaison", "niveau": "elevee", "message": "Bulbaison compromettante : calibre réduit + conservation <2 mois."}], "recommandations": [{"type": "fertilisation", "titre": "K₂SO₄ + irrigation compensatoire urgence", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation 4-5 mm/j maintenant", "priorite": 2, "urgence_jours": 1}]}	elevee	8	0.82	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1664	REN-PIM-001	rendement	risque_rendement	Piment — Risque rendement — Chaleur + Virus + Thrips	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 35}, {"op": "contains", "field": "obs.ravageurs", "value": "thrips"}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Perte récolte piment"}, "alertes": [{"titre": "Piment — Chaleur + Thrips = chute récolte", "niveau": "elevee", "message": "Chaleur >35°C + Thrips : avortement fleurs + transmission TSWV. Risque zéro récolte."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine anti-thrips urgent", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 2}, {"type": "irrigation", "titre": "Irrigation matin tôt pour rafraîchir", "priorite": 2, "urgence_jours": 1}]}	elevee	9	0.85	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1665	REN-MAG-001	rendement	risque_rendement	Mangue — Risque récolte faible — Oïdium + pluies floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "contains", "field": "obs.symptomes", "value": "oidium"}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Perte récolte mangue"}, "alertes": [{"titre": "Mangue — Oïdium + pluies floraison = récolte compromise", "niveau": "critique", "message": "Oïdium actif + pluies à floraison : perte 50-80% inflorescences possible."}], "recommandations": [{"dose": "3 kg Soufre + 0,5 L Tebu/ha", "type": "traitement_phyto", "titre": "Soufre + fongicide curatif floraison", "produit": "Soufre 80WP + Tebuconazole 25EC", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1666	REN-ANA-001	rendement	risque_rendement	Anacarde — Risque rendement noix — Anthracnose + pluies	\N	null	["floraison", "nouaison"]	[3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Perte noix cajou"}, "alertes": [{"titre": "Anthracnose anacarde + pluies = pertes noix", "niveau": "elevee", "message": "Pluies prolongées à nouaison : Colletotrichum cause chute noix jusqu'à 60%."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime + cuivre anti-Anthracnose", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1667	REN-BAN-001	rendement	risque_rendement	Banane — Risque rendement — Sigatoka noire sévère	\N	["casamance"]	null	[7, 8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "sigatoka"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement commercial nul"}, "alertes": [{"titre": "Sigatoka noire active + pluies = mûrissement prématuré", "niveau": "critique", "message": "Sigatoka sévère : défoliation >50% = régimes mûrissent 4-6 semaines trop tôt."}], "recommandations": [{"dose": "0,8 L/ha", "type": "traitement_phyto", "titre": "Programme fongicide intensif", "produit": "Propiconazole 25EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.9	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1668	REN-PAP-001	rendement	risque_rendement	Papaye — PRSV = perte totale production	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "ringspot"}, {"op": "contains", "field": "obs.symptomes", "value": "mosaique_papaye"}], "operator": "OR"}	{"risque": {"score": 0.98, "libelle": "Perte totale production papaye"}, "alertes": [{"titre": "PRSV papaye — Perte production totale", "niveau": "critique", "message": "PRSV actif : production nulle sur plants infectés. Contamination rapide voisins."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher TOUS les plants infectés", "detail": "Quarantaine parcelle. Informer producteurs voisins.", "priorite": 1, "urgence_jours": 1}, {"type": "planification", "titre": "Replanter variétés tolérantes PRSV", "detail": "Maradol rouge, Sunrise Solo si disponibles.", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1669	REN-MAN-001	rendement	risque_rendement	Manioc — CMD + qualité tubercules	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_manioc"}, {"op": "contains", "field": "obs.ravageurs", "value": "acarien_vert"}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Perte rendement manioc critique"}, "alertes": [{"titre": "Manioc — CMD + Acarien vert = rendement nul", "niveau": "critique", "message": "Mosaïque + Acarien vert simultanés : perte rendement 80-100%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants malades", "priorite": 1, "urgence_jours": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine anti-acarien", "produit": "Abamectine 1.8EC", "priorite": 2, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Replanter boutures certifiées CMD-résistantes", "priorite": 3}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1670	REN-SES-001	rendement	risque_rendement	Sésame — Risque rendement nul — égrenage avant récolte	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 30}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Perte totale égrenage"}, "alertes": [{"titre": "Sésame mûr + vent fort = RÉCOLTER IMMÉDIATEMENT", "niveau": "critique", "message": "Vent >30km/h sur sésame mûr : ouverture capsules + égrenage = pertes 100% en 1 jour."}], "recommandations": [{"type": "recolte", "titre": "Couper tiges AUJOURD'HUI — urgence absolue", "detail": "Couper à la base. Lier en gerbes immédiatement. Battre dans 48h.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1671	REN-GEN-001	rendement	optimisation	Conditions optimales sol — Rendement maximum possible	\N	null	null	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 6.0, "value2": 7.0}, {"op": "gte", "field": "sol.azote", "value": 100}, {"op": "gte", "field": "sol.phosphore", "value": 20}, {"op": "gte", "field": "sol.potassium", "value": 100}, {"op": "gte", "field": "sol.matiere_organique", "value": 2.0}], "operator": "AND"}	{"risque": {"score": 0.15, "libelle": "Risque rendement faible"}, "alertes": [{"titre": "Excellentes conditions sol — Rendement optimal", "niveau": "faible", "message": "Sol en conditions idéales. Facteur limitant = phytosanitaire uniquement."}], "recommandations": [{"type": "surveillance", "titre": "Programme prophylactique maladies/ravageurs uniquement", "detail": "Sol non limitant. Concentrer efforts sur protection phytosanitaire.", "priorite": 1}]}	faible	3	0.85	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1672	REN-GEN-002	rendement	risque_rendement	Sol très dégradé — Rendement faible garanti	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}, {"op": "lte", "field": "sol.phosphore", "value": 6}, {"op": "lte", "field": "sol.azote", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Sol dégradé rendement bas"}, "alertes": [{"titre": "Sol très dégradé — Rendement <50% potentiel garanti", "niveau": "elevee", "message": "Triple carence P + N + MO <0.5% : même avec bonnes pluies, rendement sera faible."}], "recommandations": [{"dose": "10 t/ha", "type": "amendement_organique", "titre": "Compost 10t/ha avant plantation", "produit": "Fumier composté", "priorite": 1}, {"dose": "50 kg DAP + 40 kg Urée/ha fractionnés", "type": "fertilisation", "titre": "Programme NPK complet + microdosage", "produit": "DAP 18-46-0 + Urée 46%", "priorite": 2}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1673	REN-ARA-003	rendement	prevision	Prévision rendement arachide — Conditions favorables	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 25}, {"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 32}, {"op": "between", "field": "sol.pH", "value": 5.8, "value2": 6.5}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement correct attendu"}, "alertes": [{"titre": "Conditions favorables rendement arachide", "niveau": "faible", "message": "Conditions actuelles bonnes pour remplissage gousses. Rendement estimé 1.5-2 t/ha sans pertes."}], "recommandations": [{"type": "prevision", "titre": "Préparer logistique récolte arachide", "detail": "Rendement attendu 1.5-2 t/ha en sec. Prévoir main d'oeuvre arrachage + séchage solaire 4-5 jours.", "priorite": 1}]}	faible	2	0.72	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1674	REN-ARA-004	rendement	perte_qualite	Récolte tardive arachide — Aflatoxines + germination	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 70}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Contamination aflatoxines"}, "alertes": [{"titre": "Retard récolte arachide = aflatoxines", "niveau": "critique", "message": "Arachide mûre sous pluie = Aspergillus flavus → aflatoxines B1. Invendable. Récolter immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte urgence arachide", "detail": "Arracher + sécher dans les 48h. Séchage < 8% humidité. Triage visuel gousses décolorées.", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1675	REN-SOR-003	rendement	prevision	Prévision rendement sorgho — Grains en formation	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.pluie_7j", "value": 15, "value2": 40}, {"op": "between", "field": "meteo.temp_air", "value": 27, "value2": 33}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement attendu correct"}, "alertes": [{"titre": "Remplissage grains sorgho normal", "niveau": "faible", "message": "Conditions pluie + T acceptables pour remplissage. Rendement estimé 1.5-2.5 t/ha selon variété."}], "recommandations": [{"type": "prevision", "titre": "Prévoir logistique battage sorgho", "detail": "Rendement estimé 1.5-2.5 t/ha. Prévoir séchage panicules 10-14 jours avant battage.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1676	REN-SOR-004	rendement	perte_stockage	Stockage sorgho — Moisissures grain humide	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Moisissure stockage"}, "alertes": [{"titre": "Risque stockage sorgho humide", "niveau": "elevee", "message": "Grain > 14% humidité en stockage = Aspergillus + Fusarium. Sécher à < 12% avant stockage."}], "recommandations": [{"type": "mesure_culturale", "titre": "Séchage sorgho avant stockage", "detail": "Séchage solaire sur bâche 5-7 jours. Tester humidité grains. Magasin aéré, surélevé.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1677	REN-NIE-003	rendement	perte_stockage	Niébé stockage — Bruche Callosobruchus maculatus	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Bruche stockage"}, "alertes": [{"titre": "Bruche niébé — traitement stockage urgent", "niveau": "critique", "message": "T > 28°C + HR 50-75% = conditions parfaites Callosobruchus maculatus. 100% perte en 6 mois sans protection."}], "recommandations": [{"type": "mesure_culturale", "titre": "Protection grains niébé stockage", "detail": "Huile végétale 5 ml/kg (suffoquer insectes). Ou hermétique (silo métallique). Ou N-SanKam.", "priorite": 1, "urgence_jours": 1}, {"type": "traitement", "titre": "Phosphine si attaque sévère", "detail": "Phosphine (fumigation) si infestation > 10 insectes/kg. Professionnel uniquement.", "priorite": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1678	REN-NIE-004	rendement	prevision	Prévision rendement niébé — Gousses en formation	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 27, "value2": 34}, {"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Conditions normales niébé fructification", "niveau": "faible", "message": "Gousses en formation dans bonnes conditions. Rendement attendu 0.6-1.2 t/ha graine sèche."}], "recommandations": [{"type": "prevision", "titre": "Récolte niébé 2-3 passages", "detail": "Récolter en 2-3 passages quand gousses jaunissent. Éviter attendre toutes mûres = déhiscence.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1679	REN-SES-003	rendement	prevision	Prévision rendement sésame — Capsules formées	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 27, "value2": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement attendu"}, "alertes": [{"titre": "Sésame — capsules en formation", "niveau": "faible", "message": "Capsules bien formées. Rendement attendu 400-700 kg/ha graine selon variété."}], "recommandations": [{"type": "prevision", "titre": "Préparation récolte sésame", "detail": "À 2/3 capsules jaunies = couper. Bottes debout 5j. Battre sur bâche. Rendement décortiqué × 0.97.", "priorite": 1}]}	faible	2	0.68	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1680	REN-SES-004	rendement	qualite	Sésame — Qualité huile (teneur > 50%)	\N	null	null	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 5.5, "value2": 7.0}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Qualité huile bonne"}, "alertes": [{"titre": "Conditions favorables qualité huile sésame", "niveau": "faible", "message": "T > 28°C + pH sol neutre = teneur huile optimale (51-56%). Récolte pas trop tardive pour couleur claire."}], "recommandations": [{"type": "prevision", "titre": "Séchage rapide pour sésame qualité export", "detail": "Séchage rapide < 6% humidité = qualité blanc premium. Éviter contact sol = couleur foncée déclassée.", "priorite": 1}]}	faible	2	0.68	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1681	REN-MAN-003	rendement	prevision	Prévision rendement manioc — Maturation 12-18 mois	\N	null	["tuberisation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 34}, {"op": "between", "field": "sol.pH", "value": 5.5, "value2": 7.5}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Tubérisation normale"}, "alertes": [{"titre": "Conditions normales manioc tubérisation", "niveau": "faible", "message": "Tubérisation active. Rendement 15-25 t/ha attendu à 12 mois selon variété."}], "recommandations": [{"type": "prevision", "titre": "Plan récolte manioc échelonnée", "detail": "Manioc = récolte possible 8-24 mois. Récolter par plots pour étaler commercialisation.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1682	REN-MAN-004	rendement	perte_recolte	Manioc — Pertes post-récolte détérioration 48h	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Détérioration post-récolte rapide"}, "alertes": [{"titre": "Manioc récolté — Détérioration 24-48h", "niveau": "critique", "message": "Racines manioc = périt en 24-48h après récolte. Vendre ou transformer immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Transformer manioc dans les 24h", "detail": "Gari, attiéké, farine, chips = transformer dans les 24h. Trempage eau = 48h max.", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Cirage racines si délai", "detail": "Paraffine ou huile végétale sur racines = +5 jours conservation.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1683	REN-GOM-003	rendement	prevision	Prévision rendement gombo — Production continue	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 28, "value2": 36}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Production normale"}, "alertes": [{"titre": "Rendement gombo — production continue possible", "niveau": "faible", "message": "Conditions thermiques idéales gombo. Production 8-12 t/ha/cycle sur 4-5 mois récolte continue."}], "recommandations": [{"type": "prevision", "titre": "Plan commercialisation gombo", "detail": "Récolte continue = marché local frais ou transformation (séchage). Gombo séché × 8 = valeur ajoutée.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1684	REN-PIM-003	rendement	prevision	Prévision rendement piment — Fructification normale	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Conditions piment fructification correctes", "niveau": "faible", "message": "Piment en bonnes conditions. Rendement attendu 8-15 t/ha selon variété et conduite."}], "recommandations": [{"type": "prevision", "titre": "Préparer commercialisation piment", "detail": "Piment frais = marché local. Piment rouge séché = valeur ×3. Prévoir séchoir solaire.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1685	REN-PIM-004	rendement	qualite	Piment — Calibre et teneur capsaïcine	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Qualité capsaïcine favorable"}, "alertes": [{"titre": "Chaleur sèche = capsaïcine élevée piment", "niveau": "faible", "message": "T > 30°C + faible HR = piment plus fort (capsaïcine élevée). Valeur marchande piment fort supérieure."}], "recommandations": [{"type": "prevision", "titre": "Valoriser piment fort en saison sèche", "detail": "Piment séché saison sèche = teneur capsaïcine max. Marché export possible (poudre piment).", "priorite": 1}]}	faible	2	0.65	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1686	REN-ANA-003	rendement	prevision	Prévision rendement anacarde — Maturation noix	\N	null	["fructification"]	[3, 4, 5]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 28, "value2": 36}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Anacarde — noix en formation", "niveau": "faible", "message": "Conditions sèches normales maturation anacarde. Rendement 500-800 kg/ha noix brutes attendu."}], "recommandations": [{"type": "prevision", "titre": "Récolte anacarde au sol dès chute", "detail": "Ramasser quotidiennement dès chute. Ne pas laisser > 3 jours sol (champignons). Sécher 3-5 jours.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1687	REN-ANA-004	rendement	qualite	Anacarde — Outturn (KOR) qualité export	\N	null	null	[4, 5]	{"clauses": [{"op": "lte", "field": "meteo.humidite_rel", "value": 50}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Qualité export"}, "alertes": [{"titre": "Séchage anacarde — qualité KOR optimal", "niveau": "faible", "message": "Séchage bien = KOR (Kernel Output Ratio) > 47 = prime export. Séchage < 3 jours = KOR bas."}], "recommandations": [{"type": "mesure_culturale", "titre": "Séchage anacarde 3-5 jours soleil", "detail": "Humidité 8-10% = KOR optimal. Test: bonne noix flotte pas dans eau. Stocker sur palette.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1688	REN-BAN-003	rendement	prevision	Prévision rendement banane — Régime 75-120 jours	\N	null	null	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 33}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Conditions croissance banane normales", "niveau": "faible", "message": "T 25-33°C + eau disponible = croissance optimale. Régime = 25-40 kg/plant selon variété."}], "recommandations": [{"type": "prevision", "titre": "Suivi mûrissement banane 75-120j", "detail": "Du bourgeon mâle à récolte = 75-120 jours. Récolter quand angles des doigts s'arrondissent.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1689	REN-BAN-004	rendement	perte_recolte	Banane — Pertes post-récolte mûrissement rapide	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pertes post-récolte chaleur"}, "alertes": [{"titre": "Banane — Mûrissement accéléré T > 32°C", "niveau": "elevee", "message": "> 32°C = banane verte mûrit en 2-3 jours. Logistique vente/transport urgente."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolter banane légèrement verte", "detail": "Récolter avant maturité commerciale si transport > 2 jours. Chambre fraîche si possible.", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1690	REN-PAS-003	rendement	prevision	Prévision rendement pastèque — Grossissement	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 28, "value2": 36}, {"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Pastèque en grossissement normal", "niveau": "faible", "message": "Conditions favorables grossissement. Rendement 25-35 t/ha selon conduite."}], "recommandations": [{"type": "prevision", "titre": "Indicateurs maturité pastèque", "detail": "Vrille sèche + son creux au tapotage + pédoncule brunissant = maturité. Brix > 10 = qualité premium.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1691	REN-MAG-003	rendement	perte_qualite	Mangue — Attaques mouches + anthracnose post-récolte	\N	null	["fructification"]	[4, 5, 6]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pertes mouches + anthracnose"}, "alertes": [{"titre": "Mouches fruits + anthracnose mangue post-récolte", "niveau": "elevee", "message": "Ceratitis cosyra + Colletotrichum = pertes 30-60% après récolte. Traitements bagging/trempage."}], "recommandations": [{"type": "traitement", "titre": "Ensachage mangue ou trempage post-récolte", "detail": "Bagging plastique (eau-savon) empêche ponte. Après récolte: trempage eau chaude 50°C/5min anti-anthracnose.", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1692	REN-MAG-004	rendement	prevision	Prévision rendement mangue — Floraison abondante	\N	null	["floraison"]	[1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 23, "value2": 31}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Bon potentiel récolte"}, "alertes": [{"titre": "Floraison mangue — conditions favorables", "niveau": "faible", "message": "T 23-31°C + sec = pollinisation optimale mangue. Bon nouage = récolte 3-4 mois."}], "recommandations": [{"type": "prevision", "titre": "Estimer récolte mangue 90-120 jours", "detail": "Floraison → récolte = 90-120 jours selon variété. Kent: 110j. Amélie: 90j. Keitt: 120j.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1693	REN-RIZ-003	rendement	perte_recolte	Riz — Pertes récolte tardive égrenage	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Égrenage récolte tardive"}, "alertes": [{"titre": "Riz mûr + vent = égrenage", "niveau": "elevee", "message": "Riz à maturité + vent > 30 km/h + sec = égrenage spontané. Perdre 20-30% récolte en 3-5 jours."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte riz urgence — ne pas attendre", "detail": "Couper quand 85% des grains mûrs (couleur dorée). Ne pas attendre 100% = pertes.", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1694	REN-RIZ-004	rendement	prevision	Prévision rendement riz — Remplissage grains	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "between", "field": "meteo.pluie_7j", "value": 15, "value2": 40}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement paddy attendu"}, "alertes": [{"titre": "Remplissage grains riz normal", "niveau": "faible", "message": "Conditions favorables remplissage. Rendement estimé 4-6 t/ha paddy selon variété et conduite."}], "recommandations": [{"type": "prevision", "titre": "Estimer production paddy par parcelle", "detail": "Compter 4-6 panicules/m² × 150-200 grains/panicule × 30g/1000grains = estimation.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1695	REN-MAI-003	rendement	perte_stockage	Maïs stockage — Sitophilus zeamais charançon	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 27}, {"op": "between", "field": "meteo.humidite_rel", "value": 55, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Charançon stockage maïs"}, "alertes": [{"titre": "Charançon maïs — Conditions stockage actives", "niveau": "critique", "message": "T > 27°C + HR 55-80% = Sitophilus zeamais actif. 1 femelle = 300 descendants. 50% perte en 6 mois."}], "recommandations": [{"type": "mesure_culturale", "titre": "Protection maïs stockage", "detail": "Sécher à < 12% humidité avant stockage. Silo hermétique ou traitement Actellic 2%. Durée max 6 mois.", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1696	REN-MAI-004	rendement	prevision	Prévision rendement maïs — Remplissage épis	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 33}, {"op": "between", "field": "meteo.pluie_7j", "value": 15, "value2": 40}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement attendu"}, "alertes": [{"titre": "Maïs — remplissage épis normal", "niveau": "faible", "message": "Conditions remplissage grains maïs normales. Rendement 2.5-4 t/ha selon variété."}], "recommandations": [{"type": "prevision", "titre": "Indicateurs maturité maïs", "detail": "Grain à lait → pâteux → vitreux = maturité. Couche noire base grain = maturité physiologique atteinte.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1697	REN-MIL-003	rendement	prevision	Prévision rendement mil — Chandelle formation	\N	null	["epiaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 27, "value2": 35}, {"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Rendement normal"}, "alertes": [{"titre": "Chandelle mil en formation normale", "niveau": "faible", "message": "Épiaison mil dans bonnes conditions. Rendement estimé 800-1500 kg/ha selon pluviométrie."}], "recommandations": [{"type": "prevision", "titre": "Récolte mil 90-100 JAL", "detail": "Couper chandelles à 85-90% grains mûrs. Sécher 7-10 jours. Battre quand grain dur à ongle.", "priorite": 1}]}	faible	2	0.7	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1698	REN-MIL-004	rendement	perte_stockage	Mil — Humidité stockage + mites Sitotroga	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Insectes stockage + moisissures"}, "alertes": [{"titre": "Mil stockage — Sitotroga + humidité", "niveau": "elevee", "message": "T > 28°C + HR > 65% = Sitotroga cerealella (mite) + moisissures. Grain > 12% humidité = risque."}], "recommandations": [{"type": "mesure_culturale", "titre": "Sécher mil avant grenier", "detail": "Sécher chandelles sur aire 10-12 jours. Stocker grains battus < 12% HR. Grenier ventilé surélevé.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1699	REN-GEN-003	rendement	general	Déficit combiné N+eau — Perte rendement systématique	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.05}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Double stress N+eau"}, "alertes": [{"titre": "Double stress N + eau = perte rendement -30 à -50%", "niveau": "critique", "message": "Carence N + stress hydrique simultanés = perte rendement 30-50% inévitable. Lever un des deux en priorité."}], "recommandations": [{"type": "irrigation", "titre": "Lever stress hydrique en premier", "detail": "Irrigation avant fertilisation. Urée sans eau = brûlure + volatilisation.", "priorite": 1, "urgence_jours": 1}, {"type": "fertilisation", "titre": "Urée après retour eau", "detail": "30-50 kg/ha urée dès que sol humide. Enfoui légèrement.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1700	REN-GEN-004	rendement	general	Pertes post-récolte généralisées — Mauvais séchage	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Conditions séchage défavorables"}, "alertes": [{"titre": "Mauvaises conditions séchage récoltes", "niveau": "elevee", "message": "HR > 75% + pluies = séchage impossible en plein air. Grains humides = moisissures + perte valeur."}], "recommandations": [{"type": "mesure_culturale", "titre": "Séchage artificiel ou étaler attente", "detail": "Séchoir amélioré ou étaler sur béton sous abri. Tourner 2x/jour. Humidité cible < 12%.", "priorite": 1}, {"type": "planification", "titre": "Reporter transformation si possible", "detail": "Si stock peut attendre, reporter jusqu'au temps sec. Sinon : séchoir à bois urgence.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1701	REN-GEN-005	rendement	general	Estimation pertes adventices non désherbées	\N	null	["croissance_vegetative"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pertes adventices non contrôlées"}, "alertes": [{"titre": "Adventices saison pluies — Pertes rendement -20-40%", "niveau": "elevee", "message": "Saison pluies + chaleur = explosion adventices. Sans désherbage 30-45 JAL = perte 20-40% rendement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Désherbage manuel ou herbicide 15-25 JAL", "detail": "Désherber avant 25 JAL = critique. 2e passage 45 JAL si besoin. Herbicides: Pendiméthaline + Gramoxone.", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1702	REN-GEN-006	rendement	general	Estimateur rendement global parcelle — Contexte favorable	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.pluie_7j", "value": 10, "value2": 50}, {"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 33}, {"op": "between", "field": "sol.pH", "value": 5.5, "value2": 7.5}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Conditions générales favorables"}, "alertes": [{"titre": "Contexte général favorable à la production", "niveau": "faible", "message": "Pluie, T et pH sol dans plages optimales. Conditions générales favorables. Anticiper récolte dans les délais."}], "recommandations": [{"type": "prevision", "titre": "Planifier logistique récolte selon estimation", "detail": "Prévoir main d'oeuvre, transport, stockage selon rendement attendu par culture.", "priorite": 1}]}	faible	2	0.68	premium	t	\N	1.0	2026-06-10 16:30:58.411525+00	\N
1703	GEN-SOL-001	fertilisation	sol_general	Sol salin — Réduction rendement all crops	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.conductivite", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Salinité critique"}, "alertes": [{"titre": "Sol très salin > 6 dS/m", "niveau": "critique", "message": "CE > 6 dS/m = rendement réduit 50-100% selon culture. Lessivage + gypse + drainage obligatoire."}], "recommandations": [{"type": "mesure_culturale", "titre": "Lessivage sel sol salin", "detail": "Irrigation abondante 150-200 mm/ha pour lessiver sel en profondeur. Drain nécessaire.", "priorite": 1}, {"type": "fertilisation", "titre": "Gypse sol sodique", "detail": "Gypse 2-4 t/ha si Na échangeable. Remplacement Na par Ca favorise floculation.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1704	GEN-SOL-002	fertilisation	sol_general	MO sol très faible — Dégradation structure	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Dégradation sol avancée"}, "alertes": [{"titre": "MO sol < 0.5% — Dégradation sévère", "niveau": "elevee", "message": "MO < 0.5% = sol fragile, peu de rétention eau, faible activité biologique. Agroforesterie + compost urgent."}], "recommandations": [{"type": "fertilisation", "titre": "Apport compost/fumier urgent", "detail": "10-20 t/ha fumier ou compost bien décomposé. Incorporer avant semis.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Couverture végétale permanente", "detail": "Résidus de récolte au sol + légumineuses couvertes inter-saison.", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1705	GEN-SOL-003	fertilisation	sol_general	Compaction sol — Tassement profond	\N	null	null	null	{"clauses": [{"op": "in", "field": "sol.texture", "value": ["argileuse", "argilo_limoneuse", "argilo_limoneux"]}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Compaction sol argileux"}, "alertes": [{"titre": "Risque compaction sol argileux sec", "niveau": "elevee", "message": "Sol argileux sec + passages engins = compaction durée. Racines bloquées = rendement -20-40%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Éviter passages sur sol sec argileux", "detail": "Travailler sol après pluie légère. Sous-solage 1/3 ans si compaction historique.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1706	GEN-IRR-001	irrigation	efficience	Stress hydrique cumulé — Score DSI > 4	\N	null	null	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.etp", "value": 5.5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "sol.humidite", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Stress quadruple indicateurs"}, "alertes": [{"titre": "Déficit stress combiné — Irrigation urgente", "niveau": "critique", "message": "4 indicateurs simultanés = stress hydrique extrême. Irrigation d'urgence toutes cultures actives."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation priorité maximale", "detail": "Toute culture en phase végétative/floraison doit être irriguée dans les 12-24h.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1707	GEN-IRR-002	irrigation	efficience	Nappe souterraine basse — Restriction eau	\N	null	null	[3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 7.0}, {"op": "lte", "field": "meteo.pluie_7j", "value": 2}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Restriction ressource eau"}, "alertes": [{"titre": "Saison sèche — restriction eau potentielle", "niveau": "elevee", "message": "ETP > 7 + quasi pas de pluie = nappe descendante. Prioriser eau cultures haute valeur."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation localisée goutte-à-goutte", "detail": "Goutte-à-goutte = 40-60% économie eau vs aspersion. Priorité saison sèche.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Mulch organique obligatoire", "detail": "10 cm mulch = réduit ETP sol de 30%. Paille, résidus, feuilles mortes.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1708	GEN-MET-001	meteo	alerte_integree	Triple stress thermique-hydrique-salin	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 36}, {"op": "lte", "field": "meteo.pluie_7j", "value": 3}, {"op": "gte", "field": "sol.conductivite", "value": 3.0}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Triple stress catastrophique"}, "alertes": [{"titre": "Triple stress chaleur+sécheresse+salinité", "niveau": "critique", "message": "T > 36°C + sec + sol salin = triple stress = perte rendement 60-80%. Actions d'urgence multiples."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation fractionnée urgence", "detail": "Petites doses fréquentes pour ne pas aggraver salinité. Eau < 1 dS/m si possible.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Ombrage d'urgence", "detail": "Filet ombrage 50% + mulch sol. Cultures annuelles: envisager abandon partiel.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1709	GEN-MET-002	meteo	alerte_integree	Alerte ravageurs migrateurs — Saison propice	\N	null	null	[5, 6, 10, 11]	{"clauses": [{"op": "between", "field": "meteo.vent", "value": 15, "value2": 40}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Ravageurs migrateurs possibles"}, "alertes": [{"titre": "Conditions propices ravageurs migrateurs", "niveau": "moyenne", "message": "Vent 15-40 km/h + T + humidité = arrivée noctuelles, acridiens migrateurs possible. Surveiller."}], "recommandations": [{"type": "surveillance", "titre": "Surveillance ravageurs migrateurs", "detail": "Inspection matinale. Alerter DGPV/DAPSA si criquet pèlerin ou noctuelle de l'armée observés.", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1710	GEN-RAV-001	ravageur	general	Pullulation insectes fleur — Pollinisateurs-nuisibles coexistence	\N	null	["floraison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.55, "libelle": "Pollinisateurs floraison"}, "alertes": [{"titre": "Floraison — Traiter soir pas pendant floraison", "niveau": "moyenne", "message": "Pollinisateurs actifs en journée. Tout insecticide pendant floraison = perte pollinisateurs = moins de fruits."}], "recommandations": [{"type": "traitement", "titre": "Traitement insecticide soir uniquement", "detail": "Traiter exclusivement après 18h ou avant 7h du matin. Jamais pendant pleine floraison.", "priorite": 1}]}	moyenne	4	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1711	GEN-RAV-002	ravageur	general	Résistance insecticides — Rotation molécules	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.4, "libelle": "Risque résistance"}, "alertes": [{"titre": "Prévention résistance insecticides", "niveau": "faible", "message": "Même molécule > 2x/cycle = risque résistance accéléré. Rotation groupes chimiques recommandée."}], "recommandations": [{"type": "traitement", "titre": "Rotation insecticides groupes différents", "detail": "OP → Pyrethroïde → Neonicotinoïde → rotation. Jamais même groupe 2 traitements consécutifs.", "priorite": 1}]}	faible	3	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1712	GEN-RAV-003	ravageur	general	Nématodes sol — Galles racines cultures maraîchères	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.temperature", "value": 25}, {"op": "in", "field": "sol.texture", "value": ["sableuse", "sablo_limoneuse"]}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Nématodes Meloidogyne"}, "alertes": [{"titre": "Nématodes galles — Sol sableux chaud", "niveau": "elevee", "message": "Sol sableux + T > 25°C = Meloidogyne actif. Galles racines = blocage eau+nutriments."}], "recommandations": [{"type": "mesure_culturale", "titre": "Solarisation sol anti-nématodes", "detail": "Plastique transparent sur sol humide 4-6 semaines = T > 50°C = mort nématodes.", "priorite": 1}, {"type": "traitement", "titre": "Fosthiazate ou Carbofuran nématicides", "detail": "Fosthiazate (Nemathorin) 5 kg/ha ou Carbofuran 5G si solarisation impossible.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1713	GEN-RAV-004	ravageur	general	Oiseaux granivores — Protection épiaison universelle	\N	null	["epiaison", "maturation"]	[9, 10]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Oiseaux granivores"}, "alertes": [{"titre": "Oiseaux granivores épiaison — Protection urgente", "niveau": "critique", "message": "Quelea quelea + Estrilda + tourterelles actifs à épiaison. Perte 100% en 48h si pas protégé."}], "recommandations": [{"type": "mesure_culturale", "titre": "Gardiennage continu épiaison", "detail": "Gardiennage dès 6h-18h. Fils nylon brillant + épouvantails + pétards = combinaison efficace.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Filet oiseaux si petit champ", "detail": "Filet polyéthylène < 1 ha = solution fiable. Investissement rentabilisé en 1-2 saisons.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1714	GEN-RAV-005	ravageur	general	Termites — Dégâts semis et racines saison sèche	\N	null	["levee"]	[3, 4, 5, 11, 12, 1, 2]	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 25}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Dégâts termites semis"}, "alertes": [{"titre": "Termites actifs — Sol sec chaud", "niveau": "elevee", "message": "Sol sec + chaleur = termites actifs. Semences ou racines attaquées. Manque à lever."}], "recommandations": [{"type": "traitement", "titre": "Insecticide sol contre termites", "detail": "Imidaclopride 70WS en traitement semences (5 ml/kg). Ou chlorpyrifos sol 1 L/ha.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1715	GEN-CAL-001	calendrier	general	Désherbage chimique pré-levée — Fenêtre application	\N	null	["semis"]	null	{"clauses": [{"op": "between", "field": "meteo.pluie_24h", "value": 5, "value2": 20}], "operator": "AND"}	{"risque": {"score": 0.25, "libelle": "Opportunité herbicide pré-levée"}, "alertes": [{"titre": "Fenêtre herbicide pré-levée après pluie légère", "niveau": "faible", "message": "Pluie légère = sol humide = herbicide pré-levée efficace. Traiter dans les 3 jours post-semis."}], "recommandations": [{"type": "traitement", "titre": "Pendiméthaline pré-levée", "detail": "Pendiméthaline 1.5 L/ha ou Atrazine 1 kg/ha (maïs). Sol humide, pas séché. < 3 jours post-semis.", "priorite": 1}]}	faible	3	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1716	GEN-CAL-002	calendrier	general	Traitement semences — Rappel systématique	\N	null	["semis"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.3, "libelle": "Semences non traitées"}, "alertes": [{"titre": "Traitement semences avant semis", "niveau": "faible", "message": "Traitement semences = investissement minimal + protection maximale levée. ROI 1:10."}], "recommandations": [{"type": "traitement", "titre": "Programme traitement semences", "detail": "Thirame 3g/kg (fongicide) + Imidaclopride 5ml/kg (insecticide). Mélanger avant semis.", "priorite": 1}]}	faible	2	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1717	GEN-CAL-003	calendrier	general	Récolte matinale — Qualité maximale fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Qualité récolte"}, "alertes": [{"titre": "Récolter tôt matin — Qualité + conservation", "niveau": "faible", "message": "Récolte avant 10h = température fruits basse = moins d'éthylène = 2x plus longue conservation."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte 6h-9h matin", "detail": "Récolter avant les heures chaudes. Stocker à l'ombre immédiatement. Ne pas exposer au soleil.", "priorite": 1}]}	faible	2	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1718	GEN-REN-001	rendement	general	Attaque multiple simultanée — Réduction synergique	\N	null	null	null	{"clauses": [{"op": "not_null", "field": "obs_ravageurs"}, {"op": "not_null", "field": "obs_symptomes"}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Attaques multiples synergiques"}, "alertes": [{"titre": "Attaques multiples simultanées", "niveau": "critique", "message": "Ravageur + maladie + sécheresse = synergie destructive. Pertes peuvent être totales (80-100%)."}], "recommandations": [{"type": "irrigation", "titre": "Lever stress hydrique en premier", "detail": "Plante stressée = immunité nulle. Irriguer avant tout traitement.", "priorite": 1}, {"type": "traitement", "titre": "Traitement intégré ravageur + maladie", "detail": "Tank-mix insecticide + fongicide si pas de contre-indication. Réduire nb passages.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1719	GEN-REN-002	rendement	general	Stade végétatif critique — Protection maximale	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 27}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Stade critique tous stress"}, "alertes": [{"titre": "Stade floraison-fructification — Vigilance renforcée", "niveau": "moyenne", "message": "Floraison et fructification = fenêtre 10-20 jours. Tout stress ici = perte définitive rendement."}], "recommandations": [{"type": "surveillance", "titre": "Inspection quotidienne stade critique", "detail": "Inspecter matin + soir. Résoudre tout stress sous 48h : eau, ravageurs, maladies.", "priorite": 1}]}	moyenne	6	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1720	GEN-REN-003	rendement	general	Variétés améliorées vs locales — Gain potentiel	\N	null	["semis"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Sous-performance variétés locales"}, "alertes": [{"titre": "Variétés améliorées = +30-50% rendement potentiel", "niveau": "faible", "message": "Variétés certifiées améliorées = rendement 30-50% supérieur aux variétés locales selon cultures."}], "recommandations": [{"type": "planification", "titre": "Essayer variétés améliorées sur 20% surface", "detail": "Tester 20% surface en variétés certifiées. Conserver 80% en variétés connues pour sécurité.", "priorite": 1}]}	faible	2	0.75	premium	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1721	GEN-MAL-001	maladie	general	Symptômes chlorose générale — Carence ou maladie	\N	null	null	null	{"clauses": [{"op": "not_null", "field": "obs_symptomes"}, {"op": "lte", "field": "sol.pH", "value": 5.5}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Chlorose double cause"}, "alertes": [{"titre": "Chlorose = sol acide probable", "niveau": "elevee", "message": "Chlorose + sol acide = carence Fe/Mn/Zn amplifiée par pH bas OU maladie racinaire favorisée."}], "recommandations": [{"type": "fertilisation", "titre": "Chaulage + microéléments foliaires", "detail": "Chaux pour remonter pH. Sulfate de zinc 2 kg/ha + sulfate de fer 1 kg/ha foliaire.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1722	GEN-MAL-002	maladie	general	Résidus pathogènes — Rotation obligatoire	\N	null	null	[11, 12, 1]	{"clauses": [{"op": "between", "field": "sol.pH", "value": 5.0, "value2": 7.0}, {"op": "gte", "field": "sol.humidite", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Inoculum résidus"}, "alertes": [{"titre": "Inter-saison — Gestion résidus pathogènes", "niveau": "moyenne", "message": "Résidus cultures laissés au sol = inoculum maladies saison suivante. Enfouir ou brûler."}], "recommandations": [{"type": "mesure_culturale", "titre": "Enfouissement résidus inter-saison", "detail": "Labourer profond 25-30 cm pour enfouir résidus. Ou brûler si maladie sévère saison passée.", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1723	GEN-MAL-003	maladie	general	Chaleur + humidité nuit — Maladies fongiques nocturnes	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_min", "value": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Sporulation nocturne"}, "alertes": [{"titre": "Nuits chaudes et humides — Explosion fongique", "niveau": "elevee", "message": "T nuit > 22°C + HR > 85% = sporulation massive pendant la nuit. Symptômes visibles au matin."}], "recommandations": [{"type": "traitement", "titre": "Traitement préventif coucher soleil", "detail": "Traitement fongicide en fin d'après-midi (16-18h) couvre la nuit = fenêtre optimale.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1724	GEN-FER-001	fertilisation	general	Fertilisation sous pluie — Volatilisation urée	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Pertes fertilisant pluie"}, "alertes": [{"titre": "Pluie forte — Ne pas fertiliser", "niveau": "moyenne", "message": "Pluie > 30 mm = lessivage N + volatilisation urée = gaspillage. Reporter fertilisation 2-3 jours."}], "recommandations": [{"type": "fertilisation", "titre": "Reporter fertilisation après pluie", "detail": "Attendre 2-3 jours après pluie forte. Sol ressuyé = incorporation optimale. Enfoui léger si urée.", "priorite": 1}]}	moyenne	5	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1725	GEN-FER-002	fertilisation	general	Fertilisation fractionnée — Efficience azote	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 20}, {"op": "in", "field": "sol.texture", "value": ["sableuse", "sablo_limoneuse"]}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Lessivage N sol sableux"}, "alertes": [{"titre": "Sol sableux — Fractionner azote", "niveau": "moyenne", "message": "Sol sableux = faible rétention N. 1 apport unique = 30-40% lessivé. Fractionner en 2-3 applications."}], "recommandations": [{"type": "fertilisation", "titre": "Programme N fractionné 3x", "detail": "33% levée + 33% tallage + 33% montaison. Chaque dose après pluie légère.", "priorite": 1}]}	moyenne	5	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1726	GEN-FER-003	fertilisation	general	Feuilles violacées — Carence phosphore généralisée	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 10}, {"op": "lte", "field": "sol.pH", "value": 5.8}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence P probable — Teintes violacées", "niveau": "elevee", "message": "P sol < 10 ppm + pH acide = carence P. Nervures et tiges violacées = anthocyanine stress P."}], "recommandations": [{"type": "fertilisation", "titre": "Triple super phosphate + chaulage", "detail": "TSP 50 kg/ha. pH acide bloque P : chaulage d'abord pour libérer P existant.", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1727	GEN-FER-004	fertilisation	general	Carence Zn — Nanisme petites feuilles	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "sol.pH", "value": 7.5}, {"op": "lte", "field": "sol.matiere_organique", "value": 1.0}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence Zn sol alcalin"}, "alertes": [{"titre": "Sol alcalin + MO basse = carence Zn", "niveau": "elevee", "message": "pH > 7.5 + MO basse = Zn bloqué = nanisme des jeunes feuilles (petites, en rosette)."}], "recommandations": [{"type": "fertilisation", "titre": "Sulfate de zinc correcteur", "detail": "Sulfate de zinc 5 kg/ha au sol ou 0.5% foliaire 2 applications à 10 jours.", "priorite": 1}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:58.541457+00	\N
1435	FER-ARA-002	fertilisation	calcium	Arachide — Carence calcium — pH bas gousses vides	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.8}, {"op": "lte", "field": "sol.conductivite", "value": 1.0}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Carence calcium gousses"}, "alertes": [{"titre": "Carence calcium arachide — gousses vides", "niveau": "elevee", "message": "pH <5.8 + Ca faible : syndrome 'pops' (gousses vides). Gypse agricole indispensable."}], "recommandations": [{"dose": "500 kg/ha à la floraison", "type": "fertilisation", "titre": "Gypse agricole à la floraison", "detail": "Épandre au sol autour des plants en floraison. Critique pour remplissage gousses.", "produit": "Gypse agricole (CaSO₄)", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	2026-06-10 16:54:44.604103+00
1292	MAL-OIG-003	maladie	fongique	Fonte de semis oignon — Pépinière humide	\N	null	["pepiniere", "levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis oignon", "niveau": "moyenne", "message": "Sol engorgé en pépinière : Pythium/Fusarium peuvent décimer plantules."}], "recommandations": [{"dose": "1 g/L eau arrosage", "type": "traitement_phyto", "titre": "Arrosage Métalaxyl pépinière", "produit": "Métalaxyl 25WP", "priorite": 1, "urgence_jours": 3}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1293	MAL-GOM-001	maladie	viral	Mosaïque jaune gombo — Vecteur mouche blanche	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_jaune"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Mosaïque YVMV"}, "alertes": [{"titre": "Risque Mosaïque jaune gombo", "niveau": "elevee", "message": "YVMV transmis par Bemisia tabaci. Contrôle vecteur urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride anti-aleurode", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Arracher plants jaunes", "detail": "Source virale à éliminer immédiatement.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1294	MAL-GOM-002	maladie	fongique	Fusariose gombo — Sol acide humide	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.0}, {"op": "gte", "field": "sol.humidite", "value": 75}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose gombo", "niveau": "elevee", "message": "Fusarium solani actif en sol acide chaud saturé."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage + drainage", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Rotation avec graminées 2 ans", "priorite": 2}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1295	MAL-GOM-003	maladie	fongique	Fonte de semis gombo — Levée sol humide	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis gombo", "niveau": "moyenne", "message": "Sol saturé à levée : Rhizoctonia/Pythium actifs."}], "recommandations": [{"dose": "3 g/kg", "type": "traitement_semences", "titre": "Thirame sur semences", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1296	MAL-CON-001	maladie	fongique	Mildiou cucurbitacées — Concombre fraîcheur humide	\N	null	["croissance_vegetative", "floraison", "fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mildiou cucurbitacées"}, "alertes": [{"titre": "Risque Mildiou cucurbitacées", "niveau": "elevee", "message": "Pseudoperonospora cubensis : fraîcheur + HR>88% = sporulation rapide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe préventif", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1297	MAL-CON-002	maladie	fongique	Oïdium concombre — Chaleur sèche	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Oïdium"}, "alertes": [{"titre": "Risque Oïdium concombre", "niveau": "moyenne", "message": "Sphaerotheca fuliginea : chaleur + humidité modérée. Surveiller face inférieure feuilles."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable ou Myclobutanil", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1298	MAL-CON-003	maladie	fongique	Anthracnose cucurbitacées — Fruits humides	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose cucurbitacées", "niveau": "moyenne", "message": "Colletotrichum orbiculare : fruits mouillés = taches déprimées noires."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1299	MAL-PAS-001	maladie	fongique	Fusariose vasculaire pastèque — Sol acide	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.0}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose vasculaire pastèque", "niveau": "elevee", "message": "Fusarium oxysporum f.sp. niveum : sol acide + chaleur. Pas de traitement curatif."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage avant plantation", "detail": "pH cible 6.5-7.0. Critique pour prévenir FON.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Greffage sur Cucurbita maxima", "detail": "Porte-greffe résistant Fusarium. Technique recommandée production intensive.", "priorite": 2}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1300	MAL-PAS-002	maladie	fongique	Mildiou cucurbitacées — Pastèque humidité	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Mildiou cucurbitacées"}, "alertes": [{"titre": "Risque Mildiou pastèque", "niveau": "moyenne", "message": "Pseudoperonospora cubensis actif en fraîcheur humide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide systémique Mildiou", "produit": "Métalaxyl-M + Mancozèbe", "priorite": 1, "urgence_jours": 4}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1301	MAL-PAS-003	maladie	fongique	Anthracnose cucurbitacées — Pastèque fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose pastèque", "niveau": "moyenne", "message": "Taches noires sur fruits matures sous pluie. Récolte précoce si possible."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil sur fruits", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1302	MAL-MAG-001	maladie	fongique	Anthracnose mangue — Humidité floraison-récolte	\N	null	["floraison", "fructification", "maturation"]	[3, 4, 5, 6]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Anthracnose mangue"}, "alertes": [{"titre": "Risque Anthracnose mangue", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : pluie à floraison = pertes post-récolte élevées."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose mangue", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 14}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1303	MAL-MAG-002	maladie	fongique	Oïdium mangue — Chaleur sèche floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Oïdium mangue"}, "alertes": [{"titre": "Risque Oïdium mangue à floraison", "niveau": "elevee", "message": "Oidium mangiferae peut détruire 20-80% fleurs. Traitement préventif urgent."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable ou Triadimefon floraison", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 2}]}	elevee	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1304	MAL-MAG-003	maladie	fongique	Dieback mangue — Saison sèche stress	\N	null	null	[1, 2, 3, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Dieback (Lasiodiplodia)"}, "alertes": [{"titre": "Risque Dieback mangue", "niveau": "elevee", "message": "Lasiodiplodia theobromae : stress hydrique + chaleur = infection blessures/taille."}], "recommandations": [{"type": "mesure_culturale", "titre": "Badigeonner cicatrices taille", "detail": "Pâte bordelaise sur toute coupe >2cm de diamètre.", "priorite": 1}, {"dose": "5 g/L application locale", "type": "traitement_phyto", "titre": "Trichoderma bio-fongicide", "produit": "Trichoderma harzianum", "priorite": 2, "urgence_jours": 7}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1305	MAL-MAG-004	maladie	bacterien	Bactériose angulaire mangue — Pluie vent	\N	null	null	[6, 7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 15}, {"op": "gte", "field": "meteo.vent", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Bactériose angulaire"}, "alertes": [{"titre": "Risque Bactériose angulaire mangue", "niveau": "moyenne", "message": "Xanthomonas campestris pv. mangiferaeindicae propagé par pluie + vent."}], "recommandations": [{"dose": "4 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif après pluie", "produit": "Oxychlorure de cuivre 50WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1306	MAL-ANA-001	maladie	fongique	Anthracnose anacarde — Pluie floraison-nouaison	\N	null	["floraison", "nouaison"]	[2, 3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Anthracnose anacarde"}, "alertes": [{"titre": "Risque Anthracnose anacarde", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : pluie à floraison = chute inflorescences et pommes."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Carbendazime anacarde", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1307	MAL-ANA-002	maladie	fongique	Oïdium anacarde — Floraison saison sèche	\N	null	["floraison"]	[1, 2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 78}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Oïdium anacarde"}, "alertes": [{"titre": "Risque Oïdium anacarde", "niveau": "moyenne", "message": "Oidium anacardii : fin de saison sèche + début pluies = risque élevé."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable 2 applications", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1308	MAL-ANA-003	maladie	fongique	Dieback anacarde — Stress saison sèche	\N	null	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Dieback"}, "alertes": [{"titre": "Risque Dieback anacarde", "niveau": "elevee", "message": "Lasiodiplodia theobromae sur blessures taille en saison sèche."}], "recommandations": [{"type": "mesure_culturale", "titre": "Protéger cicatrices taille", "detail": "Pâte bordelaise ou mastic de jardinage sur coupes.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1309	MAL-BAN-001	maladie	fongique	Sigatoka noire banane — Pluies prolongées	\N	["casamance"]	null	[6, 7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 60}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Sigatoka noire"}, "alertes": [{"titre": "Risque Sigatoka noire élevé", "niveau": "critique", "message": "Mycosphaerella fijiensis : saison pluies + HR>85% = défoliation rapide. Traitement aérien/pulvérisation urgente."}], "recommandations": [{"dose": "0,8 L/ha", "type": "traitement_phyto", "titre": "Programme fongicide Sigatoka noire", "produit": "Propiconazole 25EC alternance Triadimefon", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1310	MAL-BAN-002	maladie	fongique	Fusariose Panama banane — Sol acide contaminé	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fusariose_panama"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_feuilles_banane"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Fusariose Panama (FOC)"}, "alertes": [{"titre": "Maladie de Panama banane suspectée", "niveau": "critique", "message": "Fusarium oxysporum f.sp. cubense. Irréversible. Contamination sol permanente."}], "recommandations": [{"type": "mesure_culturale", "titre": "QUARANTAINE parcelle immédiate", "detail": "Ne pas déplacer matériel végétal ni terre. Alerter services phytosanitaires.", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Transition vers variétés résistantes TR4", "detail": "FHIA-01, FHIA-02 ou Grande Naine pour zones non infestées.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1311	MAL-BAN-003	maladie	fongique	Anthracnose post-récolte banane — Humidité récolte	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose post-récolte"}, "alertes": [{"titre": "Risque Anthracnose post-récolte banane", "niveau": "moyenne", "message": "Colletotrichum musae : récolte sous chaleur humide = noircissement rapide."}], "recommandations": [{"type": "mesure_post_recolte", "titre": "Réfrigération rapide 13°C", "detail": "Chaîne froide maintenir <14°C. Thiabendazole en trempage 200 ppm si export.", "priorite": 1}]}	moyenne	5	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1312	MAL-PAP-001	maladie	viral	PRSV papaye — Vecteur puceron ou symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "ringspot"}, {"op": "contains", "field": "obs.symptomes", "value": "mosaique_papaye"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "PRSV"}, "alertes": [{"titre": "PRSV papaye détecté", "niveau": "critique", "message": "Papaya Ringspot Virus transmis par pucerons. Peut détruire 100% production."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés IMMÉDIATEMENT", "detail": "Source virale à éliminer avant spread. Ne pas replanter papaye 3 ans.", "priorite": 1, "urgence_jours": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron vecteur", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 2, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Utiliser variétés tolérantes", "detail": "Maradol, Sunrise Solo tolerantes PRSV.", "priorite": 3}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1313	MAL-PAP-002	maladie	fongique	Pythium papaye — Sol engorgé plantation	\N	null	["plantation", "croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pythium fonte collet"}, "alertes": [{"titre": "Risque Pythium papaye — fonte du collet", "niveau": "elevee", "message": "Sol saturé : Pythium aphanidermatum cause pourriture collet fatale en 3-5 jours."}], "recommandations": [{"type": "mesure_culturale", "titre": "Planter sur buttes 30-40cm hauteur", "detail": "Drainage collet critique. Ne jamais planter en zone plate sans billons.", "priorite": 1}, {"dose": "2 g/L arrosage collet", "type": "traitement_phyto", "titre": "Métalaxyl préventif au collet", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1314	MAL-PAP-003	maladie	fongique	Anthracnose papaye — Humidité maturité fruits	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 82}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose papaye"}, "alertes": [{"titre": "Risque Anthracnose papaye", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime précolte", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 5, "delai_carence_jours": 7}, {"type": "mesure_post_recolte", "titre": "Trempage eau chaude 50°C 20min", "detail": "Traitement post-récolte pour export sans résidus chimiques.", "priorite": 2}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1315	MAL-MAI-005	maladie	bacteriose	Pourriture bactérienne tige maïs Erwinia chrysanthemi	\N	null	["montaison"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}, {"op": "gte", "field": "sol.humidite", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Pourriture bactérienne tige"}, "alertes": [{"titre": "Pourriture tige maïs bactérienne", "niveau": "elevee", "message": "Feuilles internes molles, odeur fétide = Erwinia. Sol saturé + chaleur = milieu parfait."}], "recommandations": [{"type": "drainage", "titre": "Drainer + éviter excès N", "detail": "Drainage prioritaire. Excès N = tiges tendres = sensibilité Erwinia. Réduire densité future.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1316	MAL-MAI-006	maladie	virose	Mosaïque maïs MDMV vecteur pucerons	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Mosaïque MDMV"}, "alertes": [{"titre": "Mosaïque maïs — virus MDMV pucerons vecteurs", "niveau": "elevee", "message": "Temps chaud sec = pucerons vecteurs actifs. Mosaïque MDMV : feuilles rayées jaune-vert. Irréversible."}], "recommandations": [{"type": "traitement", "titre": "Contrôle pucerons vecteurs", "detail": "Imidaclopride 0.2 L/ha. Traiter tôt avant symptômes. Arracher plants malades.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1317	MAL-ARA-005	maladie	pourridies	Flétrissement Sclerotium rolfsii arachide sol chaud	\N	null	["croissance_vegetative"]	[7, 8]	{"clauses": [{"op": "gte", "field": "sol.temperature", "value": 30}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "lte", "field": "sol.matiere_organique", "value": 1.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Sclerotium collet"}, "alertes": [{"titre": "Sclerotium rolfsii arachide — sol chaud", "niveau": "elevee", "message": "Sol chaud > 30°C + MO basse = Sclerotium rolfsii. Collet blanc cotonneux, tige morte. Tache qui s'étend."}], "recommandations": [{"type": "traitement", "titre": "Fongicide Sclerotium arachide", "detail": "PCNB (Terraclor) en traitement sol ou Tebuconazole 0.5 L/ha. Éliminer résidus infestés.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Chaulage sol acide", "detail": "pH < 6 favorise Sclerotium. Chaulage 1 t/ha si pH < 5.8.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1318	MAL-ARA-006	maladie	rouille	Rouille arachide Puccinia arachidis	\N	null	["floraison", "fructification"]	[8, 9, 10]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Rouille Puccinia"}, "alertes": [{"titre": "Rouille arachide — pustules orangées", "niveau": "elevee", "message": "Temps frais + humide = Puccinia arachidis. Pustules orangées face inférieure feuilles. Défoliation."}], "recommandations": [{"type": "traitement", "titre": "Fongicide anti-rouille arachide", "detail": "Propiconazole 0.5 L/ha ou Mancozèbe 2 kg/ha. Programme 14 jours.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1319	MAL-MIL-006	maladie	helminthosporiose	Helminthosporiose mil Exserohilum turcicum	\N	null	["croissance_vegetative"]	[8]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Helminthosporiose foliaire"}, "alertes": [{"titre": "Helminthosporiose mil — taches foliaires grises", "niveau": "elevee", "message": "Grandes taches gris-olive elliptiques feuilles mil = E. turcicum. Se propage en conditions humides."}], "recommandations": [{"type": "traitement", "titre": "Fongicide contact mil helminthosporiose", "detail": "Mancozèbe 2 kg/ha ou Chlorothalonil. Variétés tolérantes si parcelle récurrente.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1320	MAL-SOR-005	maladie	charbon	Charbon couvert sorgho Sporisorium sorghi	\N	null	["epiaison"]	[9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Charbon couvert sorgho"}, "alertes": [{"titre": "Charbon couvert sorgho à l'épiaison", "niveau": "elevee", "message": "Épis noirs à sortie = Sporisorium sorghi. Sol infesté spores + humidité. Traitement semences obligatoire futur."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher épis charbonnés", "detail": "Couper et brûler avant libération spores. Ne pas laisser au sol.", "priorite": 1}, {"type": "traitement", "titre": "Traitement semences prochain cycle", "detail": "Thirame 3 g/kg semence ou Carboxine 2 g/kg. Essentiel pour prochain semis.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1321	MAL-SOR-006	maladie	rouille	Rouille sorgho Puccinia purpurea	\N	null	["montaison", "floraison"]	[9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 78}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 26}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Rouille Puccinia purpurea"}, "alertes": [{"titre": "Rouille sorgho pustules pourpres", "niveau": "elevee", "message": "Pustules pourpres-brunes face inférieure = Puccinia purpurea. Fin de cycle humide favorisant."}], "recommandations": [{"type": "traitement", "titre": "Fongicide anti-rouille sorgho", "detail": "Propiconazole 0.4 L/ha ou Tebuconazole 0.5 L/ha si attaque sévère > 30% feuilles.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1322	MAL-GOM-004	maladie	fusariose	Flétrissement Fusarium oxysporum gombo	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.temperature", "value": 28}, {"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Fusarium vasculaire gombo"}, "alertes": [{"titre": "Fusarium oxysporum gombo — flétrissement", "niveau": "elevee", "message": "Sol chaud + acide + humide = Fusarium vasculaire gombo. Flétrissement unilatéral + brunissement tige."}], "recommandations": [{"type": "traitement", "titre": "Chaulage + Trichoderma sol gombo", "detail": "Chaux pour remonter pH > 6.5. Trichoderma harzianum en sol = bio-contrôle Fusarium.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1323	MAL-SES-005	maladie	bacteriose	Bactériose Pseudomonas syringae sésame	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Bactériose sésame"}, "alertes": [{"titre": "Bactériose sésame taches angulaires", "niveau": "elevee", "message": "Taches angulaires limitées nervures + halo jaune = P. syringae. Contagion par éclaboussures."}], "recommandations": [{"type": "traitement", "titre": "Cuivre bactériose sésame", "detail": "Bouillie bordelaise 1%. Éviter arrosage par aspersion. Écartement suffisant pour ventilation.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1324	MAL-SES-006	maladie	cercosporiose	Cercospora sesami sésame feuilles	\N	null	["croissance_vegetative", "floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 78}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Cercospora sesami"}, "alertes": [{"titre": "Cercospora sesami taches foliaires", "niveau": "elevee", "message": "Taches circulaires brun-rougeâtre centre gris = Cercospora sesami. Défol progressive si humidité persiste."}], "recommandations": [{"type": "traitement", "titre": "Chlorothalonil Cercospora sésame", "detail": "Chlorothalonil 1.5 kg/ha ou Mancozèbe 2 kg/ha. Viser face inférieure feuilles.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1325	MAL-NIE-005	maladie	virose	Cowpea Mosaic Virus CMV niébé	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "CMV niébé"}, "alertes": [{"titre": "CMV niébé — mosaïque vecteur pucerons", "niveau": "elevee", "message": "Temps chaud sec = pucerons vecteurs CMV actifs. Mosaïque + nanisme niébé. Perte 40-60%."}], "recommandations": [{"type": "traitement", "titre": "Insecticide pucerons CMV", "detail": "Imidaclopride 0.2 L/ha dès levée. Arracher plants très malades.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Variétés tolérantes CMV", "detail": "IT90K-272-2 = tolérant CMV. Éviter semis tardif (pucerons plus actifs).", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1326	MAL-NIE-006	maladie	sclerotiniose	Sclerotinia sclerotiorum niébé sol froid	\N	null	["croissance_vegetative"]	[11, 12, 1]	{"clauses": [{"op": "lte", "field": "meteo.temp_air", "value": 22}, {"op": "gte", "field": "sol.humidite", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Sclerotinia sclerotiorum"}, "alertes": [{"titre": "Sclerotinia niébé — saison fraîche", "niveau": "elevee", "message": "T < 22°C + sol humide = Sclerotinia. Tiges molles eau + duvet blanc. Sclerotes noirs."}], "recommandations": [{"type": "traitement", "titre": "Iprodione Sclerotinia niébé", "detail": "Iprodione 0.5 kg/ha. Drainage prioritaire. Rotation légumineuses 3 ans.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1327	MAL-AUB-005	maladie	cercosporiose	Cercospora solani aubergine	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Cercospora solani"}, "alertes": [{"titre": "Cercosporiose aubergine — taches blanches", "niveau": "elevee", "message": "Taches circulaires blanches entourées de brun foncé = Cercospora. Défoliation progressive."}], "recommandations": [{"type": "traitement", "titre": "Fongicide Cercospora aubergine", "detail": "Mancozèbe 2 kg/ha ou Chlorothalonil 1.5 kg/ha. Appliquer tôt matin.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1328	MAL-AUB-006	maladie	stemphylium	Stemphylium lycopersici aubergine	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 78}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 28}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Stemphylium foliaire"}, "alertes": [{"titre": "Stemphylium aubergine — taches nécrotiques", "niveau": "elevee", "message": "Taches nécrotiques brunes irrégulières = Stemphylium lycopersici. Favorable temps doux humide."}], "recommandations": [{"type": "traitement", "titre": "Iprodione + Chlorothalonil aubergine", "detail": "Iprodione 0.5 kg/ha + Chlorothalonil 1 kg/ha. Améliorer ventilation rangs.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1329	MAL-CON-005	maladie	oïdium	Oïdium Podosphaera xanthii concombre	\N	null	null	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Oïdium P. xanthii"}, "alertes": [{"titre": "Oïdium concombre — poudre blanche feuilles", "niveau": "elevee", "message": "Poudre blanche face supérieure feuilles = Podosphaera xanthii. Temps tiède + humidité modérée = parfait."}], "recommandations": [{"type": "traitement", "titre": "Soufre mouillable ou Myclobutanil oïdium", "detail": "Soufre 3 kg/ha ou Myclobutanil 0.3 L/ha. Ne pas appliquer par T > 32°C (brûlures).", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1330	MAL-CON-006	maladie	anthracnose	Anthracnose Colletotrichum lagenarium concombre	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Anthracnose Colletotrichum"}, "alertes": [{"titre": "Anthracnose concombre — taches eau fruits", "niveau": "elevee", "message": "Taches aqueuses s'enfonçant sur fruits + feuilles = Colletotrichum lagenarium. Perte commerciale."}], "recommandations": [{"type": "traitement", "titre": "Mancozèbe + Chlorothalonil anthracnose concombre", "detail": "Mancozèbe 2 kg/ha tous les 10 jours. Éviter contact eau-sol avec fruits.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1331	MAL-CHO-005	maladie	mildiou	Mildiou chou Peronospora parasitica	\N	null	["croissance_vegetative"]	[11, 12, 1]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 10, "value2": 20}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Mildiou Peronospora"}, "alertes": [{"titre": "Mildiou chou saison fraîche", "niveau": "elevee", "message": "T 10-20°C + HR > 85% = Peronospora parasitica. Duvet gris face inférieure + taches jaunes."}], "recommandations": [{"type": "traitement", "titre": "Métalaxyl-M chou mildiou", "detail": "Métalaxyl-M + Mancozèbe 2 kg/ha. Appliquer tôt matin. Répéter 7 jours.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1332	MAL-CHO-006	maladie	bacteriose	Pourriture noire chou Xanthomonas campestris pv. campestris	\N	null	null	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 33}, {"op": "gte", "field": "meteo.humidite_rel", "value": 78}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pourriture noire Xanthomonas"}, "alertes": [{"titre": "Pourriture noire chou Xanthomonas", "niveau": "elevee", "message": "Bord feuilles jaunit en V + nervures noires = X. campestris. Irréversible. Contamination rapide."}], "recommandations": [{"type": "traitement", "titre": "Cuivre anti-Xanthomonas chou", "detail": "Bouillie bordelaise 1% dès symptômes. Arracher plants très atteints. Pas d'arrosage sur feuilles.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation 2 ans sans brassicacées", "detail": "Sol contaminé = rotation 2-3 ans. Semences certifiées.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1333	MAL-PAP-005	maladie	virose	Papaya Ring Spot Virus PRSV papaye	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 27}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "PRSV Papaya Ringspot"}, "alertes": [{"titre": "PRSV papaye — mosaïque destructrice", "niveau": "critique", "message": "PRSV = virus le plus destructeur papaye. Tâches anneaux sur fruits + mosaïque feuilles. Vecteur pucerons."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants PRSV papaye", "detail": "Pas de traitement curatif. Arracher + brûler. Garder isolement spatial 100m du reste.", "priorite": 1}, {"type": "traitement", "titre": "Contrôle pucerons prévention PRSV", "detail": "Huile minérale 2% sur jeunes plants = réduit inoculation par pucerons.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1334	MAL-PAP-006	maladie	anthracnose	Anthracnose Colletotrichum gloeosporioides papaye	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose fruit"}, "alertes": [{"titre": "Anthracnose fruits papaye", "niveau": "elevee", "message": "Taches aqueuses s'enfonçant sur fruits papaye = Colletotrichum. Pluie + humidité. Fruits invendables."}], "recommandations": [{"type": "traitement", "titre": "Mancozèbe papaye anti-anthracnose", "detail": "Mancozèbe 2 kg/ha ou Carbendazime 0.5 kg/ha. Post-récolte: trempage Carbendazime 500 ppm.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1335	MAL-PAS-005	maladie	fusariose	Flétrissement Fusarium oxysporum f.sp. niveum pastèque	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.temperature", "value": 25}, {"op": "lte", "field": "sol.pH", "value": 6.5}, {"op": "gte", "field": "sol.humidite", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Fusarium vasculaire pastèque"}, "alertes": [{"titre": "Fusarium pastèque — flétrissement vasculaire", "niveau": "critique", "message": "Flétrissement subit = F.o. f.sp. niveum. Tige sectionnée = brunissement vasculaire. Sol persistant 10 ans."}], "recommandations": [{"type": "mesure_culturale", "titre": "Greffe porte-greffe résistant", "detail": "Greffe sur courge Cucurbita ficifolia = résistance totale Fusarium. Solution durable.", "priorite": 1}, {"type": "traitement", "titre": "Rotation longue + Trichoderma", "detail": "Rotation 5+ ans sans cucurbitacées. Trichoderma harzianum en sol.", "priorite": 2}]}	critique	10	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1336	MAL-PAS-006	maladie	anthracnose	Anthracnose Colletotrichum lagenarium pastèque	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose pastèque"}, "alertes": [{"titre": "Anthracnose pastèque — taches noires fruits", "niveau": "elevee", "message": "Taches concentriques noires sur fruits + taches foliaires = Colletotrichum. Fruits invendables."}], "recommandations": [{"type": "traitement", "titre": "Programme fongicide anthracnose pastèque", "detail": "Chlorothalonil 1.5 kg/ha + Mancozèbe 2 kg/ha. Dès début floraison, tous les 10 jours.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1337	MAL-BAN-005	maladie	cercosporiose	Cercospora noire Mycosphaerella fijiensis (Black Sigatoka)	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}, {"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Black Sigatoka catastrophique"}, "alertes": [{"titre": "Black Sigatoka bananier — maladie la plus grave", "niveau": "critique", "message": "Stries noires → taches jaunes → nécrose = M. fijiensis. Défoliation 75-80% = mûrissement prématuré."}], "recommandations": [{"type": "traitement", "titre": "Programme fongicide Black Sigatoka", "detail": "Triadimefon ou Epoxiconazole alternés. 21 jours. Effeuillage feuilles atteintes.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Effeuillage prophylactique", "detail": "Couper feuilles > 50% atteintes. Brûler. Hygiene plantation capitale.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1338	MAL-BAN-006	maladie	fusariose	Maladie Panama Fusarium oxysporum f.sp. cubense TR4	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.5}, {"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 26}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Panama Disease TR4"}, "alertes": [{"titre": "Panama Disease TR4 — Fusarium catastrophique", "niveau": "critique", "message": "Flétrissement unilateral + brunissement vasculaire = F.o. cubense TR4. Pas de traitement. Maladie de quarantaine."}], "recommandations": [{"type": "mesure_culturale", "titre": "Alerte autorités phytosanitaires", "detail": "Signaler immédiatement DAPSA/DPVC. Quarantaine parcelle. Aucun plant ni sol hors zone.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Arracher + incinérer plants malades", "detail": "Arracher. Brûler sur place. Désinfecter outils. Variétés TR4-R à planter uniquement.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1339	MAL-ANA-005	maladie	anthracnose	Anthracnose Colletotrichum gloeosporioides anacarde	\N	null	["floraison"]	[1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Anthracnose floraison"}, "alertes": [{"titre": "Anthracnose anacarde floraison", "niveau": "critique", "message": "Pluie floraison = Colletotrichum. Inflorescences noircissent. Perte totale noix possible."}], "recommandations": [{"type": "traitement", "titre": "Mancozèbe + Carbendazime anacardier floraison", "detail": "Mancozèbe 2 kg/ha + Carbendazime 0.5 kg/ha. 2 applications à 7 jours si pluie persiste.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1340	MAL-MAN-005	maladie	bacteriose	Bactériose manioc Xanthomonas axonopodis pv. manihotis	\N	null	null	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "gte", "field": "meteo.vent", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Bactériose vasculaire manioc"}, "alertes": [{"titre": "Bactériose manioc — taches angulaires tige", "niveau": "elevee", "message": "Taches foliaires angulaires + exsudat gomme sur tige + dépérissement = X. axonopodis."}], "recommandations": [{"type": "traitement", "titre": "Cuivre + couper tige malades", "detail": "Couper et brûler tiges malades. Cuivre 1% en pulvérisation. Boutures saines uniquement.", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1341	MAL-GEN-003	maladie	general	Sol acide pH<5.0 — Amplification maladies telluriques	\N	null	null	null	{"clauses": [{"op": "lt", "field": "sol.pH", "value": 5.0}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Amplification pathogènes sol acide"}, "alertes": [{"titre": "Sol très acide = amplification Fusarium/Sclerotium", "niveau": "critique", "message": "pH < 5.0 = Fusarium, Sclerotium, nématodes amplifiés. Action corrective avant toute plantation."}], "recommandations": [{"type": "fertilisation", "titre": "Chaulage urgent pH < 5.0", "detail": "Chaux agricole 2-3 t/ha. Incorporer avant plantation. Remonter pH 6.0-6.5 = idéal.", "priorite": 1, "urgence_jours": 14}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1342	MAL-GEN-004	maladie	general	Humidité prolongée + stagnation — Botrytis généralisé	\N	null	null	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}, {"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 25}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Botrytis généralisé"}, "alertes": [{"titre": "Conditions Botrytis généralisé — toutes cultures", "niveau": "elevee", "message": "HR > 88% + T fraîche = Botrytis cinerea actif sur toutes cultures. Moisissures grises fleurs/fruits."}], "recommandations": [{"type": "traitement", "titre": "Iprodione + ventilation urgence", "detail": "Iprodione 0.5 kg/ha. Écimer + ventilation entre rangs. Éliminer fleurs sèches stade sensible.", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1343	MAL-GEN-005	maladie	general	Excès azote — Sensibilité maladies fongiques augmentée	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.azote", "value": 0.25}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Sensibilité accrue excès N"}, "alertes": [{"titre": "Excès N + humidité = sensibilité fongique", "niveau": "elevee", "message": "Excès N = tissus tendres, riches, succulents = mildiou/Botrytis/rouilles plus sévères."}], "recommandations": [{"type": "fertilisation", "titre": "Réduire N et augmenter K", "detail": "Arrêt apports N. Apporter K2O 30-50 kg/ha = renforce parois cellulaires + résistance.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.031958+00	\N
1344	RAV-RIZ-001	ravageur	insecte	Foreur de tige riz — Conditions favorables tallage	\N	null	["tallage", "montaison"]	[6, 7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige riz", "niveau": "elevee", "message": "Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides au tallage", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1345	RAV-RIZ-002	ravageur	insecte	Foreur de tige riz — Cœurs morts observés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "foreur_tige"}, {"op": "contains", "field": "obs.symptomes", "value": "coeurs_morts"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Foreur tige riz confirmé", "niveau": "critique", "message": "Cœurs morts : dommages irréversibles. Traitement curatif urgent."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos foliaire", "produit": "Chlorpyrifos 48EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1346	RAV-RIZ-003	ravageur	insecte	Hispe du riz — Chaleur humide végétation	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Hispe"}, "alertes": [{"titre": "Risque Hispe du riz", "niveau": "moyenne", "message": "Dicladispa armigera : larves minent feuilles, adultes raclent surface."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Monocrotophos ou Lambda-cyhalothrine", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1347	RAV-RIZ-004	ravageur	oiseau	Quelea riz — Alerte épiaison	\N	null	["epiaison", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "quelea"}, {"op": "contains", "field": "obs.ravageurs", "value": "oiseaux_granivores"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Quelea"}, "alertes": [{"titre": "Quelea détecté — épis à risque", "niveau": "elevee", "message": "Quelea quelea en nuées : 1 oiseau consomme son poids/jour. Pertes jusqu'à 100%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Effaroucheurs acoustiques + visuels", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Gardiennage parcelles 6h-18h", "priorite": 2}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1348	RAV-MIL-001	ravageur	insecte	Foreur tiges/panicules mil — Tallage à montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur mil", "niveau": "elevee", "message": "Coniesta ignefusalis + Eldana saccharina : surveillance cœurs morts obligatoire."}], "recommandations": [{"dose": "10 kg/ha", "type": "traitement_phyto", "titre": "Insecticide systémique tallage", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1349	RAV-MIL-002	ravageur	plante_parasite	Striga mil — Détection précoce levée	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "striga"}, {"op": "contains", "field": "obs.symptomes", "value": "plante_parasite"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Striga"}, "alertes": [{"titre": "Striga détecté", "niveau": "critique", "message": "Striga hermonthica : parasite racinaire. Arracher avant floraison Striga."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher Striga AVANT floraison (fleurs violettes)", "detail": "Enfouir profond. 1 plant grainé = 50 000 graines → 20 ans infestation.", "priorite": 1, "urgence_jours": 3}, {"dose": "100 mL/kg semences", "type": "traitement_semences", "titre": "Imazapyr Clearfield (variétés tolérantes uniquement)", "produit": "Imazapyr 0.5FS", "priorite": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1350	RAV-MIL-003	ravageur	oiseau	Quelea mil — Alerte épiaison	\N	null	["epiaison", "maturation"]	[9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "quelea"}, {"op": "contains", "field": "obs.ravageurs", "value": "mange_mil"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Quelea"}, "alertes": [{"titre": "Quelea — épiaison mil à risque", "niveau": "elevee", "message": "Nuées Quelea quelea : défoliation totale panicules possible en 48h."}], "recommandations": [{"type": "mesure_culturale", "titre": "Gardiennage + effaroucheurs acoustiques", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1351	RAV-SOR-001	ravageur	insecte	Cécidomyie sorgho — Floraison humide	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Cécidomyie"}, "alertes": [{"titre": "Risque Cécidomyie sorgho", "niveau": "elevee", "message": "Stenodiplosis sorghicola : floraison humide = infestation rapide ovaires."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Malathion à début floraison", "produit": "Malathion 57EC", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1352	RAV-SOR-002	ravageur	insecte	Foreur tige sorgho — Tallage-montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige sorgho", "niveau": "elevee", "message": "Busseola fusca + Sesamia calamistis actifs en chaleur humide."}], "recommandations": [{"dose": "12 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides verticille", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1353	RAV-SOR-003	ravageur	insecte	Noctuelle américaine sorgho — Helicoverpa	\N	null	["floraison", "maturation"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.ravageurs", "value": "noctuelle"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Helicoverpa"}, "alertes": [{"titre": "Helicoverpa armigera sorgho", "niveau": "elevee", "message": "Larves perforantes dans panicules. Seuil : 2 larves/plant."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Chlorpyrifos", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1354	RAV-SOR-004	ravageur	insecte	Cochenille sorgho — Saison sèche stress	\N	null	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Cochenille"}, "alertes": [{"titre": "Risque Cochenille sorgho", "niveau": "moyenne", "message": "Saccharicoccus sacchari prolifère en stress hydrique."}], "recommandations": [{"dose": "3 L/ha huile", "type": "traitement_phyto", "titre": "Huile minérale + insecticide", "produit": "Huile minérale 80% + Malathion", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1355	RAV-MAI-001	ravageur	insecte	Chenille légionnaire d'automne maïs — Détection précoce	\N	null	["levee", "croissance_vegetative"]	[6, 7, 8, 9]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "chenille_legionnaire"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_cornet"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Spodoptera frugiperda"}, "alertes": [{"titre": "Chenille légionnaire d'automne détectée", "niveau": "critique", "message": "Spodoptera frugiperda : 1 larve/plant = 20-30% rendement perdu. Traitement immédiat."}], "recommandations": [{"dose": "0,15 kg/ha", "type": "traitement_phyto", "titre": "Emamectine benzoate dans cornet", "produit": "Emamectine benzoate 5SG", "priorite": 1, "urgence_jours": 1}, {"dose": "0,2 L/ha", "type": "traitement_phyto", "titre": "Chlorantraniliprole en alternative", "produit": "Chlorantraniliprole 200SC", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1356	RAV-MAI-002	ravageur	insecte	Chenille légionnaire — Conditions météo favorables	\N	null	["levee", "croissance_vegetative"]	[6, 7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 85}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Spodoptera frugiperda"}, "alertes": [{"titre": "Conditions favorables S. frugiperda", "niveau": "elevee", "message": "T° 22-32°C + HR 60-85% : cycle 30 jours. Surveiller cornets 2x/semaine."}], "recommandations": [{"type": "surveillance", "titre": "Piège phéromone + inspection cornet", "detail": "Seuil intervention : 1 larve/5 plants OU 20% plants infestés.", "priorite": 1}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1357	RAV-MAI-003	ravageur	insecte	Foreur de tige maïs — Tallage-montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige maïs", "niveau": "elevee", "message": "Sesamia calamistis + Busseola fusca : surveillance cœurs morts."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides verticille", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1358	RAV-MAI-004	ravageur	insecte	Cicadelle MSV maïs — Détection vecteur	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "cicadelle"}, {"op": "contains", "field": "obs.symptomes", "value": "striure"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "MSV via cicadelle"}, "alertes": [{"titre": "Cicadelle vectrice MSV détectée", "niveau": "elevee", "message": "Cicadulina mbila transmet Maize Streak Virus. Traitement urgence."}], "recommandations": [{"dose": "4 g/kg semences", "type": "traitement_semences", "titre": "Imidaclopride semences", "produit": "Imidaclopride 70WS", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1359	RAV-ARA-001	ravageur	insecte	Puceron noir arachide — Rosette + vecteur	\N	null	["levee", "croissance_vegetative"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}, {"op": "lte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Puceron noir + Rosette"}, "alertes": [{"titre": "Conditions favorables Puceron noir arachide", "niveau": "elevee", "message": "Aphis craccivora se multiplie en temps sec chaud. Vecteur Rosette."}], "recommandations": [{"dose": "4 g/kg", "type": "traitement_semences", "titre": "Imidaclopride semences anti-puceron", "produit": "Imidaclopride 70WS", "priorite": 1, "urgence_jours": 0}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1360	RAV-ARA-002	ravageur	insecte	Termites arachide — Sol sec profondeur	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "lte", "field": "sol.humidite", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Termites"}, "alertes": [{"titre": "Risque Termites arachide", "niveau": "moyenne", "message": "Sol sec : Macrotermes/Microtermes attaquent racines et gousses en saison sèche."}], "recommandations": [{"dose": "10 kg/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos en sillon de semis", "produit": "Chlorpyrifos 10G", "priorite": 1, "urgence_jours": 0}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1361	RAV-ARA-003	ravageur	insecte	Ver blanc arachide — Sol humide fructification	\N	null	["fructification"]	[8, 9, 10]	{"clauses": [{"op": "between", "field": "sol.humidite", "value": 40, "value2": 70}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Ver blanc"}, "alertes": [{"titre": "Risque Ver blanc / Hanneton", "niveau": "moyenne", "message": "Larves Holotrichia/Sophrops attaquent gousses en fructification."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos en sol à l'installation", "produit": "Chlorpyrifos 10G", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1362	RAV-NIE-001	ravageur	insecte	Helicoverpa niébé — Floraison-fructification	\N	null	["floraison", "fructification"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_gousse"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Helicoverpa armigera"}, "alertes": [{"titre": "Helicoverpa niébé confirmé", "niveau": "elevee", "message": "H. armigera perfore gousses. Seuil : 5% fleurs/gousses attaquées."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad à floraison", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1363	RAV-NIE-002	ravageur	insecte	Punaise niébé — Fructification	\N	null	["floraison", "fructification"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "punaise"}, {"op": "contains", "field": "obs.symptomes", "value": "sucion_gousses"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Punaise de gousse"}, "alertes": [{"titre": "Punaise niébé détectée", "niveau": "elevee", "message": "Clavigralla/Riptortus : succion gousses = graines avortées. Traitement urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine floraison-début gousses", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1364	RAV-NIE-003	ravageur	insecte	Thrips niébé — Floraison sèche chaude	\N	null	["floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Thrips fleurs"}, "alertes": [{"titre": "Risque Thrips niébé", "niveau": "moyenne", "message": "Megalurothrips sjostedti : temps sec chaud → prolifération rapide dans fleurs."}], "recommandations": [{"dose": "1 L/ha", "type": "traitement_phyto", "titre": "Dimethoate ou Lambda floraison", "produit": "Dimethoate 40EC", "priorite": 1, "urgence_jours": 3}]}	moyenne	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1365	RAV-NIE-004	ravageur	insecte	Bruche niébé — Stockage graines	\N	null	["maturation", "recolte"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Bruche stockage"}, "alertes": [{"titre": "Risque Bruche niébé stockage", "niveau": "elevee", "message": "Callosobruchus maculatus : conditions chaudes favorables. Traitement post-récolte urgent."}], "recommandations": [{"type": "mesure_post_recolte", "titre": "Poudre de neem ou huile végétale sur graines", "detail": "Huile arachide 5 mL/kg ou poudre neem 20 g/kg. Stocker en sacs hermétiques.", "priorite": 1}, {"dose": "3 comprimés/tonne", "type": "mesure_post_recolte", "titre": "Phosphine fumigation silo", "produit": "Phosphure d'aluminium (Phostoxin)", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1366	RAV-TOM-001	ravageur	insecte	Mineuse tomate — Conditions chaleur modérée	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 85}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Tuta absoluta"}, "alertes": [{"titre": "Risque Tuta absoluta tomate", "niveau": "elevee", "message": "Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement."}], "recommandations": [{"dose": "0,15 kg/ha", "type": "traitement_phyto", "titre": "Emamectine ou Chlorantraniliprole", "produit": "Emamectine benzoate 5SG", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Pièges phéromone (1/500m²)", "detail": "Monitoring obligatoire.", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1367	RAV-TOM-002	ravageur	insecte	Mineuse tomate — Symptômes actifs	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "mineuse"}, {"op": "contains", "field": "obs.symptomes", "value": "galeries_foliaires"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Tuta absoluta"}, "alertes": [{"titre": "Tuta absoluta confirmée", "niveau": "critique", "message": "Infestation active. Programme 3 traitements rotatifs obligatoires."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Rotation : Spinosad J0 → Emamectine J7 → Chlorantraniliprole J14", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.93	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1368	RAV-TOM-003	ravageur	insecte	Helicoverpa tomate — Fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_fruit"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Helicoverpa armigera"}, "alertes": [{"titre": "Helicoverpa tomate", "niveau": "elevee", "message": "Helicoverpa armigera perfore fruits. Seuil : 1 larve/10 plants."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Chlorantraniliprole", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1369	RAV-TOM-004	ravageur	insecte	Thrips tomate — TSWV vecteur chaleur sèche	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Thrips + TSWV"}, "alertes": [{"titre": "Risque Thrips tomate — vecteur TSWV", "niveau": "moyenne", "message": "Frankliniella occidentalis : temps sec chaud, vecteur Tomato Spotted Wilt Virus."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1370	RAV-PIM-001	ravageur	acarien	Acarien rouge piment — Chaleur sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge piment", "niveau": "elevee", "message": "Tetranychus urticae : temps sec chaud = multiplication explosive (7j/génération)."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide systémique", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1371	RAV-PIM-002	ravageur	insecte	Thrips piment — Saison sèche	\N	null	["floraison", "fructification"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Thrips piment"}, "alertes": [{"titre": "Risque Thrips piment", "niveau": "moyenne", "message": "Thrips palmi en saison sèche. Surveiller déformation fleurs."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1372	RAV-AUB-001	ravageur	insecte	Doryphore africain aubergine — Observation	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "doryphore"}, {"op": "contains", "field": "obs.symptomes", "value": "defoliation_aubergine"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Doryphore africain"}, "alertes": [{"titre": "Doryphore africain aubergine détecté", "niveau": "elevee", "message": "Leptinotarsa decemlineata var. africaine : défoliation rapide. Traitement urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine ou Deltamethrине", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1373	RAV-CHO-001	ravageur	insecte	Teigne du chou — Conditions sèches chaudes	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "lte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Plutella xylostella"}, "alertes": [{"titre": "Risque Teigne du chou", "niveau": "elevee", "message": "Plutella xylostella : résistances multiples. Rotation insecticides obligatoire."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "BT ou Emamectine (rotation avec Spinosad)", "produit": "Bacillus thuringiensis", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1374	RAV-CHO-002	ravageur	insecte	Pucerons chou — Vecteur maladies virales	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "miellat_chou"}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Pucerons"}, "alertes": [{"titre": "Pucerons chou détectés", "niveau": "moyenne", "message": "Brevicoryne brassicae : miellat + fumagine + vecteur TuMV."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Imidaclopride ou Pirimicarbe", "produit": "Pirimicarbe 50WG", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1375	RAV-OIG-001	ravageur	insecte	Thrips oignon — Saison sèche feuilles	\N	null	["croissance_vegetative", "bulbaison"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Thrips oignon"}, "alertes": [{"titre": "Risque Thrips oignon", "niveau": "elevee", "message": "Thrips tabaci : saison sèche. Silvering feuilles + vecteur IYSV."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine anti-thrips", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 4}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1376	RAV-OIG-002	ravageur	insecte	Mouche de l'oignon — Levée-repiquage	\N	null	["levee", "repiquage"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 28}, {"op": "gte", "field": "sol.humidite", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Delia antiqua"}, "alertes": [{"titre": "Risque Mouche de l'oignon", "niveau": "moyenne", "message": "Delia antiqua : larves dans bulbe au repiquage. Protection semences/plants."}], "recommandations": [{"dose": "1,5 L/ha en incorporation", "type": "traitement_phyto", "titre": "Chlorpyrifos arrosage au sol", "produit": "Chlorpyrifos 48EC", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1377	RAV-GOM-001	ravageur	insecte	Jassides gombo — Chaleur sèche	\N	null	null	[3, 4, 5, 11, 12]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Jassides"}, "alertes": [{"titre": "Risque Jassides gombo", "niveau": "moyenne", "message": "Empoasca spp. : crispation feuilles (hopperburn). Temps sec."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride foliaire", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1378	RAV-CON-001	ravageur	insecte	Mouche cucurbitacées — Fruits jeunes	\N	null	["fructification"]	[9, 10, 11, 12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Mouche cucurbitacées"}, "alertes": [{"titre": "Risque Mouche cucurbitacées", "niveau": "elevee", "message": "Dacus/Bactrocera cucurbitae : ponte dans jeunes fruits. Pertes 50-100%."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné empoisonné (GF-120)", "produit": "GF-120 NF Naturalyte", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Récolte fréquente fruits verts + enfouir fruits tombés", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1379	RAV-MAN-001	ravageur	acarien	Acarien vert manioc — Saison sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Acarien vert"}, "alertes": [{"titre": "Risque Acarien vert manioc", "niveau": "elevee", "message": "Mononychellus tanajoa : épidémies en saison sèche. Défoliation sévère possible."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine ou lâcher Phytoseiidae", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1380	RAV-MAN-002	ravageur	insecte	Mouche blanche manioc — Vecteur CMD	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}, {"op": "contains", "field": "obs.ravageurs", "value": "bemisia"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Bemisia tabaci + CMD"}, "alertes": [{"titre": "Mouche blanche manioc — Vecteur CMD", "niveau": "elevee", "message": "Bemisia tabaci biotype B : vecteur Mosaïque africaine. Contrôle urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride systémique", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1381	RAV-SES-001	ravageur	acarien	Acarien rouge sésame — Saison sèche	\N	null	null	[11, 12, 1, 2]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge sésame", "niveau": "moyenne", "message": "Tetranychus urticae : décoloration feuilles + toiles. Traitement préventif."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide Abamectine ou soufre", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1382	RAV-MAG-001	ravageur	insecte	Mouche des fruits mangue — Maturation	\N	null	["fructification", "maturation"]	[4, 5, 6, 7]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Ceratitis cosyra"}, "alertes": [{"titre": "Risque Mouche des fruits mangue", "niveau": "elevee", "message": "Ceratitis cosyra : ponte dans fruits mûrissants. Pertes 50-90% sans traitement."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné GF-120 hebdomadaire", "produit": "GF-120 NF Naturalyte", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Ramasser et enterrer fruits tombés quotidiennement", "priorite": 2}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1383	RAV-MAG-002	ravageur	insecte	Cécidomyie mangue — Floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Cécidomyie"}, "alertes": [{"titre": "Risque Cécidomyie mangue", "niveau": "elevee", "message": "Procontarinia matteiana : larves dans fleurs. Chute inflorescences."}], "recommandations": [{"dose": "1 L/ha", "type": "traitement_phyto", "titre": "Dimethoate à début floraison", "produit": "Dimethoate 40EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1384	RAV-ANA-001	ravageur	insecte	Hélopelte anacarde — Jeunes pousses	\N	null	["floraison", "croissance_vegetative"]	[2, 3, 4, 5]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Hélopelte"}, "alertes": [{"titre": "Risque Hélopelte anacarde", "niveau": "elevee", "message": "Helopeltis anacardii : piqûres nécrotiques sur jeunes pousses et noix."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine ou Dimethoate", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1385	RAV-BAN-001	ravageur	insecte	Charançon bananier — Sol humide plantation	\N	["casamance"]	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "charancon"}, {"op": "contains", "field": "obs.symptomes", "value": "galeries_pseudotronc"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Cosmopolites sordidus"}, "alertes": [{"titre": "Charançon du bananier détecté", "niveau": "elevee", "message": "Cosmopolites sordidus : galeries rhizome. Peut tuer le plant."}], "recommandations": [{"type": "mesure_culturale", "titre": "Pièges pseudotronc + feromon", "detail": "1 piège/100m². Inspecter hebdo.", "priorite": 1}, {"dose": "20 g/pied", "type": "traitement_phyto", "titre": "Chlorpyrifos au sol", "produit": "Chlorpyrifos 10G", "priorite": 2, "urgence_jours": 5}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1386	RAV-PAP-001	ravageur	insecte	Mouche des fruits papaye — Maturation	\N	null	["maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Bactrocera dorsalis"}, "alertes": [{"titre": "Risque Mouche des fruits papaye", "niveau": "elevee", "message": "Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées."}], "recommandations": [{"dose": "3 L/ha dilué", "type": "traitement_phyto", "titre": "Appât protéiné GF-120", "produit": "GF-120 NF", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1387	RAV-PAS-001	ravageur	insecte	Mouche cucurbitacées — Pastèque fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mouche cucurbitacées"}, "alertes": [{"titre": "Risque Mouche cucurbitacées pastèque", "niveau": "elevee", "message": "Dacus cucurbitae : pertes importantes en fructification."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné empoisonné GF-120", "produit": "GF-120 NF", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1388	RAV-PAP-002	ravageur	acarien	Acarien rouge papaye — Saison sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge papaye", "niveau": "moyenne", "message": "T. urticae prolifère en saison sèche. Jaunissement feuilles."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine ou soufre mouillable", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1389	RAV-ANA-002	ravageur	insecte_piqueur	Thrips anacarde — Floraison inflorescence	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Thrips floraison"}, "alertes": [{"titre": "Thrips anacarde actif", "niveau": "elevee", "message": "Saison sèche + chaleur : thrips envahissent les inflorescences, réduisant la nouaison de 20-40%."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide contact thrips anacarde", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1390	RAV-ANA-003	ravageur	insecte_piqueur	Cochenille anacarde — Tiges et feuilles	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "cochenille"}, {"op": "contains", "field": "obs.symptomes", "value": "fumagine"}], "operator": "OR"}	{"risque": {"score": 0.62, "libelle": "Cochenilles"}, "alertes": [{"titre": "Cochenille anacarde détectée", "niveau": "moyenne", "message": "Fumagine noire sur feuilles = cochenilles actives. Réduire la vigueur de 15%."}], "recommandations": [{"dose": "0,5 L + 0,3 kg/ha", "type": "traitement_phyto", "titre": "Huile blanche + insecticide", "produit": "Huile de paraffine 1% + Acétamipride 20SP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1391	RAV-ANA-004	ravageur	insecte_foreur	Foreur tige anacarde — Saison sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "sciure"}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Foreur tige"}, "alertes": [{"titre": "Foreur tige anacarde", "niveau": "moyenne", "message": "Sciure visible = galerie en cours. Risque de casse de branches fruitières."}], "recommandations": [{"type": "mesure_culturale", "titre": "Injecter insecticide dans galerie", "detail": "Coton imbibé d'acétate d'éthyle ou chlorpyrifos + obturer galerie.", "priorite": 1}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1392	RAV-AUB-002	ravageur	acarien	Acarien tétranyque aubergine — Saison sèche	\N	null	null	[11, 12, 1, 2, 3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Tetranychus urticae"}, "alertes": [{"titre": "Acariens tétranyques aubergine", "niveau": "elevee", "message": "Temps chaud et sec : prolifération rapide de Tetranychus urticae sur face inférieure."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide contact aubergine", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5, "delai_carence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1393	RAV-AUB-003	ravageur	insecte_piqueur	Aleurodes aubergine — Vecteur virus + miellat	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "aleurode"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.82, "libelle": "Aleurodes + virus"}, "alertes": [{"titre": "Aleurodes aubergine", "niveau": "elevee", "message": "Bemisia tabaci = vecteur TYLCV + fumagine. Contrôle urgent."}], "recommandations": [{"dose": "0,15 kg/ha", "type": "traitement_phyto", "titre": "Insecticide systémique aleurodes", "produit": "Thiamethoxam 25WG", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1394	RAV-AUB-004	ravageur	insecte_perforateur	Perforateur fruits aubergine — Leucinodes orbonalis	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "galerie_fruit"}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Leucinodes orbonalis"}, "alertes": [{"titre": "Perforateur fruits aubergine", "niveau": "critique", "message": "Leucinodes orbonalis : larves creusent galeries dans fruits. Perte 60-80% sans traitement."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Bacillus thuringiensis", "produit": "Spinosad 48SC", "priorite": 1, "urgence_jours": 2, "delai_carence_jours": 3}, {"type": "mesure_culturale", "titre": "Récolter fruits perforés et détruire", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1395	RAV-BAN-002	ravageur	insecte_foreur	Charançon du bananier — Cosmopolites sordidus	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "charancon"}, {"op": "contains", "field": "obs.symptomes", "value": "galerie_rhizome"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Charançon bananier"}, "alertes": [{"titre": "Charançon du bananier détecté", "niveau": "critique", "message": "Cosmopolites sordidus : larves détruisent le rhizome. Causes de dépérissement et verse. Perte potentielle >50%."}], "recommandations": [{"dose": "4 L/ha", "type": "traitement_phyto", "titre": "Endosulfan ou Chlorpyrifos sol", "detail": "Traitement sol au pied des rejets.", "produit": "Chlorpyrifos 20EC", "priorite": 1, "urgence_jours": 5}, {"type": "mesure_culturale", "titre": "Pièges à pseudotiges", "detail": "Déposer pseudo-tige coupée en tronçons → attire adultes → collecter et détruire.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1396	RAV-BAN-003	ravageur	nematode	Nématodes bananier — Pratylenchus / Radopholus	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "nanisme"}, {"op": "between", "field": "sol.pH", "value": 5.5, "value2": 7.0}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Nématodes racinaires"}, "alertes": [{"titre": "Nématodes bananier suspects", "niveau": "elevee", "message": "Nanisme + racines nécrosées = nématodes endoparasites. Analyse sol recommandée."}], "recommandations": [{"type": "mesure_culturale", "titre": "Utiliser rejets sains (macropropagation)", "detail": "Traitement eau chaude 55°C / 20 min sur rejets avant plantation.", "priorite": 1}, {"type": "amendement_sol", "titre": "Matière organique + rotation", "detail": "Fumure organique 20 t/ha améliore biodiversité sol et réduit nématodes.", "priorite": 2}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1397	RAV-BAN-004	ravageur	insecte_piqueur	Thrips bananier — Chaetanaphothrips orchidii	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Thrips bananier"}, "alertes": [{"titre": "Thrips bananier sur régimes", "niveau": "moyenne", "message": "Thrips entrainent cicatrices et nécrose sur peau banane. Impact commercial."}], "recommandations": [{"type": "mesure_culturale", "titre": "Gainer les régimes en floraison", "detail": "Gainette polyéthylène percée = protection mécanique efficace.", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1398	RAV-CON-002	ravageur	acarien	Acarien rouge concombre — Saison sèche chaude	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Acariens"}, "alertes": [{"titre": "Acariens rouges concombre", "niveau": "elevee", "message": "Chaleur + sécheresse : multiplication explosive de Tetranychus urticae."}], "recommandations": [{"dose": "0,4 L/ha", "type": "traitement_phyto", "titre": "Acaricide tétranyques concombre", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 4, "delai_carence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1399	RAV-CON-003	ravageur	insecte_piqueur	Puceron concombre — Colonie sur jeunes pousses	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "feuilles_enroulees"}], "operator": "OR"}	{"risque": {"score": 0.8, "libelle": "Pucerons + virus"}, "alertes": [{"titre": "Pucerons concombre", "niveau": "elevee", "message": "Aphis gossypii : vecteur CMV + Potyviruses. Colonies sur apex."}], "recommandations": [{"dose": "0,4 kg/ha", "type": "traitement_phyto", "titre": "Insecticide puceron concombre", "produit": "Pirimicarbe 50WG", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1400	RAV-CON-004	ravageur	insecte_foreur	Mouche du fruit concombre — Bactrocera cucurbitae	\N	null	["fructification"]	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Mouche du fruit"}, "alertes": [{"titre": "Mouche du fruit cucurbitacées", "niveau": "critique", "message": "Bactrocera cucurbitae pontes dans fruits verts → pourriture + chute."}], "recommandations": [{"dose": "5 pièges/ha", "type": "traitement_phyto", "titre": "Pièges à phéromone + appât protéiné", "produit": "Methyl Eugenol piège + Malathion appât", "priorite": 1}, {"type": "mesure_culturale", "titre": "Récolter fruits régulièrement", "detail": "Fruits laissés mûrs = sites de ponte. Enfouir fruits tombés.", "priorite": 2}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1401	RAV-GOM-002	ravageur	insecte_piqueur	Pucerons gombo — Aphis gossypii sur jeunes plants	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "miellat_gombo"}], "operator": "OR"}	{"risque": {"score": 0.78, "libelle": "Pucerons + virus"}, "alertes": [{"titre": "Pucerons gombo", "niveau": "elevee", "message": "Aphis gossypii sur jeunes plants : malformation + vecteur de virus (OKRV)."}], "recommandations": [{"dose": "0,4 L/ha", "type": "traitement_phyto", "titre": "Insecticide puceron gombo", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1402	RAV-GOM-003	ravageur	insecte_piqueur	Aleurodes gombo — Bemisia tabaci	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Aleurodes"}, "alertes": [{"titre": "Aleurodes gombo — saison sèche", "niveau": "elevee", "message": "Temps sec et chaud : explosion de Bemisia tabaci sur gombo. Fumagine + virus."}], "recommandations": [{"dose": "0,8 L/ha", "type": "traitement_phyto", "titre": "Spirotétramate contre aleurodes", "produit": "Spirotétramate 150OD", "priorite": 1, "urgence_jours": 4}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1403	RAV-GOM-004	ravageur	insecte_foreur	Perceur de la capsule gombo — Earias insulana	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "capsule_percee"}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Earias insulana"}, "alertes": [{"titre": "Earias insulana sur gombo", "niveau": "critique", "message": "Larves perforent tiges et capsules. Perte qualité commerciale."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Pyréthrinoïde sur capsules", "produit": "Cypermethrine 10EC", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 5}]}	critique	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1404	RAV-SES-002	ravageur	insecte_piqueur	Punaise tigre sésame — Sésame saison humide	\N	null	["fructification", "maturation"]	[8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Punaises capsules"}, "alertes": [{"titre": "Punaise tigre sésame", "niveau": "moyenne", "message": "Punaises actives sur capsules : succion graines en formation. Perte qualitative."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Endosulfan sur capsules sésame", "produit": "Endosulfan 35EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1405	RAV-SES-003	ravageur	acarien	Acarien sésame — Polyphagotarsonemus latus	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Acarien large"}, "alertes": [{"titre": "Acarien large sésame", "niveau": "moyenne", "message": "Polyphagotarsonemus latus : déformation jeunes feuilles en saison sèche."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Dicofol ou soufre mouillable", "produit": "Soufre mouillable 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1406	RAV-PAS-002	ravageur	insecte_foreur	Mouche du fruit pastèque — Bactrocera cucurbitae	\N	null	["fructification"]	[5, 6, 7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Mouche du fruit"}, "alertes": [{"titre": "Mouche du fruit pastèque", "niveau": "critique", "message": "Bactrocera cucurbitae : pontes dans jeunes fruits = pourriture interne totale."}], "recommandations": [{"dose": "5 pièges/ha", "type": "traitement_phyto", "titre": "Piège + appât protéiné pastèque", "produit": "Spinosad 0.02% appât + Methyl eugenol piège", "priorite": 1}, {"type": "mesure_culturale", "titre": "Récolter à maturité sans délai", "detail": "Fruits laissés au sol = foyers de reproduction. Détruire fruits infestés.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1407	RAV-PAS-003	ravageur	insecte_piqueur	Puceron pastèque — Aphis gossypii	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "enroulement_apical"}], "operator": "OR"}	{"risque": {"score": 0.82, "libelle": "Puceron + virus"}, "alertes": [{"titre": "Pucerons pastèque", "niveau": "elevee", "message": "Aphis gossypii vecteur WMV2 et CMV sur pastèque. Traitement urgent vecteur."}], "recommandations": [{"dose": "0,3 kg/ha", "type": "traitement_phyto", "titre": "Pirimicarbe contre pucerons pastèque", "produit": "Pirimicarbe 50WG", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1408	RAV-PAS-004	ravageur	acarien	Acarien rouge pastèque — Temps sec prolongé	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 32}, {"op": "lte", "field": "meteo.humidite_rel", "value": 45}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Tetranychus urticae"}, "alertes": [{"titre": "Acariens rouges pastèque", "niveau": "elevee", "message": "Extrême sécheresse : Tetranychus urticae explose sur feuilles. Brunissement foliaire."}], "recommandations": [{"dose": "0,4 L/ha", "type": "traitement_phyto", "titre": "Acaricide pastèque", "produit": "Spiromesifen 240SC", "priorite": 1, "urgence_jours": 4}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1409	RAV-ARA-004	ravageur	insecte_foreur	Termites arachide — Sol sableux saison sèche	\N	["bassin_arachidier", "soudano_sahelien"]	null	[10, 11, 12]	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 20}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Termites"}, "alertes": [{"titre": "Termites arachide saison sèche", "niveau": "elevee", "message": "Sol sec = colonisation termites. Attaquent gousses et tiges : perte qualitative importante."}], "recommandations": [{"dose": "2 L/ha (sol)", "type": "traitement_phyto", "titre": "Insecticide sol termites arachide", "produit": "Chlorpyrifos 40EC", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1410	RAV-MIL-004	ravageur	plante_parasite	Striga — Mil Sorgho zones sèches	\N	["soudano_sahelien", "sahel"]	["levee", "croissance_vegetative"]	[7, 8, 9]	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "striga"}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Striga hermonthica"}, "alertes": [{"titre": "Striga détecté", "niveau": "critique", "message": "Striga hermonthica — plante parasite racinaire. Réduit rendement 30-80% selon infestation."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher Striga avant floraison", "detail": "Avant fleur rouge = avant dispersion graines. 500 graines/plant = infestation persistante 20 ans.", "priorite": 1}, {"dose": "10 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Imazapyr", "produit": "Imazapyr 0.5% (Imazapyr-IR)", "priorite": 2}, {"type": "mesure_culturale", "titre": "Rotation légumineuses + fumier", "detail": "Niébé ou arachide avant mil + fumier 2 t/ha réduit émergence Striga.", "priorite": 3}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1411	RAV-MAG-003	ravageur	insecte_foreur	Mouche du fruit mangue — Ceratitis cosyra	\N	null	["fructification", "maturation"]	[4, 5, 6, 7]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}, {"op": "gte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Cératite de la mangue"}, "alertes": [{"titre": "Mouche du fruit mangue", "niveau": "critique", "message": "Ceratitis cosyra principal ravageur mangue Afrique. Pertes 30-80%. Piqûre sur fruits verts-jaunes."}], "recommandations": [{"dose": "5 pièges/ha + 8 appâts/ha", "type": "traitement_phyto", "titre": "Piège + appât protéiné mangue", "produit": "Spinosad 0.02% appât + piège Cue-lure", "priorite": 1}, {"dose": "Taches 1 L/arbre", "type": "traitement_phyto", "titre": "Malathion ULV couverture", "produit": "Malathion 50EC + Sucre 10%", "priorite": 2, "urgence_jours": 7}, {"type": "mesure_culturale", "titre": "Ramasser fruits tombés quotidiennement", "detail": "Fruits tombés = foyers de ponte. Enfouir à 50 cm ou immerger.", "priorite": 3}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1412	RAV-CHO-003	ravageur	insecte_foreur	Teigne des crucifères — Plutella xylostella	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "teigne_chou"}, {"op": "contains", "field": "obs.symptomes", "value": "fenestration_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Plutella xylostella"}, "alertes": [{"titre": "Teigne crucifères chou", "niveau": "critique", "message": "Plutella xylostella : ravageur #1 du chou mondial. Résistances nombreuses aux insecticides. Larves vert pâle."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "BT ou Spinosad vs teigne", "detail": "Alterner avec Spinosad 48SC (0.3 L/ha) pour éviter résistances.", "produit": "Bacillus thuringiensis subsp. kurstaki", "priorite": 1, "urgence_jours": 2}, {"dose": "0,3 L/ha", "type": "traitement_phyto", "titre": "Chlorantraniliprole systémique", "produit": "Chlorantraniliprole 18.5SC", "priorite": 2, "urgence_jours": 3, "delai_carence_jours": 14}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1413	RAV-OIG-003	ravageur	insecte_piqueur	Thrips oignon — Thrips tabaci forte pression	\N	null	["croissance_vegetative", "bulbaison"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.humidite_rel", "value": 50}, {"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "contains", "field": "obs.ravageurs", "value": "thrips"}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Thrips forte pression"}, "alertes": [{"titre": "Thrips oignon — forte pression", "niveau": "critique", "message": "Thrips tabaci population élevée : rugosité + blanchiment feuilles + transmission IYSV."}], "recommandations": [{"dose": "0,5 L + 0,3 L/ha", "type": "traitement_phyto", "titre": "Abamectine + Imidaclopride alternés", "detail": "Alterner familles pour éviter résistances.", "produit": "Abamectine 1.8EC + Imidaclopride 200SL", "priorite": 1, "urgence_jours": 2}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1414	RAV-PIM-003	ravageur	acarien	Acarien large piment — Polyphagotarsonemus latus	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}, {"op": "contains", "field": "obs.symptomes", "value": "bronzing_apex"}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Polyphagotarsonemus latus"}, "alertes": [{"titre": "Acarien large piment", "niveau": "elevee", "message": "P. latus : apex déformés en saison sèche. Ressemble à une carence. Loupe nécessaire."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine contre acarien large", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 4}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1415	RAV-RIZ-005	ravageur	insecte_piqueur	Cigale d'eau — Riz irrigation début saison	\N	["vallee_fleuve"]	["levee", "tallage"]	[4, 5, 6]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "contains", "field": "obs.symptomes", "value": "brunissement_racines"}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Cigale d'eau"}, "alertes": [{"titre": "Cigale d'eau riz", "niveau": "moyenne", "message": "Belostoma/Nepidae : sucent racines dans eau chaude. Tallage affaibli."}], "recommandations": [{"type": "mesure_culturale", "titre": "Vider et refaire lame d'eau", "detail": "Renouveler eau + Chlorpyrifos granulés si nécessaire.", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1416	RAV-MAN-003	ravageur	acarien	Acarien vert manioc — Mononychellus tanajoa	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "meteo.humidite_rel", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Acarien vert"}, "alertes": [{"titre": "Acarien vert manioc saison sèche", "niveau": "elevee", "message": "Mononychellus tanajoa : lobes déformés en saison sèche. Pertes 30-80% si non traité."}], "recommandations": [{"dose": "1 L/ha", "type": "traitement_phyto", "titre": "Acaricide manioc", "produit": "Dicofol 18.5EC ou Abamectine 1.8EC", "priorite": 1}, {"type": "mesure_culturale", "titre": "Lâcher Typhlodromalus aripo", "detail": "Acarien prédateur introduit en Afrique. Demander IITA / CSRS.", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1417	RAV-GEN-001	ravageur	general	Explosion ravageurs — Chaleur extrême + sécheresse	\N	null	null	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 35}, {"op": "lte", "field": "meteo.humidite_rel", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 2}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Ravageurs saison sèche"}, "alertes": [{"titre": "Conditions favorables explosion ravageurs", "niveau": "elevee", "message": "Temps très sec et chaud : acariens + aleurodes + pucerons en prolifération exponentielle."}], "recommandations": [{"type": "surveillance", "titre": "Inspection face inférieure des feuilles 2x/semaine", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1418	RAV-GEN-002	ravageur	general	Invasion acridienne — Criquet pèlerin zone sahel	\N	["soudano_sahelien", "sahel"]	null	[8, 9, 10, 11]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "criquet"}], "operator": "AND"}	{"risque": {"score": 0.98, "libelle": "Criquet pèlerin"}, "alertes": [{"titre": "Invasion acridienne", "niveau": "critique", "message": "Schistocerca gregaria : alerte critique. Contacter services phytosanitaires DGPV immédiatement."}], "recommandations": [{"type": "alerte_institutionnelle", "titre": "URGENCE — Contacter DGPV Sénégal : +221 33 889 10 85", "detail": "Signalement obligatoire. Traitement aérien national coordonné (Fipronil ULV).", "priorite": 1}]}	critique	10	0.98	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1419	RAV-GEN-003	ravageur	general	Nématodes polyvalents — Sol sableux acide	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "contains", "field": "obs.symptomes", "value": "galles_racinaires"}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Nématodes à galles"}, "alertes": [{"titre": "Nématodes galligènes détectés", "niveau": "elevee", "message": "Meloidogyne spp. : galles sur racines. Sol acide et sableux = conditions optimales."}], "recommandations": [{"dose": "10-15 kg/ha", "type": "traitement_sol", "titre": "Nématicide sol", "produit": "Cadusafos 10GR ou Oxamyl 10GR", "priorite": 1}, {"type": "mesure_culturale", "titre": "Solarisation sol pépinière", "detail": "Film plastique transparent 6 semaines = 80% réduction nématodes.", "priorite": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1420	RAV-GEN-004	ravageur	general	Noctuelles terricoles — Semis levée sol humide	\N	null	["semis", "levee"]	[6, 7, 8]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 24}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Noctuelles terricoles"}, "alertes": [{"titre": "Risque noctuelles terricoles", "niveau": "moyenne", "message": "Après forte pluie chaude : Agrotis/Spodoptera actifs la nuit, coupent collets jeunes plants."}], "recommandations": [{"dose": "15 kg/ha au sol", "type": "traitement_phyto", "titre": "Insecticide sol granulé ou bait", "produit": "Chlorpyrifos 10GR", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1421	RAV-GEN-005	ravageur	general	Punaises phytophages — Floraison toutes cultures	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "punaise"}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Punaises floraison"}, "alertes": [{"titre": "Punaises phytophages en floraison", "niveau": "elevee", "message": "Succion fleurs et jeunes fruits = avortement floral + stigmates piqûres commerciales."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Pyréthrinoïde contact + ingestion", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.424866+00	\N
1422	FER-RIZ-001	fertilisation	azote	Riz — Carence azote tallage	\N	null	["tallage", "montaison"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 80}, {"op": "in", "field": "culture.stade", "value": ["tallage", "montaison"]}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote riz — tallage", "niveau": "elevee", "message": "N <80 mg/kg : risque tallage insuffisant et rendement réduit de 20-40%."}], "recommandations": [{"dose": "60 kg N/ha", "type": "fertilisation", "titre": "Apport urée tallage", "detail": "Fractionner : 30 kg N au tallage + 30 kg N à la montaison.", "produit": "Urée 46%", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1423	FER-RIZ-002	fertilisation	phosphore	Riz — Carence phosphore pH acide	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 10}, {"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 20}, {"op": "lte", "field": "sol.pH", "value": 5.5}], "operator": "AND"}], "operator": "OR"}	{"risque": {"score": 0.82, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore riz", "niveau": "elevee", "message": "P <10 mg/kg ou pH<5.5 bloque assimilation P. Racines courtes, tallage faible."}], "recommandations": [{"dose": "40-60 kg P₂O₅/ha", "type": "fertilisation", "titre": "TSP à l'installation", "produit": "Triple Superphosphate (TSP 46%)", "priorite": 1, "urgence_jours": 0}, {"type": "amendement_sol", "titre": "Chaulage si pH <5.5", "detail": "Porter pH >6.0 pour débloquer P natif du sol.", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1424	FER-RIZ-003	fertilisation	pH	Riz — Sol acide fort blocage nutriments	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.0}	{"risque": {"score": 0.9, "libelle": "Acidité sol toxique"}, "alertes": [{"titre": "Sol très acide riz — pH critique", "niveau": "elevee", "message": "pH <5.0 : toxicité Al/Mn + blocage P, Ca, Mg. Productivité limitée à 30-50%."}], "recommandations": [{"dose": "2-4 t/ha", "type": "amendement_sol", "titre": "Chaulage correctif", "detail": "Appliquer 6 semaines avant plantation. pH cible 6.0-6.5.", "produit": "Chaux agricole (CaCO₃)", "priorite": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1425	FER-RIZ-004	fertilisation	matiere_organique	Riz — Matière organique faible — sol dégradé	\N	null	null	null	{"op": "lte", "field": "sol.matiere_organique", "value": 1.0}	{"risque": {"score": 0.72, "libelle": "Sol dégradé MO"}, "alertes": [{"titre": "Sol pauvre en matière organique — Riz", "niveau": "moyenne", "message": "MO <1% : faible CEC, mauvaise rétention eau/nutriments. Fertilité structurelle faible."}], "recommandations": [{"dose": "5-10 t/ha", "type": "amendement_organique", "titre": "Compost ou fumier incorporé", "detail": "Incorporer 30 jours avant plantation.", "produit": "Fumier bovin composté", "priorite": 1}]}	moyenne	6	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1426	FER-MIL-001	fertilisation	azote	Mil — Carence azote levée-tallage	\N	null	["levee", "tallage"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote mil", "niveau": "elevee", "message": "N <60 mg/kg : jaunissement précoce + tallage faible. Pertes 30-50%."}], "recommandations": [{"dose": "40 kg N/ha", "type": "fertilisation", "titre": "Urée ou sulfate d'ammonium", "detail": "Microdosage : 2 g/poquet à 21 jours après semis. Technique ISSATROP.", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1427	FER-MIL-002	fertilisation	phosphore	Mil — Carence phosphore — sol ferrugineux	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"op": "lte", "field": "sol.phosphore", "value": 10}	{"risque": {"score": 0.82, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore mil", "niveau": "elevee", "message": "P <10 mg/kg sur sol ferrugineux : racines courtes, système racinaire peu développé."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "DAP ou TSP au semis", "detail": "Placer en sillon 5cm sous la graine.", "produit": "DAP (18-46-0)", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1428	FER-MIL-003	fertilisation	potassium	Mil — Carence potassium — sol sableux	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 50}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Carence potassium"}, "alertes": [{"titre": "Carence potassium mil", "niveau": "moyenne", "message": "K <50 mg/kg : sensibilité aux maladies accrue + grains peu denses."}], "recommandations": [{"dose": "30-40 kg K₂O/ha", "type": "fertilisation", "titre": "KCl ou K2SO4", "produit": "Chlorure de potasse (KCl 60%)", "priorite": 1}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1429	FER-SOR-001	fertilisation	azote	Sorgho — Carence N levée-tallage	\N	null	["levee", "tallage"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.82, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote sorgho", "niveau": "elevee", "message": "N <60 mg/kg : jaunissement feuilles basses, tallage réduit, perte rendement."}], "recommandations": [{"dose": "50 kg N/ha en 2 fractions", "type": "fertilisation", "titre": "Urée fractionnée", "produit": "Urée 46%", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1430	FER-SOR-002	fertilisation	phosphore	Sorgho — Carence P sol acide	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 12}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore sorgho", "niveau": "elevee", "message": "P <12 mg/kg : coloration pourpre feuilles, racines peu développées."}], "recommandations": [{"dose": "40 kg P₂O₅/ha au semis", "type": "fertilisation", "titre": "TSP au semis", "produit": "TSP 46%", "priorite": 1}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1431	FER-MAI-001	fertilisation	azote	Maïs — Carence N critique levée	\N	null	["levee", "croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.9, "libelle": "Carence azote maïs"}, "alertes": [{"titre": "Carence azote maïs", "niveau": "elevee", "message": "N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé."}], "recommandations": [{"dose": "200 kg NPK/ha + 100 kg Urée/ha fractionné", "type": "fertilisation", "titre": "Programme NPK maïs", "detail": "NPK au semis + Urée ⅓ au tallage + ⅔ à la montaison.", "produit": "NPK 14-18-18 + Urée 46%", "priorite": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1432	FER-MAI-002	fertilisation	potassium	Maïs — Carence K sol sableux épuisé	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 60}	{"risque": {"score": 0.82, "libelle": "Carence K maïs"}, "alertes": [{"titre": "Carence potassium maïs", "niveau": "elevee", "message": "K <60 mg/kg : brûlures bordures feuilles, verse accrue, grains mal formés."}], "recommandations": [{"dose": "50-80 kg K₂O/ha", "type": "fertilisation", "titre": "KCl au semis", "produit": "KCl 60%", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1433	FER-MAI-003	fertilisation	pH	Maïs — pH bas — toxicité aluminium	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.5}	{"risque": {"score": 0.88, "libelle": "Acidité toxique Al"}, "alertes": [{"titre": "Sol acide maïs — toxicité Al", "niveau": "elevee", "message": "pH <5.5 : Al³⁺ toxique → racines courtes, nanisme. Chaulage urgence."}], "recommandations": [{"dose": "2-3 t/ha", "type": "amendement_sol", "titre": "Chaulage + attendre 6 semaines", "produit": "Chaux vive ou calcaire broyé", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1434	FER-ARA-001	fertilisation	phosphore	Arachide — Carence P nodulation	\N	null	null	null	{"op": "lte", "field": "sol.phosphore", "value": 10}	{"risque": {"score": 0.85, "libelle": "Carence P + nodulation faible"}, "alertes": [{"titre": "Carence phosphore arachide", "niveau": "elevee", "message": "P <10 mg/kg : nodulation rhizobium insuffisante + fixation N2 limitée."}], "recommandations": [{"dose": "30 kg P₂O₅/ha + inoculant 5 g/kg semences", "type": "fertilisation", "titre": "TSP au semis + inoculant Rhizobium", "produit": "TSP 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1436	FER-NIE-001	fertilisation	phosphore	Niébé — Carence P — nodulation faible	\N	null	null	null	{"op": "lte", "field": "sol.phosphore", "value": 8}	{"risque": {"score": 0.82, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore niébé", "niveau": "elevee", "message": "P <8 mg/kg : nodulation Rhizobium faible, fixation N2 réduite."}], "recommandations": [{"dose": "20 kg P₂O₅/ha + inoculant Bradyrhizobium", "type": "fertilisation", "titre": "TSP + inoculant semences", "produit": "TSP 46%", "priorite": 1}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1437	FER-NIE-002	fertilisation	azote	Niébé — Faible azote starter à levée	\N	null	["levee"]	null	{"op": "lte", "field": "sol.azote", "value": 40}	{"risque": {"score": 0.65, "libelle": "Carence N starter"}, "alertes": [{"titre": "Faible N starter niébé", "niveau": "moyenne", "message": "N <40 mg/kg : dose starter avant établissement nodules."}], "recommandations": [{"dose": "22-32 kg/ha", "type": "fertilisation", "titre": "Urée starter 10-15 kg N/ha au semis uniquement", "detail": "Ne pas dépasser 15 kg N/ha : excès azote inhibe nodulation.", "produit": "Urée 46%", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1438	FER-SES-001	fertilisation	azote	Sésame — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.72, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote sésame", "niveau": "moyenne", "message": "N <60 mg/kg : tiges fines, feuilles pâles. Rendement <500 kg/ha."}], "recommandations": [{"dose": "50 kg/ha au semis + 30 kg Urée à 21 jours", "type": "fertilisation", "titre": "Urée + DAP au semis + 21 jours", "produit": "DAP (18-46-0)", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1439	FER-MAN-001	fertilisation	potassium	Manioc — Carence K forte — épuisement sol	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 50}	{"risque": {"score": 0.85, "libelle": "Carence K manioc"}, "alertes": [{"titre": "Carence potassium manioc critique", "niveau": "elevee", "message": "K <50 mg/kg : manioc exigeant en K (export >200 kg K₂O/ha récolte). Sols épuisés."}], "recommandations": [{"dose": "80-120 kg K₂O/ha en 2-3 apports", "type": "fertilisation", "titre": "KCl apport fractionné", "detail": "KCl épuise sols sableux. Compléter avec fumier.", "produit": "KCl 60%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1440	FER-MAN-002	fertilisation	azote	Manioc — Carence N croissance vegetative	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 50}	{"risque": {"score": 0.72, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote manioc", "niveau": "moyenne", "message": "N <50 mg/kg : feuillage pâle, croissance lente, tubercules petits."}], "recommandations": [{"dose": "40-60 kg N/ha en 2 apports", "type": "fertilisation", "titre": "Urée fractionné 2-3 mois", "produit": "Urée 46%", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1441	FER-TOM-001	fertilisation	azote	Tomate — Carence N croissance-floraison	\N	null	["croissance_vegetative", "floraison"]	null	{"op": "lte", "field": "sol.azote", "value": 100}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote tomate", "niveau": "elevee", "message": "N <100 mg/kg : feuilles vert pâle, floraison réduite, fruits petits."}], "recommandations": [{"dose": "120-150 kg N/ha total", "type": "fertilisation", "titre": "Fertigation N ou apport sol", "detail": "Fractionner toutes les 2 semaines. En fertigation : 4-6 kg N/ha/semaine.", "produit": "Nitrate de calcium ou Urée", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1442	FER-TOM-002	fertilisation	potassium	Tomate — Carence K fructification	\N	null	["fructification", "maturation"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.85, "libelle": "Carence K + nécrose apicale"}, "alertes": [{"titre": "Carence potassium tomate — qualité fruits", "niveau": "elevee", "message": "K <80 mg/kg en fructification : nécrose apicale + coloration irrégulière fruits."}], "recommandations": [{"dose": "80-100 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ + nitrate de calcium", "detail": "Ajouter Ca via nitrate de calcium pour prévenir Blossom End Rot.", "produit": "Sulfate de potasse (K₂SO₄)", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1443	FER-TOM-003	fertilisation	pH	Tomate — pH très acide blocage Ca/Mg	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.5}	{"risque": {"score": 0.88, "libelle": "Sol acide"}, "alertes": [{"titre": "Sol acide tomate — pH critique", "niveau": "elevee", "message": "pH <5.5 : blocage Ca, Mg, B. Aggrave Fusariose + Rhizoctone."}], "recommandations": [{"dose": "2-3 t/ha", "type": "amendement_sol", "titre": "Chaulage avant plantation", "detail": "pH cible 6.2-6.8 pour tomate.", "produit": "Dolomie (Ca+Mg)", "priorite": 1}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1444	FER-TOM-004	fertilisation	phosphore	Tomate — Carence P repiquage-floraison	\N	null	["repiquage", "croissance_vegetative"]	null	{"op": "lte", "field": "sol.phosphore", "value": 15}	{"risque": {"score": 0.82, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore tomate", "niveau": "elevee", "message": "P <15 mg/kg : couleur pourpre face inférieure feuilles, floraison retardée."}], "recommandations": [{"dose": "60-80 kg P₂O₅/ha", "type": "fertilisation", "titre": "TSP ou DAP au repiquage", "produit": "TSP 46%", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1445	FER-PIM-001	fertilisation	azote	Piment — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.75, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote piment", "niveau": "moyenne", "message": "N <80 mg/kg : croissance lente, feuilles pâles, fruits petits."}], "recommandations": [{"dose": "100-120 kg N/ha total", "type": "fertilisation", "titre": "Urée + NPK fractionné", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1446	FER-AUB-001	fertilisation	azote	Aubergine — Carence N forte	\N	null	["croissance_vegetative", "floraison"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote aubergine", "niveau": "moyenne", "message": "N <80 mg/kg : production limitée."}], "recommandations": [{"dose": "150-200 kg NPK/ha + 80 kg Urée/ha fractionné", "type": "fertilisation", "titre": "Programme NPK aubergine", "produit": "NPK 12-12-17 + Urée", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1447	FER-CHO-001	fertilisation	azote	Chou — Carence N critique pommaison	\N	null	["croissance_vegetative", "pommaison"]	null	{"op": "lte", "field": "sol.azote", "value": 100}	{"risque": {"score": 0.85, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote chou", "niveau": "elevee", "message": "N <100 mg/kg : pommes lâches, jaunissement précoce."}], "recommandations": [{"dose": "150-200 kg N/ha total en 3 fractions", "type": "fertilisation", "titre": "Urée + sulfate d'ammonium fractionné", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1448	FER-CHO-002	fertilisation	pH	Chou — pH acide Hernie du chou	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 6.5}	{"risque": {"score": 0.85, "libelle": "pH + Hernie du chou"}, "alertes": [{"titre": "pH acide chou — Risque Hernie", "niveau": "elevee", "message": "pH <6.5 : Plasmodiophora brassicae active. Chaulage obligatoire avant Brassicacées."}], "recommandations": [{"dose": "3-5 t/ha", "type": "amendement_sol", "titre": "Chaulage fort avant plantation", "detail": "pH cible ≥7.0.", "produit": "Chaux vive", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1449	FER-OIG-001	fertilisation	azote	Oignon — Carence N croissance-bulbaison	\N	null	["croissance_vegetative", "bulbaison"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.85, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote oignon", "niveau": "elevee", "message": "N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite."}], "recommandations": [{"dose": "80-120 kg N/ha", "type": "fertilisation", "titre": "Urée fractionné + arrêt 4 semaines avant récolte", "detail": "Arrêter N 30 jours avant récolte pour bonne conservation.", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1450	FER-OIG-002	fertilisation	potassium	Oignon — Carence K conservation bulbes	\N	null	["bulbaison", "maturation"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.75, "libelle": "Carence K conservation"}, "alertes": [{"titre": "Carence potassium oignon", "niveau": "moyenne", "message": "K <80 mg/kg : bulbes mous, conservation réduite, pertes stockage élevées."}], "recommandations": [{"dose": "80-100 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ à la bulbaison", "produit": "Sulfate de potasse 50%", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1451	FER-MAG-001	fertilisation	NPK	Mangue — Carence nutritionnelle post-récolte	\N	null	null	[7, 8, 9]	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 50}, {"op": "lte", "field": "sol.phosphore", "value": 8}, {"op": "lte", "field": "sol.potassium", "value": 60}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Carence NPK mangue"}, "alertes": [{"titre": "Carence nutriments mangue post-récolte", "niveau": "moyenne", "message": "Sol épuisé après récolte. Fertilisation post-récolte pour recharger arbre."}], "recommandations": [{"dose": "1-3 kg/arbre selon âge", "type": "fertilisation", "titre": "NPK arbres fruitiers post-récolte", "detail": "Incorporer sous frondaison. Arroser si saison sèche.", "produit": "NPK 10-10-20", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1452	FER-ANA-001	fertilisation	NPK	Anacarde — Fertilisation jeunes plants	\N	null	null	[7, 8]	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 40}, {"op": "lte", "field": "sol.phosphore", "value": 8}], "operator": "OR"}	{"risque": {"score": 0.7, "libelle": "Sol pauvre anacarde"}, "alertes": [{"titre": "Sol pauvre — Fertilisation anacarde", "niveau": "moyenne", "message": "Sol très pauvre : fertilisation de fond indispensable pour jeunes plants."}], "recommandations": [{"dose": "200 g NPK/fosse + 50 g Urée à 3 mois", "type": "fertilisation", "titre": "NPK fosse plantation + urée 1ère année", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	moyenne	5	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1453	FER-GOM-001	fertilisation	azote	Gombo — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote gombo", "niveau": "moyenne", "message": "N <80 mg/kg : croissance lente, fruits petits."}], "recommandations": [{"dose": "40 kg N/ha en 2 apports", "type": "fertilisation", "titre": "Urée à 21 jours", "produit": "Urée 46%", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1454	FER-CON-001	fertilisation	potassium	Concombre — Carence K fructification	\N	null	["fructification"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence K"}, "alertes": [{"titre": "Carence K concombre", "niveau": "moyenne", "message": "K <80 mg/kg en fructification : fruits courbés + saveur acide."}], "recommandations": [{"dose": "60-80 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ à la fructification", "produit": "Sulfate de potasse", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1455	FER-PAS-001	fertilisation	NPK	Pastèque — Déficit NPK fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 80}, {"op": "lte", "field": "sol.azote", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Carence NPK qualité"}, "alertes": [{"titre": "Carence NPK pastèque fructification", "niveau": "moyenne", "message": "Déficit K+N : fruits petits, chair peu colorée, teneur sucre réduite."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "Fertigation NK fructification", "produit": "Nitrate de potasse (NOP 13-0-46)", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1456	FER-BAN-001	fertilisation	potassium	Banane — Forte exigence K croissance	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 100}	{"risque": {"score": 0.88, "libelle": "Carence K banane"}, "alertes": [{"titre": "Carence potassium banane critique", "niveau": "elevee", "message": "Banane exige 300-400 kg K₂O/ha/an. K <100 : régimes petits, maturation irrégulière."}], "recommandations": [{"dose": "300-400 kg K₂O/ha/an fractionné mensuellement", "type": "fertilisation", "titre": "KCl ou K₂SO₄ mensuel", "produit": "KCl 60%", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1457	FER-PAP-001	fertilisation	azote	Papaye — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.72, "libelle": "Carence N papaye"}, "alertes": [{"titre": "Carence azote papaye", "niveau": "moyenne", "message": "N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification."}], "recommandations": [{"dose": "150 g NPK + 100 g Urée/plant/mois", "type": "fertilisation", "titre": "NPK + Urée mensuel", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1458	FER-GEN-001	fertilisation	pH	Sol très alcalin — Blocage micronutriments	\N	null	null	null	{"op": "gte", "field": "sol.pH", "value": 8.0}	{"risque": {"score": 0.85, "libelle": "Alcalinité toxique"}, "alertes": [{"titre": "Sol très alcalin — pH >8.0", "niveau": "elevee", "message": "pH >8.0 : blocage Fe, Mn, Zn, B. Chlorose ferrique + déficiences multiples."}], "recommandations": [{"dose": "200-500 kg/ha", "type": "amendement_sol", "titre": "Soufre agricole pour acidifier", "detail": "Résultat en 3-6 mois. Compléter par sulfate de fer.", "produit": "Soufre élémentaire S", "priorite": 1}, {"dose": "5-10 kg/ha en fertirrigation", "type": "fertilisation", "titre": "Chélates Fe, Mn, Zn foliaires", "produit": "Chélate EDDHA 6%", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1459	FER-GEN-002	fertilisation	matiere_organique	Sol très dégradé MO — Toutes cultures	\N	null	null	null	{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}	{"risque": {"score": 0.88, "libelle": "Dégradation sol sévère"}, "alertes": [{"titre": "Sol très pauvre en matière organique", "niveau": "elevee", "message": "MO <0.5% : sol mort, efficience engrais très faible, érosion forte."}], "recommandations": [{"dose": "10-15 t/ha/an", "type": "amendement_organique", "titre": "Compost + restitution pailles", "detail": "Programme pluriannuel. Incorporer résidus de récolte au sol.", "produit": "Compost ou fumier", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation avec légumineuses", "detail": "Niébé, arachide ou mucuna comme précédent cultural.", "priorite": 2}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1460	FER-SES-002	fertilisation	phosphore	Carence phosphore sésame — Levée racinaire	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 15}, {"op": "lte", "field": "sol.pH", "value": 6.5}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore sésame", "niveau": "elevee", "message": "P < 15 ppm sur sol acide : développement racinaire limité, anthèse réduite."}], "recommandations": [{"dose": "50 kg/ha en fond", "type": "fertilisation", "titre": "Triple Superphosphate sésame", "detail": "Incorporer avant semis. Améliore enracinement et floraison.", "produit": "TSP 46% P2O5", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1461	FER-SES-003	fertilisation	potassium	Carence potassium sésame — Fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.2}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence K"}, "alertes": [{"titre": "Carence K sésame fructification", "niveau": "elevee", "message": "K+ insuffisant : remplissage graines incomplet, qualité huile réduite."}], "recommandations": [{"dose": "30 kg/ha en couverture", "type": "fertilisation", "titre": "Chlorure de potassium sésame", "produit": "KCl 60% K2O", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1462	FER-SES-004	fertilisation	azote	Apport azoté sésame — Faible teneur sol	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.8}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Carence N"}, "alertes": [{"titre": "Azote faible sésame", "niveau": "moyenne", "message": "N total < 0.8‰ : jaunissement interfoliaire anticipé. Croissance végétative compromise."}], "recommandations": [{"dose": "40 kg/ha : 20 kg semis + 20 kg floraison", "type": "fertilisation", "titre": "Urée fractionnée sésame", "produit": "Urée 46% N", "priorite": 1}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1463	FER-GOM-002	fertilisation	azote	Carence azote gombo — Jaunissement progressif	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.7}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement"}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote gombo", "niveau": "elevee", "message": "Jaunissement des vieilles feuilles + sol N< 0.7‰ : apport azoté urgent."}], "recommandations": [{"dose": "30 kg/ha fractionnés", "type": "fertilisation", "titre": "Urée en couverture gombo", "produit": "Urée 46% N", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1464	FER-GOM-003	fertilisation	phosphore	Carence phosphore gombo — Floraison réduite	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 12}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Carence P floraison"}, "alertes": [{"titre": "Phosphore faible gombo", "niveau": "moyenne", "message": "P assimilable faible : avortement floral et production capsules réduite."}], "recommandations": [{"dose": "100 kg/ha en fond", "type": "fertilisation", "titre": "Phosphate naturel Tilemsi", "produit": "Phosphate naturel 28% P2O5", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1465	FER-GOM-004	fertilisation	micronutriment	Carence calcium-magnésium gombo — Sol sableux lessivé	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "lte", "field": "sol.matiere_organique", "value": 0.8}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Carence Ca-Mg"}, "alertes": [{"titre": "Carence Ca-Mg gombo", "niveau": "moyenne", "message": "pH acide + faible MO : Ca et Mg bloqués. Pourriture apicale capsules possible."}], "recommandations": [{"dose": "500 kg/ha", "type": "amendement_sol", "titre": "Dolomite (Ca+Mg) gombo", "detail": "Relève pH + apporte Ca+Mg simultanément.", "produit": "Dolomite 18% CaO + 9% MgO", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1466	FER-CON-002	fertilisation	calcium	Carence calcium concombre — Pourriture apicale	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "pourriture_apicale"}, {"op": "gte", "field": "sol.conductivite", "value": 3.0}], "operator": "OR"}	{"risque": {"score": 0.8, "libelle": "BER (Blossom End Rot)"}, "alertes": [{"titre": "Carence Ca concombre", "niveau": "elevee", "message": "Pourriture apicale bout des fruits = carence calcique fonctionnelle. Liée à stress hydrique ou EC élevée."}], "recommandations": [{"dose": "4 kg/ha en foliaire 2x/semaine", "type": "fertilisation", "titre": "Nitrate de calcium foliaire", "detail": "Irrigation régulière simultanée — carence fonctionnelle.", "produit": "Nitrate de Ca 15%", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1467	FER-CON-003	fertilisation	azote	Programme NPK concombre — Cycle complet	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 1.0}, {"op": "lte", "field": "sol.phosphore", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Carence NPK"}, "alertes": [{"titre": "Programme NPK concombre recommandé", "niveau": "moyenne", "message": "Sol pauvre en N et P : fertilisation NPK structurée nécessaire pour potentiel productif."}], "recommandations": [{"type": "fertilisation", "titre": "Programme NPK concombre", "detail": "Fond: DAP 100 kg/ha. J15: Urée 30 kg/ha. J30: KCl 30 kg/ha. Floraison: urée 20 kg/ha.", "priorite": 1}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1468	FER-CON-004	fertilisation	micronutriment	Carence magnésium concombre — Chlorose interfoliaire	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "chlorose_interfoliaire"}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Carence Mg"}, "alertes": [{"titre": "Carence magnésium concombre", "niveau": "moyenne", "message": "Chlorose entre nervures = Mg insuffisant. Fréquent sur sables après pluies lessivantes."}], "recommandations": [{"dose": "2 kg/ha en foliaire", "type": "fertilisation", "titre": "Sulfate de magnésium foliaire", "produit": "MgSO4 (Kieserite) 16% Mg", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1469	FER-PAP-002	fertilisation	potassium	Carence potassium papaye — Qualité fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.25}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence K"}, "alertes": [{"titre": "Carence K papaye", "niveau": "elevee", "message": "K+ insuffisant en fructification : fruits petits, saveur réduite, sensibilité accrue anthracnose."}], "recommandations": [{"dose": "100 g/plant/mois", "type": "fertilisation", "titre": "Sulfate de potassium papaye", "detail": "Préférer SO4 à Cl pour papaye sensible au chlore.", "produit": "SOP K2SO4 50% K2O", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1470	FER-PAP-003	fertilisation	magnesium	Carence magnésium papaye — Feuilles basses jaunies	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.0}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_interfoliaire"}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence Mg"}, "alertes": [{"titre": "Carence Mg papaye", "niveau": "elevee", "message": "Jaunissement entre nervures feuilles âgées = Mg bloqué par pH bas ou excès K."}], "recommandations": [{"dose": "200 g/plant sol + 2 kg/ha foliaire", "type": "fertilisation", "titre": "Kieserite en sol + foliaire", "produit": "Kieserite MgSO4 26% MgO", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1471	FER-PAP-004	fertilisation	azote	Programme NPK mensuel papaye — Plantation jeune	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 1.0}, {"op": "lte", "field": "culture.jours_semis", "value": 180}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Carence NPK"}, "alertes": [{"titre": "NPK mensuel papaye requis", "niveau": "moyenne", "message": "Papaye jeune = besoins élevés. Programme mensuel recommandé pour rendement optimal."}], "recommandations": [{"type": "fertilisation", "titre": "Programme mensuel papaye (6 premiers mois)", "detail": "M1-M3: 50g urée + 50g TSP + 50g KCl/plant/mois. M4-M6: 100g urée + 50g KCl/plant/mois.", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1472	FER-MAG-002	fertilisation	phosphore	Carence phosphore mangue — Enracinement plantin	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Carence P"}, "alertes": [{"titre": "Phosphore bas mangue", "niveau": "elevee", "message": "P assimilable < 10 ppm : enracinement insuffisant jeunes arbres, floraison différée."}], "recommandations": [{"dose": "200-500 g/arbre en fond de trou", "type": "fertilisation", "titre": "DAP en fond de trou plantation", "produit": "DAP 18-46-0", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1473	FER-MAG-003	fertilisation	potassium	Potassium mangue — Qualité fruits sucrés	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.2}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Carence K fruits"}, "alertes": [{"titre": "Potassium faible avant fructification mangue", "niveau": "moyenne", "message": "K+ bas : fruits petits, moins sucrés, moins colorés. Impact commercial direct."}], "recommandations": [{"dose": "500 g-1 kg/arbre avant floraison", "type": "fertilisation", "titre": "SOP avant floraison mangue", "produit": "Sulfate potassium 50% K2O", "priorite": 1}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1474	FER-MAG-004	fertilisation	micronutriment	Carence bore mangue — Déformation fleurs	\N	null	["floraison"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "avortement_floral"}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Carence Bore"}, "alertes": [{"titre": "Possible carence bore mangue", "niveau": "elevee", "message": "Avortement floral massif = carence B possible, surtout sols sableux pluvieux lessivants."}], "recommandations": [{"dose": "0,3% en foliaire (3 kg/100L eau)", "type": "fertilisation", "titre": "Borax foliaire mangue", "detail": "2 applications : 2 semaines avant + pendant floraison.", "produit": "Borax 11% B", "priorite": 1}]}	elevee	7	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1475	FER-ANA-002	fertilisation	phosphore	Carence phosphore anacarde — Enracinement jeunes plants	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 8}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence P"}, "alertes": [{"titre": "P bas anacarde", "niveau": "elevee", "message": "P < 8 ppm sur sol ferrallitique : carence P fréquente au Sénégal pour anacarde."}], "recommandations": [{"dose": "500 g/arbre en fond de trou", "type": "fertilisation", "titre": "Phosphate naturel fond anacarde", "produit": "Phosphate de Thiès 28% P2O5", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1476	FER-ANA-003	fertilisation	potassium	Potassium anacarde — Remplissage noix	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.15}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Carence K"}, "alertes": [{"titre": "K insuffisant anacarde fructification", "niveau": "moyenne", "message": "K+ bas pendant remplissage noix : calibre et teneur huile réduits."}], "recommandations": [{"dose": "250-500 g/arbre selon âge", "type": "fertilisation", "titre": "SOP avant floraison anacarde", "produit": "K2SO4 50% K2O", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1477	FER-ANA-004	fertilisation	azote	Azote anacarde jeune — Croissance végétative	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.5}, {"op": "lte", "field": "culture.jours_semis", "value": 365}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Carence N jeune"}, "alertes": [{"titre": "N bas anacarde jeune", "niveau": "moyenne", "message": "Anacarde <1 an : N suffisant nécessaire pour charpente arbre. Ne pas négliger."}], "recommandations": [{"dose": "50-100 g/plant en 2 fractions (saison pluies)", "type": "fertilisation", "titre": "Urée anacarde jeune", "produit": "Urée 46% N", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1478	FER-BAN-002	fertilisation	potassium	Carence potassium banane — Nervures et fruits	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.3}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Carence K critique"}, "alertes": [{"titre": "Carence K banane", "niveau": "critique", "message": "Banane 1er consommateur K : K< 0.3 meq = fruit malformés, doigts courts, verse. Urgence."}], "recommandations": [{"dose": "300 g/plant/mois", "type": "fertilisation", "titre": "KCl ou SOP mensuel banane", "detail": "Banane exporte 400+ kg K2O/ha/an. Indispensable pour rendement.", "produit": "KCl 60% K2O", "priorite": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1479	FER-BAN-003	fertilisation	magnesium	Carence Mg banane — Chlorose Bluggoe	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "chlorose_banane"}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence Mg banane"}, "alertes": [{"titre": "Carence Mg banane", "niveau": "elevee", "message": "Jaunissement interfoliaire feuilles adultes = Mg déplacé par excès K. Apport Mg requis."}], "recommandations": [{"dose": "200 g/plant/mois + foliaire 2 kg/ha", "type": "fertilisation", "titre": "Kieserite sol + foliaire banane", "produit": "Kieserite 26% MgO", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1480	FER-BAN-004	fertilisation	azote	Programme azoté banane — Tallage et montaison	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 1.2}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence N"}, "alertes": [{"titre": "Azote insuffisant banane", "niveau": "elevee", "message": "N < 1.2‰ : feuilles courtes, canopée réduite, cycle allongé."}], "recommandations": [{"dose": "150-200 g/plant/mois", "type": "fertilisation", "titre": "Urée mensuel banane", "produit": "Urée 46% N", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1481	FER-PAS-002	fertilisation	azote	Carence azote pastèque — Croissance végétative	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.8}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence N"}, "alertes": [{"titre": "N faible pastèque", "niveau": "elevee", "message": "Vigueur végétative insuffisante : feuilles petites, tiges courtes. Rendement compromis."}], "recommandations": [{"dose": "50 kg/ha en 3 fractions (semis/J20/floraison)", "type": "fertilisation", "titre": "Urée fractionnée pastèque", "produit": "Urée 46% N", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1482	FER-PAS-003	fertilisation	calcium	Carence calcium pastèque — Pourriture apex fruit	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "pourriture_apicale"}], "operator": "OR"}	{"risque": {"score": 0.8, "libelle": "Carence Ca BER"}, "alertes": [{"titre": "BER pastèque (blossom end rot)", "niveau": "elevee", "message": "Bout de fleur pourri = carence Ca fonctionnelle. Stress hydrique + sol peu tamponné."}], "recommandations": [{"dose": "4 kg/ha foliaire 2x/semaine", "type": "fertilisation", "titre": "Nitrate calcium foliaire + irrigation constante", "detail": "Irrigation goutte-à-goutte régulière = Ca conduit par transpiration.", "produit": "Nitrate Ca 15%", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1483	FER-PAS-004	fertilisation	potassium	Potassium pastèque — Qualité fruit sucre	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.2}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Carence K qualité"}, "alertes": [{"titre": "K insuffisant pastèque fructification", "niveau": "elevee", "message": "K+ < 0.2 meq : teneur en sucre (Brix) réduite, chair moins dense."}], "recommandations": [{"dose": "50 kg/ha à nouaison fruits", "type": "fertilisation", "titre": "SOP en couverture pastèque", "produit": "K2SO4 50% K2O", "priorite": 1}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1484	FER-NIE-003	fertilisation	micronutriment	Inoculant rhizobium niébé — Sols non-cultivés	\N	null	["semis"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 0.5}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Manque fixation N2"}, "alertes": [{"titre": "Inoculant rhizobium recommandé niébé", "niveau": "elevee", "message": "Sol pauvre en N : inoculation Bradyrhizobium = fixation azotée 80-150 kg N/ha. ROI élevé."}], "recommandations": [{"dose": "200 g/25 kg semences", "type": "traitement_semences", "titre": "Inoculant Bradyrhizobium sur semences", "detail": "Humidifier semences légèrement + mélanger inoculant + sécher à l'ombre avant semis.", "produit": "Inoculant Bradyrhizobium japonicum (SEMIA 587)", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1485	FER-MAN-003	fertilisation	potassium	Potassium manioc — Tubérisation et rendement	\N	null	["tuberisation"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.2}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence K tubérisation"}, "alertes": [{"titre": "K insuffisant manioc tubérisation", "niveau": "elevee", "message": "K+ faible : amyloplastes réduits, tubérosités petites, qualité amidon affectée."}], "recommandations": [{"dose": "80-100 kg/ha en couverture M4-M6", "type": "fertilisation", "titre": "KCl manioc en couverture", "produit": "KCl 60% K2O", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1486	FER-PIM-003	fertilisation	potassium	Potassium piment — Qualité fruits capsaïcine	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 0.22}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Carence K piment"}, "alertes": [{"titre": "K faible piment fructification", "niveau": "elevee", "message": "K insuffisant : fruits ternes, moins piquants, sensibilité accrue aux maladies post-récolte."}], "recommandations": [{"dose": "50 kg/ha en couverture", "type": "fertilisation", "titre": "Sulfate potassium piment", "produit": "SOP 50% K2O", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1487	FER-PIM-004	fertilisation	calcium	Carence calcium piment — BER pointe fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "pourriture_apicale"}], "operator": "OR"}	{"risque": {"score": 0.78, "libelle": "BER piment"}, "alertes": [{"titre": "BER piment (bout de fleur)", "niveau": "elevee", "message": "Pourriture apicale piment = carence Ca fonctionnelle. Irrigation irrégulière facteur majeur."}], "recommandations": [{"dose": "3 kg/ha foliaire", "type": "fertilisation", "titre": "Chlorure calcium foliaire piment", "produit": "CaCl2 ou Nitrate Ca 15%", "priorite": 1}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1488	FER-GEN-003	fertilisation	pH	Acidification sol — Correction chaulage urgence	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.0}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Toxicité aluminium"}, "alertes": [{"titre": "pH sol critique < 5.0", "niveau": "critique", "message": "pH < 5.0 : Al3+ et Mn2+ toxiques, P totalement bloqué, activité biologique stoppée."}], "recommandations": [{"dose": "2-3 t/ha", "type": "amendement_sol", "titre": "Chaulage urgence pH<5", "detail": "Apporter 2-3 mois avant plantation. Viser pH cible 6.0-6.5.", "produit": "Chaux agricole CaCO3 90%", "priorite": 1}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1489	FER-GEN-004	fertilisation	pH	Sol légèrement acide — Optimisation disponibilité nutriments	\N	null	null	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 5.0, "value2": 5.8}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Blocage phosphore"}, "alertes": [{"titre": "pH suboptimal 5.0-5.8", "niveau": "elevee", "message": "P assimilable réduit de 30-60%. Chaulage modéré recommandé."}], "recommandations": [{"dose": "1-1.5 t/ha selon tampon", "type": "amendement_sol", "titre": "Chaulage modéré", "produit": "Chaux agricole 90%", "priorite": 1}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1490	FER-GEN-005	fertilisation	matiere_organique	Matière organique très basse — Tous sols	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "MO critique"}, "alertes": [{"titre": "Matière organique sol critique", "niveau": "elevee", "message": "MO < 0.5% : sol peu tamponné, rétention eau réduite, minéralisation azote très faible."}], "recommandations": [{"dose": "10-20 t/ha", "type": "amendement_sol", "titre": "Fumier organique 10 t/ha", "detail": "Application annuelle pendant 3 ans pour remonter MO de 0.5 à 1.5%.", "produit": "Fumier décomposé ou compost", "priorite": 1}, {"type": "mesure_culturale", "titre": "Enfouir résidus de culture", "detail": "Ne pas bruler les pailles. Incorporation = +0.1-0.2% MO/an.", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1491	FER-GEN-006	fertilisation	salinite	Salinité sol élevée — Stress salin cultures maraîchères	\N	["niayes", "vallee_fleuve"]	null	null	{"clauses": [{"op": "gte", "field": "sol.conductivite", "value": 4.0}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Stress salin"}, "alertes": [{"titre": "Salinité sol critique EC>4", "niveau": "critique", "message": "EC > 4 dS/m : stress osmotique sévère. Tomate/oignon rendement chutera >50%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Lessivage salin en profondeur", "detail": "Irrigation excédentaire 1000 mm pour descendre EC < 2 dS/m. Drainage nécessaire.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Variétés tolérantes sel uniquement", "detail": "Orge, betterave, date tolèrent EC 6-8. Tomate limite EC < 2.5.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1492	FER-GEN-007	fertilisation	azote	Carence azote généralisée — Observation jaunissement	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "jaunissement"}, {"op": "lte", "field": "sol.azote", "value": 0.8}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote observée", "niveau": "elevee", "message": "Jaunissement des vieilles feuilles + N bas = carence azote. Apport d'urgence."}], "recommandations": [{"dose": "30-50 kg/ha selon culture", "type": "fertilisation", "titre": "Urée ou ammonitrate en couverture urgence", "produit": "Urée 46% N", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1493	FER-GEN-008	fertilisation	phosphore	Carence phosphore — Teintes pourpres feuilles	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "teinte_pourpre"}, {"op": "lte", "field": "sol.phosphore", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore — teintes anthocyanes", "niveau": "elevee", "message": "Teinte pourpre-violette face inférieure = phosphore bloqué (froid ou pH bas)."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "DAP ou TSP en couverture", "produit": "DAP 18-46-0", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1494	FER-GEN-009	fertilisation	potassium	Carence potassium — Bordures feuilles brunies	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "brulure_bordures"}, {"op": "lte", "field": "sol.potassium", "value": 0.15}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Carence K"}, "alertes": [{"titre": "Carence potassium — bordures foliaires", "niveau": "elevee", "message": "Brûlure marginale feuilles âgées = symptôme carence K classique. Fréquent sols sableux."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "KCl en couverture urgence", "produit": "KCl 60% K2O", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1495	FER-GEN-010	fertilisation	micronutriment	Carence zinc — Petites feuilles rosette	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "petites_feuilles"}, {"op": "gte", "field": "sol.pH", "value": 7.0}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Carence Zn"}, "alertes": [{"titre": "Carence zinc probable", "niveau": "elevee", "message": "Petites feuilles + entrenœuds courts = carence Zn. Fréquent sols calcaires."}], "recommandations": [{"dose": "0,5 kg/ha foliaire 2 fois", "type": "fertilisation", "titre": "Sulfate de zinc foliaire", "produit": "ZnSO4 22% Zn", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.682065+00	\N
1496	IRR-RIZ-001	irrigation	stress_hydrique	Riz — Stress hydrique tallage — irrigation urgente	\N	["vallee_fleuve"]	["tallage", "montaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Stress hydrique"}, "alertes": [{"titre": "Stress hydrique riz — tallage", "niveau": "elevee", "message": "Sol humidité <50% + ETP élevée : risque sévère si >3j sans eau."}], "recommandations": [{"dose": "50-60 mm", "type": "irrigation", "titre": "Irrigation submersion 5-8 cm", "detail": "Maintenir lame d'eau 5 cm au tallage. Critique pour nombre de talles.", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1497	IRR-RIZ-002	irrigation	engorgement	Riz — Excès eau — drainage nécessaire	\N	null	["levee", "tallage"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 60}, {"op": "gte", "field": "sol.humidite", "value": 95}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Asphyxie racinaire"}, "alertes": [{"titre": "Excès eau riz — drainage recommandé", "niveau": "moyenne", "message": "Submersion >15 cm à levée : asphyxie jeunes plants possible."}], "recommandations": [{"type": "drainage", "titre": "Ouvrir drain si lame >15 cm", "priorite": 1, "urgence_jours": 1}]}	moyenne	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1498	IRR-RIZ-003	irrigation	stress_hydrique	Riz — Stress épiaison-floraison critique	\N	null	["epiaison", "floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 60}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Stérilité épillets"}, "alertes": [{"titre": "Stress hydrique riz à épiaison — CRITIQUE", "niveau": "critique", "message": "Épiaison = stade le plus sensible. 3j de stress = 30-50% stérilité épillets."}], "recommandations": [{"dose": "60 mm", "type": "irrigation", "titre": "Irrigation immédiate — maintenir lame 5-8 cm", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1499	IRR-MIL-001	irrigation	stress_hydrique	Mil — Stress hydrique levée-tallage	\N	null	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 30}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Stress hydrique levée"}, "alertes": [{"titre": "Stress hydrique mil levée", "niveau": "elevee", "message": "Humidité sol <30% : levée irrégulière + mortalité plantules."}], "recommandations": [{"dose": "20 mm", "type": "irrigation", "titre": "Irrigation légère 20 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1500	IRR-MIL-002	irrigation	stress_hydrique	Mil — Stress floraison critique	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Avortement panicules"}, "alertes": [{"titre": "Stress hydrique mil floraison", "niveau": "critique", "message": "Floraison = stade le plus sensible mil. Stress → avortement panicules."}], "recommandations": [{"dose": "30 mm", "type": "irrigation", "titre": "Irrigation 30 mm d'urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1501	IRR-MAI-001	irrigation	stress_hydrique	Maïs — Stress hydrique floraison — pollinisation	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Avortement floraison maïs"}, "alertes": [{"titre": "Stress hydrique maïs floraison", "niveau": "critique", "message": "Stress à floraison = asynchronie fleurs + pollinisation ratée → épis vides."}], "recommandations": [{"dose": "40-50 mm", "type": "irrigation", "titre": "Irrigation 40-50 mm urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1502	IRR-MAI-002	irrigation	stress_hydrique	Maïs — Stress remplissage grains	\N	null	["remplissage_grains"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Grains petits"}, "alertes": [{"titre": "Stress hydrique maïs remplissage", "niveau": "elevee", "message": "Remplissage grains exige besoins max. Stress → grains petits + légers."}], "recommandations": [{"dose": "30-40 mm", "type": "irrigation", "titre": "Irrigation 30-40 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1503	IRR-ARA-001	irrigation	stress_hydrique	Arachide — Stress fructification-remplissage gousses	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Gousses vides"}, "alertes": [{"titre": "Stress hydrique arachide fructification", "niveau": "elevee", "message": "Sol sec à fructification : gousses vides + avortement gynophores."}], "recommandations": [{"dose": "25-30 mm", "type": "irrigation", "titre": "Irrigation 25-30 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1504	IRR-SOR-001	irrigation	stress_hydrique	Sorgho — Stress floraison-remplissage	\N	null	["floraison", "maturation"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 30}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Stress floraison"}, "alertes": [{"titre": "Stress hydrique sorgho floraison", "niveau": "elevee", "message": "Sorgho tolérant sécheresse mais stress floraison réduit rendement 20-40%."}], "recommandations": [{"dose": "20-25 mm", "type": "irrigation", "titre": "Irrigation d'appoint 20-25 mm", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1505	IRR-TOM-001	irrigation	stress_hydrique	Tomate — Stress hydrique floraison-nouaison	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Chute fleurs + BER"}, "alertes": [{"titre": "Stress hydrique tomate floraison", "niveau": "elevee", "message": "Stress à nouaison = chute fleurs + fruits mal formés (blossom end rot)."}], "recommandations": [{"dose": "30-40 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière — maintenir 70-80% RFU", "detail": "Éviter alternance sec/humide : aggrave BER.", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1506	IRR-TOM-002	irrigation	engorgement	Tomate — Excès eau — Phytophthora + Fusariose	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 90}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pathogènes sol engorgement"}, "alertes": [{"titre": "Engorgement tomate — risque pathogènes sol", "niveau": "elevee", "message": "Sol saturé : Phytophthora + Fusariose + pourriture collet en 48h."}], "recommandations": [{"type": "drainage", "titre": "Drainer immédiatement", "priorite": 1, "urgence_jours": 1}, {"dose": "1 kg/ha arrosage sol", "type": "traitement_phyto", "titre": "Métalaxyl préventif", "produit": "Métalaxyl 25WP", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1507	IRR-OIG-001	irrigation	stress_hydrique	Oignon — Stress bulbaison critique	\N	null	["bulbaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Bulbes petits"}, "alertes": [{"titre": "Stress hydrique oignon bulbaison", "niveau": "elevee", "message": "Stress à bulbaison = bulbes petits + doubles (ciboule). Besoin max 4-5 mm/j."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1508	IRR-OIG-002	irrigation	gestion	Oignon — Arrêt irrigation maturité	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 60}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Mauvaise conservation"}, "alertes": [{"titre": "Excès eau oignon maturité", "niveau": "moyenne", "message": "Irrigation/pluie à maturité : col épais, mauvaise conservation, Botrytis aggravé."}], "recommandations": [{"type": "gestion_eau", "titre": "ARRÊTER irrigation 4 semaines avant récolte", "detail": "Sol doit être sec 3-4 semaines avant arrachage.", "priorite": 1}]}	moyenne	7	0.78	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1509	IRR-CHO-001	irrigation	stress_hydrique	Chou — Stress hydrique pommaison	\N	null	["pommaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pommaison échouée"}, "alertes": [{"titre": "Stress hydrique chou pommaison", "niveau": "elevee", "message": "Stress à pommaison = pommes lâches + montée en graines précoce."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1510	IRR-PIM-001	irrigation	stress_hydrique	Piment — Stress hydrique floraison-fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Chute fleurs + BER"}, "alertes": [{"titre": "Stress hydrique piment", "niveau": "elevee", "message": "Piment très sensible stress : chute fleurs + brûlure collet fruits (BER)."}], "recommandations": [{"dose": "25-30 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière — éviter à-coups", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1511	IRR-CON-001	irrigation	stress_hydrique	Concombre — Stress fructification — fruits amers	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fruits amers"}, "alertes": [{"titre": "Stress hydrique concombre", "niveau": "elevee", "message": "Stress en fructification : fruits amers (cucurbitacine) + croissance tordue."}], "recommandations": [{"dose": "4-6 mm/j", "type": "irrigation", "titre": "Irrigation goutte-à-goutte régulière", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1512	IRR-PAS-001	irrigation	gestion	Pastèque — Réduction eau maturité	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Qualité réduite fruits"}, "alertes": [{"titre": "Excès eau pastèque maturité", "niveau": "moyenne", "message": "Trop d'eau à maturité : fruits aqueux, fade, éclatement, Anthracnose."}], "recommandations": [{"type": "gestion_eau", "titre": "Réduire irrigation 50% à 2 semaines avant récolte", "detail": "Stress léger augmente teneur sucre (°Brix) de 1-2 points.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1513	IRR-GOM-001	irrigation	stress_hydrique	Gombo — Stress hydrique fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Stress fructification"}, "alertes": [{"titre": "Stress hydrique gombo fructification", "niveau": "moyenne", "message": "Stress en fructification : capsules dures + arrêt production."}], "recommandations": [{"dose": "25 mm/semaine", "type": "irrigation", "titre": "Irrigation 3-4 mm/j goutte-à-goutte", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1514	IRR-MAG-001	irrigation	stress_hydrique	Mangue — Stress floraison-nouaison	\N	null	["floraison", "nouaison"]	[2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Chute fleurs mangue"}, "alertes": [{"titre": "Stress hydrique mangue floraison", "niveau": "elevee", "message": "Sécheresse + chaleur à floraison : chute fleurs et avortement jeunes fruits."}], "recommandations": [{"dose": "50-60 L/arbre", "type": "irrigation", "titre": "Irrigation localisée 50-60 L/arbre/semaine", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1515	IRR-MAG-002	irrigation	gestion	Mangue — Stress sec induit floraison	\N	null	null	[11, 12, 1]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "lte", "field": "meteo.temp_air", "value": 24}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Induction florale"}, "alertes": [{"titre": "Conditions induction florale mangue", "niveau": "moyenne", "message": "Nuits fraîches + sécheresse : conditions idéales induction florale. NE PAS irriguer."}], "recommandations": [{"type": "gestion_eau", "titre": "SUSPENDRE irrigation 6-8 semaines (induction florale)", "detail": "Stress sec volontaire déclenche floraison. Reprendre à apparition des panicules.", "priorite": 1}]}	faible	5	0.75	premium	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1516	IRR-BAN-001	irrigation	stress_hydrique	Banane — Stress hydrique croissance	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.etp", "value": 5}, {"op": "lte", "field": "sol.humidite", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Stress hydrique"}, "alertes": [{"titre": "Stress hydrique banane saison sèche", "niveau": "elevee", "message": "Banane exige 1500-2000 mm/an. Stress en saison sèche : régimes petits."}], "recommandations": [{"dose": "20-25 L/plant/jour", "type": "irrigation", "titre": "Irrigation goutte-à-goutte 20-25 L/plant/j", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1517	IRR-PAP-001	irrigation	gestion	Papaye — Engorgement sol collet mortel	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Mortalité Pythium"}, "alertes": [{"titre": "Engorgement sol papaye — MORTEL", "niveau": "critique", "message": "Papaye = 0 tolérance asphyxie racinaire. 48h engorgé = Pythium → mort."}], "recommandations": [{"type": "drainage", "titre": "Drainage d'urgence immédiat", "priorite": 1, "urgence_jours": 1}, {"dose": "2 g/L arrosage collet", "type": "traitement_phyto", "titre": "Métalaxyl préventif collet", "produit": "Métalaxyl 25WP", "priorite": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1518	IRR-ANA-001	irrigation	gestion	Anacarde — Irrigation jeunes plants saison sèche	\N	null	null	[12, 1, 2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "sol.humidite", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Mortalité jeunes plants"}, "alertes": [{"titre": "Stress hydrique anacarde saison sèche", "niveau": "moyenne", "message": "Jeunes plants (<3 ans) : mortalité si stress prolongé >3 semaines."}], "recommandations": [{"dose": "20-30 L/arbre/semaine", "type": "irrigation", "titre": "Arrosage hebdomadaire 20-30 L/arbre", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1519	IRR-NIE-001	irrigation	stress_hydrique	Niébé — Stress floraison-fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Avortement fleurs"}, "alertes": [{"titre": "Stress hydrique niébé floraison", "niveau": "elevee", "message": "Stress à floraison = chute fleurs + avortement gousses."}], "recommandations": [{"dose": "20-25 mm", "type": "irrigation", "titre": "Irrigation 20-25 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1520	IRR-SES-001	irrigation	gestion	Sésame — Excès eau collet levée	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Phytophtora engorgement"}, "alertes": [{"titre": "Excès eau sésame — Phytophthora", "niveau": "elevee", "message": "Sésame = 0 tolérance engorgement. Phytophtora actif sol saturé."}], "recommandations": [{"type": "drainage", "titre": "Drainage immédiat", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1521	IRR-MAN-001	irrigation	gestion	Manioc — Engorgement persistant pourriture racines	\N	null	["tuberisation", "maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pourriture racinaire"}, "alertes": [{"titre": "Engorgement sol manioc — pourriture", "niveau": "elevee", "message": "Sol engorgé en tubérisation : Phytophthora + bactéries pourrissant les racines."}], "recommandations": [{"type": "drainage", "titre": "Billonnage + drainage urgence", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Récolte anticipée >12 mois", "detail": "Manioc mûr en sol détrempé : récolter avant pourriture totale.", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1522	IRR-AUB-001	irrigation	stress_hydrique	Aubergine — Stress fructification qualité fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Qualité fruits dégradée"}, "alertes": [{"titre": "Stress hydrique aubergine fructification", "niveau": "moyenne", "message": "Stress = fruits petits, amers, pépins nombreux, couleur terne."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 2}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1523	IRR-ARA-002	irrigation	stress_hydrique	Stress hydrique arachide — Floraison gynophore	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "gte", "field": "meteo.etp", "value": 5.5}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Stress gynophore"}, "alertes": [{"titre": "Stress hydrique critique arachide floraison", "niveau": "critique", "message": "Gynophore en formation = phase la plus sensible. Manque d'eau = gousses vides. Irriguer immédiatement."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation urgence gynophore arachide", "detail": "Apporter 30-40 mm. Maintenir humidité sol à 60-80% capacité de rétention.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1524	IRR-ARA-003	irrigation	exces_eau	Excès eau arachide — Fructification sol saturé	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Pourriture gousses"}, "alertes": [{"titre": "Excès eau arachide fructification", "niveau": "elevee", "message": "Sol saturé pendant fructification = pourriture gousses + aflatoxines. Drainer."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence arachide", "detail": "Creuser rigoles de drainage. Arrêter toute irrigation. Prévoir récolte précoce si nécessaire.", "priorite": 1}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1525	IRR-SOR-002	irrigation	stress_hydrique	Stress hydrique sorgho — Epiaison floraison critique	\N	null	["epiaison", "floraison"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.temp_air", "value": 33}, {"op": "gte", "field": "meteo.etp", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Stérilité pollen"}, "alertes": [{"titre": "Stress hydrique sorgho épiaison", "niveau": "critique", "message": "Épiaison-floraison = fenêtre critique 10 jours. Stérilité du pollen si stress hydrique. Irriguer d'urgence."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation prioritaire sorgho épiaison", "detail": "20-25 mm immédiatement. Maintenir humidité sol >50% jusqu'à formation grains.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1526	IRR-SOR-003	irrigation	besoin_eau	Besoin eau sorgho — Tallage formation tiges	\N	null	["tallage", "montaison"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.etp", "value": 5.0}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Déficit tallage"}, "alertes": [{"titre": "Déficit hydrique sorgho tallage", "niveau": "elevee", "message": "Tallage insuffisant si manque d'eau : moins de tiges → moins d'épis → rendement réduit."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation sorgho tallage", "detail": "15-20 mm tous les 8-10 jours si pas de pluie.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1527	IRR-NIE-002	irrigation	stress_hydrique	Stress hydrique niébé — Floraison nouaison	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Avortement floral"}, "alertes": [{"titre": "Stress hydrique niébé floraison", "niveau": "critique", "message": "Manque d'eau à floraison : abscission florale. Perte rendement jusqu'à 80%. Irriguer si disponible."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation niébé floraison", "detail": "15-20 mm si possible. Niébé tolérant mais la floraison reste le point critique.", "priorite": 1, "urgence_jours": 2}]}	critique	9	0.85	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1528	IRR-NIE-003	irrigation	besoin_eau	Besoin eau niébé — Phase levée sèche	\N	null	["levee"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "lte", "field": "sol.humidite", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Levée irrégulière"}, "alertes": [{"titre": "Sol sec levée niébé", "niveau": "elevee", "message": "Sol trop sec à levée : germination irrégulière, manque à planter."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation légère levée niébé", "detail": "10 mm léger pour humidifier les 10 premiers cm. Ne pas inonder.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1529	IRR-SES-002	irrigation	exces_eau	Excès eau sésame — Engorgement mortel	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Engorgement mortel"}, "alertes": [{"titre": "Engorgement mortel sésame", "niveau": "critique", "message": "Sésame = culture la plus sensible à l'eau stagnante. 24h engorgé = Fusarium + Phytophtora fatal."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence sésame", "detail": "Drainer immédiatement. Éviter toute irrigation supplémentaire. Billonner si non fait.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1530	IRR-SES-003	irrigation	besoin_eau	Besoin eau sésame — Floraison capsules	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Avortement capsules"}, "alertes": [{"titre": "Déficit eau sésame floraison", "niveau": "elevee", "message": "Floraison = période de besoin modéré. Sec prolongé = avortement capsules."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation légère sésame floraison", "detail": "10-15 mm tous les 10 jours si pas de pluie. Ne pas mouiller le collet.", "priorite": 1}]}	elevee	7	0.7	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1531	IRR-MAN-002	irrigation	stress_hydrique	Stress hydrique manioc — Saison sèche prolongée	\N	null	["croissance_vegetative", "tuberisation"]	[11, 12, 1, 2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 33}, {"op": "gte", "field": "meteo.etp", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Stress saison sèche"}, "alertes": [{"titre": "Stress hydrique manioc saison sèche", "niveau": "elevee", "message": "Manioc tolérant mais prolonged drought > 3 mois = défoliation défensive + perte rendement 30%."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation d'appoint manioc", "detail": "20 mm/15 jours en saison sèche si possible. Couvre-sol mulch feuilles mortes.", "priorite": 1}]}	elevee	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1532	IRR-MAN-003	irrigation	exces_eau	Engorgement manioc — Pourriture racinaire saison pluies	\N	null	null	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 88}, {"op": "gte", "field": "meteo.pluie_7j", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Pourriture racinaire"}, "alertes": [{"titre": "Engorgement manioc saison pluies", "niveau": "elevee", "message": "Sol saturé > 2 semaines = Phytophtora drechsleri sur racines. Billonner et drainer."}], "recommandations": [{"type": "drainage", "titre": "Billonnage manioc en sol plat", "detail": "Créer billons 30 cm hauteur si sol plat. Décollage des eaux de surface.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1533	IRR-PIM-002	irrigation	stress_hydrique	Stress hydrique piment — Floraison avortement	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.temp_air", "value": 33}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Avortement fleurs + BER"}, "alertes": [{"titre": "Stress hydrique piment floraison", "niveau": "critique", "message": "Chaleur + sécheresse : avortement fleurs + BER fruits. Irriguer immédiatement."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière piment", "detail": "Goutte-à-goutte 15 mm/semaine. Éviter stress hydrique et réhumidification brutale (BER).", "priorite": 1, "urgence_jours": 1}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1534	IRR-PIM-003	irrigation	exces_eau	Engorgement piment — Phytophtora collet	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 82}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Phytophtora capsici"}, "alertes": [{"titre": "Excès eau piment", "niveau": "elevee", "message": "Sol saturé = Phytophthora capsici mortel sur collet piment. Drainage urgent."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence piment", "detail": "Drainer. Métalaxyl préventif sur sol si terrain concerné.", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1535	IRR-GOM-002	irrigation	stress_hydrique	Stress hydrique gombo — ETP élevée	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 6.5}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Stress ETP élevée"}, "alertes": [{"titre": "ETP élevée + sec = stress gombo", "niveau": "elevee", "message": "ETP > 6.5 mm/j avec peu de pluie : gombo stresse, capsules durcissent prématurément."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation gombo selon ETP", "detail": "Apporter 70% ETP = 4-5 mm/j. Fréquence tous les 3 jours en chaleur.", "priorite": 1}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
1536	IRR-GOM-003	irrigation	besoin_eau	Programme irrigation gombo — Cycle complet	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Besoin eau production"}, "alertes": [{"titre": "Apport eau régulier gombo requis", "niveau": "moyenne", "message": "Gombo à haute production nécessite 400-600 mm. Irrigation complémentaire requise."}], "recommandations": [{"type": "irrigation", "titre": "Programme irrigation gombo", "detail": "Levée: 1x/semaine. Végétation: 2x/semaine 15 mm. Floraison: 3x/semaine 10-15 mm.", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-10 16:30:57.891063+00	\N
\.


--
-- Data for Name: re_regles_cultures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles_cultures (id, regle_id, culture_id, notes) FROM stdin;
1471	1237	21	\N
1472	1238	21	\N
1473	1239	21	\N
1474	1240	21	\N
1475	1241	21	\N
1476	1242	21	\N
1477	1243	21	\N
1478	1244	24	\N
1479	1245	24	\N
1480	1246	24	\N
1481	1247	24	\N
1482	1248	24	\N
1483	1249	25	\N
1484	1250	25	\N
1485	1251	25	\N
1486	1252	25	\N
1487	1253	22	\N
1488	1254	22	\N
1489	1255	22	\N
1490	1256	22	\N
1491	1257	23	\N
1492	1258	23	\N
1493	1259	23	\N
1494	1260	23	\N
1495	1261	26	\N
1496	1262	26	\N
1497	1263	26	\N
1498	1264	26	\N
1499	1265	27	\N
1500	1266	27	\N
1501	1267	27	\N
1502	1268	27	\N
1503	1269	28	\N
1504	1270	28	\N
1505	1271	28	\N
1506	1272	28	\N
1507	1273	29	\N
1508	1274	29	\N
1509	1275	29	\N
1510	1276	29	\N
1511	1277	29	\N
1512	1278	29	\N
1513	1279	29	\N
1514	1280	31	\N
1515	1281	31	\N
1516	1282	31	\N
1517	1283	31	\N
1518	1284	33	\N
1519	1285	33	\N
1520	1286	33	\N
1521	1287	34	\N
1522	1288	34	\N
1523	1289	34	\N
1524	1290	30	\N
1525	1291	30	\N
1526	1292	30	\N
1527	1293	32	\N
1528	1294	32	\N
1529	1295	32	\N
1530	1296	35	\N
1531	1297	35	\N
1532	1298	35	\N
1533	1299	36	\N
1534	1300	36	\N
1535	1301	36	\N
1536	1302	37	\N
1537	1303	37	\N
1538	1304	37	\N
1539	1305	37	\N
1540	1306	38	\N
1541	1307	38	\N
1542	1308	38	\N
1543	1309	39	\N
1544	1310	39	\N
1545	1311	39	\N
1546	1312	40	\N
1547	1313	40	\N
1548	1314	40	\N
1549	1315	22	\N
1550	1316	22	\N
1551	1317	23	\N
1552	1318	23	\N
1553	1319	24	\N
1554	1320	25	\N
1555	1321	25	\N
1556	1322	32	\N
1557	1323	27	\N
1558	1324	27	\N
1559	1325	26	\N
1560	1326	26	\N
1561	1327	33	\N
1562	1328	33	\N
1563	1329	35	\N
1564	1330	35	\N
1565	1331	34	\N
1566	1332	34	\N
1567	1333	40	\N
1568	1334	40	\N
1569	1335	36	\N
1570	1336	36	\N
1571	1337	39	\N
1572	1338	39	\N
1573	1339	38	\N
1574	1340	28	\N
1575	1344	21	\N
1576	1345	21	\N
1577	1346	21	\N
1578	1347	21	\N
1579	1348	24	\N
1580	1349	24	\N
1581	1350	24	\N
1582	1351	25	\N
1583	1352	25	\N
1584	1353	25	\N
1585	1354	25	\N
1586	1355	22	\N
1587	1356	22	\N
1588	1357	22	\N
1589	1358	22	\N
1590	1359	23	\N
1591	1360	23	\N
1592	1361	23	\N
1593	1362	26	\N
1594	1363	26	\N
1595	1364	26	\N
1596	1365	26	\N
1597	1366	29	\N
1598	1367	29	\N
1599	1368	29	\N
1600	1369	29	\N
1601	1370	31	\N
1602	1371	31	\N
1603	1372	33	\N
1604	1373	34	\N
1605	1374	34	\N
1606	1375	30	\N
1607	1376	30	\N
1608	1377	32	\N
1609	1378	35	\N
1610	1379	28	\N
1611	1380	28	\N
1612	1381	27	\N
1613	1382	37	\N
1614	1383	37	\N
1615	1384	38	\N
1616	1385	39	\N
1617	1386	40	\N
1618	1387	36	\N
1619	1388	40	\N
1620	1389	38	\N
1621	1390	38	\N
1622	1391	38	\N
1623	1392	33	\N
1624	1393	33	\N
1625	1394	33	\N
1626	1395	39	\N
1627	1396	39	\N
1628	1397	39	\N
1629	1398	35	\N
1630	1399	35	\N
1631	1400	35	\N
1632	1401	32	\N
1633	1402	32	\N
1634	1403	32	\N
1635	1404	27	\N
1636	1405	27	\N
1637	1406	36	\N
1638	1407	36	\N
1639	1408	36	\N
1640	1409	23	\N
1641	1410	24	\N
1642	1410	25	\N
1643	1411	37	\N
1644	1412	34	\N
1645	1413	30	\N
1646	1414	31	\N
1647	1415	21	\N
1648	1416	28	\N
1649	1422	21	\N
1650	1423	21	\N
1651	1424	21	\N
1652	1425	21	\N
1653	1426	24	\N
1654	1427	24	\N
1655	1428	24	\N
1656	1429	25	\N
1657	1430	25	\N
1658	1431	22	\N
1659	1432	22	\N
1660	1433	22	\N
1661	1434	23	\N
1662	1435	23	\N
1663	1436	26	\N
1664	1437	26	\N
1665	1438	27	\N
1666	1439	28	\N
1667	1440	28	\N
1668	1441	29	\N
1669	1442	29	\N
1670	1443	29	\N
1671	1444	29	\N
1672	1445	31	\N
1673	1446	33	\N
1674	1447	34	\N
1675	1448	34	\N
1676	1449	30	\N
1677	1450	30	\N
1678	1451	37	\N
1679	1452	38	\N
1680	1453	32	\N
1681	1454	35	\N
1682	1455	36	\N
1683	1456	39	\N
1684	1457	40	\N
1685	1458	29	\N
1686	1458	31	\N
1687	1458	33	\N
1688	1458	34	\N
1689	1458	30	\N
1690	1459	21	\N
1691	1459	22	\N
1692	1459	24	\N
1693	1459	25	\N
1694	1459	23	\N
1695	1460	27	\N
1696	1461	27	\N
1697	1462	27	\N
1698	1463	32	\N
1699	1464	32	\N
1700	1465	32	\N
1701	1466	35	\N
1702	1467	35	\N
1703	1468	35	\N
1704	1469	40	\N
1705	1470	40	\N
1706	1471	40	\N
1707	1472	37	\N
1708	1473	37	\N
1709	1474	37	\N
1710	1475	38	\N
1711	1476	38	\N
1712	1477	38	\N
1713	1478	39	\N
1714	1479	39	\N
1715	1480	39	\N
1716	1481	36	\N
1717	1482	36	\N
1718	1483	36	\N
1719	1484	26	\N
1720	1485	28	\N
1721	1486	31	\N
1722	1487	31	\N
1723	1496	21	\N
1724	1497	21	\N
1725	1498	21	\N
1726	1499	24	\N
1727	1500	24	\N
1728	1501	22	\N
1729	1502	22	\N
1730	1503	23	\N
1731	1504	25	\N
1732	1505	29	\N
1733	1506	29	\N
1734	1507	30	\N
1735	1508	30	\N
1736	1509	34	\N
1737	1510	31	\N
1738	1511	35	\N
1739	1512	36	\N
1740	1513	32	\N
1741	1514	37	\N
1742	1515	37	\N
1743	1516	39	\N
1744	1517	40	\N
1745	1518	38	\N
1746	1519	26	\N
1747	1520	27	\N
1748	1521	28	\N
1749	1522	33	\N
1750	1523	23	\N
1751	1524	23	\N
1752	1525	25	\N
1753	1526	25	\N
1754	1527	26	\N
1755	1528	26	\N
1756	1529	27	\N
1757	1530	27	\N
1758	1531	28	\N
1759	1532	28	\N
1760	1533	31	\N
1761	1534	31	\N
1762	1535	32	\N
1763	1536	32	\N
1764	1537	33	\N
1765	1538	33	\N
1766	1539	34	\N
1767	1540	34	\N
1768	1541	35	\N
1769	1542	35	\N
1770	1543	40	\N
1771	1544	40	\N
1772	1545	38	\N
1773	1546	38	\N
1774	1547	39	\N
1775	1548	39	\N
1776	1549	36	\N
1777	1550	36	\N
1778	1556	29	\N
1779	1556	31	\N
1780	1556	33	\N
1781	1556	32	\N
1782	1556	35	\N
1783	1557	21	\N
1784	1557	22	\N
1785	1557	24	\N
1786	1557	25	\N
1787	1558	29	\N
1788	1558	31	\N
1789	1558	34	\N
1790	1558	30	\N
1791	1558	36	\N
1792	1559	24	\N
1793	1559	25	\N
1794	1559	23	\N
1795	1559	26	\N
1796	1559	22	\N
1797	1560	37	\N
1798	1560	38	\N
1799	1560	39	\N
1800	1560	40	\N
1801	1561	28	\N
1802	1561	27	\N
1803	1561	23	\N
1804	1562	29	\N
1805	1562	31	\N
1806	1562	33	\N
1807	1562	40	\N
1808	1562	27	\N
1809	1563	21	\N
1810	1563	22	\N
1811	1563	29	\N
1812	1563	31	\N
1813	1563	33	\N
1814	1563	34	\N
1815	1564	29	\N
1816	1564	22	\N
1817	1564	30	\N
1818	1564	31	\N
1819	1564	34	\N
1820	1565	22	\N
1821	1565	25	\N
1822	1565	24	\N
1823	1566	37	\N
1824	1566	38	\N
1825	1566	39	\N
1826	1566	40	\N
1827	1567	29	\N
1828	1567	31	\N
1829	1567	30	\N
1830	1567	34	\N
1831	1567	32	\N
1832	1568	29	\N
1833	1568	31	\N
1834	1568	33	\N
1835	1568	40	\N
1836	1568	35	\N
1837	1569	29	\N
1838	1569	34	\N
1839	1569	30	\N
1840	1569	31	\N
1841	1570	21	\N
1842	1570	22	\N
1843	1570	29	\N
1844	1570	31	\N
1845	1570	34	\N
1846	1570	35	\N
1847	1570	36	\N
1848	1571	29	\N
1849	1571	31	\N
1850	1571	33	\N
1851	1571	28	\N
1852	1571	40	\N
1853	1571	36	\N
1854	1572	29	\N
1855	1572	22	\N
1856	1572	30	\N
1857	1572	21	\N
1858	1572	31	\N
1859	1572	34	\N
1860	1573	24	\N
1861	1573	25	\N
1862	1573	26	\N
1863	1573	23	\N
1864	1573	27	\N
1865	1574	24	\N
1866	1574	25	\N
1867	1574	22	\N
1868	1574	26	\N
1869	1574	23	\N
1870	1574	27	\N
1871	1575	29	\N
1872	1575	31	\N
1873	1575	33	\N
1874	1576	21	\N
1875	1577	22	\N
1876	1578	21	\N
1877	1578	22	\N
1878	1578	25	\N
1879	1578	24	\N
1880	1580	29	\N
1881	1580	30	\N
1882	1580	34	\N
1883	1580	35	\N
1884	1582	29	\N
1885	1582	33	\N
1886	1582	31	\N
1887	1582	35	\N
1888	1582	40	\N
1889	1583	21	\N
1890	1585	23	\N
1891	1585	22	\N
1892	1585	29	\N
1893	1585	30	\N
1894	1589	29	\N
1895	1589	30	\N
1896	1590	30	\N
1897	1591	23	\N
1898	1592	21	\N
1899	1593	38	\N
1900	1594	37	\N
1901	1595	28	\N
1902	1596	23	\N
1903	1598	21	\N
1904	1599	21	\N
1905	1600	24	\N
1906	1601	24	\N
1907	1602	25	\N
1908	1603	22	\N
1909	1604	22	\N
1910	1605	23	\N
1911	1606	23	\N
1912	1607	29	\N
1913	1608	29	\N
1914	1609	29	\N
1915	1610	30	\N
1916	1611	30	\N
1917	1612	34	\N
1918	1613	31	\N
1919	1614	35	\N
1920	1615	36	\N
1921	1616	32	\N
1922	1617	37	\N
1923	1618	37	\N
1924	1619	38	\N
1925	1620	39	\N
1926	1621	40	\N
1927	1622	28	\N
1928	1623	26	\N
1929	1624	26	\N
1930	1625	27	\N
1931	1626	23	\N
1932	1627	23	\N
1933	1628	25	\N
1934	1629	25	\N
1935	1630	26	\N
1936	1631	26	\N
1937	1632	27	\N
1938	1633	27	\N
1939	1634	32	\N
1940	1635	34	\N
1941	1636	34	\N
1942	1637	35	\N
1943	1638	40	\N
1944	1639	40	\N
1945	1640	36	\N
1946	1641	36	\N
1947	1642	38	\N
1948	1643	38	\N
1949	1644	39	\N
1950	1645	39	\N
1951	1646	37	\N
1952	1647	37	\N
1953	1648	21	\N
1954	1649	21	\N
1955	1650	22	\N
1956	1651	22	\N
1957	1655	21	\N
1958	1656	21	\N
1959	1657	22	\N
1960	1658	24	\N
1961	1659	23	\N
1962	1660	25	\N
1963	1661	26	\N
1964	1662	29	\N
1965	1663	30	\N
1966	1664	31	\N
1967	1665	37	\N
1968	1666	38	\N
1969	1667	39	\N
1970	1668	40	\N
1971	1669	28	\N
1972	1670	27	\N
1973	1671	29	\N
1974	1671	22	\N
1975	1671	21	\N
1976	1671	30	\N
1977	1672	24	\N
1978	1672	25	\N
1979	1672	23	\N
1980	1672	26	\N
1981	1672	22	\N
1982	1673	23	\N
1983	1674	23	\N
1984	1675	25	\N
1985	1676	25	\N
1986	1677	26	\N
1987	1678	26	\N
1988	1679	27	\N
1989	1680	27	\N
1990	1681	28	\N
1991	1682	28	\N
1992	1683	32	\N
1993	1684	31	\N
1994	1685	31	\N
1995	1686	38	\N
1996	1687	38	\N
1997	1688	39	\N
1998	1689	39	\N
1999	1690	36	\N
2000	1691	37	\N
2001	1692	37	\N
2002	1693	21	\N
2003	1694	21	\N
2004	1695	22	\N
2005	1696	22	\N
2006	1697	24	\N
2007	1698	24	\N
2008	1712	29	\N
2009	1712	33	\N
2010	1712	32	\N
2011	1712	30	\N
2012	1712	31	\N
2013	1713	24	\N
2014	1713	25	\N
2015	1713	21	\N
2016	1713	22	\N
2017	1714	22	\N
2018	1714	25	\N
2019	1714	24	\N
2020	1714	23	\N
2021	1714	28	\N
2022	1715	22	\N
2023	1715	25	\N
2024	1715	24	\N
2025	1715	23	\N
2026	1715	26	\N
2027	1717	29	\N
2028	1717	35	\N
2029	1717	31	\N
2030	1717	33	\N
2031	1717	32	\N
2032	1727	22	\N
2033	1727	21	\N
2034	1727	25	\N
2035	1727	24	\N
\.


--
-- Data for Name: re_regles_entites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles_entites (id, regle_id, entite_type, entite_id) FROM stdin;
448	1237	maladie	66
449	1238	maladie	66
450	1239	maladie	68
451	1240	maladie	68
452	1241	maladie	67
453	1242	maladie	70
454	1243	maladie	69
455	1244	maladie	79
456	1245	maladie	79
457	1246	maladie	81
458	1247	maladie	80
459	1248	maladie	82
460	1249	maladie	83
461	1250	maladie	83
462	1251	maladie	85
463	1252	maladie	86
464	1253	maladie	72
465	1254	maladie	73
466	1255	maladie	71
467	1256	maladie	74
468	1257	maladie	75
469	1258	maladie	75
470	1259	maladie	76
471	1260	maladie	78
472	1261	maladie	89
473	1262	maladie	90
474	1263	maladie	87
475	1264	maladie	88
476	1265	maladie	91
477	1266	maladie	91
478	1267	maladie	93
479	1268	maladie	92
480	1269	maladie	94
481	1270	maladie	95
482	1271	maladie	96
483	1272	maladie	97
484	1273	maladie	98
485	1274	maladie	98
486	1275	maladie	99
487	1276	maladie	102
488	1277	maladie	102
489	1278	maladie	100
490	1279	maladie	101
491	1280	maladie	106
492	1281	maladie	102
493	1282	maladie	107
494	1283	maladie	108
495	1284	maladie	112
496	1285	maladie	102
497	1286	maladie	99
498	1287	maladie	115
499	1288	maladie	113
500	1289	maladie	114
501	1290	maladie	103
502	1291	maladie	104
503	1292	maladie	105
504	1293	maladie	110
505	1294	maladie	109
506	1295	maladie	111
507	1296	maladie	116
508	1297	maladie	117
509	1298	maladie	118
510	1299	maladie	119
511	1300	maladie	116
512	1301	maladie	118
513	1302	maladie	120
514	1303	maladie	121
515	1304	maladie	123
516	1305	maladie	122
517	1306	maladie	124
518	1307	maladie	125
519	1308	maladie	123
520	1309	maladie	127
521	1310	maladie	126
522	1311	maladie	128
523	1312	maladie	129
524	1313	maladie	131
525	1314	maladie	130
526	1344	ravageur	54
527	1345	ravageur	54
528	1346	ravageur	56
529	1347	ravageur	55
530	1348	ravageur	65
531	1349	ravageur	64
532	1350	ravageur	55
533	1351	ravageur	68
534	1352	ravageur	66
535	1353	ravageur	69
536	1354	ravageur	67
537	1355	ravageur	58
538	1356	ravageur	58
539	1357	ravageur	59
540	1358	ravageur	60
541	1359	ravageur	61
542	1360	ravageur	62
543	1361	ravageur	63
544	1362	ravageur	69
545	1363	ravageur	72
546	1364	ravageur	71
547	1365	ravageur	70
548	1366	ravageur	79
549	1367	ravageur	79
550	1368	ravageur	69
551	1369	ravageur	80
552	1370	ravageur	75
553	1371	ravageur	84
554	1372	ravageur	88
555	1373	ravageur	89
556	1374	ravageur	90
557	1375	ravageur	81
558	1376	ravageur	82
559	1377	ravageur	86
560	1378	ravageur	91
561	1379	ravageur	78
562	1380	ravageur	77
563	1381	ravageur	75
564	1382	ravageur	92
565	1383	ravageur	94
566	1384	ravageur	95
567	1385	ravageur	97
568	1386	ravageur	99
569	1387	ravageur	91
570	1388	ravageur	75
\.


--
-- Data for Name: re_sessions_evaluation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_sessions_evaluation (id, org_id, parcelle_id, contexte, regles_evaluees, regles_declenchees, duree_ms, created_at) FROM stdin;
\.


--
-- Data for Name: sc_analyse_economique; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_analyse_economique (id, analyse_id, superficie_ha, rendement_actuel_estime_t_ha, rendement_potentiel_t_ha, perte_volume_t_ha, prix_marche_fcfa_kg, perte_potentielle_fcfa_ha, cout_correction_estime_fcfa_ha, gain_potentiel_fcfa_ha, roi_estime, created_at) FROM stdin;
\.


--
-- Data for Name: sc_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_analyses (id, parcelle_id, culture_id, org_id, statut, analyse_le, duree_ms, erreur_message, niveau_donnees, score_sante, score_vigueur, score_hydrique, score_fertilite, score_maladie, score_ravageur, etat_general, contexte_entree, resultat) FROM stdin;
\.


--
-- Data for Name: sc_cartes_precision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_cartes_precision (id, analyse_id, parcelle_id, type_carte, donnees, resolution_m, nb_cellules, created_at) FROM stdin;
\.


--
-- Data for Name: sc_consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_consultations (id, org_id, parcelle_id, culture_id, type, statut, contexte, resume, nb_photos, created_by, created_at, updated_at) FROM stdin;
4	1	\N	21	MALADIE	EN_COURS	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	\N	0	1	2026-06-09 17:49:31.454173	2026-06-09 17:49:31.454176
6	1	\N	22	FERTILISATION	EN_COURS	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	\N	0	1	2026-06-09 17:49:31.490661	2026-06-09 17:49:31.490665
5	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	\N	0	1	2026-06-09 17:49:31.47411	2026-06-09 17:49:31.922331
7	1	\N	21	MALADIE	EN_COURS	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	\N	0	1	2026-06-09 17:51:10.692098	2026-06-09 17:51:10.692101
9	1	\N	22	FERTILISATION	EN_COURS	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	\N	0	1	2026-06-09 17:51:10.717263	2026-06-09 17:51:10.717265
8	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	\N	0	1	2026-06-09 17:51:10.706094	2026-06-09 17:51:11.132809
10	1	\N	21	MALADIE	ANALYSE	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	Aucun diagnostic établi. Ajouter des observations pour affiner l'analyse.	0	1	2026-06-09 18:16:40.654335	2026-06-09 18:16:41.344
12	1	\N	22	FERTILISATION	ANALYSE	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	Carence probable : Carence Azote (N) (confiance 50%). Suivre le plan de correction fertilisation.	0	1	2026-06-09 18:16:41.109731	2026-06-09 18:16:41.535401
11	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	Ravageur probable : Foreur de tige du riz (confiance 30%). Appliquer les mesures de lutte recommandées.	0	1	2026-06-09 18:16:40.890043	2026-06-09 18:16:41.707428
13	3	5	21	MALADIE	ANALYSE	{"culture_id": 21, "stade_actuel": "tallage"}	Aucun diagnostic établi. Ajouter des observations pour affiner l'analyse.	0	3	2026-06-10 05:43:55.32884	2026-06-10 05:44:54.72793
14	5	6	40	MALADIE	EN_COURS	{"culture_id": 40, "stade_actuel": "floraison"}	\N	0	4	2026-06-10 06:13:59.121661	2026-06-10 06:13:59.121665
15	4	7	30	RAVAGEUR	EN_COURS	{"culture_id": 30, "stade_actuel": "bulbaison"}	\N	0	5	2026-06-10 06:13:59.335383	2026-06-10 06:13:59.335387
16	6	8	22	MALADIE	EN_COURS	{"culture_id": 22, "stade_actuel": "levee"}	\N	0	6	2026-06-10 06:13:59.520994	2026-06-10 06:13:59.520997
17	1	\N	\N	MALADIE	EN_COURS	{}	\N	0	1	2026-06-10 11:58:31.587105	2026-06-10 11:58:31.587109
18	5	11	\N	MALADIE	ANALYSE	{"mois": 6, "stade_actuel": "floraison"}	Aucun diagnostic établi. Ajouter des observations pour affiner l'analyse.	0	4	2026-06-10 13:12:48.382633	2026-06-10 13:12:48.492878
19	5	12	\N	MALADIE	EN_COURS	{}	\N	1	4	2026-06-10 13:16:45.698661	2026-06-10 13:16:45.720118
20	4	13	29	MALADIE	CONFIRME	{"mois": 6, "culture_id": 29}	Maladie probable : Mildiou de la tomate (confiance 40%). Consultez le plan de traitement et surveillez l'évolution.	1	5	2026-06-10 13:49:23.868629	2026-06-10 13:49:24.067457
21	4	14	29	MALADIE	CONFIRME	{"mois": 6, "culture_id": 29}	Maladie probable : Mildiou de la tomate (confiance 40%). Consultez le plan de traitement et surveillez l'évolution.	1	5	2026-06-10 13:57:21.062779	2026-06-10 13:57:21.230268
\.


--
-- Data for Name: sc_diagnostics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_diagnostics (id, consultation_id, rang, entite_type, entite_id, entite_nom, score_confiance, score_rules, score_symptomes, regles_matches, methode, statut, confirme_par, confirme_le, note_expert, created_at) FROM stdin;
1	11	1	RAVAGEUR	54	Foreur de tige du riz	0.3	0	1	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.400991
2	12	1	CARENCE	0	Carence Azote (N)	0.5	0	0.5	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507211
3	12	2	CARENCE	0	Carence Phosphore (P)	0.467	0	0.467	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507216
4	12	3	CARENCE	0	Acidité/Alcalinité sol	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507217
5	12	4	CARENCE	0	Carence Potassium (K)	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507218
6	12	5	CARENCE	0	Faible matière organique	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507225
8	20	2	MALADIE	99	Alternariose	0.4	0	1	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-10 13:49:23.980273
7	20	1	MALADIE	98	Mildiou de la tomate	0.4	0	1	[]	SYMPTOMES	CONFIRME	5	2026-06-10 13:49:24.066546	\N	2026-06-10 13:49:23.980269
10	21	2	MALADIE	99	Alternariose	0.4	0	1	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-10 13:57:21.157096
9	21	1	MALADIE	98	Mildiou de la tomate	0.4	0	1	[]	SYMPTOMES	CONFIRME	5	2026-06-10 13:57:21.22963	\N	2026-06-10 13:57:21.157091
\.


--
-- Data for Name: sc_indices_satellitaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_indices_satellitaires (id, parcelle_id, analyse_id, date_image, date_calcul, satellite, ndvi, ndre, savi, evi, msavi, ndwi, couverture_nuages, ndvi_label, ndre_label, savi_label, evi_label, msavi_label, ndwi_label, sentinelhub_request_id, bbox, expire_le) FROM stdin;
\.


--
-- Data for Name: sc_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_observations (id, consultation_id, type, partie_plante, valeur, note_terrain, created_at) FROM stdin;
1	4	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 17:49:31.565557
2	4	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 17:49:31.59924
3	4	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 17:49:31.618639
4	5	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 17:49:31.635743
5	6	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 17:49:31.74255
6	7	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 17:51:10.757838
7	7	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 17:51:10.77567
8	7	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 17:51:10.798524
9	8	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 17:51:10.816639
10	9	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 17:51:10.916168
11	10	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 18:16:41.190088
12	10	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 18:16:41.227989
13	10	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 18:16:41.248872
14	11	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 18:16:41.26791
15	12	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 18:16:41.458126
16	13	SYMPTOME	FEUILLE	{"densite": "moderee", "description": "Taches brunes elliptiques avec halo jaune, caractéristiques pyriculariose", "localisation": "Tiers supérieur feuilles, bordure parcelle", "surface_touchee_pct": 20}	\N	2026-06-10 05:44:43.899326
17	14	SYMPTOME	FEUILLE	{"densite": "elevee", "description": "Taches chlorotiques jaune-vert sur feuilles, debut extrémités, typique PRSV (virus de la tachure annulaire papaye)", "localisation": "Toutes feuilles adultes, progression ascendante", "surface_touchee_pct": 35}	\N	2026-06-10 06:13:59.259005
18	15	RAVAGEUR_OBSERVE	FEUILLE	{"nom": "Thrips de loignon (Thrips tabaci)", "stade": "larves et adultes", "densite": "forte", "description": "Nombreuses thrips sur feuilles tubulaires, degats mecaniques et transmission virus"}	\N	2026-06-10 06:13:59.461568
19	16	SYMPTOME	RACINE	{"densite": "moderee", "description": "Racinelles brunes et nécrosées, collet mou, plants versent facilement. Typique Pythium ou Fusarium.", "localisation": "Zones basses parcelle, sol plus humide", "surface_touchee_pct": 15}	\N	2026-06-10 06:13:59.637996
20	18	SYMPTOME	FEUILLE	{"code": "taches_foliaires", "intensite": 6}	Taches jaunâtres sur feuilles de papaye	2026-06-10 13:12:48.410055
21	20	SYMPTOME	\N	{"code": "taches", "intensite": "moderee", "description": "Taches brunes sur feuilles inférieures", "localisation": "feuilles"}	\N	2026-06-10 13:49:23.896518
22	21	SYMPTOME	\N	{"code": "taches", "intensite": "moderee", "description": "Taches brunes sur feuilles inférieures", "localisation": "feuilles"}	\N	2026-06-10 13:57:21.080834
\.


--
-- Data for Name: sc_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_photos (id, consultation_id, observation_id, source_photo, filename, url, thumbnail_url, taille_ko, photo_meta, uploaded_at) FROM stdin;
1	19	\N	SMARTPHONE	0b2b56e12b4546449c18447da7255d1c.jpg	/uploads/maladies/0b2b56e12b4546449c18447da7255d1c.jpg	\N	0	{"taille_b": 212, "mime_type": "image/jpeg", "hash_sha256": "91760bfb6ceca43238b19c56b0b63e4be40b89bb81bcbce5021e33e79f2919e9", "original_name": "test.jpg"}	2026-06-10 13:16:45.721368
2	20	\N	SMARTPHONE	332e2b9ab6904bf4a9e44a92639e6d75.png	/uploads/maladies/332e2b9ab6904bf4a9e44a92639e6d75.png	\N	0	{"taille_b": 67, "mime_type": "image/png", "hash_sha256": "08d2521273459ce20781173ac9cbf8f162880a70420b236ab5641a795bb02b54", "original_name": "test_tache.png"}	2026-06-10 13:49:23.931263
3	21	\N	SMARTPHONE	5d557154ab914bd8b9aa555113db6421.png	/uploads/maladies/5d557154ab914bd8b9aa555113db6421.png	\N	0	{"taille_b": 67, "mime_type": "image/png", "hash_sha256": "08d2521273459ce20781173ac9cbf8f162880a70420b236ab5641a795bb02b54", "original_name": "test_tache.png"}	2026-06-10 13:57:21.104638
\.


--
-- Data for Name: sc_previsions_rendement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_previsions_rendement (id, analyse_id, culture_id, rendement_estime, rendement_potentiel, ecart_performance, facteurs_limitants, confiance, methode, created_at) FROM stdin;
\.


--
-- Data for Name: sc_rapports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_rapports (id, consultation_id, org_id, type, titre, url, taille_ko, genere_par, genere_le, telechargements) FROM stdin;
\.


--
-- Data for Name: sc_suivis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_suivis (id, consultation_id, date_suivi, evolution, efficacite, note, photo_url, created_at) FROM stdin;
1	4	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 17:49:31.854882
2	7	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 17:51:11.037515
3	10	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 18:16:41.623724
\.


--
-- Data for Name: sc_traitements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_traitements (id, consultation_id, diagnostic_id, priorite, type, titre, produit, dose, frequence, delai_carence_jours, urgence_jours, detail, date_application, statut, applique_le, note) FROM stdin;
1	11	1	1	SURVEILLANCE	Surveiller évolution : Foreur de tige du riz	\N	\N	\N	\N	7	Diagnostic probable : Foreur de tige du riz (confiance 30%). Prendre photo et contacter technicien si aggravation.	2026-06-16	PLANIFIE	\N	\N
2	12	2	1	SURVEILLANCE	Surveiller évolution : Carence Azote (N)	\N	\N	\N	\N	7	Diagnostic probable : Carence Azote (N) (confiance 50%). Prendre photo et contacter technicien si aggravation.	2026-06-16	PLANIFIE	\N	\N
3	20	7	1	SURVEILLANCE	Surveiller évolution : Mildiou de la tomate	\N	\N	\N	\N	7	Diagnostic probable : Mildiou de la tomate (confiance 40%). Prendre photo et contacter technicien si aggravation.	2026-06-17	PLANIFIE	\N	\N
4	21	9	1	SURVEILLANCE	Surveiller évolution : Mildiou de la tomate	\N	\N	\N	\N	7	Diagnostic probable : Mildiou de la tomate (confiance 40%). Prendre photo et contacter technicien si aggravation.	2026-06-17	PLANIFIE	\N	\N
\.


--
-- Data for Name: service_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_requests (id, user_id, service_id, farm_id, statut, credits_debites, entree, resultat, erreur, cree_le, demarre_le, termine_le) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, code, nom, cout_credits, actif, cree_le) FROM stdin;
1	weather	Alertes meteo	0	t	2026-06-03 11:45:06.691033+00
2	area	Calcul de superficie	10	t	2026-06-03 11:45:06.691033+00
3	soil	Analyse de sol	10	t	2026-06-03 11:45:06.691033+00
4	ndvi	Suivi NDVI / NDRE	10	t	2026-06-03 11:45:06.691033+00
5	yield	Prevision de rendement	10	t	2026-06-03 11:45:06.691033+00
6	irrigation	Irrigation intelligente	10	t	2026-06-03 11:45:06.691033+00
7	disease	Detection de maladies	10	t	2026-06-03 11:45:06.691033+00
8	mapping	Cartographie de parcelle	10	t	2026-06-03 11:45:06.691033+00
9	farm_mgmt	Gestion d'exploitation	10	t	2026-06-03 11:45:06.691033+00
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, org_id, plan, status, started_at, current_period_end, seats, auto_renew) FROM stdin;
1	1	PREMIUM	PAST_DUE	2026-05-31 17:07:05.826261	2026-07-09 15:43:44.0149	1	f
2	2	GRATUIT	ACTIVE	2026-06-09 20:10:06.037836	\N	1	f
3	3	GRATUIT	ACTIVE	2026-06-10 05:40:50.371054	\N	1	f
7	7	GRATUIT	ACTIVE	2026-06-10 11:52:11.399836	\N	1	f
8	8	GRATUIT	ACTIVE	2026-06-10 11:52:37.508756	\N	1	f
4	5	PREMIUM	ACTIVE	2026-06-10 06:09:04.129887	\N	1	f
5	4	PREMIUM	ACTIVE	2026-06-10 06:09:04.131256	\N	1	f
6	6	PREMIUM	ACTIVE	2026-06-10 06:09:04.140443	\N	1	f
9	9	GRATUIT	ACTIVE	2026-06-11 01:29:40.591032	\N	1	f
\.


--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_counters (id, org_id, period, analyses_count) FROM stdin;
1	1	2026-05	1
2	1	2026-06	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, org_id, full_name, email, phone, hashed_password, role, is_active, created_at, account_type, profil) FROM stdin;
1	1	Khadim thiam	thiamkhadim304@gmail.com	784919011	$2b$12$8MqOI1WSkfm6MxaV034y5uhfpMaOim3PXN3cVvDwgKEKBgQ.zBGSW	OWNER	t	2026-05-31 17:07:05.817406	particulier	producteur
2	2	Test User	test@agroscan.sn	\N	$2b$12$9ZmItraEGBrO0VYVs0KRSOhvUSFuJtOJXU8ElKkER91VCd6IV9d5C	OWNER	t	2026-06-09 20:10:06.03008	particulier	producteur
3	3	Mamadou Diallo	producteur.demo@agroscanpro.com	+221 77 123 45 67	$2b$12$uzINUFVyZ1n4HRpyrSzsSuUISbQ/DCpBQh7.FxF3IywFrd/He36iC	OWNER	t	2026-06-10 05:40:50.361848	particulier	producteur
4	5	Ibrahima Diallo	ibrahima.kedougou@agroscanpro.com	+221 77 201 33 44	$2b$12$k9vJCNwQhd6/DhjqvgghqeyH7ISnxOAo5odyt2ie2QvAqNzci4Sr6	OWNER	t	2026-06-10 06:09:04.102932	particulier	producteur
6	6	Fatou Ndiaye	fatou.tamba@agroscanpro.com	+221 76 345 67 89	$2b$12$DcPuCFIqZU/X3fB5Rwg8ouidGOrVI/80bvwXQ.cxNK.NoaJkNlySW	OWNER	t	2026-06-10 06:09:04.114661	particulier	producteur
7	7	Test Producteur Phase0	test.prod.phase0@gmail.com	\N	$2b$12$uwxRDVkIxBkuYdsu1gQD1.0MUgyHqd9tmL27NVq1/i3xvHsSu6qMm	OWNER	t	2026-06-10 11:52:11.388606	particulier	producteur
8	8	Test Conseiller Phase0	test.cons.phase0@gmail.com	\N	$2b$12$zl7JnpiNaBlOhRPU1/EnwuRBfUwATFSt../LI7aQCE7KJ2WaUxKxe	OWNER	t	2026-06-10 11:52:37.504428	particulier	conseiller
5	4	Moussa Sarr	moussa.saintlouis@agroscanpro.com	+221 70 456 78 90	$2b$12$ayCtv9EBYvMXlSMnPiHqnuzrIz1TCsUDqHoecfxBaIyFjuVbiMl6m	OWNER	t	2026-06-10 06:09:04.106834	particulier	producteur
9	9	Mohira Charles	charlesmohira@gmail.com	+509 44939240	$2b$12$bT6b3rYxuNlERkVm4hOt4uXZK8BfICAM4wBrwRu2nfB/zn9BGrPl.	OWNER	t	2026-06-11 01:29:40.577831	particulier	producteur
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallets (user_id, solde, maj_le) FROM stdin;
1	30	2026-06-03 16:40:49.739664+00
2	30	2026-06-10 05:30:50.575811+00
3	30	2026-06-10 05:54:09.234435+00
\.


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_besoins_eau_id_seq', 184, true);


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_besoins_nutritionnels_id_seq', 120, true);


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_calendriers_culturaux_id_seq', 136, true);


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_culture_maladies_id_seq', 138, true);


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_culture_ravageurs_id_seq', 122, true);


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_cultures_id_seq', 40, true);


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_maladies_id_seq', 131, true);


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_parametres_climatiques_id_seq', 40, true);


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_ravageurs_id_seq', 100, true);


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_recommandations_id_seq', 96, true);


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_rendements_reference_id_seq', 120, true);


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_stades_phenologiques_id_seq', 210, true);


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_varietes_id_seq', 154, true);


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analyses_id_seq', 2, true);


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_cartographies_id_seq', 9, true);


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_infrastructures_id_seq', 8, true);


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_parcelles_id_seq', 15, true);


--
-- Name: champ_sols_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_sols_id_seq', 13, true);


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_sources_eau_id_seq', 11, true);


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_ledger_id_seq', 3, true);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_purchases_id_seq', 1, false);


--
-- Name: farms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.farms_id_seq', 1, false);


--
-- Name: gf_activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_activites_id_seq', 19, true);


--
-- Name: gf_couts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_couts_id_seq', 13, true);


--
-- Name: gf_journal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_journal_id_seq', 5, true);


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_main_oeuvre_id_seq', 3, true);


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_preuves_id_seq', 1, true);


--
-- Name: ia_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_config_id_seq', 5, true);


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_conversations_id_seq', 13, true);


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_feedback_id_seq', 2, true);


--
-- Name: ia_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_messages_id_seq', 29, true);


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_recommandations_id_seq', 7, true);


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_alertes_id_seq', 13, true);


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_conditions_id_seq', 11, true);


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_config_alertes_id_seq', 5, true);


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_planificateur_id_seq', 6, true);


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_previsions_id_seq', 26, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organizations_id_seq', 9, true);


--
-- Name: parcelles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parcelles_id_seq', 5, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 3, true);


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_declenchements_id_seq', 1, false);


--
-- Name: re_parametres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_parametres_id_seq', 1, false);


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_cultures_id_seq', 2035, true);


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_entites_id_seq', 570, true);


--
-- Name: re_regles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_id_seq', 1727, true);


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_sessions_evaluation_id_seq', 1, false);


--
-- Name: sc_analyse_economique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_analyse_economique_id_seq', 1, false);


--
-- Name: sc_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_analyses_id_seq', 1, false);


--
-- Name: sc_cartes_precision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_cartes_precision_id_seq', 1, false);


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_consultations_id_seq', 21, true);


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_diagnostics_id_seq', 10, true);


--
-- Name: sc_indices_satellitaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_indices_satellitaires_id_seq', 1, false);


--
-- Name: sc_observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_observations_id_seq', 22, true);


--
-- Name: sc_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_photos_id_seq', 3, true);


--
-- Name: sc_previsions_rendement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_previsions_rendement_id_seq', 1, false);


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_rapports_id_seq', 1, false);


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_suivis_id_seq', 3, true);


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_traitements_id_seq', 4, true);


--
-- Name: service_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_requests_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 9, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 9, true);


--
-- Name: usage_counters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usage_counters_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: agro_besoins_eau agro_besoins_eau_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau
    ADD CONSTRAINT agro_besoins_eau_pkey PRIMARY KEY (id);


--
-- Name: agro_besoins_nutritionnels agro_besoins_nutritionnels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels
    ADD CONSTRAINT agro_besoins_nutritionnels_pkey PRIMARY KEY (id);


--
-- Name: agro_calendriers_culturaux agro_calendriers_culturaux_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT agro_calendriers_culturaux_pkey PRIMARY KEY (id);


--
-- Name: agro_culture_maladies agro_culture_maladies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_pkey PRIMARY KEY (id);


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_pkey PRIMARY KEY (id);


--
-- Name: agro_cultures agro_cultures_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures
    ADD CONSTRAINT agro_cultures_nom_key UNIQUE (nom);


--
-- Name: agro_cultures agro_cultures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures
    ADD CONSTRAINT agro_cultures_pkey PRIMARY KEY (id);


--
-- Name: agro_maladies agro_maladies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_maladies
    ADD CONSTRAINT agro_maladies_pkey PRIMARY KEY (id);


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_culture_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_culture_id_key UNIQUE (culture_id);


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_pkey PRIMARY KEY (id);


--
-- Name: agro_ravageurs agro_ravageurs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_ravageurs
    ADD CONSTRAINT agro_ravageurs_pkey PRIMARY KEY (id);


--
-- Name: agro_recommandations agro_recommandations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations
    ADD CONSTRAINT agro_recommandations_pkey PRIMARY KEY (id);


--
-- Name: agro_rendements_reference agro_rendements_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_pkey PRIMARY KEY (id);


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_pkey PRIMARY KEY (id);


--
-- Name: agro_varietes agro_varietes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes
    ADD CONSTRAINT agro_varietes_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: champ_cartographies champ_cartographies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies
    ADD CONSTRAINT champ_cartographies_pkey PRIMARY KEY (id);


--
-- Name: champ_infrastructures champ_infrastructures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures
    ADD CONSTRAINT champ_infrastructures_pkey PRIMARY KEY (id);


--
-- Name: champ_parcelles champ_parcelles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_pkey PRIMARY KEY (id);


--
-- Name: champ_sols champ_sols_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols
    ADD CONSTRAINT champ_sols_pkey PRIMARY KEY (id);


--
-- Name: champ_sources_eau champ_sources_eau_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau
    ADD CONSTRAINT champ_sources_eau_pkey PRIMARY KEY (id);


--
-- Name: credit_ledger credit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_reference_key UNIQUE (reference);


--
-- Name: farms farms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms
    ADD CONSTRAINT farms_pkey PRIMARY KEY (id);


--
-- Name: gf_activites gf_activites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_pkey PRIMARY KEY (id);


--
-- Name: gf_couts gf_couts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_pkey PRIMARY KEY (id);


--
-- Name: gf_journal gf_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_pkey PRIMARY KEY (id);


--
-- Name: gf_main_oeuvre gf_main_oeuvre_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_pkey PRIMARY KEY (id);


--
-- Name: gf_preuves gf_preuves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_pkey PRIMARY KEY (id);


--
-- Name: ia_config ia_config_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_org_id_key UNIQUE (org_id);


--
-- Name: ia_config ia_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_pkey PRIMARY KEY (id);


--
-- Name: ia_conversations ia_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_pkey PRIMARY KEY (id);


--
-- Name: ia_feedback ia_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_pkey PRIMARY KEY (id);


--
-- Name: ia_messages ia_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_pkey PRIMARY KEY (id);


--
-- Name: ia_recommandations ia_recommandations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_pkey PRIMARY KEY (id);


--
-- Name: mt_alertes mt_alertes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_pkey PRIMARY KEY (id);


--
-- Name: mt_conditions mt_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_pkey PRIMARY KEY (id);


--
-- Name: mt_config_alertes mt_config_alertes_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_org_id_key UNIQUE (org_id);


--
-- Name: mt_config_alertes mt_config_alertes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_pkey PRIMARY KEY (id);


--
-- Name: mt_planificateur mt_planificateur_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_pkey PRIMARY KEY (id);


--
-- Name: mt_previsions mt_previsions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: parcelles parcelles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles
    ADD CONSTRAINT parcelles_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: re_declenchements re_declenchements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements
    ADD CONSTRAINT re_declenchements_pkey PRIMARY KEY (id);


--
-- Name: re_parametres re_parametres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_parametres
    ADD CONSTRAINT re_parametres_pkey PRIMARY KEY (id);


--
-- Name: re_regles_cultures re_regles_cultures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_pkey PRIMARY KEY (id);


--
-- Name: re_regles_cultures re_regles_cultures_regle_id_culture_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_regle_id_culture_id_key UNIQUE (regle_id, culture_id);


--
-- Name: re_regles_entites re_regles_entites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites
    ADD CONSTRAINT re_regles_entites_pkey PRIMARY KEY (id);


--
-- Name: re_regles re_regles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles
    ADD CONSTRAINT re_regles_pkey PRIMARY KEY (id);


--
-- Name: re_sessions_evaluation re_sessions_evaluation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_sessions_evaluation
    ADD CONSTRAINT re_sessions_evaluation_pkey PRIMARY KEY (id);


--
-- Name: sc_analyse_economique sc_analyse_economique_analyse_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyse_economique
    ADD CONSTRAINT sc_analyse_economique_analyse_id_key UNIQUE (analyse_id);


--
-- Name: sc_analyse_economique sc_analyse_economique_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyse_economique
    ADD CONSTRAINT sc_analyse_economique_pkey PRIMARY KEY (id);


--
-- Name: sc_analyses sc_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyses
    ADD CONSTRAINT sc_analyses_pkey PRIMARY KEY (id);


--
-- Name: sc_cartes_precision sc_cartes_precision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_cartes_precision
    ADD CONSTRAINT sc_cartes_precision_pkey PRIMARY KEY (id);


--
-- Name: sc_consultations sc_consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_pkey PRIMARY KEY (id);


--
-- Name: sc_diagnostics sc_diagnostics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_pkey PRIMARY KEY (id);


--
-- Name: sc_indices_satellitaires sc_indices_satellitaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_indices_satellitaires
    ADD CONSTRAINT sc_indices_satellitaires_pkey PRIMARY KEY (id);


--
-- Name: sc_observations sc_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations
    ADD CONSTRAINT sc_observations_pkey PRIMARY KEY (id);


--
-- Name: sc_photos sc_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_pkey PRIMARY KEY (id);


--
-- Name: sc_previsions_rendement sc_previsions_rendement_analyse_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_previsions_rendement
    ADD CONSTRAINT sc_previsions_rendement_analyse_id_key UNIQUE (analyse_id);


--
-- Name: sc_previsions_rendement sc_previsions_rendement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_previsions_rendement
    ADD CONSTRAINT sc_previsions_rendement_pkey PRIMARY KEY (id);


--
-- Name: sc_rapports sc_rapports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_pkey PRIMARY KEY (id);


--
-- Name: sc_suivis sc_suivis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis
    ADD CONSTRAINT sc_suivis_pkey PRIMARY KEY (id);


--
-- Name: sc_traitements sc_traitements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_pkey PRIMARY KEY (id);


--
-- Name: service_requests service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_pkey PRIMARY KEY (id);


--
-- Name: services services_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_code_key UNIQUE (code);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_org_id_key UNIQUE (org_id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: agro_calendriers_culturaux uq_calendrier_culture_zone_saison; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT uq_calendrier_culture_zone_saison UNIQUE (culture_id, zone_agro, saison);


--
-- Name: agro_culture_maladies uq_culture_maladie; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT uq_culture_maladie UNIQUE (culture_id, maladie_id);


--
-- Name: agro_culture_ravageurs uq_culture_ravageur; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT uq_culture_ravageur UNIQUE (culture_id, ravageur_id);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (user_id);


--
-- Name: idx_ledger_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ledger_user_date ON public.credit_ledger USING btree (user_id, cree_le DESC);


--
-- Name: idx_purchases_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_user ON public.credit_purchases USING btree (user_id, cree_le DESC);


--
-- Name: idx_req_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_req_user_date ON public.service_requests USING btree (user_id, cree_le DESC);


--
-- Name: ix_agro_besoins_eau_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_besoins_eau_culture ON public.agro_besoins_eau USING btree (culture_id);


--
-- Name: ix_agro_cal_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cal_culture_zone ON public.agro_calendriers_culturaux USING btree (culture_id, zone_agro);


--
-- Name: ix_agro_cm_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cm_culture ON public.agro_culture_maladies USING btree (culture_id);


--
-- Name: ix_agro_cr_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cr_culture ON public.agro_culture_ravageurs USING btree (culture_id);


--
-- Name: ix_agro_cultures_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cultures_categorie ON public.agro_cultures USING btree (categorie);


--
-- Name: ix_agro_reco_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_reco_categorie ON public.agro_recommandations USING btree (categorie_reco);


--
-- Name: ix_agro_reco_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_reco_culture_zone ON public.agro_recommandations USING btree (culture_id, zone_agro);


--
-- Name: ix_agro_rendements_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_rendements_culture_zone ON public.agro_rendements_reference USING btree (culture_id, zone_agro, pratique);


--
-- Name: ix_agro_stades_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_stades_culture ON public.agro_stades_phenologiques USING btree (culture_id);


--
-- Name: ix_agro_varietes_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_varietes_culture ON public.agro_varietes USING btree (culture_id);


--
-- Name: ix_champ_cartographies_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_cartographies_id ON public.champ_cartographies USING btree (id);


--
-- Name: ix_champ_cartographies_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_cartographies_parcelle_id ON public.champ_cartographies USING btree (parcelle_id);


--
-- Name: ix_champ_infrastructures_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_infrastructures_id ON public.champ_infrastructures USING btree (id);


--
-- Name: ix_champ_infrastructures_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_infrastructures_parcelle_id ON public.champ_infrastructures USING btree (parcelle_id);


--
-- Name: ix_champ_parcelles_code_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_champ_parcelles_code_parcelle ON public.champ_parcelles USING btree (code_parcelle);


--
-- Name: ix_champ_parcelles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_parcelles_id ON public.champ_parcelles USING btree (id);


--
-- Name: ix_champ_parcelles_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_parcelles_org_id ON public.champ_parcelles USING btree (org_id);


--
-- Name: ix_champ_sols_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sols_id ON public.champ_sols USING btree (id);


--
-- Name: ix_champ_sols_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sols_parcelle_id ON public.champ_sols USING btree (parcelle_id);


--
-- Name: ix_champ_sources_eau_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sources_eau_id ON public.champ_sources_eau USING btree (id);


--
-- Name: ix_champ_sources_eau_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sources_eau_parcelle_id ON public.champ_sources_eau USING btree (parcelle_id);


--
-- Name: ix_gf_activites_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_date ON public.gf_activites USING btree (date_prevue);


--
-- Name: ix_gf_activites_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_org ON public.gf_activites USING btree (org_id);


--
-- Name: ix_gf_activites_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_parcelle ON public.gf_activites USING btree (parcelle_id);


--
-- Name: ix_gf_activites_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_statut ON public.gf_activites USING btree (statut);


--
-- Name: ix_gf_activites_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_type ON public.gf_activites USING btree (type);


--
-- Name: ix_gf_couts_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_couts_activite ON public.gf_couts USING btree (activite_id);


--
-- Name: ix_gf_couts_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_couts_org ON public.gf_couts USING btree (org_id);


--
-- Name: ix_gf_journal_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_date ON public.gf_journal USING btree (date_entree);


--
-- Name: ix_gf_journal_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_org ON public.gf_journal USING btree (org_id);


--
-- Name: ix_gf_journal_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_parcelle ON public.gf_journal USING btree (parcelle_id);


--
-- Name: ix_gf_mo_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_mo_activite ON public.gf_main_oeuvre USING btree (activite_id);


--
-- Name: ix_gf_preuves_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_preuves_activite ON public.gf_preuves USING btree (activite_id);


--
-- Name: ix_ia_conversations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_conversations_org_id ON public.ia_conversations USING btree (org_id);


--
-- Name: ix_ia_feedback_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_feedback_org_id ON public.ia_feedback USING btree (org_id);


--
-- Name: ix_ia_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_messages_conversation_id ON public.ia_messages USING btree (conversation_id);


--
-- Name: ix_ia_messages_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_messages_org_id ON public.ia_messages USING btree (org_id);


--
-- Name: ix_ia_recommandations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_recommandations_org_id ON public.ia_recommandations USING btree (org_id);


--
-- Name: ix_ia_recommandations_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_recommandations_parcelle_id ON public.ia_recommandations USING btree (parcelle_id);


--
-- Name: ix_mt_alertes_niveau; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_niveau ON public.mt_alertes USING btree (niveau);


--
-- Name: ix_mt_alertes_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_org_id ON public.mt_alertes USING btree (org_id);


--
-- Name: ix_mt_alertes_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_parcelle_id ON public.mt_alertes USING btree (parcelle_id);


--
-- Name: ix_mt_alertes_type_alerte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_type_alerte ON public.mt_alertes USING btree (type_alerte);


--
-- Name: ix_mt_conditions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_conditions_org_id ON public.mt_conditions USING btree (org_id);


--
-- Name: ix_mt_conditions_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_conditions_parcelle_id ON public.mt_conditions USING btree (parcelle_id);


--
-- Name: ix_mt_planificateur_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_planificateur_org_id ON public.mt_planificateur USING btree (org_id);


--
-- Name: ix_mt_planificateur_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_planificateur_parcelle_id ON public.mt_planificateur USING btree (parcelle_id);


--
-- Name: ix_mt_previsions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_previsions_org_id ON public.mt_previsions USING btree (org_id);


--
-- Name: ix_mt_previsions_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_previsions_parcelle_id ON public.mt_previsions USING btree (parcelle_id);


--
-- Name: ix_re_decl_org_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_decl_org_date ON public.re_declenchements USING btree (org_id, declenche_le);


--
-- Name: ix_re_declenchements_acquitte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_acquitte ON public.re_declenchements USING btree (acquitte);


--
-- Name: ix_re_declenchements_declenche_le; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_declenche_le ON public.re_declenchements USING btree (declenche_le);


--
-- Name: ix_re_declenchements_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_org_id ON public.re_declenchements USING btree (org_id);


--
-- Name: ix_re_declenchements_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_regle_id ON public.re_declenchements USING btree (regle_id);


--
-- Name: ix_re_parametres_cle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_re_parametres_cle ON public.re_parametres USING btree (cle);


--
-- Name: ix_re_regles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_active ON public.re_regles USING btree (active);


--
-- Name: ix_re_regles_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_categorie ON public.re_regles USING btree (categorie);


--
-- Name: ix_re_regles_categorie_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_categorie_active ON public.re_regles USING btree (categorie, active);


--
-- Name: ix_re_regles_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_re_regles_code ON public.re_regles USING btree (code);


--
-- Name: ix_re_regles_cultures_culture_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_cultures_culture_id ON public.re_regles_cultures USING btree (culture_id);


--
-- Name: ix_re_regles_cultures_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_cultures_regle_id ON public.re_regles_cultures USING btree (regle_id);


--
-- Name: ix_re_regles_entites_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_entites_regle_id ON public.re_regles_entites USING btree (regle_id);


--
-- Name: ix_re_regles_gravite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_gravite ON public.re_regles USING btree (gravite);


--
-- Name: ix_re_regles_gravite_prio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_gravite_prio ON public.re_regles USING btree (gravite, priorite);


--
-- Name: ix_re_regles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_id ON public.re_regles USING btree (id);


--
-- Name: ix_re_sessions_evaluation_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_sessions_evaluation_org_id ON public.re_sessions_evaluation USING btree (org_id);


--
-- Name: ix_sc_analyse_economique_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyse_economique_id ON public.sc_analyse_economique USING btree (id);


--
-- Name: ix_sc_analyses_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyses_id ON public.sc_analyses USING btree (id);


--
-- Name: ix_sc_analyses_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyses_org_id ON public.sc_analyses USING btree (org_id);


--
-- Name: ix_sc_analyses_parcelle_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyses_parcelle_date ON public.sc_analyses USING btree (parcelle_id, analyse_le);


--
-- Name: ix_sc_analyses_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyses_parcelle_id ON public.sc_analyses USING btree (parcelle_id);


--
-- Name: ix_sc_analyses_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_analyses_statut ON public.sc_analyses USING btree (statut);


--
-- Name: ix_sc_cartes_analyse_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_cartes_analyse_type ON public.sc_cartes_precision USING btree (analyse_id, type_carte);


--
-- Name: ix_sc_cartes_precision_analyse_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_cartes_precision_analyse_id ON public.sc_cartes_precision USING btree (analyse_id);


--
-- Name: ix_sc_cartes_precision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_cartes_precision_id ON public.sc_cartes_precision USING btree (id);


--
-- Name: ix_sc_cartes_precision_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_cartes_precision_parcelle_id ON public.sc_cartes_precision USING btree (parcelle_id);


--
-- Name: ix_sc_consultations_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_consultations_org ON public.sc_consultations USING btree (org_id);


--
-- Name: ix_sc_consultations_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_consultations_parcelle ON public.sc_consultations USING btree (parcelle_id);


--
-- Name: ix_sc_diag_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_diag_consultation ON public.sc_diagnostics USING btree (consultation_id);


--
-- Name: ix_sc_indices_parcelle_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_indices_parcelle_date ON public.sc_indices_satellitaires USING btree (parcelle_id, date_image);


--
-- Name: ix_sc_indices_satellitaires_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_indices_satellitaires_id ON public.sc_indices_satellitaires USING btree (id);


--
-- Name: ix_sc_indices_satellitaires_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_indices_satellitaires_parcelle_id ON public.sc_indices_satellitaires USING btree (parcelle_id);


--
-- Name: ix_sc_obs_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_obs_consultation ON public.sc_observations USING btree (consultation_id);


--
-- Name: ix_sc_photos_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_photos_consultation ON public.sc_photos USING btree (consultation_id);


--
-- Name: ix_sc_previsions_rendement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_previsions_rendement_id ON public.sc_previsions_rendement USING btree (id);


--
-- Name: ix_sc_rapports_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_rapports_consultation ON public.sc_rapports USING btree (consultation_id);


--
-- Name: ix_sc_rapports_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_rapports_org ON public.sc_rapports USING btree (org_id);


--
-- Name: ix_sc_suivis_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_suivis_consultation ON public.sc_suivis USING btree (consultation_id);


--
-- Name: ix_sc_trait_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_trait_consultation ON public.sc_traitements USING btree (consultation_id);


--
-- Name: ix_usage_counters_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_usage_counters_period ON public.usage_counters USING btree (period);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: uniq_service_actif; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_service_actif ON public.service_requests USING btree (user_id) WHERE (statut = ANY (ARRAY['en_attente'::public.service_statut, 'en_cours'::public.service_statut]));


--
-- Name: agro_besoins_eau agro_besoins_eau_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau
    ADD CONSTRAINT agro_besoins_eau_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_besoins_nutritionnels agro_besoins_nutritionnels_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels
    ADD CONSTRAINT agro_besoins_nutritionnels_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_calendriers_culturaux agro_calendriers_culturaux_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT agro_calendriers_culturaux_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_maladies agro_culture_maladies_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_maladies agro_culture_maladies_maladie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_maladie_id_fkey FOREIGN KEY (maladie_id) REFERENCES public.agro_maladies(id) ON DELETE CASCADE;


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_ravageur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_ravageur_id_fkey FOREIGN KEY (ravageur_id) REFERENCES public.agro_ravageurs(id) ON DELETE CASCADE;


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_recommandations agro_recommandations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations
    ADD CONSTRAINT agro_recommandations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_rendements_reference agro_rendements_reference_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_rendements_reference agro_rendements_reference_variete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_variete_id_fkey FOREIGN KEY (variete_id) REFERENCES public.agro_varietes(id) ON DELETE SET NULL;


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_variete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_variete_id_fkey FOREIGN KEY (variete_id) REFERENCES public.agro_varietes(id) ON DELETE SET NULL;


--
-- Name: agro_varietes agro_varietes_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes
    ADD CONSTRAINT agro_varietes_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: analyses analyses_farm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_farm_id_fkey FOREIGN KEY (farm_id) REFERENCES public.farms(id);


--
-- Name: analyses analyses_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: analyses analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: champ_cartographies champ_cartographies_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies
    ADD CONSTRAINT champ_cartographies_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_infrastructures champ_infrastructures_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures
    ADD CONSTRAINT champ_infrastructures_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_parcelles champ_parcelles_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: champ_parcelles champ_parcelles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: champ_sols champ_sols_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols
    ADD CONSTRAINT champ_sols_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_sources_eau champ_sources_eau_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau
    ADD CONSTRAINT champ_sources_eau_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: credit_ledger credit_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: credit_purchases credit_purchases_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.credit_ledger(id);


--
-- Name: credit_purchases credit_purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: farms farms_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms
    ADD CONSTRAINT farms_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: credit_ledger fk_ledger_request; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT fk_ledger_request FOREIGN KEY (service_request_id) REFERENCES public.service_requests(id);


--
-- Name: gf_activites gf_activites_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_activites gf_activites_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: gf_couts gf_couts_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_couts gf_couts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_journal gf_journal_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE SET NULL;


--
-- Name: gf_journal gf_journal_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gf_journal gf_journal_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_journal gf_journal_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: gf_main_oeuvre gf_main_oeuvre_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_main_oeuvre gf_main_oeuvre_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_preuves gf_preuves_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_preuves gf_preuves_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ia_config ia_config_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_conversations ia_conversations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: ia_conversations ia_conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_conversations ia_conversations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: ia_conversations ia_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ia_feedback ia_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id);


--
-- Name: ia_feedback ia_feedback_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.ia_messages(id);


--
-- Name: ia_feedback ia_feedback_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_feedback ia_feedback_recommandation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_recommandation_id_fkey FOREIGN KEY (recommandation_id) REFERENCES public.ia_recommandations(id);


--
-- Name: ia_messages ia_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id) ON DELETE CASCADE;


--
-- Name: ia_messages ia_messages_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_recommandations ia_recommandations_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id);


--
-- Name: ia_recommandations ia_recommandations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: ia_recommandations ia_recommandations_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.ia_messages(id);


--
-- Name: ia_recommandations ia_recommandations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_recommandations ia_recommandations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_alertes mt_alertes_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: mt_alertes mt_alertes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_alertes mt_alertes_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_conditions mt_conditions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_conditions mt_conditions_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_config_alertes mt_config_alertes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_planificateur mt_planificateur_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id);


--
-- Name: mt_planificateur mt_planificateur_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: mt_planificateur mt_planificateur_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_planificateur mt_planificateur_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_previsions mt_previsions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_previsions mt_previsions_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: parcelles parcelles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles
    ADD CONSTRAINT parcelles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id);


--
-- Name: re_declenchements re_declenchements_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements
    ADD CONSTRAINT re_declenchements_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id);


--
-- Name: re_regles_cultures re_regles_cultures_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: re_regles_cultures re_regles_cultures_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id) ON DELETE CASCADE;


--
-- Name: re_regles_entites re_regles_entites_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites
    ADD CONSTRAINT re_regles_entites_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id) ON DELETE CASCADE;


--
-- Name: sc_analyse_economique sc_analyse_economique_analyse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyse_economique
    ADD CONSTRAINT sc_analyse_economique_analyse_id_fkey FOREIGN KEY (analyse_id) REFERENCES public.sc_analyses(id) ON DELETE CASCADE;


--
-- Name: sc_analyses sc_analyses_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyses
    ADD CONSTRAINT sc_analyses_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: sc_analyses sc_analyses_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyses
    ADD CONSTRAINT sc_analyses_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: sc_analyses sc_analyses_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_analyses
    ADD CONSTRAINT sc_analyses_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE CASCADE;


--
-- Name: sc_cartes_precision sc_cartes_precision_analyse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_cartes_precision
    ADD CONSTRAINT sc_cartes_precision_analyse_id_fkey FOREIGN KEY (analyse_id) REFERENCES public.sc_analyses(id) ON DELETE CASCADE;


--
-- Name: sc_cartes_precision sc_cartes_precision_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_cartes_precision
    ADD CONSTRAINT sc_cartes_precision_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE CASCADE;


--
-- Name: sc_consultations sc_consultations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_consultations sc_consultations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE SET NULL;


--
-- Name: sc_consultations sc_consultations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sc_consultations sc_consultations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: sc_diagnostics sc_diagnostics_confirme_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_confirme_par_fkey FOREIGN KEY (confirme_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_diagnostics sc_diagnostics_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_indices_satellitaires sc_indices_satellitaires_analyse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_indices_satellitaires
    ADD CONSTRAINT sc_indices_satellitaires_analyse_id_fkey FOREIGN KEY (analyse_id) REFERENCES public.sc_analyses(id) ON DELETE CASCADE;


--
-- Name: sc_indices_satellitaires sc_indices_satellitaires_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_indices_satellitaires
    ADD CONSTRAINT sc_indices_satellitaires_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE CASCADE;


--
-- Name: sc_observations sc_observations_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations
    ADD CONSTRAINT sc_observations_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_photos sc_photos_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_photos sc_photos_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.sc_observations(id) ON DELETE SET NULL;


--
-- Name: sc_previsions_rendement sc_previsions_rendement_analyse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_previsions_rendement
    ADD CONSTRAINT sc_previsions_rendement_analyse_id_fkey FOREIGN KEY (analyse_id) REFERENCES public.sc_analyses(id) ON DELETE CASCADE;


--
-- Name: sc_previsions_rendement sc_previsions_rendement_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_previsions_rendement
    ADD CONSTRAINT sc_previsions_rendement_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: sc_rapports sc_rapports_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_rapports sc_rapports_genere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_genere_par_fkey FOREIGN KEY (genere_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_rapports sc_rapports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sc_suivis sc_suivis_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis
    ADD CONSTRAINT sc_suivis_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_traitements sc_traitements_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_traitements sc_traitements_diagnostic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_diagnostic_id_fkey FOREIGN KEY (diagnostic_id) REFERENCES public.sc_diagnostics(id) ON DELETE SET NULL;


--
-- Name: service_requests service_requests_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: service_requests service_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: usage_counters usage_counters_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT usage_counters_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict PSx7a4soJ8sZLpd5rzA1ZzNfXd1vD8DkRMrXX4irSOuK93wTFVLnA36d8SbfjPo

