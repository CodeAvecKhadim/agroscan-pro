--
-- PostgreSQL database dump
--

\restrict SeVbnvflmoAnL7Oh3sazUdc9NMWcl3ToYaMzLrMafciuM6bva8HNAj867WjrzH1

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: categoriecoût; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."categoriecoût" AS ENUM (
    'INTRANT',
    'MATERIEL',
    'TRANSPORT',
    'PRESTATION',
    'AUTRE'
);


--
-- Name: categoriereco; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.categoriereco AS ENUM (
    'SOL',
    'FERTILISATION',
    'MALADIE',
    'RAVAGEUR',
    'IRRIGATION',
    'CALENDRIER',
    'RECOLTE',
    'GENERAL'
);


--
-- Name: credit_motif; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.credit_motif AS ENUM (
    'achat',
    'service',
    'remboursement',
    'bonus',
    'ajustement'
);


--
-- Name: disponibiliteeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.disponibiliteeau AS ENUM (
    'PERMANENTE',
    'SAISONNIERE',
    'IRREGULIERE'
);


--
-- Name: erosionsol; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.erosionsol AS ENUM (
    'NULLE',
    'FAIBLE',
    'MODEREE',
    'FORTE',
    'TRES_FORTE'
);


--
-- Name: etatinfrastructure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.etatinfrastructure AS ENUM (
    'BON',
    'MOYEN',
    'MAUVAIS',
    'A_REPARER',
    'HORS_SERVICE'
);


--
-- Name: evolutionsuivi; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.evolutionsuivi AS ENUM (
    'AMELIORATION',
    'STABLE',
    'AGGRAVATION'
);


--
-- Name: methodediagnostic; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.methodediagnostic AS ENUM (
    'RULES_ENGINE',
    'BIBLIOTHEQUE',
    'SYMPTOMES',
    'COMBINEE'
);


--
-- Name: modeconversation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.modeconversation AS ENUM (
    'LIBRE',
    'ANALYSE_PARCELLE',
    'DIAGNOSTIC',
    'PLANIFICATION',
    'BILAN'
);


--
-- Name: niveaualerte; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.niveaualerte AS ENUM (
    'INFO',
    'AVERTISSEMENT',
    'CRITIQUE'
);


--
-- Name: paiement_statut; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.paiement_statut AS ENUM (
    'en_attente',
    'paye',
    'echoue',
    'rembourse'
);


--
-- Name: partieplante; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.partieplante AS ENUM (
    'FEUILLE',
    'TIGE',
    'RACINE',
    'FRUIT',
    'GRAINE',
    'PLANTE_ENTIERE',
    'SOL'
);


--
-- Name: plantype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.plantype AS ENUM (
    'GRATUIT',
    'PREMIUM',
    'COOPERATIVE'
);


--
-- Name: qualiteeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.qualiteeau AS ENUM (
    'BONNE',
    'ACCEPTABLE',
    'TRAITEE_REQUISE',
    'IMPROPRE'
);


--
-- Name: rolemessage; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rolemessage AS ENUM (
    'USER',
    'ASSISTANT',
    'SYSTEM'
);


--
-- Name: service_statut; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.service_statut AS ENUM (
    'en_attente',
    'en_cours',
    'termine',
    'echoue',
    'annule'
);


--
-- Name: sourcemesure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcemesure AS ENUM (
    'GPS_TERRAIN',
    'DESSIN_CARTE',
    'IMPORT_FICHIER',
    'ESTIMATION'
);


--
-- Name: sourcemeteo; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcemeteo AS ENUM (
    'OPEN_METEO',
    'CAPTEUR',
    'MANUEL'
);


--
-- Name: sourcephoto; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcephoto AS ENUM (
    'TERRAIN',
    'LABORATOIRE',
    'DRONE',
    'SMARTPHONE',
    'AUTRE'
);


--
-- Name: sourceplanificateur; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourceplanificateur AS ENUM (
    'RULES_ENGINE',
    'METEO',
    'GF_ACTIVITE',
    'MANUEL'
);


--
-- Name: sourcepreuve; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sourcepreuve AS ENUM (
    'SMARTPHONE',
    'DRONE',
    'TABLETTE',
    'AUTRE'
);


--
-- Name: statutactivite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutactivite AS ENUM (
    'PLANIFIE',
    'EN_COURS',
    'TERMINE',
    'ANNULE'
);


--
-- Name: statutconsultation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutconsultation AS ENUM (
    'EN_COURS',
    'ANALYSE',
    'CONFIRME',
    'ARCHIVE'
);


--
-- Name: statutconversation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutconversation AS ENUM (
    'ACTIVE',
    'ARCHIVEE',
    'TERMINEE'
);


--
-- Name: statutdiagnostic; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutdiagnostic AS ENUM (
    'PROBABLE',
    'CONFIRME',
    'EXCLU'
);


--
-- Name: statutparcelle; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutparcelle AS ENUM (
    'ACTIVE',
    'EN_REPOS',
    'EN_PREPARATION',
    'ARCHIVE'
);


--
-- Name: statutplanificateur; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutplanificateur AS ENUM (
    'RECOMMANDE',
    'PLANIFIE',
    'IGNORE',
    'FAIT'
);


--
-- Name: statutreco; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statutreco AS ENUM (
    'NOUVELLE',
    'VUE',
    'APPLIQUEE',
    'IGNOREE'
);


--
-- Name: statuttraitement; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.statuttraitement AS ENUM (
    'PLANIFIE',
    'APPLIQUE',
    'SKIP'
);


--
-- Name: substatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.substatus AS ENUM (
    'ACTIVE',
    'TRIAL',
    'PAST_DUE',
    'CANCELED',
    'EXPIRED'
);


--
-- Name: texturesol; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.texturesol AS ENUM (
    'SABLEUX',
    'LIMONEUX',
    'ARGILEUX',
    'ARGILO_LIMONEUX',
    'SABLO_LIMONEUX',
    'LIMON_ARGILEUX'
);


--
-- Name: tonassistant; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tonassistant AS ENUM (
    'TECHNIQUE',
    'SIMPLE',
    'PEDAGOGIQUE'
);


--
-- Name: typeactivite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeactivite AS ENUM (
    'SEMIS',
    'PLANTATION',
    'FERTILISATION',
    'TRAITEMENT',
    'IRRIGATION',
    'DESHERBAGE',
    'RECOLTE',
    'AUTRE'
);


--
-- Name: typealerte; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typealerte AS ENUM (
    'METEO',
    'MALADIE',
    'RAVAGEUR',
    'FERTILISATION',
    'IRRIGATION',
    'CALENDRIER',
    'PLANIFICATEUR'
);


--
-- Name: typeconsultation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeconsultation AS ENUM (
    'MALADIE',
    'RAVAGEUR',
    'FERTILISATION'
);


--
-- Name: typeentite; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeentite AS ENUM (
    'MALADIE',
    'RAVAGEUR',
    'CARENCE'
);


--
-- Name: typegeometrie; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typegeometrie AS ENUM (
    'POLYGON',
    'POINT',
    'LINESTRING'
);


--
-- Name: typeinfrastructure; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeinfrastructure AS ENUM (
    'BATIMENT',
    'HANGAR',
    'SERRE',
    'CLOTURE',
    'PISTE',
    'CANAL',
    'DIGUE',
    'FORAGE',
    'PUITS',
    'RESERVOIR',
    'COMPOSTIERE',
    'AUTRE'
);


--
-- Name: typejournal; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typejournal AS ENUM (
    'OBSERVATION',
    'DECISION',
    'ALERTE',
    'NOTE_TERRAIN',
    'METEO'
);


--
-- Name: typemainoeuvre; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typemainoeuvre AS ENUM (
    'FAMILIALE',
    'SALARIALE',
    'ENTRAIDE',
    'PRESTATAIRE'
);


--
-- Name: typeobservation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typeobservation AS ENUM (
    'SYMPTOME',
    'RAVAGEUR_OBSERVE',
    'SOL',
    'METEO',
    'AUTRE'
);


--
-- Name: typepreuve; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typepreuve AS ENUM (
    'PHOTO',
    'VIDEO'
);


--
-- Name: typerapport; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typerapport AS ENUM (
    'DIAGNOSTIC_MALADIE',
    'DIAGNOSTIC_RAVAGEUR',
    'PLAN_FERTILISATION',
    'SUIVI'
);


--
-- Name: typesourceeau; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typesourceeau AS ENUM (
    'FORAGE',
    'PUITS_TRADITIONNEL',
    'COURS_EAU',
    'MARE_PERMANENTE',
    'MARE_TEMPORAIRE',
    'RESERVOIR',
    'EAU_DE_PLUIE',
    'CANAL_IRRIGATION'
);


--
-- Name: typetraitement; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.typetraitement AS ENUM (
    'TRAITEMENT_PHYTO',
    'FERTILISATION',
    'IRRIGATION',
    'MESURE_CULTURALE',
    'RECOLTE',
    'SURVEILLANCE'
);


--
-- Name: userrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.userrole AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER',
    'VIEWER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agro_besoins_eau; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_besoins_eau (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    stade character varying(80) NOT NULL,
    besoin_mm_semaine numeric(5,1),
    sensibilite character varying(20),
    frequence_irrigation character varying(100),
    notes text
);


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_besoins_eau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_besoins_eau_id_seq OWNED BY public.agro_besoins_eau.id;


--
-- Name: agro_besoins_nutritionnels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_besoins_nutritionnels (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    stade character varying(80) NOT NULL,
    azote_kg_ha numeric(6,1),
    phosphore_kg_ha numeric(6,1),
    potassium_kg_ha numeric(6,1),
    calcium_kg_ha numeric(6,1),
    magnesium_kg_ha numeric(6,1),
    engrais_recommandes text,
    moment_application text,
    notes text
);


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_besoins_nutritionnels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_besoins_nutritionnels_id_seq OWNED BY public.agro_besoins_nutritionnels.id;


--
-- Name: agro_calendriers_culturaux; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_calendriers_culturaux (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    zone_agro character varying(40) NOT NULL,
    saison character varying(20) NOT NULL,
    mois_semis_debut integer,
    mois_semis_fin integer,
    mois_recolte_debut integer,
    mois_recolte_fin integer,
    remarques text
);


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_calendriers_culturaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_calendriers_culturaux_id_seq OWNED BY public.agro_calendriers_culturaux.id;


--
-- Name: agro_culture_maladies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_culture_maladies (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    maladie_id integer NOT NULL,
    frequence character varying(20),
    gravite character varying(20),
    stade_sensible character varying(100),
    pertes_estimees character varying(100),
    prevention text,
    traitement text NOT NULL
);


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_culture_maladies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_culture_maladies_id_seq OWNED BY public.agro_culture_maladies.id;


--
-- Name: agro_culture_ravageurs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_culture_ravageurs (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    ravageur_id integer NOT NULL,
    frequence character varying(20),
    gravite character varying(20),
    stade_sensible character varying(100),
    pertes_estimees character varying(100),
    prevention text,
    lutte text NOT NULL
);


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_culture_ravageurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_culture_ravageurs_id_seq OWNED BY public.agro_culture_ravageurs.id;


--
-- Name: agro_cultures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_cultures (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    nom_scientifique character varying(200),
    nom_local character varying(200),
    famille character varying(100),
    categorie character varying(30) NOT NULL,
    icone character varying(10),
    description text,
    actif boolean,
    created_at timestamp without time zone,
    CONSTRAINT ck_culture_categorie CHECK (((categorie)::text = ANY ((ARRAY['grandes_cultures'::character varying, 'maraichage'::character varying, 'arboriculture'::character varying])::text[])))
);


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_cultures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_cultures_id_seq OWNED BY public.agro_cultures.id;


--
-- Name: agro_maladies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_maladies (
    id integer NOT NULL,
    nom character varying(150) NOT NULL,
    nom_scientifique character varying(200),
    pathogene_type character varying(20),
    symptomes text NOT NULL,
    conditions_favorables text,
    created_at timestamp without time zone,
    CONSTRAINT ck_maladie_type CHECK (((pathogene_type)::text = ANY ((ARRAY['fongique'::character varying, 'bacterien'::character varying, 'viral'::character varying, 'parasitaire'::character varying, 'physiologique'::character varying, 'nematode'::character varying])::text[])))
);


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_maladies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_maladies_id_seq OWNED BY public.agro_maladies.id;


--
-- Name: agro_parametres_climatiques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_parametres_climatiques (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    temp_min_c numeric(4,1),
    temp_opt_min_c numeric(4,1),
    temp_opt_max_c numeric(4,1),
    temp_max_c numeric(4,1),
    pluvio_min_mm integer,
    pluvio_opt_mm integer,
    pluvio_max_mm integer,
    altitude_max_m integer,
    ensoleillement_h numeric(3,1),
    ph_min numeric(3,1),
    ph_opt_min numeric(3,1),
    ph_opt_max numeric(3,1),
    ph_max numeric(3,1),
    texture_preferee character varying(100)
);


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_parametres_climatiques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_parametres_climatiques_id_seq OWNED BY public.agro_parametres_climatiques.id;


--
-- Name: agro_ravageurs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_ravageurs (
    id integer NOT NULL,
    nom character varying(150) NOT NULL,
    nom_scientifique character varying(200),
    type_ravageur character varying(20),
    description text,
    symptomes_degats text NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_ravageurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_ravageurs_id_seq OWNED BY public.agro_ravageurs.id;


--
-- Name: agro_recommandations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_recommandations (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    zone_agro character varying(40),
    categorie_reco character varying(50) NOT NULL,
    titre character varying(200) NOT NULL,
    contenu text NOT NULL,
    priorite integer,
    mois_applicable jsonb,
    created_at timestamp without time zone
);


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_recommandations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_recommandations_id_seq OWNED BY public.agro_recommandations.id;


--
-- Name: agro_rendements_reference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_rendements_reference (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    variete_id integer,
    zone_agro character varying(40),
    pratique character varying(20) NOT NULL,
    rendement_min_t_ha numeric(5,2),
    rendement_max_t_ha numeric(5,2),
    rendement_moyen_t_ha numeric(5,2),
    unite character varying(20),
    source character varying(100),
    annee_reference integer
);


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_rendements_reference_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_rendements_reference_id_seq OWNED BY public.agro_rendements_reference.id;


--
-- Name: agro_stades_phenologiques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_stades_phenologiques (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    variete_id integer,
    ordre integer NOT NULL,
    nom_stade character varying(100) NOT NULL,
    jours_debut integer,
    jours_fin integer,
    description text,
    actions_cles jsonb,
    indicateurs_visuels text
);


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_stades_phenologiques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_stades_phenologiques_id_seq OWNED BY public.agro_stades_phenologiques.id;


--
-- Name: agro_varietes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agro_varietes (
    id integer NOT NULL,
    culture_id integer NOT NULL,
    nom character varying(150) NOT NULL,
    origine character varying(100),
    cycle_min_jours integer,
    cycle_max_jours integer,
    precocite character varying(20),
    tolerance_secheresse boolean,
    tolerance_salinite boolean,
    zones_adaptees jsonb,
    rendement_potentiel_t_ha numeric(5,2),
    notes text
);


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agro_varietes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agro_varietes_id_seq OWNED BY public.agro_varietes.id;


--
-- Name: analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer,
    farm_id integer,
    culture character varying,
    region character varying,
    measurements json,
    score integer,
    verdict character varying,
    advanced boolean,
    created_at timestamp without time zone
);


--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: champ_cartographies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_cartographies (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type_geometrie public.typegeometrie NOT NULL,
    coordonnees jsonb NOT NULL,
    projection character varying(20),
    source_mesure public.sourcemesure,
    precision_m double precision,
    date_mesure date,
    actif boolean,
    created_at timestamp with time zone
);


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_cartographies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_cartographies_id_seq OWNED BY public.champ_cartographies.id;


--
-- Name: champ_infrastructures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_infrastructures (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type public.typeinfrastructure NOT NULL,
    nom character varying(200),
    description text,
    longueur_m double precision,
    superficie_m2 double precision,
    capacite double precision,
    unite_capacite character varying(20),
    etat public.etatinfrastructure,
    annee_construction smallint,
    localisation jsonb,
    created_at timestamp with time zone
);


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_infrastructures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_infrastructures_id_seq OWNED BY public.champ_infrastructures.id;


--
-- Name: champ_parcelles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_parcelles (
    id integer NOT NULL,
    org_id integer NOT NULL,
    nom character varying(200) NOT NULL,
    code_parcelle character varying(50),
    type_culture character varying(100),
    culture_id integer,
    zone_agro character varying(50),
    region character varying(100),
    localite character varying(200),
    statut public.statutparcelle NOT NULL,
    description text,
    superficie_m2 double precision,
    superficie_ha double precision,
    perimetre_m double precision,
    centre_lat double precision,
    centre_lon double precision,
    score_completude smallint,
    score_detail jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_parcelles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_parcelles_id_seq OWNED BY public.champ_parcelles.id;


--
-- Name: champ_sols; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_sols (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    date_analyse date,
    texture public.texturesol,
    profondeur_labour_cm smallint,
    pierrosite_pct double precision,
    erosion public.erosionsol,
    "pH_eau" double precision,
    "pH_kcl" double precision,
    matiere_organique double precision,
    azote_total double precision,
    phosphore_assim double precision,
    potassium_echang double precision,
    calcium double precision,
    magnesium double precision,
    sodium double precision,
    cec double precision,
    conductivite_ds_m double precision,
    methode_analyse character varying(100),
    laboratoire character varying(200),
    reference_labo character varying(100),
    observations text,
    created_at timestamp with time zone
);


--
-- Name: champ_sols_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_sols_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_sols_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_sols_id_seq OWNED BY public.champ_sols.id;


--
-- Name: champ_sources_eau; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.champ_sources_eau (
    id integer NOT NULL,
    parcelle_id integer NOT NULL,
    type public.typesourceeau NOT NULL,
    nom character varying(200),
    debit_m3h double precision,
    profondeur_m double precision,
    "pH_eau" double precision,
    conductivite_ds_m double precision,
    qualite public.qualiteeau,
    disponibilite public.disponibiliteeau,
    partage boolean,
    superficie_m2 double precision,
    localisation jsonb,
    created_at timestamp with time zone
);


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.champ_sources_eau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.champ_sources_eau_id_seq OWNED BY public.champ_sources_eau.id;


--
-- Name: credit_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_ledger (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    delta integer NOT NULL,
    motif public.credit_motif NOT NULL,
    solde_apres integer NOT NULL,
    service_request_id bigint,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    cree_le timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_ledger_id_seq OWNED BY public.credit_ledger.id;


--
-- Name: credit_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_purchases (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    credits integer NOT NULL,
    montant_fcfa integer NOT NULL,
    fournisseur text,
    reference text,
    statut public.paiement_statut DEFAULT 'en_attente'::public.paiement_statut NOT NULL,
    ledger_id bigint,
    cree_le timestamp with time zone DEFAULT now() NOT NULL,
    paye_le timestamp with time zone
);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_purchases_id_seq OWNED BY public.credit_purchases.id;


--
-- Name: farms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.farms (
    id integer NOT NULL,
    org_id integer NOT NULL,
    name character varying NOT NULL,
    region character varying,
    locality character varying,
    latitude double precision,
    longitude double precision,
    area_ha double precision,
    created_at timestamp without time zone
);


--
-- Name: farms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.farms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: farms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.farms_id_seq OWNED BY public.farms.id;


--
-- Name: gf_activites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_activites (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    consultation_id integer,
    type public.typeactivite NOT NULL,
    statut public.statutactivite NOT NULL,
    titre character varying(200) NOT NULL,
    description text,
    date_prevue date,
    date_debut timestamp without time zone,
    date_fin timestamp without time zone,
    duree_minutes integer,
    stade_culture character varying(100),
    surface_traitee_ha double precision,
    conditions_meteo jsonb,
    localisation_debut jsonb,
    details jsonb,
    note text,
    created_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: gf_activites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_activites_id_seq OWNED BY public.gf_activites.id;


--
-- Name: gf_couts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_couts (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    categorie public."categoriecoût" NOT NULL,
    sous_categorie character varying(100),
    description character varying(300) NOT NULL,
    quantite double precision,
    unite character varying(30),
    prix_unitaire_fcfa integer,
    montant_total_fcfa integer NOT NULL,
    fournisseur character varying(200),
    date_achat date,
    recu boolean,
    note text,
    created_at timestamp without time zone
);


--
-- Name: gf_couts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_couts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_couts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_couts_id_seq OWNED BY public.gf_couts.id;


--
-- Name: gf_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_journal (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    activite_id integer,
    date_entree date NOT NULL,
    type public.typejournal NOT NULL,
    titre character varying(200),
    contenu text NOT NULL,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: gf_journal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_journal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_journal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_journal_id_seq OWNED BY public.gf_journal.id;


--
-- Name: gf_main_oeuvre; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_main_oeuvre (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typemainoeuvre NOT NULL,
    description character varying(200),
    nb_personnes smallint NOT NULL,
    duree_jours double precision NOT NULL,
    taux_journalier_fcfa integer,
    montant_total_fcfa integer,
    note text,
    created_at timestamp without time zone
);


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_main_oeuvre_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_main_oeuvre_id_seq OWNED BY public.gf_main_oeuvre.id;


--
-- Name: gf_preuves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gf_preuves (
    id integer NOT NULL,
    activite_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typepreuve NOT NULL,
    filename character varying(255) NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    duree_secondes smallint,
    taille_ko integer,
    source public.sourcepreuve,
    localisation jsonb,
    horodatage_terrain timestamp without time zone,
    photo_meta jsonb,
    uploaded_at timestamp without time zone
);


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gf_preuves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gf_preuves_id_seq OWNED BY public.gf_preuves.id;


--
-- Name: ia_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_config (
    id integer NOT NULL,
    org_id integer NOT NULL,
    langue character varying(10),
    ton public.tonassistant,
    focus_cultures character varying[],
    inclure_meteo boolean,
    inclure_regles boolean,
    inclure_historique_sante boolean,
    inclure_couts boolean,
    updated_at timestamp without time zone
);


--
-- Name: ia_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_config_id_seq OWNED BY public.ia_config.id;


--
-- Name: ia_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_conversations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    titre character varying(200),
    statut public.statutconversation NOT NULL,
    mode public.modeconversation NOT NULL,
    nb_messages integer,
    tokens_total integer,
    contexte_init jsonb,
    mois_periode character varying(7),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_conversations_id_seq OWNED BY public.ia_conversations.id;


--
-- Name: ia_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_feedback (
    id integer NOT NULL,
    org_id integer NOT NULL,
    conversation_id integer NOT NULL,
    message_id integer NOT NULL,
    recommandation_id integer,
    note smallint,
    utile boolean,
    commentaire text,
    amelioration text,
    created_at timestamp without time zone
);


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_feedback_id_seq OWNED BY public.ia_feedback.id;


--
-- Name: ia_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    org_id integer NOT NULL,
    role public.rolemessage NOT NULL,
    contenu text NOT NULL,
    tokens_in integer,
    tokens_out integer,
    modele character varying(60),
    duree_ms integer,
    contexte_inject jsonb,
    regles_codes character varying[],
    created_at timestamp without time zone
);


--
-- Name: ia_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_messages_id_seq OWNED BY public.ia_messages.id;


--
-- Name: ia_recommandations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ia_recommandations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    conversation_id integer,
    message_id integer,
    parcelle_id integer,
    culture_id integer,
    categorie public.categoriereco NOT NULL,
    priorite smallint,
    titre character varying(200) NOT NULL,
    action text NOT NULL,
    justification text,
    sources jsonb,
    echeance_jours integer,
    statut public.statutreco NOT NULL,
    confiance double precision,
    created_at timestamp without time zone
);


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ia_recommandations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ia_recommandations_id_seq OWNED BY public.ia_recommandations.id;


--
-- Name: mt_alertes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_alertes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    type_alerte public.typealerte NOT NULL,
    sous_type character varying(80),
    niveau public.niveaualerte NOT NULL,
    titre character varying(200) NOT NULL,
    message text NOT NULL,
    details jsonb,
    regle_code character varying(20),
    valable_du timestamp without time zone,
    valable_au timestamp without time zone,
    lu boolean,
    lu_le timestamp without time zone,
    action_prise boolean,
    created_at timestamp without time zone
);


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_alertes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_alertes_id_seq OWNED BY public.mt_alertes.id;


--
-- Name: mt_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_conditions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    lat double precision NOT NULL,
    lon double precision NOT NULL,
    zone_agro character varying(40),
    source public.sourcemeteo,
    temp_actuelle double precision,
    temp_min double precision,
    temp_max double precision,
    humidite_rel smallint,
    pluie_mm double precision,
    vent_kmh double precision,
    direction_vent smallint,
    etp_mm double precision,
    code_meteo smallint,
    description_fr character varying(100),
    date_releve date,
    heure_releve timestamp without time zone,
    expire_le timestamp without time zone,
    created_at timestamp without time zone
);


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_conditions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_conditions_id_seq OWNED BY public.mt_conditions.id;


--
-- Name: mt_config_alertes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_config_alertes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    seuils jsonb,
    alertes_meteo_actives boolean,
    alertes_maladies_actives boolean,
    alertes_ravageurs_actives boolean,
    alertes_fertilisation_actives boolean,
    alertes_irrigation_actives boolean,
    alertes_planificateur_actives boolean,
    heure_envoi_alertes time without time zone,
    updated_at timestamp without time zone
);


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_config_alertes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_config_alertes_id_seq OWNED BY public.mt_config_alertes.id;


--
-- Name: mt_planificateur; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_planificateur (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    activite_id integer,
    date_recommandee date NOT NULL,
    type_activite character varying(50),
    titre character varying(200) NOT NULL,
    priorite smallint,
    raison text,
    fenetre_debut date,
    fenetre_fin date,
    conditions_ok boolean,
    detail_conditions jsonb,
    statut public.statutplanificateur,
    source public.sourceplanificateur,
    genere_le timestamp without time zone,
    expire_le date
);


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_planificateur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_planificateur_id_seq OWNED BY public.mt_planificateur.id;


--
-- Name: mt_previsions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mt_previsions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    lat double precision NOT NULL,
    lon double precision NOT NULL,
    zone_agro character varying(40),
    source character varying(30),
    horizon_jours smallint NOT NULL,
    donnees jsonb NOT NULL,
    genere_le timestamp without time zone,
    expire_le timestamp without time zone
);


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mt_previsions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mt_previsions_id_seq OWNED BY public.mt_previsions.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_cooperative boolean,
    created_at timestamp without time zone
);


--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: parcelles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parcelles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    nom text NOT NULL,
    culture text,
    superficie_ha numeric(10,3),
    superficie_m2 numeric(14,2),
    centre_lat double precision,
    centre_lng double precision,
    contour jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    precision_m numeric(8,1),
    methode text
);


--
-- Name: parcelles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.parcelles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parcelles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.parcelles_id_seq OWNED BY public.parcelles.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    provider character varying,
    provider_ref character varying,
    amount_ht integer,
    vat integer,
    amount_ttc integer,
    status character varying,
    created_at timestamp without time zone
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: re_declenchements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_declenchements (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    analyse_id integer,
    contexte_entree jsonb,
    resultat jsonb,
    score_confiance double precision,
    declenche_le timestamp with time zone DEFAULT now(),
    acquitte boolean,
    acquitte_le timestamp with time zone
);


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_declenchements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_declenchements_id_seq OWNED BY public.re_declenchements.id;


--
-- Name: re_parametres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_parametres (
    id integer NOT NULL,
    cle character varying(100) NOT NULL,
    valeur jsonb NOT NULL,
    categorie character varying(50),
    description text,
    modifiable_admin boolean,
    updated_at timestamp with time zone
);


--
-- Name: re_parametres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_parametres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_parametres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_parametres_id_seq OWNED BY public.re_parametres.id;


--
-- Name: re_regles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    categorie character varying(30) NOT NULL,
    sous_categorie character varying(50),
    nom character varying(250) NOT NULL,
    description text,
    zones_applicables jsonb,
    stades_applicables jsonb,
    mois_applicables jsonb,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    gravite character varying(20),
    priorite smallint,
    confiance double precision,
    plan_requis character varying(20),
    active boolean,
    source text,
    version character varying(10),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: re_regles_cultures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles_cultures (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    culture_id integer NOT NULL,
    notes text
);


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_cultures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_cultures_id_seq OWNED BY public.re_regles_cultures.id;


--
-- Name: re_regles_entites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_regles_entites (
    id integer NOT NULL,
    regle_id integer NOT NULL,
    entite_type character varying(20) NOT NULL,
    entite_id integer NOT NULL
);


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_entites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_entites_id_seq OWNED BY public.re_regles_entites.id;


--
-- Name: re_regles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_regles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_regles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_regles_id_seq OWNED BY public.re_regles.id;


--
-- Name: re_sessions_evaluation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.re_sessions_evaluation (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    contexte jsonb,
    regles_evaluees integer,
    regles_declenchees integer,
    duree_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.re_sessions_evaluation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.re_sessions_evaluation_id_seq OWNED BY public.re_sessions_evaluation.id;


--
-- Name: sc_consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_consultations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    parcelle_id integer,
    culture_id integer,
    type public.typeconsultation NOT NULL,
    statut public.statutconsultation NOT NULL,
    contexte jsonb,
    resume text,
    nb_photos smallint,
    created_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_consultations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_consultations_id_seq OWNED BY public.sc_consultations.id;


--
-- Name: sc_diagnostics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_diagnostics (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    rang smallint NOT NULL,
    entite_type public.typeentite NOT NULL,
    entite_id integer NOT NULL,
    entite_nom character varying(200),
    score_confiance double precision,
    score_rules double precision,
    score_symptomes double precision,
    regles_matches jsonb,
    methode public.methodediagnostic,
    statut public.statutdiagnostic,
    confirme_par integer,
    confirme_le timestamp without time zone,
    note_expert text,
    created_at timestamp without time zone
);


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_diagnostics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_diagnostics_id_seq OWNED BY public.sc_diagnostics.id;


--
-- Name: sc_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_observations (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    type public.typeobservation NOT NULL,
    partie_plante public.partieplante,
    valeur jsonb NOT NULL,
    note_terrain text,
    created_at timestamp without time zone
);


--
-- Name: sc_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_observations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_observations_id_seq OWNED BY public.sc_observations.id;


--
-- Name: sc_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_photos (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    observation_id integer,
    source_photo public.sourcephoto,
    filename character varying(255) NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    taille_ko integer,
    photo_meta jsonb,
    uploaded_at timestamp without time zone
);


--
-- Name: sc_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_photos_id_seq OWNED BY public.sc_photos.id;


--
-- Name: sc_rapports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_rapports (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    org_id integer NOT NULL,
    type public.typerapport NOT NULL,
    titre character varying(300) NOT NULL,
    url text NOT NULL,
    taille_ko integer,
    genere_par integer,
    genere_le timestamp without time zone,
    telechargements smallint
);


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_rapports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_rapports_id_seq OWNED BY public.sc_rapports.id;


--
-- Name: sc_suivis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_suivis (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    date_suivi date NOT NULL,
    evolution public.evolutionsuivi,
    efficacite smallint,
    note text,
    photo_url text,
    created_at timestamp without time zone
);


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_suivis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_suivis_id_seq OWNED BY public.sc_suivis.id;


--
-- Name: sc_traitements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sc_traitements (
    id integer NOT NULL,
    consultation_id integer NOT NULL,
    diagnostic_id integer,
    priorite smallint,
    type public.typetraitement NOT NULL,
    titre character varying(300) NOT NULL,
    produit character varying(200),
    dose character varying(100),
    frequence character varying(100),
    delai_carence_jours smallint,
    urgence_jours smallint,
    detail text,
    date_application date,
    statut public.statuttraitement,
    applique_le date,
    note text
);


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sc_traitements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sc_traitements_id_seq OWNED BY public.sc_traitements.id;


--
-- Name: service_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_requests (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    service_id integer NOT NULL,
    farm_id integer,
    statut public.service_statut DEFAULT 'en_attente'::public.service_statut NOT NULL,
    credits_debites integer DEFAULT 0 NOT NULL,
    entree jsonb DEFAULT '{}'::jsonb NOT NULL,
    resultat jsonb,
    erreur text,
    cree_le timestamp with time zone DEFAULT now() NOT NULL,
    demarre_le timestamp with time zone,
    termine_le timestamp with time zone
);


--
-- Name: service_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_requests_id_seq OWNED BY public.service_requests.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    code text NOT NULL,
    nom text NOT NULL,
    cout_credits integer DEFAULT 10 NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    cree_le timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    plan public.plantype NOT NULL,
    status public.substatus NOT NULL,
    started_at timestamp without time zone,
    current_period_end timestamp without time zone,
    seats integer,
    auto_renew boolean
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: usage_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_counters (
    id integer NOT NULL,
    org_id integer NOT NULL,
    period character varying,
    analyses_count integer
);


--
-- Name: usage_counters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usage_counters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usage_counters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usage_counters_id_seq OWNED BY public.usage_counters.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    org_id integer NOT NULL,
    full_name character varying NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    hashed_password character varying NOT NULL,
    role public.userrole,
    is_active boolean,
    created_at timestamp without time zone,
    account_type text DEFAULT 'particulier'::text NOT NULL,
    CONSTRAINT users_account_type_check CHECK ((account_type = ANY (ARRAY['particulier'::text, 'institution'::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    user_id integer NOT NULL,
    solde integer DEFAULT 0 NOT NULL,
    maj_le timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT wallets_solde_check CHECK ((solde >= 0))
);


--
-- Name: agro_besoins_eau id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau ALTER COLUMN id SET DEFAULT nextval('public.agro_besoins_eau_id_seq'::regclass);


--
-- Name: agro_besoins_nutritionnels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels ALTER COLUMN id SET DEFAULT nextval('public.agro_besoins_nutritionnels_id_seq'::regclass);


--
-- Name: agro_calendriers_culturaux id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux ALTER COLUMN id SET DEFAULT nextval('public.agro_calendriers_culturaux_id_seq'::regclass);


--
-- Name: agro_culture_maladies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies ALTER COLUMN id SET DEFAULT nextval('public.agro_culture_maladies_id_seq'::regclass);


--
-- Name: agro_culture_ravageurs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs ALTER COLUMN id SET DEFAULT nextval('public.agro_culture_ravageurs_id_seq'::regclass);


--
-- Name: agro_cultures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures ALTER COLUMN id SET DEFAULT nextval('public.agro_cultures_id_seq'::regclass);


--
-- Name: agro_maladies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_maladies ALTER COLUMN id SET DEFAULT nextval('public.agro_maladies_id_seq'::regclass);


--
-- Name: agro_parametres_climatiques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques ALTER COLUMN id SET DEFAULT nextval('public.agro_parametres_climatiques_id_seq'::regclass);


--
-- Name: agro_ravageurs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_ravageurs ALTER COLUMN id SET DEFAULT nextval('public.agro_ravageurs_id_seq'::regclass);


--
-- Name: agro_recommandations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations ALTER COLUMN id SET DEFAULT nextval('public.agro_recommandations_id_seq'::regclass);


--
-- Name: agro_rendements_reference id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference ALTER COLUMN id SET DEFAULT nextval('public.agro_rendements_reference_id_seq'::regclass);


--
-- Name: agro_stades_phenologiques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques ALTER COLUMN id SET DEFAULT nextval('public.agro_stades_phenologiques_id_seq'::regclass);


--
-- Name: agro_varietes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes ALTER COLUMN id SET DEFAULT nextval('public.agro_varietes_id_seq'::regclass);


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: champ_cartographies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies ALTER COLUMN id SET DEFAULT nextval('public.champ_cartographies_id_seq'::regclass);


--
-- Name: champ_infrastructures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures ALTER COLUMN id SET DEFAULT nextval('public.champ_infrastructures_id_seq'::regclass);


--
-- Name: champ_parcelles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles ALTER COLUMN id SET DEFAULT nextval('public.champ_parcelles_id_seq'::regclass);


--
-- Name: champ_sols id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols ALTER COLUMN id SET DEFAULT nextval('public.champ_sols_id_seq'::regclass);


--
-- Name: champ_sources_eau id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau ALTER COLUMN id SET DEFAULT nextval('public.champ_sources_eau_id_seq'::regclass);


--
-- Name: credit_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger ALTER COLUMN id SET DEFAULT nextval('public.credit_ledger_id_seq'::regclass);


--
-- Name: credit_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases ALTER COLUMN id SET DEFAULT nextval('public.credit_purchases_id_seq'::regclass);


--
-- Name: farms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms ALTER COLUMN id SET DEFAULT nextval('public.farms_id_seq'::regclass);


--
-- Name: gf_activites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites ALTER COLUMN id SET DEFAULT nextval('public.gf_activites_id_seq'::regclass);


--
-- Name: gf_couts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts ALTER COLUMN id SET DEFAULT nextval('public.gf_couts_id_seq'::regclass);


--
-- Name: gf_journal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal ALTER COLUMN id SET DEFAULT nextval('public.gf_journal_id_seq'::regclass);


--
-- Name: gf_main_oeuvre id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre ALTER COLUMN id SET DEFAULT nextval('public.gf_main_oeuvre_id_seq'::regclass);


--
-- Name: gf_preuves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves ALTER COLUMN id SET DEFAULT nextval('public.gf_preuves_id_seq'::regclass);


--
-- Name: ia_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config ALTER COLUMN id SET DEFAULT nextval('public.ia_config_id_seq'::regclass);


--
-- Name: ia_conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations ALTER COLUMN id SET DEFAULT nextval('public.ia_conversations_id_seq'::regclass);


--
-- Name: ia_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback ALTER COLUMN id SET DEFAULT nextval('public.ia_feedback_id_seq'::regclass);


--
-- Name: ia_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages ALTER COLUMN id SET DEFAULT nextval('public.ia_messages_id_seq'::regclass);


--
-- Name: ia_recommandations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations ALTER COLUMN id SET DEFAULT nextval('public.ia_recommandations_id_seq'::regclass);


--
-- Name: mt_alertes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes ALTER COLUMN id SET DEFAULT nextval('public.mt_alertes_id_seq'::regclass);


--
-- Name: mt_conditions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions ALTER COLUMN id SET DEFAULT nextval('public.mt_conditions_id_seq'::regclass);


--
-- Name: mt_config_alertes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes ALTER COLUMN id SET DEFAULT nextval('public.mt_config_alertes_id_seq'::regclass);


--
-- Name: mt_planificateur id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur ALTER COLUMN id SET DEFAULT nextval('public.mt_planificateur_id_seq'::regclass);


--
-- Name: mt_previsions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions ALTER COLUMN id SET DEFAULT nextval('public.mt_previsions_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: parcelles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles ALTER COLUMN id SET DEFAULT nextval('public.parcelles_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: re_declenchements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements ALTER COLUMN id SET DEFAULT nextval('public.re_declenchements_id_seq'::regclass);


--
-- Name: re_parametres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_parametres ALTER COLUMN id SET DEFAULT nextval('public.re_parametres_id_seq'::regclass);


--
-- Name: re_regles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles ALTER COLUMN id SET DEFAULT nextval('public.re_regles_id_seq'::regclass);


--
-- Name: re_regles_cultures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures ALTER COLUMN id SET DEFAULT nextval('public.re_regles_cultures_id_seq'::regclass);


--
-- Name: re_regles_entites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites ALTER COLUMN id SET DEFAULT nextval('public.re_regles_entites_id_seq'::regclass);


--
-- Name: re_sessions_evaluation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_sessions_evaluation ALTER COLUMN id SET DEFAULT nextval('public.re_sessions_evaluation_id_seq'::regclass);


--
-- Name: sc_consultations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations ALTER COLUMN id SET DEFAULT nextval('public.sc_consultations_id_seq'::regclass);


--
-- Name: sc_diagnostics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics ALTER COLUMN id SET DEFAULT nextval('public.sc_diagnostics_id_seq'::regclass);


--
-- Name: sc_observations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations ALTER COLUMN id SET DEFAULT nextval('public.sc_observations_id_seq'::regclass);


--
-- Name: sc_photos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos ALTER COLUMN id SET DEFAULT nextval('public.sc_photos_id_seq'::regclass);


--
-- Name: sc_rapports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports ALTER COLUMN id SET DEFAULT nextval('public.sc_rapports_id_seq'::regclass);


--
-- Name: sc_suivis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis ALTER COLUMN id SET DEFAULT nextval('public.sc_suivis_id_seq'::regclass);


--
-- Name: sc_traitements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements ALTER COLUMN id SET DEFAULT nextval('public.sc_traitements_id_seq'::regclass);


--
-- Name: service_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests ALTER COLUMN id SET DEFAULT nextval('public.service_requests_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: usage_counters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters ALTER COLUMN id SET DEFAULT nextval('public.usage_counters_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: agro_besoins_eau; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_besoins_eau (id, culture_id, stade, besoin_mm_semaine, sensibilite, frequence_irrigation, notes) FROM stdin;
94	21	Tallage	70.0	elevee	Maintien lame d'eau 5 cm en continu	Tout déficit hydrique réduit le nombre de talles fertiles.
93	21	Semis / Repiquage	50.0	critique	Inondation permanente + appoint quotidien	Lame d'eau de 3-5 cm indispensable pour la reprise des plants.
95	21	Montaison / Épiaison	80.0	critique	Lame d'eau 5-8 cm, aucune interruption tolérée	Stress hydrique à ce stade peut réduire le rendement de 40-60%.
96	21	Floraison / Grain laiteux	70.0	elevee	Maintien humidité sol, lame d'eau 3-5 cm	Chaleur excessive + sécheresse cause stérilité des épillets.
97	21	Maturité / Récolte	20.0	faible	Arrêt irrigation 10-15 jours avant récolte	Assèchement contrôlé facilite la mécanisation et réduit les maladies.
98	22	Semis	25.0	critique	Apport unique avant semis pour humidifier le sol	Sol doit être humide sur 30 cm de profondeur pour assurer la germination.
99	22	Croissance végétative	40.0	moyenne	Tous les 5-7 jours en absence de pluie	La plante peut tolérer une courte sécheresse à ce stade.
100	22	Floraison	60.0	critique	Tous les 3-4 jours si pas de pluie	Manque d'eau 10 jours avant/après la floraison = réduction de 50% du rendement.
101	22	Remplissage des grains	50.0	elevee	Tous les 5 jours	Humidité nécessaire pour le remplissage ; réduire progressivement à l'approche de la maturité.
102	22	Maturité / Récolte	10.0	faible	Arrêt 2 semaines avant récolte	Sécheresse finale favorise le séchage sur pied et réduit les maladies de stockage.
103	23	Semis	20.0	critique	Sol doit être humide sur 20 cm à la mise en place	Germination requiert un sol humide ; sécheresse immédiate après semis = échec de levée.
104	23	Croissance végétative	30.0	moyenne	Tous les 7-10 jours en absence de pluie	Culture assez tolérante à ce stade ; éviter l'engorgement.
105	23	Floraison	40.0	elevee	Tous les 5-7 jours	Déficit hydrique à la floraison réduit la nouaison et la pénétration des gynophores.
106	23	Fructification / Grossissement	40.0	elevee	Tous les 5-7 jours	Humidité régulière indispensable pour le développement des gousses.
107	23	Maturité / Récolte	10.0	faible	Arrêt irrigation 2-3 semaines avant récolte	Sol trop humide à la récolte rend l'arrachage difficile et favorise les moisissures.
108	24	Semis	20.0	critique	Dépendant des pluies ; 30 mm au semis indispensables	Culture pluviale ; semer uniquement après pluies suffisantes pour éviter echec levée.
109	24	Tallage	25.0	elevee	Pluies hebdomadaires suffisantes	Période de stress peut réduire le nombre de talles fertiles.
110	24	Montaison	35.0	elevee	Pluies tous les 7-10 jours	Stress à la montaison raccourcit la panicule.
111	24	Épiaison / Floraison	40.0	critique	Pluie ou irrigation tous les 5-7 jours	Stade le plus sensible au déficit hydrique : stérilité des grains si sécheresse.
112	24	Maturité / Récolte	10.0	faible	Sécheresse de fin de saison naturelle	Sécheresse en fin de cycle assure maturation et facilite battage.
113	25	Semis	20.0	critique	Pluie ≥ 25 mm avant semis	Le sorgho est très sensible à la sécheresse à la levée ; sol doit être humide.
114	25	Tallage	30.0	elevee	Pluies tous les 7-10 jours	Tolérance à la sécheresse supérieure au maïs mais sensible au tallage.
115	25	Montaison	35.0	elevee	Pluies tous les 7 jours	Le sorgho entre en quiescence en cas de sécheresse et reprend si la pluie revient.
116	25	Floraison	45.0	critique	Irrigation tous les 5-7 jours si culture irriguée	Stade le plus sensible ; sécheresse à la floraison cause stérilité et panicules vides.
117	25	Maturité / Récolte	10.0	faible	Sécheresse naturelle en fin de saison	Excellente tolérance à la sécheresse terminale ; peut laisser mûrir sur pied.
118	26	Semis	20.0	critique	Sol humide sur 20 cm avant semis	Niébé très sensible à la sécheresse en germination.
119	26	Croissance végétative	25.0	moyenne	Tous les 7-10 jours si pas de pluie	Tolérance modérée à la sécheresse à ce stade.
120	26	Floraison	35.0	elevee	Tous les 5-7 jours	Déficit hydrique à la floraison provoque l'avortement des fleurs.
121	26	Fructification / Remplissage	30.0	elevee	Tous les 7 jours	Humidité nécessaire pour le remplissage des grains.
122	26	Maturité / Récolte	5.0	faible	Arrêt irrigation 10 jours avant récolte	Sol sec favorise la récolte et réduit les moisissures sur gousses.
123	27	Semis	15.0	critique	Sol humide sur 10 cm ; graines très sensibles à la dessiccation	Graines minuscules : une croûte de battance peut empêcher la levée.
124	27	Croissance végétative	25.0	moyenne	Tous les 7-10 jours en absence de pluie	Sésame tolère la sécheresse mais croissance ralentie.
125	27	Floraison	35.0	elevee	Tous les 5-7 jours	Avortement floral si stress hydrique à la floraison.
126	27	Fructification / Remplissage	30.0	moyenne	Tous les 7-10 jours	Excès d'eau cause la pourriture des capsules ; arrêter tôt.
127	27	Maturité / Récolte	5.0	faible	Arrêt total 2-3 semaines avant récolte	Séchage sur pied est indispensable ; pluie tardive cause perte par déhiscence.
128	28	Plantation (bouturage)	25.0	critique	Sol humide impératif les 2-3 premières semaines	Boutures ne peuvent développer des racines qu'en sol humide.
129	28	Croissance végétative	35.0	moyenne	Tous les 7-14 jours en saison sèche	Manioc supporte la sécheresse mais croissance ralentie ; pas adapté aux longues sécheresses.
130	28	Tubérisation active	40.0	elevee	Tous les 7-10 jours en saison sèche	Humidité régulière indispensable pour le remplissage des tubercules.
131	28	Maturation	20.0	faible	Tous les 14 jours, arrêt progressif	Réduction de l'eau concentre l'amidon et facilite l'arrachage.
132	28	Récolte	0.0	faible	Sol légèrement humide facilite l'arrachage	Sol trop sec rend l'arrachage difficile ; sol trop humide cause pourriture.
133	29	Pépinière	20.0	critique	2 fois/jour (matin et soir)	Sol toujours humide mais pas détrempé pour éviter la fonte des semis.
134	29	Repiquage / Reprise	35.0	critique	Tous les jours pendant 7-10 jours	Arrosage copieux immédiatement après repiquage pour favoriser la reprise racinaire.
135	29	Croissance végétative	40.0	moyenne	Tous les 2-3 jours (goutte-à-goutte idéal)	Sol maintenu humide mais non gorgé pour éviter les maladies racinaires.
136	29	Floraison	45.0	elevee	Tous les 2 jours	Stress hydrique à la floraison = chute des fleurs et avortement des fruits.
137	29	Fructification / Grossissement	55.0	elevee	Tous les 2 jours, régulier	Irrégularité d'arrosage cause la BER (nécrose apicale) et l'éclatement des fruits.
138	29	Récolte	35.0	moyenne	Tous les 3 jours	Réduire l'irrigation en fin de cycle pour améliorer la qualité gustative et la conservation.
139	30	Pépinière	25.0	elevee	2 fois/jour (matin et soir)	Sol humide en permanence ; micro-arrosage recommandé pour ne pas déchausser les semis.
140	30	Repiquage / Reprise	40.0	critique	Quotidienne les 7 premiers jours	Reprise racinaire critique ; ne pas laisser sécher le sol.
141	30	Croissance végétative	35.0	elevee	Tous les 3 jours	L'oignon a un système racinaire superficiel ; ne pas laisser le sol se dessécher.
142	30	Formation du bulbe	30.0	elevee	Tous les 3-4 jours	Apport d'eau régulier pour grossissement uniforme ; excès = bulbes mous.
143	30	Maturation / Récolte	5.0	faible	Arrêt 10-15 jours avant récolte	Assèchement contrôlé durcit les bulbes et améliore la conservation.
144	31	Pépinière	20.0	elevee	2 fois/jour	Sol humide permanent ; germination lente du piment (10-15 jours).
145	31	Repiquage / Reprise	30.0	critique	Quotidienne pendant 5-7 jours	Très sensible au stress hydrique à la reprise.
146	31	Croissance végétative	35.0	moyenne	Tous les 3-4 jours	Tolérance à la légère sécheresse en cours de cycle.
147	31	Floraison	40.0	elevee	Tous les 2-3 jours	Stress hydrique à la floraison = chute des fleurs et avortement.
148	31	Fructification et récolte	40.0	elevee	Tous les 3 jours	Réguler l'irrigation pour éviter la pourriture des fruits.
149	32	Semis	20.0	elevee	Tous les 2-3 jours	Sol humide sur 10 cm pour assurer la germination.
150	32	Croissance végétative	35.0	moyenne	Tous les 4-5 jours	Gombo est relativement tolérant à la chaleur et légère sécheresse.
151	32	Floraison et fructification	45.0	elevee	Tous les 3-4 jours	Arrosage régulier pour production continue de fruits tendres ; stress = fibrosité.
152	33	Pépinière	20.0	elevee	2 fois/jour	Substrat toujours humide sans être détrempé.
153	33	Croissance végétative	40.0	moyenne	Tous les 3 jours	Tolérant à la chaleur mais sensible à la sécheresse prolongée.
154	33	Floraison / Fructification	50.0	elevee	Tous les 2-3 jours	Régularité impérative pour éviter la chute des fleurs et la BER.
155	34	Pépinière	15.0	elevee	2 fois/jour (léger)	Humidité constante sans excès pour éviter la fonte des semis.
156	34	Croissance feuillaire	45.0	elevee	Tous les 2-3 jours	Forte demande en eau pendant la phase de croissance feuillaire.
157	34	Formation de la pomme	50.0	critique	Tous les 2 jours	Manque d'eau = pomme petite et peu dense ; excès = pourriture.
158	34	Récolte	20.0	faible	Tous les 5 jours	Réduire l'irrigation avant récolte pour éviter l'éclatement des pommes.
159	35	Semis	20.0	critique	Tous les 2 jours	Sol humide sur 15 cm pour assurer la germination.
160	35	Croissance végétative	35.0	moyenne	Tous les 3 jours	Éviter l'engorgement qui favorise les maladies racinaires.
161	35	Floraison	45.0	elevee	Tous les 2 jours	Stress hydrique à la floraison = avortement et fruits amers.
162	35	Fructification / Récolte	55.0	elevee	Tous les 2 jours, régulier	Régularité cruciale ; variations d'humidité = fruits tordus ou amers.
163	36	Semis	20.0	elevee	Tous les 2-3 jours	Sol humide pour germination ; sécheresse immédiate = échec.
164	36	Croissance végétative	35.0	moyenne	Tous les 4-5 jours	Pastèque tolère mieux la sécheresse que concombre ou tomate.
165	36	Floraison	45.0	elevee	Tous les 3 jours	Manque d'eau = avortement des fruits.
166	36	Grossissement des fruits	55.0	elevee	Tous les 3 jours, puis réduire	Besoins importants pendant le grossissement ; réduire 10 jours avant récolte.
167	36	Maturité / Récolte	15.0	faible	Arrêt 7-10 jours avant récolte	Réduction de l'arrosage améliore le sucre et réduit les risques d'éclatement.
168	37	Floraison	10.0	critique	Stress hydrique intentionnel 4-6 semaines avant floraison souhaitée	Le manque d'eau en novembre-décembre induit la floraison ; arroser uniquement si sécheresse sévère.
169	37	Nouaison	20.0	elevee	Irrigation légère tous les 7-10 jours si pas de pluie	Pluie à la floraison = anthracnose sévère ; préférer les périodes sèches.
170	37	Croissance des fruits	35.0	elevee	Tous les 7 jours en mars-avril (saison sèche)	Déficit hydrique en mars-avril = chute prématurée des fruits.
171	37	Maturité / Récolte	15.0	faible	Réduire l'irrigation 2-3 semaines avant récolte	Concentration des sucres améliorée par légère réduction de l'eau.
172	37	Post-récolte / Entretien	30.0	faible	Pluies d'hivernage suffisantes ; irrigation d'appoint si nécessaire	Saison des pluies couvre la majorité des besoins post-récolte.
173	38	Floraison	5.0	critique	Aucune irrigation (saison sèche) ; naturellement adapté	L'anacarde fleurit en saison sèche naturellement ; pluie à la floraison = anthracnose.
174	38	Nouaison	15.0	elevee	Aucune irrigation en production normale	Stress hydrique modéré toléré ; culture résistante à la sécheresse.
175	38	Maturité / Récolte	20.0	faible	Pluies de fin de saison sèche suffisent	Récolte de mars à mai ; les premières pluies favorisent le grossissement final.
176	38	Post-récolte / Entretien	40.0	faible	Pluies d'hivernage (juin-septembre) suffisantes	Croissance végétative pendant l'hivernage grâce aux pluies.
177	39	Plantation / Levée	40.0	critique	Quotidienne les 2 premières semaines	Enracinement critique ; ne jamais laisser sécher le sol.
178	39	Croissance végétative	60.0	elevee	Tous les 2-3 jours (goutte-à-goutte recommandé)	Banane a les besoins en eau les plus élevés des cultures fruitières au Sénégal.
179	39	Floraison / Formation du régime	70.0	critique	Tous les 2 jours	Manque d'eau à ce stade réduit la taille et le nombre de mains.
180	39	Maturité / Récolte	50.0	elevee	Tous les 3 jours	Maintenir l'irrigation jusqu'à la récolte.
181	40	Pépinière	20.0	elevee	2 fois/jour (modéré)	Très sensible à l'engorgement ; sol humide mais jamais détrempé.
182	40	Croissance végétative	50.0	elevee	Tous les 2-3 jours au goutte-à-goutte	Papaye est exigeante en eau mais INTOLERANTE à l'engorgement = mort du plant.
183	40	Floraison / Fructification	60.0	critique	Tous les 2 jours	Stress hydrique = chute des fruits ; excès = Pythium et pourriture du collet.
184	40	Récolte continue	55.0	elevee	Tous les 2-3 jours toute l'année	Maintenir l'irrigation constante pour une production continue.
\.


--
-- Data for Name: agro_besoins_nutritionnels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_besoins_nutritionnels (id, culture_id, stade, azote_kg_ha, phosphore_kg_ha, potassium_kg_ha, calcium_kg_ha, magnesium_kg_ha, engrais_recommandes, moment_application, notes) FROM stdin;
61	21	total	120.0	30.0	60.0	20.0	10.0	Urée 46% (260 kg/ha), DAP (65 kg/ha), KCl (100 kg/ha)	DAP au semis/repiquage ; Urée en 3 fractions (reprise, tallage actif, épiaison)	Fractionnement obligatoire de l'azote pour limiter les pertes par volatilisation.
62	21	Tallage	40.0	0.0	30.0	0.0	0.0	Urée 46% (87 kg/ha), KCl (50 kg/ha)	À 21-25 jours après repiquage, en début de tallage actif	Application sur sol inondé ; incorporer légèrement pour éviter les pertes.
63	21	Épiaison	40.0	0.0	0.0	0.0	0.0	Urée 46% (87 kg/ha)	10 jours avant épiaison visible (gonflement de la panicule)	Azote panicule critique pour le remplissage des grains et la qualité.
95	32	Croissance végétative	40.0	40.0	40.0	10.0	5.0	NPK 15-15-15 (150 kg/ha)	À J25-30 en couverture autour des plants	Une seule application de NPK suffit pour la phase végétative.
64	22	total	100.0	46.0	60.0	25.0	12.0	DAP (100 kg/ha au semis), Urée 46% (220 kg/ha en 2 fractions), KCl (100 kg/ha)	DAP au semis ; urée 1/2 à V4, 1/2 avant montaison ; KCl au semis	Maïs est très exigeant en azote ; le fractionnement est impératif pour éviter la verse.
65	22	Semis	0.0	46.0	60.0	0.0	0.0	DAP (100 kg/ha) + KCl (100 kg/ha) en fond de poquet	Au moment du semis, en fond de poquet à 5 cm sous la graine	Ne pas mettre l'engrais en contact direct avec la graine (brûlure).
66	22	Croissance végétative (V4)	50.0	0.0	0.0	0.0	0.0	Urée 46% (109 kg/ha)	Stade V4 (4 feuilles bien développées), en couronne autour du plant	Arroser après application pour dissolution et absorption rapide.
67	23	total	20.0	30.0	50.0	30.0	8.0	Phosphate de Thiès (250 kg/ha) ou DAP (65 kg/ha), gypse (100 kg/ha), KCl (80 kg/ha)	Phosphate et gypse au semis ; azote symbolique uniquement si pas d'inoculant	Légumineuse : fixe 80-150 kg N/ha via symbiose ; éviter l'azote minéral qui inhibe la fixation.
68	23	Semis	0.0	30.0	50.0	20.0	0.0	Phosphate de Thiès (250 kg/ha) + KCl (80 kg/ha) + inoculant Rhizobium	En fond de poquet au semis ; inoculant sur la graine avant semis	Le phosphore est l'élément limitant le plus important pour l'arachide au Sénégal.
69	23	Fructification	0.0	0.0	0.0	10.0	0.0	Gypse (CaSO4) 100 kg/ha	Au début de la pénétration des gynophores (J50-60)	Calcium indispensable pour la formation des gousses et la prévention des grains vides.
70	24	total	60.0	20.0	30.0	10.0	5.0	DAP (45 kg/ha) + Urée 46% (130 kg/ha)	DAP au semis ; urée en 2 fractions (démariage J15, tallage J30)	Mil est relativement peu exigeant ; éviter excès d'azote qui favorise la verse.
71	24	Semis	0.0	20.0	15.0	0.0	0.0	DAP (45 kg/ha) ou Phosphate de Thiès (150 kg/ha)	Au semis, enfoui dans le poquet	Le phosphore de Thiès est moins soluble mais moins onéreux ; efficace sur sols acides.
72	24	Tallage	60.0	0.0	15.0	0.0	0.0	Urée 46% (130 kg/ha) en 2 apports	1er apport à J15 après levée, 2e à J30 au tallage actif	Appliquer en couronne à 5-10 cm des plants après une pluie ou irrigation.
73	25	total	80.0	25.0	40.0	15.0	8.0	DAP (55 kg/ha) + Urée 46% (175 kg/ha) + KCl (65 kg/ha)	DAP et KCl au semis ; urée en 2 fractions (J20, J45)	Sorgho plus tolérant que le maïs aux sols pauvres ; la fumure organique est très valorisée.
74	25	Semis	0.0	25.0	40.0	0.0	0.0	DAP (55 kg/ha) ou Phosphate de Thiès (200 kg/ha) + KCl (65 kg/ha)	En fond de poquet au semis	La fumure de fond est essentielle ; le sorgho valorise bien le phosphate naturel de Thiès.
75	25	Tallage actif	80.0	0.0	0.0	0.0	0.0	Urée 46% (175 kg/ha) en 2 apports égaux	1er apport J20 après levée, 2e à J40-45	Appliquer en couronne après pluie ou irrigation pour éviter la volatilisation.
76	26	total	15.0	20.0	30.0	15.0	5.0	Phosphate de Thiès (200 kg/ha) ou DAP (45 kg/ha) + inoculant Rhizobium	Phosphore au semis ; pas d'azote minéral (fixation biologique suffisante)	Légumineuse fixant 50-100 kg N/ha ; l'azote minéral est contre-indiqué.
77	26	Semis	0.0	20.0	30.0	0.0	0.0	DAP (45 kg/ha) + KCl (50 kg/ha) en fond de poquet + inoculant	Au semis, engrais déposé sous la graine	Le phosphore est l'élément limitant le plus fréquent pour le niébé au Sénégal.
78	26	Floraison	0.0	0.0	0.0	15.0	0.0	Pas d'engrais minéral ; surveiller carence en molybdène (Mo)	Application foliaire de molybdate d'ammonium 50 g/ha si carence	La carence en Mo inhibe la fixation d'azote ; important en sols acides.
79	27	total	30.0	15.0	20.0	10.0	5.0	DAP (33 kg/ha) + Urée 46% (65 kg/ha) + KCl (33 kg/ha)	DAP et KCl au semis (fond) ; urée en 1 apport à J20-25	Sésame est peu exigeant en engrais ; excès d'azote favorise la végétation au détriment des graines.
80	27	Semis	0.0	15.0	20.0	0.0	0.0	DAP (33 kg/ha) + KCl (33 kg/ha) incorporés au sol avant semis	Incorporation légère (5 cm) avant semis pour ne pas brûler les graines	Sésame est sensible à la salinité ; ne pas dépasser les doses recommandées.
81	27	Croissance végétative (J20-25)	30.0	0.0	0.0	0.0	0.0	Urée 46% (65 kg/ha)	En couronne à 5-8 cm des plants, après pluie ou irrigation	Apport unique d'azote ; ne pas dépasser pour éviter la verse.
82	28	total	80.0	40.0	120.0	30.0	15.0	NPK 15-15-15 (270 kg/ha) + KCl (170 kg/ha) + Urée 46% (110 kg/ha)	NPK à J30 (plantation) ; KCl et urée complémentaires à J90	Manioc est très exigeant en potassium (K) qui est l'élément le plus exporté par les tubercules.
83	28	Plantation (J30-45)	40.0	40.0	60.0	0.0	0.0	NPK 15-15-15 (270 kg/ha)	À J30-45 après plantation, en couronne à 15-20 cm des plants	Premier apport de fond ; ne pas fertiliser avant J30 pour éviter de brûler les racines naissantes.
84	28	Tubérisation (J90)	40.0	0.0	60.0	0.0	0.0	Urée 46% (87 kg/ha) + KCl (100 kg/ha)	À J90, début de la tubérisation active	Le potassium est critique pour la qualité et le rendement des tubercules.
85	29	total	150.0	60.0	200.0	80.0	25.0	NPK 15-15-15 (300 kg/ha), Urée (200 kg/ha), KNO3 (200 kg/ha), CaNO3 (100 kg/ha)	NPK à la plantation ; Urée en couverture J20 et J40 ; KNO3 à la floraison	Tomate est très exigeante en K et Ca. Carence en Ca = BER (nécrose apicale).
86	29	Plantation	20.0	60.0	50.0	30.0	8.0	DAP (130 kg/ha) + KCl (80 kg/ha) en fond de trou	Au moment du repiquage, dans le trou de plantation	Ne pas mettre en contact direct avec les racines.
87	29	Floraison / Fructification	60.0	0.0	120.0	40.0	10.0	KNO3 (200 kg/ha) + CaNO3 (100 kg/ha) en fertirrigation	En plusieurs fractions à la floraison et au grossissement des fruits	Potassium élevé améliore la coloration, la fermeté et la durée de conservation.
88	30	total	120.0	50.0	120.0	30.0	15.0	NPK 15-15-15 (200 kg/ha), Urée (200 kg/ha), KCl (100 kg/ha)	NPK au repiquage ; Urée à J70 et J90 ; KCl à la formation du bulbe	Réduire l'azote après J100 pour ne pas retarder la bulbification.
89	30	Repiquage	30.0	50.0	30.0	10.0	5.0	NPK 15-15-15 (200 kg/ha)	En fond de billon au moment du repiquage	Base indispensable pour assurer la reprise et la croissance initiale.
90	30	Formation du bulbe	0.0	0.0	60.0	10.0	5.0	KCl (100 kg/ha) en couverture	À J100-110 au début de formation visible du bulbe	Potassium améliore la grosseur, la fermeté et la conservation des bulbes.
91	31	total	100.0	50.0	120.0	40.0	15.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha), KNO3 (150 kg/ha)	NPK à la plantation, Urée à J60, KNO3 à la fructification	Potassium essentiel pour la qualité et la piquant des fruits.
92	31	Plantation	15.0	50.0	30.0	15.0	5.0	DAP (110 kg/ha) + KCl (50 kg/ha)	En fond de trou au moment de la plantation	Phosphore indispensable pour l'enracinement.
93	31	Fructification	30.0	0.0	60.0	15.0	5.0	KNO3 (150 kg/ha) en fertigation	En début de fructification (J85-95)	K et Ca réduisent la chute prématurée des fruits.
94	32	total	80.0	40.0	80.0	20.0	10.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha)	NPK à J30, Urée à J55 en couverture	Gombo est peu exigeant en fertilisation si sol bien préparé avec compost.
96	32	Fructification	30.0	0.0	30.0	5.0	3.0	Urée (65 kg/ha) + KCl (50 kg/ha)	Au début de la fructification (J55) pour prolonger la production	Maintenir la nutrition pour éviter le vieillissement prématuré des plants.
97	33	total	120.0	50.0	130.0	40.0	15.0	NPK 15-15-15 (150 kg/ha), Urée (150 kg/ha), KCl (100 kg/ha)	NPK à la plantation ; Urée à J60 et J90 ; KCl à la fructification	Exigeante en K et Ca comme toutes les solanacées.
98	33	Plantation	20.0	50.0	40.0	15.0	5.0	DAP (110 kg/ha) + KCl (65 kg/ha)	En fond de trou au repiquage	Phosphore pour l'enracinement.
99	33	Fructification	40.0	0.0	60.0	15.0	5.0	Urée (90 kg/ha) + KCl (100 kg/ha)	À J85-95 pour soutenir la fructification continue	Potassium améliore la qualité et la fermeté des fruits.
100	34	total	150.0	60.0	150.0	50.0	20.0	NPK 15-15-15 (200 kg/ha), Urée (220 kg/ha), KCl (100 kg/ha)	NPK à la plantation ; Urée à J45 et J65 ; KCl à J65	Chou est très exigeant en azote et calcium. Carence Ca = brûlures internes (tipburn).
101	34	Plantation	30.0	60.0	50.0	20.0	8.0	NPK 15-15-15 (200 kg/ha) + compost (5 t/ha)	En fond de planche avant repiquage	Compost améliore la structure du sol et la rétention en eau.
102	34	Formation de la pomme	50.0	0.0	80.0	20.0	8.0	Urée (110 kg/ha) + KCl (130 kg/ha) + CaO folaire	À J60-65, début de formation de la pomme	Potassium améliore la densité de la pomme et la durée de conservation.
103	35	total	100.0	50.0	100.0	30.0	12.0	NPK 15-15-15 (150 kg/ha), Urée (100 kg/ha), KCl (80 kg/ha)	NPK à J15 ; Urée à J35 ; KCl à J55	Cucurbitacée peu exigeante mais répondant bien aux apports équilibrés.
104	35	Semis / Croissance	20.0	50.0	30.0	10.0	4.0	NPK 15-15-15 (150 kg/ha)	À J15 en couronne autour des plants	Application précoce pour soutenir la croissance végétative rapide.
105	35	Fructification	30.0	0.0	50.0	10.0	4.0	Urée (65 kg/ha) + KCl (80 kg/ha)	À J50-55 pour soutenir la fructification	Potassium améliore la qualité et réduit l'amertume des fruits.
106	36	total	100.0	60.0	150.0	30.0	15.0	NPK 15-15-15 (200 kg/ha), Urée (100 kg/ha), KCl (130 kg/ha)	NPK au semis ; Urée à J40 ; KCl à J60 pour le sucre	Potassium élevé est essentiel pour la teneur en sucre et la qualité des fruits.
107	36	Semis / Levée	20.0	60.0	50.0	10.0	5.0	NPK 15-15-15 (200 kg/ha) en fond de poquet	Au moment du semis, sous la graine	Base phosphorée pour l'enracinement et le développement initial.
108	36	Grossissement	30.0	0.0	80.0	10.0	5.0	Urée (65 kg/ha) + KCl (130 kg/ha)	À J55-60, début de grossissement rapide des fruits	Apport de K à ce stade = meilleur goût, meilleure conservation.
109	37	total	100.0	40.0	120.0	30.0	20.0	NPK 15-15-15 (500 g/arbre) + KCl (200 g/arbre) + compost (10 kg/arbre)	NPK après la récolte (août) + KCl en janvier pour la floraison	Fertilisation par arbre, pas par hectare. Densité typique : 100-200 arbres/ha.
110	37	Post-récolte (floraison suivante)	60.0	40.0	60.0	15.0	10.0	NPK 15-15-15 (500 g/arbre) + compost (10 kg/arbre) en août-septembre	Après la récolte, pendant la saison des pluies pour bonne absorption	Réserves nutritionnelles construites ici seront mobilisées à la floraison.
111	37	Induction florale	0.0	0.0	40.0	5.0	5.0	KNO3 folaire (2%) + micronutriments en janvier	Application foliaire 2-4 semaines avant floraison souhaitée	KNO3 folaire stimule l'induction florale et améliore la nouaison.
112	38	total	60.0	25.0	80.0	15.0	10.0	NPK 15-15-15 (200 g/arbre) + compost (5 kg/arbre)	En début de saison des pluies (juillet) pour l'absorption maximale	Anacarde peu exigeant en intrants ; sols pauvres tolérés. Éviter excès d'azote.
113	38	Jeune plantation (0-3 ans)	30.0	25.0	30.0	10.0	5.0	NPK 15-15-15 (100 g/plant) + compost (3 kg/plant)	En juillet-août chaque année pendant les 3 premières années	Jeunes plants ont besoin d'un appui en phosphore pour l'enracinement.
114	38	Arbre adulte en production	30.0	0.0	50.0	5.0	5.0	KCl (100 g/arbre) + urée (50 g/arbre) en juillet	Après la récolte, début saison des pluies	Potassium améliore la taille et la qualité des noix.
115	39	total	300.0	60.0	600.0	80.0	40.0	Urée (650 kg/ha/an), DAP (130 kg/ha), KCl (1000 kg/ha/an), compost (20 t/ha)	Fractionné tous les 2 mois ; K est l'élément le plus limitant	Banane est de loin la culture la plus exigeante en potassium. KCl obligatoire.
116	39	Croissance végétative (mensuel)	25.0	5.0	50.0	7.0	3.0	Urée (55 g/plant) + KCl (120 g/plant) par mois	Application mensuelle en ceinture à 50 cm du plant	Fractionnement mensuel obligatoire pour la banane (sol sableux = lixiviation).
117	39	Montaison / Floraison	30.0	0.0	80.0	10.0	5.0	KCl (200 g/plant) + CaNO3 (50 g/plant) à la montaison	Dès le gonflement du cœur (montaison imminente)	Apport de K à ce stade améliore directement le poids du régime.
118	40	total	200.0	80.0	250.0	60.0	30.0	Urée (435 kg/ha/an), DAP (175 kg/ha), KCl (415 kg/ha/an)	Fractionné tous les 2 mois ; K indispensable pour le sucre des fruits	Forte exigence en K et Ca. Fertilisation régulière = production continue.
119	40	Plantation	30.0	80.0	50.0	15.0	8.0	DAP (175 kg/ha) + compost (10 kg/plant) en fond de trou	Au moment de la plantation dans le trou préparé	Phosphore crucial pour l'enracinement rapide après transplantation.
120	40	Fructification (mensuel)	15.0	0.0	20.0	5.0	2.0	Urée (35 g/plant) + KCl (50 g/plant) par mois	Application mensuelle en ceinture à 50 cm du tronc	Maintenir la fertilisation mensuelle pour production continue.
\.


--
-- Data for Name: agro_calendriers_culturaux; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_calendriers_culturaux (id, culture_id, zone_agro, saison, mois_semis_debut, mois_semis_fin, mois_recolte_debut, mois_recolte_fin, remarques) FROM stdin;
69	21	vallee_fleuve	hivernage	7	8	10	11	Culture irriguée ; pépinière en juillet, repiquage août, récolte octobre-novembre.
70	21	vallee_fleuve	contre_saison	1	2	5	6	Deuxième cycle irrigué (saison chaude) ; rendements souvent inférieurs à cause de la chaleur.
71	21	casamance	hivernage	6	7	10	11	Riz pluvial en bas-fonds ; risque de sécheresse en début de cycle.
72	21	senegal_oriental	hivernage	6	7	10	11	Bas-fonds aménagés ; variétés pluviales tolérantes à la sécheresse recommandées.
73	22	bassin_arachidier	hivernage	6	7	9	10	Principal bassin de production ; semis dès premières pluies (60 mm cumulés).
74	22	casamance	hivernage	6	7	10	11	Pluviométrie abondante favorable ; risque de maladies fongiques à surveiller.
75	22	vallee_fleuve	contre_saison	11	1	3	4	Culture irriguée en contre-saison froide ; températures favorables pour le maïs.
76	22	senegal_oriental	hivernage	6	7	10	11	Zone à forte pluviométrie ; bon potentiel de rendement avec intrants.
77	23	bassin_arachidier	hivernage	6	7	9	10	Cœur de la campagne arachidière ; GOANA en juin-juillet avec les premières pluies (30-40 mm).
78	23	zone_sylvopastorale	hivernage	7	7	10	10	Variétés hâtives obligatoires (55-437, Fleur 11) compte tenu de la courte saison des pluies.
79	23	casamance	hivernage	6	7	10	11	Pluviométrie favorable ; variétés semi-tardives à haut rendement possibles.
80	23	senegal_oriental	hivernage	6	7	10	11	Bon potentiel ; risque de cercosporiose lié à l'humidité prolongée.
81	24	bassin_arachidier	hivernage	6	7	9	10	Première culture semée après les pluies ; variétés hâtives pour zone centrale.
82	24	zone_sylvopastorale	hivernage	7	7	10	10	Saison courte ; variétés très hâtives (Souna 3, <85 jours) indispensables.
83	24	casamance	hivernage	6	7	10	11	Variétés Sanio locales tardives possibles grâce à la pluviométrie suffisante.
84	24	senegal_oriental	hivernage	6	7	10	10	Conditions favorables ; compétition avec le sorgho et le maïs pour les terres.
85	25	bassin_arachidier	hivernage	6	7	10	11	En association avec mil ou niébé ; semis après mil en début de saison.
86	25	senegal_oriental	hivernage	6	7	10	11	Zone à fort potentiel ; sorgho en rotation avec maïs ou coton.
87	25	casamance	hivernage	6	7	11	12	Variétés photopériodiques locales à cycle long ; récolte en décembre.
88	25	zone_sylvopastorale	hivernage	7	7	10	11	Variétés hâtives impératives ; sorgho concurrent du mil dans cette zone.
89	26	bassin_arachidier	hivernage	7	8	9	10	Cultivé en rotation ou en association avec l'arachide et le mil.
90	26	niayes	contre_saison	2	4	5	6	Culture irriguée de contre-saison chaude ; marché de légumes frais.
91	26	casamance	hivernage	7	8	10	11	Bon potentiel en Casamance ; associé avec sorgho ou maïs.
92	26	senegal_oriental	hivernage	7	8	10	11	Niébé en fin de rotation après céréales pour régénérer l'azote du sol.
93	27	bassin_arachidier	hivernage	7	8	10	11	Semis après l'arachide ou en rotation ; attendre sol stable après premières pluies.
94	27	senegal_oriental	hivernage	7	8	10	11	Zone en expansion pour le sésame d'export ; bonne adaptation aux sols sableux.
95	27	casamance	hivernage	7	8	10	11	Risque de maladies fongiques élevé en Casamance ; variétés semi-indéhiscentes recommandées.
96	27	zone_sylvopastorale	hivernage	7	7	10	10	Variétés hâtives obligatoires (90 jours) compte tenu de la courte saison pluvieuse.
97	28	casamance	hivernage	5	7	1	4	Plantation dès premières pluies (mai-juin) ; récolte 9-12 mois après en saison sèche.
98	28	senegal_oriental	hivernage	6	7	3	5	Bon potentiel dans les zones humides du Sénégal Oriental ; cycle 10-12 mois.
99	28	niayes	contre_saison	11	1	9	11	Culture irriguée dans les Niayes ; cycle 10 mois avec irrigation régulière.
100	28	bassin_arachidier	hivernage	6	7	3	6	Zone marginale pour le manioc ; variétés tolérantes à la sécheresse (Bocou 1) seulement.
101	29	niayes	saison_seche	10	12	1	4	Principale saison de production ; températures fraîches favorables, faible pression maladies.
102	29	niayes	contre_saison	8	9	11	12	Fin d'hivernage ; forte pression Tuta absoluta et TYLCV. Variétés résistantes obligatoires.
103	29	vallee_fleuve	saison_seche	10	11	1	3	Culture irriguée en saison fraîche ; bons rendements avec intrants.
104	29	casamance	saison_seche	11	12	2	4	Humidité résiduelle favorable ; réduire les fongicides en saison fraîche.
105	30	vallee_fleuve	saison_seche	9	10	2	4	Principale zone de production irriguée ; récolte en saison chaude favorable au séchage.
106	30	niayes	saison_seche	10	11	3	5	Températures fraîches favorables à la bulbification ; humidité à surveiller (mildiou).
107	30	bassin_arachidier	saison_seche	10	11	3	4	Cultivation en contre-saison avec irrigation ; potentiel de développement important.
108	31	niayes	saison_seche	10	11	2	5	Principale saison ; températures favorables, faible pression maladie.
109	31	casamance	hivernage	6	7	10	12	Culture pluviale possible en Casamance ; variétés locales bien adaptées.
110	31	vallee_fleuve	saison_seche	10	11	2	5	Culture irriguée prometteuse ; production hors saison en expansion.
111	32	vallee_fleuve	saison_seche	10	12	1	4	Culture irriguée très profitable ; peu de maladies en saison fraîche.
112	32	bassin_arachidier	hivernage	6	7	8	11	Semis dès les premières pluies ; bonne production sans irrigation.
113	32	niayes	saison_seche	11	1	2	5	Bonne période de production pour l'approvisionnement de Dakar.
114	32	casamance	hivernage	5	7	8	11	Excellent gombo en Casamance avec pluviométrie naturelle ; variétés locales recommandées.
115	33	niayes	saison_seche	9	11	12	4	Principale saison ; températures optimales pour la fructification.
116	33	casamance	hivernage	5	6	8	12	Culture pluviale possible ; forte production en saison humide.
117	33	vallee_fleuve	saison_seche	10	11	1	4	Culture irriguée prometteuse ; développement en cours.
118	34	niayes	saison_seche	10	12	1	4	Saison idéale ; températures fraîches favorables à la pommaison.
119	34	vallee_fleuve	saison_seche	10	11	1	3	Culture irriguée possible ; choisir des variétés tolérantes à la chaleur.
120	35	niayes	saison_seche	10	12	12	3	Saison principale ; faible pression maladies, températures adaptées.
121	35	vallee_fleuve	saison_seche	10	11	12	2	Culture irriguée rentable ; cycle court de 60-70 jours.
122	35	casamance	saison_seche	11	12	1	3	Humidité résiduelle bénéfique ; surveiller mildiou.
123	36	vallee_fleuve	saison_seche	11	2	2	5	Zone principale ; culture irriguée de saison fraîche-chaude.
124	36	niayes	saison_seche	11	1	2	4	Production pour le marché de Dakar ; bonne rentabilité.
125	36	bassin_arachidier	hivernage	7	8	10	11	Culture pluviale possible ; rendements inférieurs mais peu d'intrants.
126	37	casamance	saison_seche	12	2	5	7	Floraison de décembre à février ; récolte mai-juillet selon variété.
127	37	senegal_oriental	saison_seche	12	2	5	7	Zone à haut potentiel ; Amélie dès avril, Kent et Keitt en juin-juillet.
128	37	bassin_arachidier	saison_seche	1	2	4	6	Zone marginale pour la mangue ; variétés hâtives (Amélie) recommandées.
129	38	casamance	saison_seche	11	1	3	5	Principale zone (Ziguinchor, Sédhiou) ; floraison nov-jan, récolte mars-mai.
130	38	senegal_oriental	saison_seche	11	1	3	5	Zone en développement ; Kédougou et Tambacounda à fort potentiel.
131	39	niayes	saison_seche	4	6	2	5	Plantation en avril-juin ; récolte 9-12 mois après avec irrigation permanente.
132	39	casamance	hivernage	6	8	4	7	Plantation en hivernage profite des pluies ; irrigation en saison sèche.
133	39	vallee_fleuve	saison_seche	3	5	1	4	Culture irriguée toute l'année possible ; températures chaudes favorables.
134	40	niayes	saison_seche	10	12	7	12	Plantation en pépinière oct-déc ; récolte continue 9-12 mois après.
135	40	casamance	hivernage	5	7	2	7	Plantation en début d'hivernage ; pluies assurent la croissance initiale.
136	40	vallee_fleuve	saison_seche	9	11	6	11	Culture irriguée toute l'année ; températures chaudes favorables à la croissance.
\.


--
-- Data for Name: agro_culture_maladies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_culture_maladies (id, culture_id, maladie_id, frequence, gravite, stade_sensible, pertes_estimees, prevention, traitement) FROM stdin;
131	38	125	frequente	moyenne	Floraison	15-35%	Soufre préventif avant floraison, bonne aération	Soufre mouillable (Thiovit) 3 kg/ha ou Triadiménol 0,5 kg/ha
67	21	66	tres_frequente	elevee	Tallage et épiaison	20-50% en cas d'épidémie sur panicule	Variétés résistantes (Sahel 108), semis non trop dense, éviter excès d'azote	Tricyclazole (Beam 75WP) 0,6 kg/ha ou Propiconazole (Tilt 250EC) 0,5 L/ha
68	21	67	frequente	moyenne	Tallage à maturité	10-30% si non traité	Semences saines, fumure équilibrée, rotation	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Chlorothalonil 1,5 L/ha
69	21	68	occasionnelle	elevee	Tallage à épiaison	Jusqu'à 50% dans les foyers	Variétés résistantes, plants sains, éviter les blessures	Aucun traitement curatif ; éliminer les plants malades, cuivre préventif
70	21	69	occasionnelle	moyenne	Floraison	5-15% des grains affectés	Semences traitées, rotation, variétés tolérantes	Traitement semences au thirame (Thiram 75WS) 3 g/kg de semences
71	21	70	tres_frequente	elevee	Tallage à épiaison	10-30% en riziculture intensive	Densité modérée, équilibre de la fumure azotée, variétés tolérantes	Azoxystrobine (Amistar 250SC) 0,5 L/ha ou Hexaconazole 0,5 L/ha dès apparition des lésions
72	22	71	frequente	moyenne	Floraison à remplissage des grains	10-30% selon l'intensité	Variétés résistantes, rotation, élimination des résidus de culture	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
73	22	72	frequente	elevee	Remplissage des grains	Jusqu'à 30% + risque toxicologique pour la consommation humaine	Variétés tolérantes, récolte à bonne maturité, séchage rapide	Fongicides au semis (thirame) ; gestion post-récolte (séchage < 14%)
74	22	73	frequente	elevee	Levée à V6	20-80% selon la précocité de l'infection	Semis précoce, variétés résistantes (MSV-R), lutte contre les cicadelles	Pas de traitement curatif ; insecticide sur cicadelles : Lambdacyhalothrine 0,5 L/ha
75	22	74	occasionnelle	moyenne	Floraison	5-20% en foyers	Rotation, élimination des galles avant éclatement, semences saines	Traitement semences au carboxine-thirame ; pas de traitement curatif efficace
76	23	75	tres_frequente	elevee	Croissance végétative à fructification	20-50% de défoliation possible	Rotation cultures, variétés tolérantes, ne pas recycler les semences malades	Chlorothalonil (Bravo 500SC) 1,5 L/ha ou Mancozèbe (Dithane M-45) 2 kg/ha tous les 14 jours
77	23	76	frequente	elevee	Levée à V30	Jusqu'à 100% en cas d'épidémie précoce	Semis précoce groupé, variétés résistantes (RMP 12, Brewer), contrôle des pucerons	Pas de traitement curatif ; insecticide contre pucerons : Imidaclopride (Confidor) 0,3 L/ha
78	23	77	frequente	moyenne	Floraison à fructification	10-25%	Variétés résistantes, rotation, élimination des résidus	Triadiménol (Bayleton 25WP) 0,5 kg/ha ou Propiconazole (Tilt 250EC) 0,5 L/ha
79	23	78	frequente	elevee	Fructification à stockage	5-30% + rejet à l'export pour cause d'aflatoxines	Récolte à temps, séchage rapide sous 14% humidité, stockage hermétique	Biocontrôle : Aflasafe (Aspergillus flavus non-toxigène) ; séchage rapide obligatoire
80	24	79	tres_frequente	elevee	Levée à montaison	30-80% en cas d'épidémie	Variétés résistantes (IBV 8004, ICMV IS 89305), traitement semences au métalaxyl	Métalaxyl (Ridomil 25WP) 2 g/kg semences ; pas de traitement foliaire curatif efficace
81	24	80	frequente	moyenne	Floraison	5-20% des épis	Rotation culturale, semences saines certifiées, éviter de recycler les semences	Traitement semences au carboxine-thirame ou Thiram 75WS (3 g/kg)
82	24	81	occasionnelle	moyenne	Floraison	5-15%	Variétés à floraison courte, semis précoce	Pas de traitement curatif ; retirer les scléroties à la main ; thirame préventif
83	24	82	occasionnelle	faible	Montaison à maturité	5-10%	Variétés tolérantes, rotation	Mancozèbe (Dithane M-45) 2 kg/ha si attaque sévère
84	25	83	tres_frequente	elevee	Tallage à maturité	20-50% en zone humide	Variétés résistantes, rotation, élimination des résidus	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
85	25	84	frequente	moyenne	Floraison	10-30% des épis	Semences certifiées, rotation, élimination des épis atteints	Traitement semences : carboxine (Vitavax 200WP) 3 g/kg ou thirame 75WS 3 g/kg
86	25	85	occasionnelle	moyenne	Levée à montaison	10-30%	Variétés résistantes, traitement semences au métalaxyl	Métalaxyl (Ridomil 25WP) 2 g/kg semences en traitement préventif
87	25	86	frequente	moyenne	Montaison à remplissage	10-25%	Rotation, élimination résidus, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha si attaque précoce
88	26	87	frequente	moyenne	Levée à V10	10-25% à la levée	Sol bien drainé, éviter l'excès d'eau, rotation	Traitement semences au thirame 75WS (3 g/kg) + métalaxyl
89	26	88	frequente	moyenne	Floraison à fructification	10-20%	Variétés tolérantes, rotation, espacement suffisant	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil 1,5 L/ha
90	26	89	frequente	elevee	Croissance végétative	20-60% selon précocité	Variétés résistantes, contrôle des pucerons, semis précoce	Insecticides contre pucerons : Imidaclopride (Confidor) 0,3 L/ha
91	26	90	occasionnelle	moyenne	Fructification	10-30%	Semences saines, rotation de 3 ans	Mancozèbe (Dithane M-45) 2 kg/ha dès apparition des symptômes
92	27	91	frequente	elevee	Croissance végétative à floraison	20-50% en foyers	Rotation 3-4 ans, sol bien drainé, pH > 6, variétés tolérantes (NRCSS 2001)	Pas de traitement curatif ; Trichoderma spp. en biocontrôle préventif
93	27	92	frequente	moyenne	Fructification à maturité	10-25%	Rotation, espacement suffisant, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha ou Chlorothalonil (Bravo 500SC) 1,5 L/ha
94	27	93	occasionnelle	elevee	Tout le cycle	10-40% en sols hydromorphes	Drainage impératif, billonnage, éviter les bas-fonds	Métalaxyl (Ridomil 25WP) 2 g/kg semences ; améliorer le drainage
95	28	94	tres_frequente	elevee	Tout le cycle (infection précoce plus grave)	30-80% selon précocité et variété	Boutures certifiées saines (TME 419, TMS 30572 résistantes), lutte contre mouche blanche	Pas de traitement curatif ; arracher et bruler les plants très atteints ; insecticides contre B. tabaci
96	28	95	frequente	elevee	Croissance végétative en saison humide	20-50% en épidémie	Boutures saines, rotation, variétés résistantes, éviter les blessures	Pas de traitement curatif efficace ; cuivre (Bouillie bordelaise) préventif 0,5%
97	28	96	occasionnelle	elevee	Tubérisation à récolte	20-60% en sols hydromorphes	Drainage impératif, billonnage, ne pas cultiver en bas-fond	Métalaxyl (Ridomil 25WP) en préventif ; améliorer le drainage
98	28	97	frequente	faible	Croissance végétative	5-15%	Espacement suffisant, variétés tolérantes	Mancozèbe (Dithane M-45) 2 kg/ha si attaque sévère
99	29	98	tres_frequente	elevee	Croissance végétative à fructification	50-100% si non traité en conditions favorables	Variétés résistantes, éviter mouillage des feuilles, désherbage, rotation	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha ou Chlorothalonil 1,5 L/ha tous les 7-10 jours
100	29	99	frequente	moyenne	Floraison à récolte	10-30%	Rotation, élimination feuilles malades, bonne aération	Azoxystrobine (Amistar 250SC) 1 L/ha ou Iprodione (Rovral 50WP) 1,5 kg/ha
101	29	100	tres_frequente	elevee	Tous stades, surtout levée à floraison	Jusqu'à 100% sur variétés sensibles	Variétés résistantes (Mongal F1, Power Ranger), filets anti-insectes en pépinière	Pas de traitement curatif ; contrôler la mouche blanche : Imidaclopride 0,3 L/ha
102	29	101	frequente	elevee	Croissance végétative	20-80% selon l'infestation du sol	Rotation 3-4 ans, variétés résistantes (F), solarisation du sol	Fongicide sol Thiophanate-méthyl (Pelt 44SC) 2 L/ha ; solarisation en préventif
103	29	102	tres_frequente	elevee	Tout le cycle	30-100% en sols infestés	Rotation 3-4 ans avec céréales ou manioc, solarisation, drainage, chaulage du sol (pH >6,5), pépinière saine	Pas de traitement curatif efficace ; arracher et brûler immédiatement les plants malades ; désinfecter les outils
104	30	103	frequente	elevee	Croissance végétative	20-50%	Éviter mouillage des feuilles, espacement suffisant, variétés tolérantes	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha hebdomadaire
105	30	104	frequente	elevee	Maturité et stockage	20-50% en stockage humide	Séchage soigneux post-récolte, manipulation douce, stockage sec et ventilé	Iprodione (Rovral 50WP) 1,5 kg/ha en préventif ; séchage rigoureux en curatif
106	30	105	frequente	moyenne	Pépinière	30-80% en pépinière si non traité	Substrat sain et drainé, ne pas surirriguer, solarisation du sol de pépinière	Metalaxyl-M (Ridomil Gold 480SL) 0,5 L/ha en arrosage du pied
107	31	106	tres_frequente	elevee	Fructification	20-50% des fruits	Variétés résistantes, ne pas blesser les fruits, rotation	Azoxystrobine (Amistar 250SC) 1 L/ha ou Mancozèbe 2 kg/ha hebdomadaire
108	31	107	frequente	elevee	Tout le cycle	30-70% en cas d'engorgement	Billons surélevés, drainage, rotation, compost	Metalaxyl (Ridomil 72WP) 2 kg/ha en arrosage du pied
109	31	108	frequente	moyenne	Tous stades	15-40%	Semences saines, lutte contre pucerons, éliminer plants malades	Pas de traitement curatif ; insecticide contre pucerons : Imidaclopride 0,3 L/ha
110	31	102	frequente	elevee	Tout le cycle	20-70% en sols infestés	Rotation 3-4 ans avec céréales, solarisation, chaulage du sol	Pas de traitement curatif ; arracher et brûler les plants malades immédiatement
111	32	109	frequente	elevee	Croissance végétative	20-50%	Rotation 3-4 ans, variétés résistantes (Parbhani Kranti), solarisation	Thiophanate-méthyl 2 L/ha en arrosage ; pas de traitement curatif efficace
112	32	110	frequente	elevee	Tous stades	30-70%	Variétés résistantes (Parbhani Kranti), lutte contre aleurodes	Pas de traitement curatif ; insecticide aleurodes : Imidaclopride 0,3 L/ha
113	32	111	occasionnelle	moyenne	Levée	10-40% en conditions défavorables	Semis sur billons surélevés, ne pas surirriguer, rotation	Metalaxyl + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha en arrosage préventif
114	33	112	frequente	elevee	Croissance végétative	20-60% en sols infestés	Rotation 3-4 ans avec céréales, solarisation, variétés tolérantes	Pas de traitement curatif ; prévention par solarisation 6-8 semaines
115	33	99	frequente	moyenne	Floraison à récolte	15-30%	Rotation, bonne aération, retirer feuilles basses malades	Azoxystrobine (Amistar) 1 L/ha ou Mancozèbe 2,5 kg/ha hebdomadaire
116	33	102	frequente	elevee	Croissance végétative à fructification	20-60% en sols infestés	Rotation avec céréales, solarisation, drainage, pépinière sur substrat sain	Pas de traitement curatif ; arracher et brûler les plants malades
117	34	113	tres_frequente	elevee	Croissance feuillaire à formation de la pomme	20-50%	Rotation, aération, éviter mouillage des feuilles	Iprodione (Rovral 50WP) 1,5 kg/ha ou Azoxystrobine 1 L/ha hebdomadaire
118	34	114	occasionnelle	elevee	Repiquage à croissance végétative	50-100% en sols infestés	Rotation longue (5-7 ans), chaulage pour pH > 7.2, drainage	Chaulage préventif (2-3 t/ha de chaux) ; carbendazime au repiquage
119	34	115	frequente	elevee	Croissance à pommaison	20-60%	Semences saines, rotation, éviter blessures, ne pas arroser sur les feuilles	Cuivre (Kocide 101) 3 kg/ha préventif ; pas de traitement curatif
120	35	116	tres_frequente	elevee	Croissance végétative à fructification	30-80%	Variétés tolérantes, éviter mouillage des feuilles, rotation	Méfénoxam + Mancozèbe (Ridomil Gold MZ) 2,5 kg/ha hebdomadaire
121	35	117	frequente	moyenne	Fructification	15-30%	Variétés résistantes (Poinsett 76), bonne aération	Triadiménol (Bayleton 25WP) 0,5 kg/ha ou soufre mouillable 3 kg/ha
122	35	118	frequente	moyenne	Fructification	20-40%	Rotation, semences saines, drainage	Mancozèbe 2,5 kg/ha ou Azoxystrobine 1 L/ha
123	36	119	frequente	elevee	Croissance végétative	20-60% en sols infestés	Rotation 4-5 ans, greffage sur porte-greffe résistant (Cucurbita), solarisation	Thiophanate-méthyl en arrosage ; greffage préventif recommandé
124	36	118	frequente	moyenne	Fructification à maturité	15-35%	Variétés résistantes (Charleston Grey), rotation, drainage	Mancozèbe 2,5 kg/ha ou Azoxystrobine 1 L/ha hebdomadaire
125	36	116	frequente	moyenne	Croissance végétative	20-40%	Variétés tolérantes, espacement, éviter mouillage des feuilles	Ridomil Gold MZ 2,5 kg/ha hebdomadaire
126	37	120	tres_frequente	elevee	Floraison et récolte	20-60% en saison humide	Taille pour aérer le houppier, ne pas irriguer sur les fleurs	Mancozèbe (Dithane M-45) 2,5 kg/ha ou Carbendazime 0,5 kg/ha sur les panicules
127	37	121	tres_frequente	elevee	Floraison	30-80% sur fleurs si épidémie	Taille, aération, soufre préventif avant floraison	Soufre mouillable (Thiovit) 3 kg/ha ou Triadiménol 0,5 kg/ha sur les panicules
128	37	122	occasionnelle	moyenne	Croissance végétative	10-20%	Taille des rameaux malades, cuivre préventif en début de saison des pluies	Cuivre (Kocide 101) 3 kg/ha en pulvérisation ; pas de traitement curatif
129	37	123	tres_frequente	elevee	Toute l'année (pic en saison sèche)	10-40% de perte de production sur arbres adultes ; mort de jeunes plants	Taille sanitaire avec outils désinfectés (hypochlorite 10%), badigeonnage des plaies au mastic fongicide, irrigation en saison sèche	Couper et brûler les rameaux atteints jusqu'au bois sain ; badigeonner les plaies au Carbendazime 0,5% ; pulvérisation de Thiophanate-méthyl 0,5 kg/ha
130	38	124	tres_frequente	elevee	Floraison et nouaison	20-50%	Variétés tolérantes, taille pour aérer, cuivre préventif	Mancozèbe (Dithane M-45) 2,5 kg/ha sur les panicules dès leur apparition
132	38	123	tres_frequente	elevee	Toute l'année (pic fin saison sèche)	15-50% de panicules perdues dans les vergers non entretenus	Taille sanitaire avec désinfection des outils, badigeon au mastic fongicide, gestion de l'Hélopelte vecteur de blessures	Couper et brûler les rameaux malades dès détection ; badigeonner les plaies au Carbendazime ; Thiophanate-méthyl en pulvérisation
133	39	126	frequente	elevee	Tout le cycle	50-100% en sol infesté (race Tropical 4)	Utiliser des vitroplants certifiés, éviter les blessures racinaires, rotation longue	Pas de traitement curatif ; prévention stricte et variétés résistantes obligatoires
134	39	127	tres_frequente	elevee	Tout le cycle	20-50% en l'absence de traitement	Variétés tolérantes, effeuillage préventif des feuilles malades	Propiconazole (Tilt 250EC) 0,5 L/ha ou Carbendazime 0,5 kg/ha tous les 21 jours
135	39	128	frequente	moyenne	Post-récolte	10-30% des fruits	Manipulation soigneuse, emballage protecteur, froid	Bain post-récolte : thiabendazole 0,1% ou eau chaude 52°C pendant 30 sec
136	40	129	tres_frequente	elevee	Tous stades	50-100% sur variétés sensibles	Variétés résistantes (Red Lady F1, Tainung 1), lutte contre pucerons, pépinière protégée	Pas de traitement curatif ; détruire les plants malades ; insecticide contre pucerons
137	40	130	tres_frequente	elevee	Maturité et post-récolte	20-50% en conditions humides	Manipulation soigneuse, emballage protecteur	Bain post-récolte : thiabendazole ou eau chaude (52°C, 20 min) + Mancozèbe en champ
138	40	131	frequente	elevee	Plantation à croissance végétative	30-80% en cas d'inondation	Billons de 30-40 cm, sol très bien drainé, ne jamais planter en bas-fond	Metalaxyl (Ridomil Gold 480SL) 0,5 L/ha en arrosage du pied
\.


--
-- Data for Name: agro_culture_ravageurs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_culture_ravageurs (id, culture_id, ravageur_id, frequence, gravite, stade_sensible, pertes_estimees, prevention, lutte) FROM stdin;
59	21	54	tres_frequente	elevee	Tallage et épiaison	15-40% si non contrôlé	Variétés résistantes, élimination des chaumes après récolte, plants sains	Carbofuran (Furadan 3G) 25 kg/ha en granulés ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
60	21	55	tres_frequente	elevee	Floraison à maturité	30-100% en cas d'invasion	Surveillance, semis groupés pour noyer les dégâts, effarouchement collectif	Effarouchement sonore, filets, guet permanent ; traitement avicide (Queletox) uniquement sur autorisation DGPV
61	21	56	frequente	moyenne	Tallage	10-25%	Drainage temporaire, éviter l'excès d'azote	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Chlorpyrifos-éthyl 1 L/ha
62	21	57	occasionnelle	moyenne	Repiquage à tallage	10-20% en sols infestés	Rotation avec légumineuses, sols bien inondés (réduit les nématodes)	Inondation prolongée avant repiquage ; Carbofuran 3G si forte infestation
63	22	58	tres_frequente	elevee	Levée à V8	20-70% si non traité	Semis précoce, surveillance dès la levée, pièges à phéromones	Emamectin benzoate (Emacot 1.9EC) 0,75 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dans le cornet
64	22	59	frequente	elevee	V4 à floraison	15-40%	Semis précoce, rotation, destruction des résidus de maïs	Carbofuran granulés dans le cornet ou Lambdacyhalothrine 0,5 L/ha en début d'infestation
65	22	60	frequente	elevee	Levée à V6	Dommages indirects via MSV : 20-80%	Variétés résistantes au virus, semis en période moins favorable aux cicadelles	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès apparition des symptômes
66	23	61	tres_frequente	elevee	Levée à floraison	Dommages directs 5-10% + indirects via rosette jusqu'à 100%	Semis précoce, variétés résistantes, rotation	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
67	23	62	frequente	elevee	Tout le cycle	10-30% en sols très infestés	Labour profond, élimination des souches d'arbres, rotation	Chlorpyrifos-éthyl (Dursban 480EC) 2 L/ha en pulvérisation sur le sol avant semis
68	23	63	occasionnelle	moyenne	Fructification	5-20% en foyers	Labour profond pour exposer les larves aux prédateurs, rotation	Carbofuran (Furadan 3G) 25 kg/ha incorporé au sol ; insecticide de sol
69	24	55	tres_frequente	elevee	Épiaison à maturité	30-100% dans les zones d'invasion	Surveillance DGPV, semis groupés, alertes précoces, effarouchement collectif	Effarouchement sonore continu ; traitement avicide (Queletox) uniquement sur autorisation DGPV
70	24	64	tres_frequente	elevee	Tout le cycle	20-80% dans les zones infestées	Variétés résistantes, rotation légumineuses, semences exemptes de Striga	Herbicide Imazapyr (Strigaway) sur semences traitées ; arrachage manuel avant fructification du Striga
71	24	65	frequente	moyenne	Tallage à épiaison	10-30%	Semis précoce, élimination des résidus de culture, variétés résistantes	Décis (Deltaméthrine 2,5EC) 0,5 L/ha ou Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha
72	25	66	tres_frequente	elevee	Tallage à montaison	15-40%	Semis précoce, destruction des résidus, rotation	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Décis (Deltaméthrine 2,5EC) 0,5 L/ha
73	25	67	occasionnelle	moyenne	Montaison	5-15%	Variétés tolérantes, semis précoce	Chlorpyrifos-éthyl (Dursban 480EC) 1 L/ha ou huile minérale en pulvérisation
74	25	55	tres_frequente	elevee	Floraison à maturité	30-100% en zone d'invasion	Surveillance, semis groupés, effarouchement collectif	Effarouchement continu (6h-19h) ; signalement DGPV pour intervention avicide si nécessaire
75	25	68	tres_frequente	elevee	Floraison (anthèse)	30-50% en zone sahélienne, jusqu'à 100% localement	Semis précoce ou tardif pour décaler la floraison du pic d'adultes, variétés à panicules compactes	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès début épiaison ; surveiller les fleurets à l'anthèse
76	25	69	frequente	elevee	Floraison à maturité	10-30% selon niveau d'infestation	Surveillance des pontes (œufs ronds jaunes sur feuilles), pièges à phéromones sexuelles	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha ; rotation des matières actives
77	26	70	tres_frequente	elevee	Stockage	50-100% des grains en 3 mois si non traité	Séchage à <12% humidité, sacs hermétiques (GrainPro), récolte à sec	Pirimiphos-méthyl (Actellic 2% dust) 2 g/kg ou huile de neem 5 mL/kg ; stockage hermétique
78	26	71	tres_frequente	elevee	Floraison	30-70% des rendements en grains	Semis précoce pour décaler la floraison des pics de thrips	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha dès apparition ; Décis (Deltaméthrine) 0,5 L/ha
79	26	61	frequente	elevee	Levée à floraison	Dommages directs + indirects via virus : 20-80%	Variétés résistantes, semis précoce, lutte chimique précoce	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine 0,5 L/ha
80	26	72	tres_frequente	elevee	Fructification à maturité	20-50%	Semis précoce, récolte rapide dès maturité, plantes-pièges (sésame)	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Deltaméthrine (Décis 2,5EC) 0,5 L/ha en début fructification
81	26	69	frequente	elevee	Floraison à maturité	10-25%	Surveillance des pontes, pièges à phéromones	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha
82	27	73	frequente	elevee	Floraison à fructification	15-40%	Semis précoce, élimination des résidus, rotation	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Décis (Deltaméthrine 2,5EC) 0,5 L/ha
83	27	74	frequente	moyenne	Croissance végétative à floraison	10-20%	Semis précoce, rotation, prédateurs naturels	Imidaclopride (Confidor 200SL) 0,3 L/ha ou savon insecticide
84	27	75	occasionnelle	moyenne	Croissance végétative en saison sèche	5-15%	Irrigation régulière (acariens prolifèrent en sécheresse), prédateurs	Acaricide : Abamectine (Vertimec 1,8EC) 0,75 L/ha ; huile de neem 5 L/ha
85	28	76	tres_frequente	elevee	Croissance végétative (saison sèche)	20-80% en saison sèche sans lutte biologique	Boutures saines, lutte biologique (Anagyrus lopezi), variétés tolérantes	Parasitoïde Anagyrus lopezi (lutte biologique prioritaire) ; Lambdacyhalothrine 0,5 L/ha si urgence
86	28	77	tres_frequente	elevee	Tout le cycle	Dommages indirects via mosaïque : 30-80%	Variétés résistantes à la mosaïque, boutures saines	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Lambdacyhalothrine 0,5 L/ha
87	28	78	frequente	elevee	Croissance végétative en saison sèche	15-40% en saison sèche	Variétés tolérantes (TME 419), prédateurs naturels (Typhlodromalus aripo)	Soufre mouillable 3 kg/ha ou Abamectine (Vertimec 1,8EC) 0,75 L/ha
88	28	62	frequente	moyenne	Plantation à tubérisation	5-20% en sols très infestés	Labour profond, rotation, éviter sols très sableux et secs	Chlorpyrifos-éthyl (Dursban 480EC) 2 L/ha incorporé avant plantation
89	29	79	tres_frequente	elevee	Tous stades	50-100% sans gestion	Pièges à phéromones, filets anti-insectes, surveillance quotidienne	Emamectin benzoate (Proclaim 5WG) 0,3 kg/ha, rotation Chlorantraniliprole (Coragen) 0,25 L/ha
90	29	77	tres_frequente	elevee	Pépinière à floraison	30-100% via virus TYLCV	Filets anti-insectes en pépinière, pièges jaunes englués	Imidaclopride (Confidor 200SL) 0,3 L/ha ou Spiromesifen (Oberon SC) 0,5 L/ha
91	29	80	frequente	moyenne	Floraison	10-30%	Pièges bleus collants, rotation insecticides	Spinosad (Success 480SC) 0,25 L/ha ou Abamectine (Dynamec 1.8EC) 0,5 L/ha
92	29	69	frequente	elevee	Fructification	20-40%	Pièges à phéromones sexuelles (1/ha), surveillance des pontes sur feuilles	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha ; rotation des matières actives
93	30	81	tres_frequente	elevee	Croissance végétative à formation du bulbe	20-40%	Pièges bleus collants, espacement suffisant, éviter stress hydrique	Spinosad (Success 480SC) 0,25 L/ha ou Abamectine 0,5 L/ha ; alterner les matières actives
94	30	82	occasionnelle	moyenne	Repiquage à croissance végétative	5-20% en zones infestées	Rotation, pièges jaunes, bâches blanches répulsives	Chlorpyrifos-éthyl (Dursban 480EC) 1 L/ha en traitement sol au repiquage
95	30	83	frequente	moyenne	Tout le cycle	15-30% en sols très infestés	Rotation avec céréales, solarisation du sol, compost de qualité	Carbofuran (Furadan 3G) 20 kg/ha ou Nématicide biologique (Purpureocillium lilacinum)
96	31	84	tres_frequente	elevee	Floraison	15-30%	Pièges bleus, rotation insecticides	Spinosad (Success) 0,25 L/ha ou Abamectine 0,5 L/ha tous les 7 jours
97	31	75	frequente	moyenne	Croissance à fructification	15-25%	Éviter la sécheresse, favoriser les acariens prédateurs (Phytoseiidae)	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Spiromesifen 0,75 L/ha
98	31	85	frequente	elevee	Pépinière à floraison	10-50% (virus)	Filets anti-insectes en pépinière, pièges jaunes	Imidaclopride (Confidor) 0,3 L/ha ou Pyméthrozine (Chess 50WG) 0,2 kg/ha
99	31	69	frequente	elevee	Fructification	10-30%	Pièges à phéromones, surveillance des pontes	Spinosad (Success 480SC) 0,25 L/ha ou Indoxacarbe (Steward 30EC) 0,33 L/ha
100	32	86	tres_frequente	moyenne	Tous stades	10-25%	Variétés à pilosité foliaire (Clemson Spineless), bonne nutrition	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Dimethoate 1 L/ha
101	32	74	frequente	moyenne	Levée à floraison	10-20%	Favoriser les prédateurs naturels (coccinelles, chrysopes)	Imidaclopride (Confidor) 0,3 L/ha ; insecticides biologiques à base de pyrèthre naturel
102	32	87	frequente	moyenne	Fructification	10-30%	Plantes pièges (sorgho), inspection régulière des fruits	Lambdacyhalothrine (Karaté) 0,5 L/ha en début de fructification
103	33	88	tres_frequente	elevee	Fructification	30-70%	Récolte fréquente, filets insect-proof, pièges à phéromones	Emamectin benzoate (Proclaim 5WG) 0,3 kg/ha ou Chlorantraniliprole 0,25 L/ha
104	33	75	frequente	moyenne	Croissance à fructification	15-25%	Irrigation régulière, favoriser la faune auxiliaire	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Spiromesifen 0,75 L/ha
105	33	74	frequente	moyenne	Tous stades	10-25%	Pièges jaunes, favoriser auxiliaires naturels	Imidaclopride (Confidor) 0,3 L/ha ou pyrèthre naturel en bio
106	34	89	tres_frequente	elevee	Tous stades	30-80% sans gestion	Filets anti-insectes, pièges à phéromones, Bacillus thuringiensis	Bt (Biobit/Dipel) 1 kg/ha ou Emamectin benzoate 0,3 kg/ha ; rotation impérative
107	34	90	frequente	moyenne	Croissance végétative	15-25%	Pièges jaunes, favoriser auxiliaires (coccinelles)	Imidaclopride (Confidor) 0,3 L/ha ou pyréthrine naturelle
108	35	91	tres_frequente	elevee	Fructification	30-70%	Pièges à protéine (attractif), ramassage fruits tombés	Appâts protéinés + Malathion ; Spinosad (Success) 0,25 L/ha sur les pièges
109	35	74	frequente	elevee	Tous stades	15-50% via virus	Pièges jaunes, favoriser auxiliaires	Imidaclopride (Confidor) 0,3 L/ha ou pyrèthre naturel
110	36	91	tres_frequente	elevee	Grossissement des fruits	30-70%	Pièges à protéine (1/500 m²), ramassage fruits tombés	Pièges protéine + Spinosad 0,25 L/ha ; récolter à maturité optimale
111	36	74	frequente	moyenne	Croissance végétative à floraison	10-30%	Pièges jaunes, rotation des cultures	Imidaclopride 0,3 L/ha ou savon insecticide en bio
112	36	75	frequente	moyenne	Croissance à fructification	15-25%	Irrigation régulière, ne pas stresser les plants	Abamectine (Dynamec 1.8EC) 0,5 L/ha
113	37	92	tres_frequente	elevee	Maturité et récolte	30-80% sans gestion ; cause principale de rejet à l'export	Pièges McPhail avec attractif protéiné (1/ha), ramassage fruits tombés	Appâts Spinosad (GF120) + protéine hydrolysée ; Malathion 50EC 1,5 L/ha en dernier recours
114	37	93	frequente	moyenne	Croissance des fruits	10-30%	Favoriser les parasitoïdes naturels (Gyranusoidea tebygi)	Huile minérale (Volck oil) 1,5 L/ha ou Imidaclopride systémique 0,5 L/ha
115	37	94	frequente	elevee	Floraison	30-60% des fleurs	Surveillance dès l'apparition des panicules	Lambdacyhalothrine (Karaté) 0,5 L/ha dès sortie des panicules
116	38	95	tres_frequente	elevee	Floraison et nouaison	30-70% des panicules en forte infestation	Surveillance dès la sortie des panicules, plantation de haies répulsives	Lambdacyhalothrine (Karaté 2,5EC) 0,5 L/ha ou Chlorpyrifos 1 L/ha dès apparition
117	38	96	frequente	moyenne	Croissance des fruits	10-25%	Favoriser les parasitoïdes naturels (Leptomastix dactylopii)	Huile minérale 2% ou Imidaclopride 0,5 L/ha en systémique
118	39	97	tres_frequente	elevee	Tout le cycle	20-50% de perte de vigueur ; mort des plants en forte infestation	Utiliser des rejets propres (éliminer les tissus infectés), pièges à phéromones	Pièges-billots (morceaux de pseudo-tronc attractifs) + Chlorpyrifos 2% sur les pièges
119	39	98	tres_frequente	elevee	Tout le cycle	20-40% en sols infestés	Vitroplants certifiés, rotation, solarisation	Nématicide biologique (Purpureocillium lilacinum) ou Carbofuran (Furadan 3G) 50 kg/ha
120	40	99	tres_frequente	elevee	Maturité / Récolte	20-60%	Pièges McPhail avec attractif, ramassage fruits tombés quotidien	Appâts Spinosad + protéine ; Malathion 50EC 1,5 L/ha en dernier recours
121	40	100	tres_frequente	elevee	Tous stades	50-100% via PRSV	Filets anti-insectes en pépinière, variétés résistantes au PRSV	Imidaclopride (Confidor) 0,3 L/ha ou Pyméthrozine (Chess 50WG) 0,2 kg/ha
122	40	75	frequente	moyenne	Croissance végétative	10-20%	Irrigation régulière ; ne pas stresser les plants	Abamectine (Dynamec 1.8EC) 0,5 L/ha ou Soufre mouillable 3 kg/ha
\.


--
-- Data for Name: agro_cultures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_cultures (id, nom, nom_scientifique, nom_local, famille, categorie, icone, description, actif, created_at) FROM stdin;
21	Riz	Oryza sativa L.	Maaro (wolof)	Poaceae	grandes_cultures	🌾	Céréale de base cultivée en irrigué dans la Vallée du Fleuve Sénégal et en pluvial en Casamance. Culture stratégique pour la sécurité alimentaire nationale.	t	2026-06-09 10:15:40.754788
22	Maïs	Zea mays L.	Maïs (wolof: maïs)	Poaceae	grandes_cultures	🌽	Céréale à forte productivité cultivée en hivernage dans tout le Sénégal et en contre-saison irriguée dans la Vallée du Fleuve. Aliment de base et fourrage.	t	2026-06-09 10:15:40.821905
23	Arachide	Arachis hypogaea L.	Gerte (wolof)	Fabaceae	grandes_cultures	🥜	Légumineuse oléagineuse, principale culture de rente du Sénégal. Cultivée dans le Bassin Arachidier, fixe l'azote atmosphérique et enrichit les sols.	t	2026-06-09 10:15:40.857658
24	Mil	Pennisetum glaucum (L.) R.Br.	Souna / Sanio (wolof)	Poaceae	grandes_cultures	🌾	Céréale de sécurité alimentaire par excellence au Sénégal, particulièrement adaptée aux zones semi-arides. Base alimentaire des populations rurales (thiéré, couscous, bouillie).	t	2026-06-09 10:15:40.888183
25	Sorgho	Sorghum bicolor (L.) Moench	Gawri (wolof)	Poaceae	grandes_cultures	🌾	Céréale très résistante à la sécheresse, cultivée dans tout le Sénégal. Aliment de base, fourrage et matière première pour la bière traditionnelle (dolo).	t	2026-06-09 10:15:40.916252
26	Niébé	Vigna unguiculata (L.) Walp.	Niébé (wolof: thiaw)	Fabaceae	grandes_cultures	🫘	Légumineuse polyvalente cultivée pour ses grains (protéines) et ses fanes (fourrage). Culture importante pour la sécurité nutritionnelle et l'amélioration de la fertilité des sols au Sénégal.	t	2026-06-09 10:15:40.949795
27	Sésame	Sesamum indicum L.	Bénéfin / Bissap blanc (wolof: bénéfin)	Pedaliaceae	grandes_cultures	🌱	Oléagineuse rustique à haute valeur commerciale, en forte expansion au Sénégal grâce à la demande à l'export. Culture adaptée aux zones semi-arides et peu exigeante en intrants.	t	2026-06-09 10:15:40.985026
28	Manioc	Manihot esculenta Crantz	Maaniog (wolof)	Euphorbiaceae	grandes_cultures	🌿	Tubercule vivrier de sécurité alimentaire cultivé principalement en Casamance et au Sénégal Oriental. Culture rustique à cycle long, productrice de féculents et de feuilles consommées comme légume.	t	2026-06-09 10:15:41.012745
29	Tomate	Solanum lycopersicum L.	Tomaat (wolof)	Solanaceae	maraichage	🍅	Légume-fruit le plus produit et consommé au Sénégal. Cultivée principalement dans les Niayes et la Vallée du Fleuve. Double usage : consommation fraîche et transformation (concentré, purée). Exportée vers l'Europe depuis les Niayes.	t	2026-06-09 10:15:41.045595
30	Oignon	Allium cepa L.	Seef (wolof)	Alliaceae	maraichage	🧅	Principal légume bulbeux du Sénégal. Produit massivement dans la Vallée du Fleuve (Podor, Dagana, Saint-Louis) et les Niayes. Enjeu national : forte dépendance aux imports hollandais malgré la production locale en plein essor.	t	2026-06-09 10:15:41.082808
31	Piment	Capsicum frutescens L.	Kaani (wolof)	Solanaceae	maraichage	🌶️	Condiment incontournable de la cuisine sénégalaise. Cultivé dans les Niayes, la Casamance et autour des grandes villes. Production fraîche et séchée pour export.	t	2026-06-09 10:15:41.124822
32	Gombo	Abelmoschus esculentus (L.) Moench	Kanja (wolof)	Malvaceae	maraichage	🌿	Légume incontournable de la cuisine sénégalaise (sauces, soupes). Cultivé partout au Sénégal, résistant à la chaleur. Culture facile avec débouchés garantis sur les marchés locaux.	t	2026-06-09 10:15:41.165574
33	Aubergine	Solanum melongena L.	Jaxatu (wolof)	Solanaceae	maraichage	🍆	Légume incontournable de la cuisine sénégalaise (thiéboudienne, mafé). Cultivée toute l'année dans les Niayes et en Casamance. Marché local solide avec demande constante.	t	2026-06-09 10:15:41.190074
34	Chou	Brassica oleracea var. capitata L.	Chou (wolof: chou)	Brassicaceae	maraichage	🥬	Culture maraîchère des Niayes et de la Vallée du Fleuve. Production saisonnière pour les marchés urbains de Dakar et Saint-Louis. Forte sensibilité aux fortes chaleurs ; culture de saison fraîche.	t	2026-06-09 10:15:41.208412
35	Concombre	Cucumis sativus L.	Concombre (wolof)	Cucurbitaceae	maraichage	🥒	Cucurbitacée à croissance rapide cultivée dans les Niayes et la Vallée du Fleuve. Cycle court de 60-75 jours ; rentable pour les maraichers. Marché local en croissance avec consommation fraîche et salade.	t	2026-06-09 10:15:41.228781
36	Pastèque	Citrullus lanatus (Thunb.) Matsum. & Nakai	Faas (wolof)	Cucurbitaceae	maraichage	🍉	Cucurbitacée très appréciée au Sénégal, cultivée en saison chaude. Tolère mieux la chaleur et la sécheresse que les autres cucurbitacées. Marchés locaux et export vers l'Europe depuis la Vallée du Fleuve.	t	2026-06-09 10:15:41.247917
37	Mangue	Mangifera indica L.	Mangoro (wolof)	Anacardiaceae	arboriculture	🥭	Principal fruit d'exportation du Sénégal. Cultivée en Casamance, au Sénégal Oriental et dans les Niayes. Exportée vers l'Europe (Kent, Keitt) de mai à juillet. Culture stratégique pour les revenus des producteurs.	t	2026-06-09 10:15:41.267523
38	Anacarde	Anacardium occidentale L.	Fondé (wolof) / Caju (diola)	Anacardiaceae	arboriculture	🌰	Deuxième culture d'exportation du Sénégal après l'arachide. Cultivé principalement en Casamance et au Sénégal Oriental. Noix de cajou exportée brute vers l'Inde et le Vietnam. Fort potentiel de transformation locale (ITA Dakar).	t	2026-06-09 10:15:41.292226
39	Banane	Musa spp. (groupe AAA)	Banana (wolof)	Musaceae	arboriculture	🍌	Fruit tropical cultivé dans les Niayes (Thiès, Mbour), la Casamance et la Vallée du Fleuve. Production principalement destinée au marché local dakarois. Forte demande avec marché intérieur à développer.	t	2026-06-09 10:15:41.312895
40	Papaye	Carica papaya L.	Papay (wolof)	Caricaceae	arboriculture	🍈	Fruit tropical à croissance rapide cultivé dans les Niayes, la Casamance et la Vallée du Fleuve. Production toute l'année avec plantation de vitroplants. Marché local en forte demande ; potentiel export (papaye verte pour transformation).	t	2026-06-09 10:15:41.334103
\.


--
-- Data for Name: agro_maladies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_maladies (id, nom, nom_scientifique, pathogene_type, symptomes, conditions_favorables, created_at) FROM stdin;
66	Pyriculariose	Pyricularia oryzae	fongique	Taches losangiques gris-brunâtres sur feuilles avec halo jaune ; attaque possible sur cou de panicule (cassure).	Humidité > 90%, températures 20-28°C, excès d'azote, forte rosée nocturne.	2026-06-09 10:15:40.771543
67	Helminthosporiose	Cochliobolus miyabeanus (Helminthosporium oryzae)	fongique	Taches ovales brun-chocolat avec halo jaune sur feuilles ; brunissement des grains.	Températures 25-30°C, forte humidité, sols pauvres en silice.	2026-06-09 10:15:40.788762
68	Bactériose du riz (Flétrissement bactérien)	Xanthomonas oryzae pv. oryzae	bacterien	Jaunissement et flétrissement des feuilles en partant du bord ; liséré ondulé blanc-jaune.	Chaleur, humidité élevée, blessures aux feuilles lors du repiquage.	2026-06-09 10:15:40.792777
69	Charbon des balles	Tilletia barclayana	fongique	Grains transformés en masse de spores noires ; contamination à la floraison.	Humidité élevée à la floraison, températures fraîches.	2026-06-09 10:15:40.795449
70	Rhizoctoniose du riz (gaine)	Rhizoctonia solani (AG1-IA)	fongique	Lésions elliptiques brun-grisâtres sur la gaine foliaire ; pont mycélien entre plants en cours de saison humide.	Chaleur (28-32°C), humidité élevée, forte densité de semis, excès d'azote.	2026-06-09 10:15:40.798234
71	Helminthosporiose du maïs	Exserohilum turcicum	fongique	Grandes taches nécrotiques allongées, brun-grisâtres, sur les feuilles basses puis remontant.	Humidité élevée, températures 20-25°C, rosée prolongée.	2026-06-09 10:15:40.830375
72	Fusariose de l'épi	Fusarium moniliforme / F. graminearum	fongique	Grains roses/blancs avec mycélium cotonneux sur l'épi ; production de fumonisines (mycotoxines).	Chaleur et humidité lors du remplissage, blessures d'insectes.	2026-06-09 10:15:40.838232
73	Striure du maïs	Maize streak virus (MSV)	viral	Stries jaune-vert sur les feuilles, rabougrissement des plants, épis peu garnis.	Présence de cicadelles (Cicadulina mbila) vecteurs, saison sèche.	2026-06-09 10:15:40.841062
74	Charbon commun du maïs	Ustilago maydis	fongique	Galles blanches puis noires (spores) sur les épis, les tiges ou les feuilles.	Températures chaudes (25-30°C), blessures mécaniques.	2026-06-09 10:15:40.843545
75	Cercosporiose (tache de la feuille)	Cercospora arachidicola / Cercosporidium personatum	fongique	Taches circulaires brun-rouge sur feuilles (cercospora précoce) ou taches noires (tardive) causant la défoliation.	Humidité > 80%, températures 25-30°C, densité excessive.	2026-06-09 10:15:40.864112
76	Rosette de l'arachide	Groundnut rosette virus (GRV)	viral	Nanisme des plants, chlorose en mosaïque ou verte, feuilles petites, pas de gousse.	Présence du puceron Aphis craccivora vecteur ; début de saison des pluies.	2026-06-09 10:15:40.87171
77	Rouille de l'arachide	Puccinia arachidis	fongique	Pustules orangées sur la face inférieure des feuilles, taches jaunes en face supérieure.	Humidité élevée, températures 20-28°C.	2026-06-09 10:15:40.874076
78	Pourriture des gousses	Aspergillus flavus (aflatoxines)	fongique	Moisissure verte-jaunâtre sur les gousses ; production d'aflatoxines cancérigènes.	Sécheresse en fin de cycle, température > 30°C, insectes dans le sol.	2026-06-09 10:15:40.876742
79	Mildiou du mil	Sclerospora graminicola	fongique	Chlorose des feuilles, sporulation blanche sur face inférieure, déformation des épis (virescence), nanisme.	Humidité > 85%, températures 25-30°C, sols lourds mal drainés.	2026-06-09 10:15:40.894527
80	Charbon du mil	Moesziomyces penicillariae	fongique	Grains transformés en masses de spores noires, épis inutilisables.	Semences infectées, humidité à la floraison.	2026-06-09 10:15:40.901316
81	Ergot du mil (Maladie du miel)	Claviceps fusiformis	fongique	Exsudat sucré (miellat) sur les fleurs, puis scléroties noires à la place des grains.	Humidité élevée, températures modérées pendant la floraison.	2026-06-09 10:15:40.903561
82	Rouille du mil	Puccinia penniseti	fongique	Pustules orangées sur feuilles et gaines, réduction de la photosynthèse.	Humidité, températures 20-28°C en fin de saison.	2026-06-09 10:15:40.905727
83	Anthracnose du sorgho	Colletotrichum sublineolum	fongique	Taches rouges à pourpres avec centre gris sur feuilles ; attaque possible sur tige et panicule.	Humidité > 80%, températures 28-32°C, blessures.	2026-06-09 10:15:40.923026
84	Charbon couvert du sorgho	Sporisorium sorghi	fongique	Grains transformés en masses de spores noires enveloppées d'une membrane.	Semences infectées, sol humide.	2026-06-09 10:15:40.931093
85	Mildiou du sorgho	Peronosclerospora sorghi	fongique	Chlorose des jeunes feuilles, sporulation blanche, nanisme des plants, panicules déformées.	Humidité élevée, températures fraîches (22-25°C) au démarrage.	2026-06-09 10:15:40.933003
86	Helminthosporiose du sorgho	Exserohilum turcicum / Bipolaris sorghicola	fongique	Grandes taches nécrotiques elliptiques brun-grisâtres sur les feuilles.	Humidité, températures 22-28°C, rosée persistante.	2026-06-09 10:15:40.934799
87	Pourridié / Fonte des semis	Pythium aphanidermatum / Rhizoctonia solani	fongique	Pourriture du collet et des racines chez les jeunes plants ; flétrissement et mort.	Sol trop humide, températures > 30°C, densité excessive.	2026-06-09 10:15:40.957442
88	Cercosporiose du niébé	Cercospora canescens	fongique	Taches angulaires brun-rouge sur feuilles avec halo jaune ; défoliation précoce.	Humidité > 80%, températures 25-30°C.	2026-06-09 10:15:40.966389
89	Mosaïque du niébé	Cowpea mosaic virus (CPMV)	viral	Mosaïque vert clair-vert foncé sur feuilles, déformation foliaire, nanisme.	Pucerons vecteurs (Aphis craccivora), conditions chaudes.	2026-06-09 10:15:40.96881
90	Anthracnose du niébé	Colletotrichum lindemuthianum	fongique	Lésions sombres sur les gousses, tiges et feuilles ; sporulation rose en conditions humides.	Pluies fréquentes, températures 18-24°C.	2026-06-09 10:15:40.971239
91	Flétrissement fusarien du sésame	Fusarium oxysporum f.sp. sesami	fongique	Flétrissement rapide des plants en journée, puis mort irréversible ; vaisseaux brunis à la coupe de la tige.	Sols lourds ou engorgés, températures 27-30°C, pH acide.	2026-06-09 10:15:40.99156
92	Cercosporiose du sésame	Cercospora sesami	fongique	Taches circulaires brun-rougeâtre avec halo jaune sur les feuilles ; défoliation précoce.	Humidité > 80%, températures 25-30°C.	2026-06-09 10:15:40.998785
93	Phytophtora du sésame	Phytophthora parasitica	fongique	Pourriture du collet et des racines en conditions d'engorgement.	Sol imperméable, pluies excessives, mauvais drainage.	2026-06-09 10:15:41.00103
94	Mosaïque africaine du manioc	African Cassava Mosaic Virus (ACMV)	viral	Mosaïque vert clair / vert foncé sur feuilles, déformation foliaire, chlorose, nanisme sévère.	Présence de mouche blanche (Bemisia tabaci) vectrice, boutures infectées.	2026-06-09 10:15:41.018755
95	Bactériose vasculaire du manioc	Xanthomonas phaseoli pv. manihotis	bacterien	Taches angulaires wilt foliaire, exsudat bactérien sur tiges, flétrissement descendant.	Humidité élevée, blessures, variétés sensibles.	2026-06-09 10:15:41.025365
96	Pourriture brune des racines	Phytophthora drechsleri	fongique	Pourriture humide des racines tubéreuses, odeur fermentée, chair brune.	Sol engorgé, drainage insuffisant.	2026-06-09 10:15:41.027904
97	Taches brunes foliaires	Cercospora caribaea	fongique	Taches angulaires brunes sur feuilles, halo jaune, défoliation partielle.	Humidité prolongée, températures 25-30°C.	2026-06-09 10:15:41.030081
98	Mildiou de la tomate	Phytophthora infestans	fongique	Taches huileuses brunes sur feuilles avec duvet blanc en face inférieure ; brunissement des tiges et fruits.	Humidité > 85%, températures 10-24°C, nuits fraîches et rosée.	2026-06-09 10:15:41.052502
99	Alternariose	Alternaria solani	fongique	Taches brunes concentriques (cible) sur feuilles basses, avec halo jaune ; attaque possible sur tiges et fruits.	Températures 25-30°C, humidité alternée, feuillage vieillissant.	2026-06-09 10:15:41.059037
100	Virus TYLCV (jaunissement en cuillère)	Tomato Yellow Leaf Curl Virus	viral	Feuilles enroulées en cuillère vers le haut, jaunissement des bords, rabougrissement.	Forte densité de mouche blanche (Bemisia tabaci) vecteur.	2026-06-09 10:15:41.06182
101	Fusariose vasculaire	Fusarium oxysporum f.sp. lycopersici	fongique	Jaunissement unilatéral du feuillage, flétrissement progressif, brunissement vasculaire à la coupe.	Sols infestés, températures 25-30°C, pH bas.	2026-06-09 10:15:41.064619
102	Flétrissement bactérien	Ralstonia solanacearum	bacterien	Flétrissement soudain du plant entier sans jaunissement préalable ; brunissement vasculaire brun-brique à la coupe de la tige ; exsudat laiteux caractéristique en eau.	Sols chauds (25-35°C), humidité, blessures racinaires par nématodes ou labour, pH bas (<6).	2026-06-09 10:15:41.066987
103	Mildiou de l'oignon	Peronospora destructor	fongique	Feutrage gris-violacé sur feuilles, jaunissement puis nécrose ; plants affaiblis.	Humidité > 80%, températures 13-22°C, rosée nocturne.	2026-06-09 10:15:41.089902
104	Botrytis (pourriture du col)	Botrytis allii	fongique	Pourriture grise du col du bulbe au stockage ; moisissure grise sur les tuniques.	Humidité, blessures mécaniques, récolte avec col humide.	2026-06-09 10:15:41.107586
105	Fonte des semis de l'oignon	Pythium spp. / Rhizoctonia solani	fongique	Plants tombants et pourrissant au collet en pépinière ; jaunissement brutal.	Sol mal drainé, sur-arrosage, densité excessive en pépinière.	2026-06-09 10:15:41.112447
106	Anthracnose du piment	Colletotrichum capsici / C. gloeosporioides	fongique	Taches circulaires brunes à noires sur fruits, aspect pourrissant sur tige.	Humidité > 80%, temps chaud et humide, blessures.	2026-06-09 10:15:41.135071
107	Phytophthora du collet	Phytophthora capsici	fongique	Brunissement et pourriture du collet, flétrissement rapide du plant.	Excès d'humidité au sol, mauvais drainage.	2026-06-09 10:15:41.142881
108	Mosaïque du piment	Pepper mosaic virus (PepMV) / CMV	viral	Feuilles mosaïquées, déformées, fruits tachetés ou déformés.	Pucerons vecteurs, semences infectées.	2026-06-09 10:15:41.148206
109	Fusariose du gombo	Fusarium oxysporum f.sp. vasinfectum	fongique	Jaunissement et flétrissement des feuilles, brunissement vasculaire, mort du plant.	Sols infestés, températures 25-30°C, pH bas.	2026-06-09 10:15:41.172345
110	Mosaïque jaune du gombo	Okra Yellow Vein Mosaic Virus (OYVMV)	viral	Jaunissement en réseau (veinures jaunes), feuilles déformées, fruits malformés.	Bemisia tabaci (aleurode) vecteur ; saison sèche.	2026-06-09 10:15:41.178732
111	Pourriture de la tige (fonte des semis)	Pythium spp. / Rhizoctonia solani	fongique	Brunissement et pourriture du collet en début de levée ; plants tombants.	Excès d'humidité, sol mal drainé, semis trop profonds.	2026-06-09 10:15:41.18091
112	Verticilliose	Verticillium dahliae	fongique	Jaunissement ascendant du feuillage, flétrissement, brunissement vasculaire.	Sol infesté, températures fraîches-modérées (20-28°C).	2026-06-09 10:15:41.19496
113	Alternariose des Brassicacées	Alternaria brassicae / A. brassicicola	fongique	Taches concentriques noires sur feuilles extérieures, pourriture de la pomme en conditions humides.	Humidité > 85%, rosée nocturne, températures 20-25°C.	2026-06-09 10:15:41.213581
114	Hernie du chou	Plasmodiophora brassicae	parasitaire	Galles sur les racines, flétrissement en pleine journée, croissance réduite.	Sol acide (pH < 6.5), sols humides, températures 18-25°C.	2026-06-09 10:15:41.219669
115	Pourriture noire des Brassicacées	Xanthomonas campestris pv. campestris	bacterien	Jaunissement en V à partir des bords foliaires, nervures noires, pourriture interne de la pomme.	Chaleur, humidité, blessures, irrigation par aspersion.	2026-06-09 10:15:41.221672
116	Mildiou des cucurbitacées	Pseudoperonospora cubensis	fongique	Taches angulaires jaunes en face supérieure, feutrage violet en face inférieure.	Humidité > 85%, températures 15-23°C, rosée nocturne.	2026-06-09 10:15:41.233977
117	Oïdium du concombre	Sphaerotheca fuliginea / Erysiphe cichoracearum	fongique	Poudre blanche farineuse sur les feuilles et tiges.	Temps sec et chaud, humidité relative 50-80%.	2026-06-09 10:15:41.239326
118	Anthracnose des cucurbitacées	Colletotrichum lagenarium	fongique	Taches aqueuses puis brunes sur feuilles et fruits ; fruits pourris.	Humidité élevée, températures 22-27°C.	2026-06-09 10:15:41.241121
119	Fusariose vasculaire de la pastèque	Fusarium oxysporum f.sp. niveum	fongique	Flétrissement soudain d'un côté, brunissement vasculaire rouge-brun à la coupe.	Sol infesté, pH acide, températures 25-32°C.	2026-06-09 10:15:41.253672
120	Anthracnose de la mangue	Colletotrichum gloeosporioides	fongique	Taches noires sur feuilles, fleurs et fruits ; pourriture des fruits mûrs.	Humidité élevée à la floraison, pluie pendant la nouaison.	2026-06-09 10:15:41.272146
121	Oïdium de la mangue	Oidium mangiferae	fongique	Poudre blanche sur les panicules florales et les jeunes feuilles ; avortement floral.	Temps sec et chaud, atmosphère humide la nuit, forte rosée.	2026-06-09 10:15:41.277379
122	Bactériose angulaire	Xanthomonas campestris pv. mangiferaeindicae	bacterien	Taches angulaires huileuses sur feuilles, exsudat bactérien, dessèchement.	Pluies et blessures par le vent ou les insectes.	2026-06-09 10:15:41.279254
123	Dieback (dessèchement des rameaux)	Lasiodiplodia theobromae	fongique	Dessèchement progressif des rameaux depuis l'extrémité vers la base ; chancre brun-noir sous l'écorce ; mort descendante des branches.	Blessures (taille, insectes, vent), stress hydrique prononcé, arbres affaiblis, températures élevées.	2026-06-09 10:15:41.281448
124	Anthracnose de l'anacarde	Colletotrichum gloeosporioides	fongique	Taches nécrotiques sur panicules, feuilles et pommes cajou ; dessèchement floral.	Pluies et humidité à la floraison.	2026-06-09 10:15:41.298317
125	Oïdium de l'anacarde	Oidium anacardii	fongique	Poudre blanche sur jeunes feuilles et panicules ; avortement floral.	Temps sec avec humidité nocturne.	2026-06-09 10:15:41.303288
126	Maladie de Panama (Fusariose)	Fusarium oxysporum f.sp. cubense (race 1 et race 4TR)	fongique	Jaunissement des feuilles de l'extérieur vers le centre, brunissement vasculaire rouge à la coupe.	Sol infesté, blessures racinaires, stress hydrique.	2026-06-09 10:15:41.318299
127	Sigatoka noire	Mycosphaerella fijiensis	fongique	Stries brun-noir sur feuilles, nécrose rapide, défoliation sévère réduisant la photosynthèse.	Humidité > 80%, températures 25-28°C, précipitations fréquentes.	2026-06-09 10:15:41.323661
128	Anthracnose post-récolte	Colletotrichum musae	fongique	Taches noires sur fruits mûrs au cours du mûrissage.	Humidité, chaleur, blessures mécaniques.	2026-06-09 10:15:41.325625
129	Ringspot de la papaye (PRSV)	Papaya ringspot virus	viral	Mosaïque des feuilles, anneaux sur les fruits, nanisme, déformation totale.	Pucerons vecteurs (Myzus persicae, Aphis gossypii), saison sèche.	2026-06-09 10:15:41.339515
130	Anthracnose de la papaye	Colletotrichum gloeosporioides	fongique	Lésions circulaires noires sur les fruits mûrs avec cavités en post-récolte.	Humidité élevée, fruits blessés, chaleur.	2026-06-09 10:15:41.345068
131	Pythium (fonte du collet)	Pythium aphanidermatum	fongique	Pourriture et noircissement du collet, flétrissement et mort rapide du plant.	Engorgement du sol, mauvais drainage.	2026-06-09 10:15:41.347385
\.


--
-- Data for Name: agro_parametres_climatiques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_parametres_climatiques (id, culture_id, temp_min_c, temp_opt_min_c, temp_opt_max_c, temp_max_c, pluvio_min_mm, pluvio_opt_mm, pluvio_max_mm, altitude_max_m, ensoleillement_h, ph_min, ph_opt_min, ph_opt_max, ph_max, texture_preferee) FROM stdin;
21	21	15.0	24.0	30.0	38.0	400	1200	2000	1500	7.0	5.0	5.5	6.5	7.5	Argilo-limoneux, imperméable, bien retenant l'eau
22	22	10.0	22.0	32.0	40.0	500	800	1500	1500	8.0	5.5	6.0	7.0	8.0	Limon-sableux à argilo-limoneux, bien drainé
23	23	15.0	25.0	32.0	40.0	400	700	1200	1500	8.0	5.5	6.0	6.8	7.5	Sablo-limoneux, bien drainé, meuble (pénétration des gynophores)
24	24	20.0	28.0	35.0	42.0	250	500	900	1500	8.5	5.0	5.5	7.0	8.0	Sablo-limoneux, bien drainé, tolérance aux sols pauvres
25	25	15.0	27.0	34.0	42.0	300	600	1000	1500	8.0	5.5	6.0	7.5	8.5	Argilo-limoneux à limon-sableux ; tolère les vertisols
26	26	18.0	25.0	35.0	42.0	300	600	1000	1500	8.5	5.5	6.0	7.0	8.0	Limon-sableux à sablo-limoneux, bien drainé
27	27	20.0	28.0	35.0	42.0	300	550	800	1500	9.0	5.5	6.0	7.0	7.5	Limon-sableux bien drainé ; sensible à l'engorgement
28	28	18.0	25.0	32.0	40.0	600	1200	2000	1500	7.5	4.5	5.5	6.5	7.5	Sablo-limoneux à limon-sableux, bien drainé, meuble
29	29	10.0	18.0	27.0	38.0	400	600	1200	1500	8.0	5.5	6.0	6.8	7.5	Limon-sableux à argilo-limoneux, bien drainé, riche en M.O.
30	30	7.0	15.0	25.0	35.0	300	500	900	1500	9.0	6.0	6.2	7.0	7.8	Sablo-limoneux à limoneux, bien drainé, riche en matière organique
31	31	15.0	22.0	30.0	38.0	400	600	1200	1500	8.0	5.5	6.0	6.8	7.5	Limon-sableux à limoneux, bien drainé, riche en M.O.
32	32	20.0	27.0	35.0	42.0	400	700	1500	1500	9.0	6.0	6.5	7.5	8.0	Sablo-limoneux à argilo-limoneux, bien drainé
33	33	17.0	22.0	32.0	40.0	400	600	1200	1500	8.5	5.5	6.0	6.8	7.5	Limon-sableux, bien drainé, riche en matière organique
34	34	5.0	15.0	22.0	32.0	300	500	900	1500	7.0	6.0	6.5	7.0	7.5	Limon-argileux, bien drainé, riche en matière organique
35	35	15.0	22.0	30.0	38.0	400	600	1200	1500	8.0	6.0	6.2	7.0	7.5	Sablo-limoneux, bien drainé, riche en matière organique
36	36	18.0	25.0	35.0	42.0	300	600	1000	1500	9.0	6.0	6.5	7.5	8.0	Sablo-limoneux, bien drainé, sol léger et chaud
37	37	15.0	24.0	35.0	42.0	500	1000	2000	1500	9.0	5.5	6.0	7.0	7.5	Limon-sableux à argilo-limoneux, bien drainé, profond
38	38	10.0	24.0	35.0	42.0	600	1200	2000	1500	9.0	5.0	5.5	6.5	7.5	Sol sablo-limoneux, bien drainé, supporte sols pauvres et latéritiques
39	39	14.0	25.0	35.0	40.0	1000	1500	3000	1500	8.5	5.5	6.0	7.0	7.5	Limon-argileux, bien drainé, riche en matière organique, profond
40	40	15.0	22.0	32.0	38.0	600	1200	2000	1500	9.0	5.5	6.0	6.8	7.5	Limon-sableux, très bien drainé (intolérant à l'engorgement), riche en M.O.
\.


--
-- Data for Name: agro_ravageurs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_ravageurs (id, nom, nom_scientifique, type_ravageur, description, symptomes_degats, created_at) FROM stdin;
54	Foreur de tige du riz	Chilo suppressalis / Diopsis thoracica	insecte	Larves qui percent la tige et détruisent le point de croissance ou la panicule.	Cœur mort (dead heart) au tallage, panicule blanche stérile (white ear) à l'épiaison.	2026-06-09 10:15:40.803928
55	Quelea / Mange-mil	Quelea quelea	oiseau	Oiseau granivore migrateur attaquant en nuées de millions d'individus.	Grains arrachés et broutés sur la panicule ; dégâts massifs en quelques heures.	2026-06-09 10:15:40.806291
56	Hispe du riz	Dicladispa armigera	insecte	Coléoptère dont larves et adultes minent et rognent les feuilles.	Stries blanches longitudinales sur les feuilles ; aspect grillé du feuillage.	2026-06-09 10:15:40.810361
57	Nématode des racines	Meloidogyne graminicola	nematode	Nématode endoparasite formant des galles sur les racines du riz.	Galles sur racines, jaunissement, tallage réduit, plants chétifs.	2026-06-09 10:15:40.812977
58	Chenille légionnaire d'automne	Spodoptera frugiperda	insecte	Lépidoptère invasif (depuis 2016 en Afrique) dont les larves ravagent le cœur de la plante.	Trous dans les feuilles, sciure de bois dans le cornet, destruction du point végétatif.	2026-06-09 10:15:40.846846
59	Foreur de tige du maïs	Busseola fusca / Sesamia calamistis	insecte	Larves qui pénètrent dans la tige et créent des galeries, affaiblissant la plante.	Cœur mort, verse des plants attaqués, galeries dans la tige.	2026-06-09 10:15:40.848968
60	Cicadelle vectrice du MSV	Cicadulina mbila	insecte	Insecte piqueur-suceur qui transmet le Maize Streak Virus.	Stries virales sur les feuilles ; transmission en chaîne de plante à plante.	2026-06-09 10:15:40.851953
61	Puceron noir (Aphis craccivora)	Aphis craccivora	insecte	Puceron noir vecteur du virus de la rosette ; colonies sur les jeunes pousses.	Déformation des feuilles, miellat favorisant la fumagine, transmission virale.	2026-06-09 10:15:40.879302
62	Termites	Macrotermes spp. / Microtermes spp.	insecte	Termites qui attaquent les racines, tiges et gousses souterraines de l'arachide.	Plants flétris puis morts subitement, gousses rongées, galeries de terre sur tiges.	2026-06-09 10:15:40.880906
63	Ver blanc / Hanneton	Pachnoda marginata / Heteronychus spp.	insecte	Larves de coléoptères qui rongent les racines et les gousses dans le sol.	Flétissement des plants, gousses rongées, galeries dans le sol.	2026-06-09 10:15:40.88315
64	Striga (plante parasite)	Striga hermonthica	plante_parasite	Plante parasite hémiholoparasite qui se fixe sur les racines du mil et lui vole eau et nutriments.	Nanisme, jaunissement, plant parasité ne peut atteindre sa maturité ; tiges rouges-violettes du Striga.	2026-06-09 10:15:40.909163
65	Foreur des tiges / Panicules	Coniesta ignefusalis / Heliocheilus albipunctella	insecte	Larves qui pénètrent dans la tige (cœur mort) ou s'attaquent aux panicules.	Cœur mort au tallage, panicules partiellement détruites, galeries dans la tige.	2026-06-09 10:15:40.911343
66	Foreur de tige du sorgho	Busseola fusca	insecte	Larves de noctuelle qui pénètrent dans la tige causant le dépérissement.	Cœur mort (dead heart), tiges avec galeries, cassure de la tige principale.	2026-06-09 10:15:40.937034
67	Cochenille du sorgho	Melanaspis glomerata	insecte	Cochenille diaspididae formant des colonies sur les tiges et les feuilles.	Jaunissement et dessèchement des tiges infestées ; réduction de la croissance.	2026-06-09 10:15:40.938388
68	Cécidomyie du sorgho	Stenodiplosis sorghicola	insecte	Moucheron dont les larves se développent dans les grains en formation, les vidant complètement.	Grains vides (fleurets rouges restants caractéristiques), panicules apparemment saines mais stériles.	2026-06-09 10:15:40.940822
69	Noctuelle américaine (Helicoverpa)	Helicoverpa armigera	insecte	Chenille polyphage attaquant panicules, grains et fruits sur nombreuses cultures ; ravageur mondial majeur.	Perforations et galeries dans grains et panicules ; déjections caractéristiques (boulettes noirâtres).	2026-06-09 10:15:40.944431
70	Bruche du niébé	Callosobruchus maculatus	insecte	Coléoptère dont les larves se développent à l'intérieur des grains stockés.	Trous ronds dans les grains, farine à l'intérieur, grains non comestibles.	2026-06-09 10:15:40.973896
71	Thrips des fleurs	Megalurothrips sjostedti	insecte	Thrips qui se nourrit des fleurs et jeunes gousses du niébé.	Déformation des fleurs, avortement des gousses, rugosité des feuilles.	2026-06-09 10:15:40.975582
72	Punaise du niébé	Clavigralla tomentosicollis / Riptortus dentipes	insecte	Punaises hémiptères perçant les gousses et grains en développement avec leur rostre.	Grains tachetés, déformés ou avortés ; chute prématurée de gousses ; taches noires sur grains séchés.	2026-06-09 10:15:40.978547
73	Punaise du sésame	Antigastra catalaunalis	insecte	Lépidoptère dont les larves minent les feuilles et s'attaquent aux capsules.	Feuilles minées avec passages blancs, capsules percées et vidées.	2026-06-09 10:15:41.003585
74	Puceron du coton (Aphis gossypii)	Aphis gossypii	insecte	Puceron vert-jaune formant des colonies sur les jeunes pousses et fleurs.	Déformation des feuilles et fleurs, fumagine, réduction de la croissance.	2026-06-09 10:15:41.005218
75	Acarien rouge	Tetranychus urticae	acarien	Acarien tisserand formant des toiles sur la face inférieure des feuilles.	Jaunissement et bronzage des feuilles, toiles fines, défoliation en saison sèche.	2026-06-09 10:15:41.007467
76	Cochenille farineuse du manioc	Phenacoccus manihoti	insecte	Cochenille couverte de cire blanche formant des colonies sur les parties terminales.	Déformation des tiges ('queue de rat'), feuilles réduites, nanisme, fumagine.	2026-06-09 10:15:41.033766
77	Mouche blanche (Bemisia tabaci)	Bemisia tabaci	insecte	Aleurode vecteur des virus de la mosaïque africaine ; dommages directs par succion.	Jaunissement foliaire, fumagine, transmission virale (mosaïque).	2026-06-09 10:15:41.03561
78	Acarien vert du manioc	Mononychellus tanajoa	acarien	Acarien inféodé au manioc, proliférant en saison sèche chaude.	Chlorose des jeunes feuilles, déformation et nécrose, bronzage foliaire.	2026-06-09 10:15:41.038162
79	Mineuse de la tomate	Tuta absoluta	insecte	Lépidoptère invasif (depuis 2012 en Afrique de l'Ouest) ravageant tomates sous abris et en plein champ.	Mines blanchâtres dans les feuilles, galeries dans les fruits, attaque des tiges.	2026-06-09 10:15:41.06986
80	Thrips	Frankliniella occidentalis / Thrips tabaci	insecte	Insecte minuscule piqueur-suceur vecteur du TSWV (virus de la bronzure de la tomate).	Déformations florales, cicatrices argentées sur fruits, transmission virale.	2026-06-09 10:15:41.072392
81	Thrips de l'oignon	Thrips tabaci	insecte	Principal ravageur de l'oignon au Sénégal ; insecte minuscule piqueur-suceur.	Rayures argentées sur feuilles, déformation et décoloration, plants affaiblis.	2026-06-09 10:15:41.115453
82	Mouche de l'oignon	Delia antiqua	insecte	Diptère dont les larves creusent les bulbes et les tiges.	Plants flétris, galeries dans les bulbes, pourriture secondaire.	2026-06-09 10:15:41.117204
83	Nématodes des racines	Meloidogyne spp.	nematode	Nématodes endoparasites formant des galles sur les racines de l'oignon.	Plants chétifs, jaunissement, galles sur racines, bulbes petits et difformes.	2026-06-09 10:15:41.119464
84	Thrips du piment	Thrips tabaci / Frankliniella occidentalis	insecte	Insectes minuscules piquant les fleurs et les jeunes fruits.	Avortement floral, cicatrices et déformations sur fruits, transmission virale.	2026-06-09 10:15:41.153647
85	Pucerons verts	Myzus persicae	insecte	Puceron vecteur de nombreux virus du piment.	Enroulement des feuilles, miellat, fumagine, transmission virale.	2026-06-09 10:15:41.156077
86	Jassides (cicadelles)	Empoasca facialis	insecte	Cicadelle piqueur-suceur causant le dessèchement marginal des feuilles.	Bords des feuilles brunis et recroquevillés (tip burn), plants chétifs.	2026-06-09 10:15:41.183555
87	Punaise verte du gombo	Nezara viridula	insecte	Punaise piquant les fruits en développement ; fruits déformés.	Taches liégeuses sur fruits, déformation, chute prématurée.	2026-06-09 10:15:41.185779
88	Doryphore africain de l'aubergine	Leucinodes orbonalis	insecte	Lépidoptère dont les larves percent les fruits de l'aubergine.	Trous d'entrée avec galeries dans les fruits, présence de larves roses.	2026-06-09 10:15:41.20339
89	Teigne du chou	Plutella xylostella	insecte	Lépidoptère dont les larves minent les feuilles et pénètrent dans le cœur de la pomme.	Mines translucides sur feuilles, trous dans les feuilles, dégâts sur la pomme.	2026-06-09 10:15:41.223882
90	Pucerons du chou	Brevicoryne brassicae	insecte	Puceron farieux bleu-vert colonisant la face inférieure des feuilles.	Feuilles déformées et jaunissantes, miellat favorisant la fumagine.	2026-06-09 10:15:41.2252
91	Mouche des cucurbitacées	Bactrocera cucurbitae	insecte	Diptère dont les femelles pondent dans les jeunes fruits.	Fruits perforés, pourriture interne, chute des fruits.	2026-06-09 10:15:41.243319
92	Mouche des fruits de la mangue	Ceratitis cosyra / Bactrocera invadens	insecte	Diptère ravageur majeur ; femelles pondent dans les fruits en maturité.	Fruits piqués, galeries de larves, pourriture interne et chute des fruits.	2026-06-09 10:15:41.284122
93	Cochenilles farineusse	Rastrococcus invadens	insecte	Cochenille envahissante colonisant les fruits et rameaux.	Miellat favorisant la fumagine, fruits collants et noircis, réduction de la vigueur.	2026-06-09 10:15:41.285648
94	Cécidomyie de la mangue	Erosomyia mangiferae	insecte	Moucheron dont les larves ravagent les panicules florales.	Avortement floral massif ; panicules noircissant et tombant.	2026-06-09 10:15:41.287631
95	Hélopelte de l'anacarde	Helopeltis anacardii	insecte	Punaise piqueuse attaquant les jeunes pousses et les fruits en développement.	Lésions nécrotiques noires sur les jeunes fruits, pousses et feuilles.	2026-06-09 10:15:41.306744
96	Cochenille de l'anacarde	Planococcus citri	insecte	Cochenille colonisant les rameaux et les fruits.	Miellat, fumagine noire sur les fruits, réduction de la vigueur.	2026-06-09 10:15:41.308324
97	Charançon du bananier	Cosmopolites sordidus	insecte	Coléoptère dont les larves creusent le pseudo-tronc et le bulbe.	Galeries dans le pseudo-tronc et le rhizome, plant affaibli ou mort.	2026-06-09 10:15:41.327931
98	Nématodes des bananiers	Radopholus similis / Meloidogyne spp.	nematode	Nématodes endoparasites des racines causant pourriture et déracinement.	Racines pourries, plant déraciné par le vent, réduction du régime.	2026-06-09 10:15:41.329307
99	Mouche des fruits	Bactrocera cucurbitae / Ceratitis capitata	insecte	Femelles pondent dans les fruits mûrs ou brécheux.	Fruits piqués avec galeries, pourriture interne, chute prématurée.	2026-06-09 10:15:41.349829
100	Pucerons vecteurs PRSV	Myzus persicae / Aphis gossypii	insecte	Pucerons transmettant le virus PRSV de plante en plante.	Mosaïque virale (PRSV), dégâts directs mineurs mais transmission dévastatrice.	2026-06-09 10:15:41.351187
\.


--
-- Data for Name: agro_recommandations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_recommandations (id, culture_id, zone_agro, categorie_reco, titre, contenu, priorite, mois_applicable, created_at) FROM stdin;
52	21	\N	recolte	Séchage rapide après récolte	Récolter quand 80-85% des grains sont dorés (humidité ≈ 20-22%). Sécher immédiatement sur bâches à l'ombre ou étuve pour atteindre 13-14% d'humidité. Ne pas stocker au-dessus de 14% pour éviter les moisissures.	2	[10, 11, 12, 5, 6]	2026-06-09 10:15:40.817598
49	21	vallee_fleuve	semis_plantation	Repiquage en poquets à densité optimale	Repiquer 2-3 plants âgés de 21-25 jours par poquet, en lignes 20×20 cm. Un repiquage trop tardif ou trop profond réduit le tallage. Planter tôt le matin pour limiter le stress thermique des plants.	1	[7, 8]	2026-06-09 10:15:40.817592
50	21	\N	fertilisation	Fractionnement de l'azote en 3 apports	Apporter l'urée en 3 fois : 1/3 à la reprise (J+7), 1/3 au tallage actif (J+25), 1/3 avant l'épiaison (gonflement). Cette pratique réduit les pertes par volatilisation et évite la verse. Ne jamais appliquer l'urée sur sol sec.	1	[7, 8, 9, 10]	2026-06-09 10:15:40.817596
51	21	\N	protection_phyto	Surveillance précoce de la pyriculariose	Inspecter les feuilles dès le tallage actif. Taches losangiques grises = pyriculariose. Traiter immédiatement au Tricyclazole (Beam 75WP, 0,6 kg/ha). Éviter les excès d'azote qui favorisent l'attaque.	1	[8, 9, 10]	2026-06-09 10:15:40.817597
53	22	\N	protection_phyto	Surveillance quotidienne de la chenille légionnaire	Inspecter le cornet de chaque plant dès la levée. Présence de sciure = larves actives. Traiter dès le début d'infestation (stade L1-L2) avec Emamectin benzoate dans le cornet. Le traitement tardif (larves > L3) est beaucoup moins efficace.	1	[7, 8, 9]	2026-06-09 10:15:40.85415
54	22	\N	semis_plantation	Semis à densité optimale et démariage	Semer 3-4 grains par poquet (80×40 cm) et démarier à 2 plants par poquet au stade V3. La densité optimale est de 55 000 à 65 000 plants/ha. Densité trop forte = verse et maladies fongiques.	1	[6, 7]	2026-06-09 10:15:40.854154
55	22	\N	recolte	Séchage et stockage sous hermétisme	Récolter à maturité physiologique (pointe noire visible). Sécher en épis ou en grains jusqu'à 13% d'humidité. Stocker dans des sacs hermétiques GrainPro ou silos métalliques pour éviter les pertes dues aux charançons et moisissures.	2	[10, 11, 12]	2026-06-09 10:15:40.854155
56	23	bassin_arachidier	semis_plantation	Utiliser des semences certifiées ISRA	Éviter de recycler les semences d'une récolte à l'autre (dégénérescence). Utiliser des semences certifiées des variétés 55-437 ou Fleur 11 disponibles via l'ISRA/FONGS. Traiter les semences au thirame avant semis pour protéger contre les fontes de semis (10 g/kg de semences).	1	[5, 6, 7]	2026-06-09 10:15:40.885454
57	23	\N	recolte	Prévention des aflatoxines par séchage rapide	Récolter au bon stade de maturité (ne pas laisser sur pied en sol sec). Sécher les gousses immédiatement en couche mince à l'air libre pendant 5-7 jours. Stocker à moins de 10% d'humidité dans des sacs hermétiques. Les aflatoxines rendent l'arachide non exportable et dangereuse pour la santé.	1	[9, 10, 11]	2026-06-09 10:15:40.885458
58	23	\N	fertilisation	Inoculation au Rhizobium pour économiser l'azote	Inoculer les semences avec Bradyrhizobium japonicum avant le semis (inoculant disponible à l'ISRA Bambey). Cette pratique apporte jusqu'à 150 kg N/ha gratuitement via la fixation biologique et améliore le rendement de 15-25% sans coût supplémentaire en urée.	2	[6, 7]	2026-06-09 10:15:40.885459
59	24	zone_sylvopastorale	semis_plantation	Semis impératif dès les premières pluies utiles	Dans la zone sylvopastorale, la saison des pluies dure 60-70 jours maximum. Semer dès que 25-30 mm de pluie ont été reçus en 3-4 jours. Utiliser uniquement des variétés hâtives (Souna 3, cycle ≤ 85 jours). Le retard au semis = réduction de 100 kg/ha de rendement par semaine.	1	[6, 7]	2026-06-09 10:15:40.913326
60	24	\N	preparation_terrain	Démariage rigoureux à 2 plants par poquet	Le démariage est une opération cruciale trop souvent négligée. Démarier à 2 plants/poquet au stade 3-4 feuilles (J12-15). Garder les plants les plus vigoureux. Un poquet surdensifié donne des épis chétifs et est plus sensible au mildiou.	1	[7, 8]	2026-06-09 10:15:40.91333
61	24	\N	protection_phyto	Lutte collective contre les oiseaux (Quelea)	Le Quelea quelea ne peut être combattu efficacement qu'à l'échelle villageoise. Organiser un système de guet tournant dès l'épiaison (6h-19h). Utiliser des effrayants sonores, des rubans brillants et des silhouettes de prédateurs. Signaler les invasions à la brigade phytosanitaire (DGPV).	1	[9, 10]	2026-06-09 10:15:40.913331
62	25	\N	preparation_terrain	Labour avant hivernage pour casser la croûte et éliminer les adventices	Un labour profond (20-25 cm) en fin de saison sèche améliore la rétention d'eau et réduit le stock de graines d'adventices. Enfouir les résidus de culture pour réduire la source d'inoculum des maladies (anthracnose, charbon).	2	[4, 5, 6]	2026-06-09 10:15:40.946804
63	25	\N	fertilisation	Valoriser la fumure organique en complément des engrais minéraux	Le sorgho répond bien à la fumure organique (fumier, compost). Apporter 3-5 t/ha de fumier composté avant labour. En complément, 45 kg/ha de DAP au semis + 80 kg/ha d'urée en 2 fractions. La fumure organique améliore la structure du sol et réduit le besoin en engrais minéraux.	1	[5, 6, 7, 8]	2026-06-09 10:15:40.946807
64	25	casamance	semis_plantation	Préserver les variétés locales photopériodiques	Les variétés locales de sorgho photopériodiques de Casamance sont adaptées aux conditions locales (résistance aux maladies, qualité gustative). Les conserver dans les banques de semences communautaires. Les associer avec des variétés améliorées pour diversifier les risques.	2	[6, 7]	2026-06-09 10:15:40.946808
65	26	\N	recolte	Protection des stocks contre les bruches	La bruche du niébé (Callosobruchus) est le principal ennemi du niébé stocké. Récolter les gousses bien sèches, battre et vanner. Sécher les grains à l'air à <12% d'humidité. Stocker immédiatement dans des sacs hermétiques GrainPro ou jerricans + Actellic 2% dust (2 g/kg). Ne jamais stocker sans traitement préventif.	1	[9, 10, 11, 12, 1, 2]	2026-06-09 10:15:40.982493
66	26	\N	protection_phyto	Traitement contre les thrips à la floraison	Les thrips (Megalurothrips sjostedti) sont le ravageur le plus destructeur du niébé. Inspecter les fleurs dès le début de la floraison (insectes minuscules bruns). Traiter avec Karaté 2,5EC (0,5 L/ha) dès les premiers dégâts, de préférence le soir pour préserver les pollinisateurs.	1	[8, 9, 10]	2026-06-09 10:15:40.982497
67	26	\N	semis_plantation	Inoculer les semences avec Rhizobium	L'inoculation des semences de niébé avec Bradyrhizobium japonicum améliore la fixation d'azote de 30-50%. L'inoculant est disponible à l'ISRA Bambey. Enrober les graines humidifiés avec l'inoculant juste avant le semis, à l'ombre pour éviter l'inactivation par le soleil.	2	[7, 8]	2026-06-09 10:15:40.982498
68	27	\N	recolte	Récolte avant déhiscence totale des capsules	Le sésame est très sensible à la déhiscence (ouverture des capsules). Récolter quand 20-30% des capsules basales sont jaunies mais pas encore ouvertes. Couper les plants à la base tôt le matin, les mettre debout en bottes sur des bâches. Ne jamais laisser mûrir complètement sur pied : pertes de 40-60% possibles.	1	[10, 11]	2026-06-09 10:15:41.009564
69	27	\N	semis_plantation	Préparation du lit de semence pour les petites graines	Les graines de sésame sont très petites (0,3 g/1000 graines). Le lit de semence doit être finement émietté, sans mottes, parfaitement nivelé. Mélanger les graines avec 3-5 fois leur volume de sable fin pour faciliter la distribution. Semer en ligne à 45-50 cm, sans dépasser 4-5 kg de graines/ha.	1	[7, 8]	2026-06-09 10:15:41.009567
70	27	\N	preparation_terrain	Drainage impératif pour éviter le flétrissement fusarien	Le sésame est très sensible à l'engorgement. Ne jamais cultiver en bas-fond ou en terrain plat imperméable. Billonner les rangs à 20-25 cm de hauteur pour favoriser le drainage. En sol argileux, faire des planches surélevées. Le flétrissement fusarien qui en résulte est irréversible et très destructeur.	1	[7, 8]	2026-06-09 10:15:41.009568
71	28	casamance	semis_plantation	Utiliser uniquement des boutures certifiées indemnes de mosaïque	La mosaïque africaine est la principale contrainte du manioc. Sélectionner des boutures issues de plants sains (feuilles uniformément vertes, sans mosaïque). Les variétés résistantes TME 419 et TMS 30572 sont disponibles à l'ISRA. Ne jamais utiliser des boutures de plants malades même si elles semblent bonnes.	1	[5, 6, 7]	2026-06-09 10:15:41.042037
72	28	\N	recolte	Transformation rapide après récolte	Les racines de manioc se détériorent en 24-48h après l'arrachage. Planifier la transformation immédiate (gari, attiéké, farine, cossettes séchées). Si stockage en terre non possible : couvrir avec des feuilles de manioc et consommer sous 2-3 jours. La transformation en cossettes séchées (teneur < 14%) est la meilleure option de conservation.	1	[1, 2, 3, 4, 5, 6, 11, 12]	2026-06-09 10:15:41.04204
73	28	\N	fertilisation	Priorité au potassium pour les tubercules	Le potassium (K) est l'élément le plus important pour le manioc. Un apport insuffisant en K réduit le rendement en tubercules et leur teneur en amidon. Apporter KCl (100 kg/ha) à J90 en complément du NPK de fond. Sur sols sableux très pauvres, doubler la dose de KCl pour compenser la lixiviation.	2	[8, 9, 10]	2026-06-09 10:15:41.042041
74	28	\N	protection_phyto	Favoriser la lutte biologique contre la cochenille farineuse	Le parasitoïde Anagyrus lopezi est le principal ennemi naturel de la cochenille farineuse (Phenacoccus manihoti). Éviter les insecticides à large spectre qui éliminent ce parasitoïde. En cas d'infestation sévère, contacter le service de protection des végétaux (DGPV) pour obtenir des lâchers d'Anagyrus lopezi.	2	[1, 2, 3, 4, 11, 12]	2026-06-09 10:15:41.042042
75	29	\N	protection_phyto	Gestion intégrée Tuta absoluta	Installer 1 piège à phéromones par 500 m² dès la plantation. Surveiller quotidiennement les mines sur feuilles. Traiter dès les premiers adultes avec Emamectin benzoate ou Chlorantraniliprole. Alterner les matières actives pour éviter les résistances.	1	[9, 10, 11, 12, 1, 2, 3]	2026-06-09 10:15:41.079786
76	29	\N	fertilisation	Prévention de la nécrose apicale (BER) par apport de calcium	La BER (bout blanc des fruits) est due à une carence en calcium exacerbée par l'irrégularité d'arrosage. Appliquer CaNO3 (150 kg/ha en fertigation) et un fertilisant foliaire à base de chlorure de calcium (0,5%) 2 fois/semaine dès la nouaison.	1	[1, 2, 3, 11, 12]	2026-06-09 10:15:41.079791
77	29	niayes	semis_plantation	Utiliser des variétés résistantes au TYLCV dans les Niayes	Les zones Niayes ont une forte pression de Bemisia tabaci vecteur du TYLCV. Utiliser exclusivement des hybrides F1 avec gène Ty (Mongal, Power Ranger, Padma). Protéger la pépinière avec des filets anti-insectes (50 mesh).	1	[8, 9, 10, 11]	2026-06-09 10:15:41.079792
78	30	vallee_fleuve	semis_plantation	Pépinière soignée = succès de la culture	La qualité de la pépinière détermine 60% du succès. Utiliser un substrat solarisé ou pasteurisé. Semer à densité correcte (8-10 g/m²). Plants trop fins ou malades causent une mauvaise reprise et perte de rendement.	1	[9, 10]	2026-06-09 10:15:41.121808
79	30	\N	recolte	Séchage post-récolte pour éviter les pertes au stockage	Sécher les bulbes 7-10 jours en andains dans le champ après arrachage. Compléter 2-3 semaines en stockage ventilé (hangar avec filets). Humidité des bulbes < 12% avant stockage longue durée. Le mauvais séchage est la 1ère cause de pertes post-récolte au Sénégal.	1	[2, 3, 4, 5]	2026-06-09 10:15:41.121812
80	31	\N	recolte	Récolte et séchage pour le piment sec	Pour la production de piment sec, laisser les fruits atteindre la pleine maturité (rouge vif). Récolter par temps sec. Sécher sur claies ou bâches au soleil pendant 5-10 jours. Humidité finale < 12% avant broyage ou stockage. Le piment sec se conserve 6-12 mois dans des sacs hermétiques à l'abri de l'humidité.	2	[11, 12, 1, 2, 3, 4]	2026-06-09 10:15:41.161743
81	31	\N	protection_phyto	Lutte intégrée contre les thrips	Les thrips sont le ravageur n°1 du piment. Installer des pièges bleus collants (1 piège/100 m²). Traiter dès détection avec Spinosad le matin (moins d'impact sur les pollinisateurs). Alterner avec Abamectine toutes les 2 semaines pour éviter les résistances.	1	[1, 2, 3, 11, 12]	2026-06-09 10:15:41.161747
82	32	\N	recolte	Récolte quotidienne pour maintenir la qualité	Récolter les fruits à 5-8 cm (avant lignification fibreuse). Ne pas dépasser 3-4 jours entre les récoltes. Fruits trop mûrs non récoltés épuisent le plant et réduisent la floraison. Porter des gants pour la récolte (poils irritants sur certaines variétés).	1	[1, 2, 3, 8, 9, 10, 11]	2026-06-09 10:15:41.187796
83	32	\N	semis_plantation	Trempage des semences pour améliorer la germination	Tremper les graines dans l'eau tiède (30°C) pendant 12-24 heures avant semis. Cette technique améliore le taux de germination de 20-30%. Après trempage, semer immédiatement sans laisser sécher les graines.	2	[5, 6, 7, 10, 11, 12]	2026-06-09 10:15:41.187798
84	33	\N	protection_phyto	Surveillance obligatoire du foreur des fruits (Leucinodes)	Leucinodes orbonalis est le ravageur n°1 de l'aubergine au Sénégal. Inspecter tous les fruits lors de chaque récolte. Traiter à l'Emamectin benzoate dès détection. Fruits perforés à éliminer immédiatement pour éviter la propagation.	1	[1, 2, 3, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.206749
85	34	niayes	protection_phyto	Lutte intégrée contre la teigne du chou	Installer des pièges à phéromones (1/500 m²). Appliquer Bacillus thuringiensis (Bt) dès la levée, tous les 7 jours. Réserver l'Emamectin benzoate pour les fortes infestations uniquement. Alterner les matières actives pour lutter contre les résistances (fréquentes chez Plutella).	1	[10, 11, 12, 1, 2, 3]	2026-06-09 10:15:41.226849
86	35	\N	protection_phyto	Lutte contre la mouche des cucurbitacées par pièges	Installer des pièges à protéine-insecticide (1 piège/500 m²) dès la floraison. Ramasser et détruire tous les fruits tombés ou piqués. Ne pas laisser les fruits mûrir sur la plante (source de reproduction). La mouche est la principale raison des pertes post-floraison au Sénégal.	1	[12, 1, 2, 3, 4]	2026-06-09 10:15:41.245615
87	36	\N	recolte	Identifier la maturité de la pastèque sans la couper	Pour déterminer la maturité sans couper le fruit : 1) Vrille la plus proche du fruit complètement sèche = mûr ; 2) Son creux et profond à la percussion (son sourd) ; 3) Face ventrale jaune ou crème ; 4) Queue du fruit légèrement sèche. Ne jamais récolter avec la vrille encore verte.	1	[2, 3, 4, 5, 10, 11]	2026-06-09 10:15:41.265275
88	36	vallee_fleuve	semis_plantation	Préparation profonde du sol pour la pastèque	La pastèque a un système racinaire profond (1-1,5 m). Labourer à 40 cm de profondeur si possible. Incorporer 5 t/ha de compost pour améliorer la capacité de rétention en eau. Billons de 30 cm de hauteur recommandés pour le drainage.	2	[10, 11, 12]	2026-06-09 10:15:41.265279
89	37	\N	protection_phyto	Gestion de la mouche des fruits pour l'export	La mouche des fruits est le principal obstacle à l'export. Installer 1 piège McPhail avec attractif protéiné par ha dès la nouaison. Ramasser et détruire quotidiennement les fruits tombés. Récolter à maturité optimale (brécheux) sans laisser les fruits sur l'arbre. Les mangues destinées à l'export nécessitent un traitement post-récolte (eau chaude 46°C pendant 90 min ou vapeur chaleur) pour certifier l'absence de larves.	1	[4, 5, 6, 7]	2026-06-09 10:15:41.289718
90	37	\N	preparation_terrain	Taille de formation et d'entretien	Tailler immédiatement après la récolte (juillet-août). Supprimer les branches mortes, croisées et les gourmands. Objectif : houppier aéré en gobelet ou vase, hauteur contrôlée à 4-5 m. Enduire les plaies de taille avec de la bouillie bordelaise ou du goudron. Un arbre bien taillé produit plus et est plus facile à traiter.	1	[7, 8]	2026-06-09 10:15:41.289721
91	38	casamance	recolte	Ramassage quotidien pour la qualité des noix	Les noix de cajou tombent naturellement au sol. Ramasser quotidiennement le matin avant la chaleur. Les noix laissées au sol > 24h se détériorent (humidité, insectes). Sécher immédiatement sur claies 3-5 jours à 12-14% humidité avant stockage. Stocker dans des sacs de jute aérés à l'abri de l'humidité et de la pluie.	1	[3, 4, 5]	2026-06-09 10:15:41.310268
92	38	\N	preparation_terrain	Plantation en verger structuré pour augmenter les rendements	La plupart des vergers sénégalais sont des plantations non structurées. Planter en ligne à 10×10 m (100 arbres/ha) avec des clones ISRA (Jumbo 1, B11). Désherber le premier cercle (2 m de rayon) autour de chaque arbre. Les vergers structurés avec clones améliorés produisent 3-5 fois plus que les plantations paysannes non entretenues.	1	[6, 7, 8]	2026-06-09 10:15:41.310271
93	39	\N	semis_plantation	Utiliser des vitroplants certifiés	Les rejets paysans sont souvent infestés par le charançon et les nématodes. Investir dans des vitroplants in vitro certifiés (disponibles à l'ITA Dakar ou ISRA). Le coût plus élevé des vitroplants est compensé par un meilleur départ et une absence de contamination en charançons et nématodes.	1	[4, 5, 6, 7, 8]	2026-06-09 10:15:41.331552
94	39	\N	fertilisation	Potassium obligatoire pour de bons régimes	Le potassium est l'élément le plus limitant pour la banane. Un plant qui manque de K produit des régimes légers avec des doigts courts. Apporter 120 g de KCl par plant chaque mois tout au long du cycle. Sur sol sableux des Niayes, augmenter à 150 g/plant/mois.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.331554
95	40	\N	preparation_terrain	Billons obligatoires pour éviter la mort par engorgement	La papaye meurt en 24-48h d'engorgement du collet (Pythium). Toujours planter sur billons de 30-40 cm de hauteur minimum. En sol argileux ou à nappe phréatique haute, monter à 50-60 cm. Ne jamais planter en bas-fond ou zone inondable.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.353964
96	40	\N	protection_phyto	Gestion du PRSV par les variétés résistantes	Le Papaya Ringspot Virus est la principale menace pour la papaye au Sénégal. Utiliser exclusivement des variétés résistantes (Red Lady F1, Tainung 1). Protéger la pépinière avec des filets anti-insectes pour empêcher les pucerons vecteurs. Arracher et détruire immédiatement tout plant présentant des symptômes de mosaïque.	1	[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]	2026-06-09 10:15:41.353967
\.


--
-- Data for Name: agro_rendements_reference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_rendements_reference (id, culture_id, variete_id, zone_agro, pratique, rendement_min_t_ha, rendement_max_t_ha, rendement_moyen_t_ha, unite, source, annee_reference) FROM stdin;
61	21	\N	\N	subsistance	1.50	3.00	2.20	t/ha	ANSD / DAPSA	2022
62	21	\N	\N	amelioree	3.50	5.50	4.50	t/ha	ISRA / SAED	2022
63	21	\N	vallee_fleuve	intensive	5.50	8.00	6.50	t/ha	SAED / ISRA Saint-Louis	2023
64	22	\N	\N	subsistance	0.80	2.00	1.50	t/ha	ANSD / DAPSA	2022
65	22	\N	\N	amelioree	2.50	4.50	3.50	t/ha	ISRA / ANCAR	2022
66	22	\N	\N	intensive	5.00	8.00	6.00	t/ha	ISRA Bambey / expérimentations	2023
67	23	\N	\N	subsistance	0.50	1.20	0.90	t/ha	ANSD / DAPSA	2022
68	23	\N	\N	amelioree	1.50	2.50	2.00	t/ha	ISRA Bambey	2022
69	23	\N	\N	intensive	2.50	4.00	3.00	t/ha	ISRA / ICRISAT expérimentations	2023
70	24	\N	\N	subsistance	0.40	0.90	0.70	t/ha	ANSD / DAPSA	2022
71	24	\N	\N	amelioree	1.00	2.00	1.50	t/ha	ISRA / ANCAR	2022
72	24	\N	\N	intensive	2.00	3.50	2.50	t/ha	ISRA Bambey / ICRISAT	2023
73	25	\N	\N	subsistance	0.40	1.00	0.70	t/ha	ANSD / DAPSA	2022
74	25	\N	\N	amelioree	1.20	2.50	1.80	t/ha	ISRA / ANCAR	2022
75	25	\N	\N	intensive	2.50	4.50	3.50	t/ha	ISRA Séfa / expérimentations	2023
76	26	\N	\N	subsistance	0.30	0.70	0.50	t/ha	ANSD / DAPSA	2022
77	26	\N	\N	amelioree	0.80	1.50	1.20	t/ha	ISRA / ANCAR	2022
78	26	\N	\N	intensive	1.50	2.50	2.00	t/ha	ISRA Bambey / IITA expérimentations	2023
79	27	\N	\N	subsistance	0.20	0.50	0.35	t/ha	ANSD / DAPSA	2022
80	27	\N	\N	amelioree	0.50	0.90	0.70	t/ha	ISRA / ANCAR	2022
81	27	\N	\N	intensive	0.90	1.50	1.20	t/ha	ISRA / expérimentations NRCSS	2023
82	28	\N	\N	subsistance	5.00	10.00	7.50	t/ha	ANSD / DAPSA	2022
83	28	\N	\N	amelioree	12.00	20.00	16.00	t/ha	ISRA / IITA	2022
84	28	\N	\N	intensive	20.00	35.00	28.00	t/ha	IITA / expérimentations ISRA Séfa	2023
85	29	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD / DAPSA	2022
86	29	\N	\N	amelioree	20.00	40.00	30.00	t/ha	ISRA / ANCAR	2022
87	29	\N	niayes	intensive	50.00	80.00	60.00	t/ha	Marché export Niayes / ISRA CDH	2023
88	30	\N	\N	subsistance	5.00	12.00	8.00	t/ha	ANSD / DAPSA	2022
89	30	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA / SAED	2022
90	30	\N	vallee_fleuve	intensive	25.00	40.00	32.00	t/ha	SAED / ISRA CDH	2023
91	31	\N	\N	subsistance	3.00	8.00	5.00	t/ha	ANSD	2022
92	31	\N	\N	amelioree	8.00	18.00	12.00	t/ha	ISRA CDH	2022
93	31	\N	\N	intensive	18.00	30.00	22.00	t/ha	ISRA CDH / producteurs export	2023
94	32	\N	\N	subsistance	3.00	6.00	4.50	t/ha	ANSD	2022
95	32	\N	\N	amelioree	6.00	12.00	9.00	t/ha	ISRA CDH	2022
96	32	\N	\N	intensive	12.00	20.00	15.00	t/ha	Producteurs Vallée du Fleuve	2023
97	33	\N	\N	subsistance	6.00	12.00	9.00	t/ha	ANSD	2022
98	33	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA CDH	2022
99	33	\N	\N	intensive	25.00	40.00	30.00	t/ha	Producteurs Niayes	2023
100	34	\N	\N	subsistance	10.00	20.00	15.00	t/ha	ANSD	2022
101	34	\N	\N	amelioree	25.00	40.00	32.00	t/ha	ISRA CDH	2022
102	34	\N	niayes	intensive	40.00	60.00	50.00	t/ha	Producteurs export Niayes	2023
103	35	\N	\N	subsistance	5.00	12.00	8.00	t/ha	ANSD	2022
104	35	\N	\N	amelioree	15.00	25.00	20.00	t/ha	ISRA CDH	2022
105	35	\N	\N	intensive	25.00	40.00	30.00	t/ha	Producteurs Niayes	2023
106	36	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD	2022
107	36	\N	\N	amelioree	20.00	35.00	25.00	t/ha	ISRA CDH	2022
108	36	\N	vallee_fleuve	intensive	35.00	55.00	42.00	t/ha	SAED / Producteurs export	2023
109	37	\N	\N	subsistance	3.00	7.00	5.00	t/ha	ANSD / DAPSA	2022
110	37	\N	\N	amelioree	8.00	15.00	12.00	t/ha	ISRA / SODAGRI	2022
111	37	\N	casamance	intensive	15.00	25.00	18.00	t/ha	GIE export / APIX	2023
112	38	\N	\N	subsistance	0.30	0.80	0.50	t/ha	ANSD / DAPSA	2022
113	38	\N	\N	amelioree	1.00	2.00	1.50	t/ha	ISRA Djibélor	2022
114	38	\N	casamance	intensive	2.00	3.50	2.50	t/ha	ISRA / GIE producteurs	2023
115	39	\N	\N	subsistance	8.00	15.00	12.00	t/ha	ANSD	2022
116	39	\N	\N	amelioree	20.00	35.00	28.00	t/ha	ISRA / ANCAR	2022
117	39	\N	niayes	intensive	35.00	55.00	45.00	t/ha	Producteurs Niayes	2023
118	40	\N	\N	subsistance	15.00	30.00	20.00	t/ha	ANSD	2022
119	40	\N	\N	amelioree	35.00	60.00	45.00	t/ha	ISRA / ANCAR	2022
120	40	\N	niayes	intensive	60.00	100.00	80.00	t/ha	Producteurs Niayes (Red Lady F1)	2023
\.


--
-- Data for Name: agro_stades_phenologiques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_stades_phenologiques (id, culture_id, variete_id, ordre, nom_stade, jours_debut, jours_fin, description, actions_cles, indicateurs_visuels) FROM stdin;
106	21	\N	1	Semis / Repiquage	0	7	Semis en pépinière ou repiquage de plants âgés de 21-25 jours.	["Préparer la pépinière avec compost", "Inonder la parcelle avant repiquage", "Repiquer 2-3 plants par poquet à 20×20 cm"]	Grains germés ou plants de 20-25 cm bien racinés.
107	21	\N	2	Levée / Reprise	7	21	Établissement des plants et développement du système racinaire.	["Maintenir lame d'eau de 3-5 cm", "Désherbage manuel si nécessaire", "Apport d'urée (1/3 dose N)"]	Plants debout, 3-4 feuilles bien vertes, pas de jaunissement.
108	21	\N	3	Tallage	21	55	Formation des talles secondaires ; stade critique pour le rendement en grains.	["Apport de 1/3 azote (urée)", "Désherbage chimique (herbicide sélectif graminées)", "Surveiller pyriculariose et foreurs"]	3-5 talles par plant visible, feuillage dense et vert foncé.
109	21	\N	4	Montaison / Épiaison	55	80	Élongation de la tige et sortie de la panicule ; stade très sensible au déficit hydrique.	["Apport final d'azote (1/3 restant)", "Maintenir lame d'eau 5-8 cm", "Traitement fongicide si nécessaire (pyriculariose)"]	Gonflement de la gaine foliaire, sortie progressive de la panicule.
110	21	\N	5	Floraison / Grain laiteux	80	100	Fécondation et remplissage des grains ; sensibilité maximale aux oiseaux.	["Effarouchement des oiseaux (Quelea quelea)", "Maintenir humidité", "Surveiller la noctuelle (Spodoptera)"]	Panicules inclinées, grains laiteux puis dorés, anthères visibles.
111	21	\N	6	Maturité / Récolte	100	115	Grains durs et dorés ; couper l'irrigation 10-15 jours avant récolte.	["Arrêter l'irrigation à maturité laiteuse", "Récolter quand 80-85% des grains sont dorés", "Sécher à 14% humidité avant stockage"]	Panicules courbées, grains durs, feuilles jaunissantes.
112	22	\N	1	Semis	0	5	Dépôt des grains en poquet à 5-7 cm de profondeur dans sol humide.	["Préparer le sol (labour + binage)", "Semer 3-4 grains/poquet en lignes 80×40 cm", "Apport de DAP au fond du poquet"]	Sol humide, grains bien couverts de 5 cm de terre.
113	22	\N	2	Levée	5	14	Émergence des plantules ; stade très sensible aux adventices et aux insectes.	["Démariage à 1-2 plants/poquet à V3", "Désherbage chimique préémergence (Atrazine 2 kg/ha)", "Surveiller les vers gris et foreurs"]	Plantules avec 2-3 feuilles bien ouvertes.
114	22	\N	3	Croissance végétative (V4-V8)	14	45	Développement rapide du feuillage et de la tige ; absorption maximale des nutriments.	["Premier apport urée (50 kg/ha) à V4", "Binage inter-rang", "Surveiller chenille légionnaire (Spodoptera frugiperda)"]	6-8 feuilles larges et vertes, tige commençant à s'élever.
115	22	\N	4	Floraison	45	65	Émission de la panicule mâle (tassel) et des soies femelles ; pollinisation.	["Apport final urée (50 kg/ha) avant montaison", "Irrigation si sécheresse (stade le plus sensible)", "Surveiller foreurs de tiges"]	Panicule mâle au sommet, soies soyeuses rougeâtres aux épis.
116	22	\N	5	Remplissage des grains	65	90	Accumulation des glucides dans les grains ; épi se remplit et pend.	["Maintenir l'humidité du sol", "Surveiller les rongeurs et oiseaux", "Traitement fongicide si helminthosporiose"]	Épis lourds qui s'inclinent, feuilles commençant à jaunir.
117	22	\N	6	Maturité / Récolte	90	110	Grains durs, pointés noirs visibles ; récolte manuelle ou mécanisée.	["Récolter quand humidité grains ≈ 20-22%", "Sécher à 13% avant stockage", "Stocker dans des sacs hermétiques (GrainPro) ou silos métalliques"]	Spathes sèches, grains durs et jaunâtres, feuilles desséchées.
118	23	\N	1	Semis	0	7	Mise en place des graines décortiquées en poquets dans sol meuble et humide.	["Semer 2 graines/poquet à 3-5 cm de profondeur", "Inoculer avec Rhizobium (bradyrhizobium) si première culture", "Apport de Phosphate de Thiès (150 kg/ha) ou DAP en fond"]	Sol bien humide, graines bien couvertes sans compactage de surface.
119	23	\N	2	Levée	7	15	Émergence des cotylédons et premières feuilles ; formation des nodosités commence.	["Démariage à 1 plant par poquet si 2 sont levés", "Désherbage précoce", "Pas d'engrais azoté (fixation symbiotique)"]	Cotylédons verts au sol, premières feuilles trifoliées visibles.
120	23	\N	3	Croissance végétative	15	40	Développement du feuillage et des tiges ; nodosités actives sur les racines.	["Binage léger pour ameublir le sol", "Désherbage si couvrant", "Apport de soufre si nécessaire (20 kg/ha S)"]	Feuilles pennées vert vif, tiges ramifiées, nodosités roses à la base.
121	23	\N	4	Floraison	40	60	Fleurs jaunes autofécondes ; après fécondation, le gynophore s'enfonce en terre.	["Sol meuble autour des plants pour pénétration des gynophores", "Ne pas butter trop fortement", "Surveiller rosette virale (pucerons)"]	Petites fleurs jaunes à l'aisselle des feuilles, gynophores géotropiques.
122	23	\N	5	Fructification / Grossissement	60	90	Développement des gousses dans le sol ; apport en calcium critique.	["Apport de gypse (CaSO4) 100 kg/ha si sol acide", "Maintenir humidité modérée", "Surveiller cercosporiose"]	Gynophores enfoncés dans le sol, gousses en formation visibles à l'arrachage.
123	23	\N	6	Maturité / Récolte	90	110	Gousses mûres avec graines bien formées ; récolter avant les pluies tardives.	["Arracher les plants avant sécheresse totale (graines restent dans gousses)", "Sécher en andains 3-5 jours avant battage", "Stocker à 8-10% humidité pour éviter les aflatoxines"]	Réticulation interne des gousses brune, feuilles jaunissant, graines colorées.
124	24	\N	1	Semis	0	5	Semis en poquets de 5-10 grains à 2-3 cm de profondeur après les premières pluies.	["Attendre cumul pluies ≥ 30 mm sur 3-4 jours", "Semer 5-7 grains/poquet à 80×80 cm ou 1×1 m", "Semer peu profond (2-3 cm) en sol léger"]	Sol humide en surface, grains correctement couverts.
125	24	\N	2	Levée	5	15	Émergence des plantules ; stade critique pour les mauvaises herbes.	["Démariage à 3-4 plants/poquet à J12-15", "Désherbage manuel immédiat", "Pas d'engrais avant démariage"]	Plantules coleoptiles émergeant, feuilles dressées.
126	24	\N	3	Tallage	15	40	Formation des talles ; apport d'azote pour stimuler le tallage utile.	["Démariage définitif à 2 plants/poquet", "Apport urée 50 kg/ha à J20", "Désherbage et binage"]	2-4 talles visibles par plant, feuillage érigé.
127	24	\N	4	Montaison	40	60	Élongation de la tige principale et des talles ; formation du limbe foliaire.	["Surveillance mildiou (Sclerospora)", "Désherbage si mauvaises herbes", "Pas d'apport fertilisant à ce stade"]	Tiges bien dressées, gaine enveloppant la panicule naissante.
128	24	\N	5	Épiaison / Floraison	60	75	Sortie et floraison de l'épi cylindrique (chandelle) ; pollinisation.	["Effarouchement des oiseaux (Quelea, mange-mil)", "Surveiller foreurs de panicules", "Maintenir humidité si possible"]	Épis cylindriques en forme de chandelle, pollen visible.
129	24	\N	6	Maturité / Récolte	75	90	Grains durs et colorés ; récolte par coupe des épis.	["Couper les épis à maturité complète", "Sécher en greniers aérés", "Battre et vanner avant stockage"]	Grains durs de couleur grise-jaunâtre, feuilles desséchées.
130	25	\N	1	Semis	0	7	Semis en poquets après les premières pluies utiles.	["Semer 5-6 grains/poquet à 3-4 cm de profondeur", "Écartement 80×50 cm ou 1×0,5 m", "Apport de DAP ou Phosphate de Thiès en fond de poquet"]	Sol bien humide sur 20 cm, graines bien enfouies.
131	25	\N	2	Levée	7	15	Émergence des plantules ; démariage précoce nécessaire.	["Démariage à 3-4 plants/poquet", "Désherbage manuel ou herbicide sélectif", "Surveiller les attaques de termites"]	Plantules de 5-8 cm, feuilles primaires bien étalées.
132	25	\N	3	Tallage	15	45	Formation de 3-6 talles par poquet ; apport d'azote stimulant.	["Démariage final à 2 plants/poquet à J20", "Apport urée (50 kg/ha) à J20-25", "Désherbage et binage"]	3-5 talles visibles, feuillage dense et érigé.
133	25	\N	4	Montaison	45	70	Élongation de la tige principale et des talles vers la panicule.	["Surveiller le charbon du sorgho", "Binage inter-rang si adventices", "Apport urée complémentaire si carence"]	Tiges dressées de 1-1,5 m, gaines enveloppant la panicule.
134	25	\N	5	Floraison	70	90	Émergence et floraison de la panicule terminale.	["Effarouchement des oiseaux", "Maintenir humidité si stress", "Surveiller les foreurs de panicules"]	Panicule émergée, stigmates et anthères visibles.
135	25	\N	6	Maturité / Récolte	90	120	Grains durs et colorés ; récolte par coupe des panicules.	["Couper les panicules avant sur-maturité", "Sécher 3-5 jours avant battage", "Stocker en grenier aéré ou sacs hermétiques"]	Grains durs, panicule pendante, feuilles basales jaunissantes.
136	26	\N	1	Semis	0	5	Mise en place des graines en poquets dans sol bien ameubli.	["Semer 2-3 grains/poquet à 3-4 cm profondeur", "Écartement 60×40 cm ou 75×50 cm", "Inoculer avec Rhizobium (Bradyrhizobium)"]	Sol humide, graines bien couvertes.
137	26	\N	2	Levée	5	12	Émergence des cotylédons et premières feuilles trifoliées.	["Démariage à 1-2 plants/poquet si nécessaire", "Désherbage précoce (adventices très compétitives)", "Apport de Phosphate de Thiès si non fait"]	Cotylédons bien développés, premières feuilles simples.
138	26	\N	3	Croissance végétative	12	35	Développement du feuillage, des tiges et nodosités actives.	["Binage léger pour aérer le sol", "Contrôle des adventices (très critique)", "Surveiller les thrips sur feuilles terminales"]	Feuilles trifoliées abondantes, tiges volubiles ou érigées selon variété.
139	26	\N	4	Floraison	35	50	Floraison abondante ; fleurs papilionacées blanches-violettes.	["Surveiller les thrips (déformations florales)", "Ne pas appliquer insecticides à cette période (abeilles pollinisatrices)", "Maintenir humidité"]	Nombreuses fleurs blanches-violettes, bourgeonnement abondant.
140	26	\N	5	Fructification / Remplissage	50	65	Développement des gousses ; remplissage en grains.	["Surveiller les bruches (Callosobruchus) sur gousses", "Réduction de l'irrigation en fin de stade", "Surveiller les punaises de gousses"]	Gousses de 15-20 cm pendantes, grains visibles par transparence.
141	26	\N	6	Maturité / Récolte	65	80	Gousses sèches et dorées ; récolte progressive par passages successifs.	["Récolter les gousses mûres à sec", "Battre et vanner immédiatement", "Traiter les grains stockés contre les bruches (Pirimiphos-methyl)"]	Gousses beiges à dorées, grains durs audibles au froissement.
142	27	\N	1	Semis	0	5	Semis en surface ou superficiel (graines très petites) en sol bien préparé.	["Préparer lit de semence fin et nivelé", "Semer en lignes à 45-50 cm entre rangs, mélangé à du sable fin", "Ne pas couvrir les graines (ou très légèrement, 1 cm max)"]	Surface du sol propre et plane, légèrement humide.
143	27	\N	2	Levée	5	12	Émergence des plantules ; démariage indispensable dès ce stade.	["Démariage à 10-15 cm entre plants sur la ligne", "Désherbage manuel précoce (adventices très compétitives)", "Pas d'engorgement toléré"]	Plantules de 3-5 cm, cotylédons bien verts.
144	27	\N	3	Croissance végétative	12	40	Développement rapide de la tige principale et des feuilles.	["Binage et désherbage à J20", "Apport urée légère (20-25 kg/ha) si sol pauvre", "Surveiller les pucerons"]	Tige dressée de 30-50 cm, feuilles opposées bien développées.
145	27	\N	4	Floraison	40	60	Floraison axillaire successive ; fleurs blanches-violacées.	["Surveiller les insectes floricoles (punaises, acariens)", "Maintenir humidité modérée", "Eviter les stress hydriques"]	Fleurs tubulaires blanches-rosées à l'aisselle des feuilles.
146	27	\N	5	Fructification / Remplissage	60	80	Formation et remplissage des capsules ; accumulation d'huile dans les graines.	["Réduire arrosage pour éviter pourriture capsules", "Surveiller la cercosporiose", "Préparer matériel de récolte (bâches)"]	Capsules rectangulaires de 3-4 cm, graines visibles par transparence.
147	27	\N	6	Maturité / Récolte	80	100	Capsules basales commencent à jaunir et s'ouvrir (déhiscence) ; récolte urgente.	["Récolter quand 25-30% des capsules sont jaunies (avant ouverture)", "Couper les plants entiers, mettre en bottes debout sur bâches", "Battre délicatement sur bâche après 5-7 jours de séchage"]	Capsules basales jaunissantes, graines claires dans les capsules.
148	28	\N	1	Plantation (bouturage)	0	10	Plantation de boutures de tiges saines de 20-25 cm en sol humide.	["Sélectionner des tiges saines et indemnes de mosaïque", "Couper en boutures de 25-30 cm avec 5-6 nœuds", "Planter à l'oblique ou à plat selon le système (45° ou horizontal)"]	Boutures bien enfoncées dans sol humide, à 80×80 cm ou 1×1 m.
149	28	\N	2	Établissement / Levée	10	30	Développement des bourgeons, émission des premières feuilles.	["Rebouturage si levée < 80%", "Premier désherbage manuel", "Ne pas fertiliser avant J30"]	Bourgeons verts, premières feuilles palmatisées sur les boutures.
150	28	\N	3	Croissance végétative	30	120	Développement intense du feuillage et de la tige ; début de tubérisation.	["Apport d'engrais NPK à J30-45", "Désherbage 2-3 fois jusqu'à J90 (couverture complète)", "Surveiller cochenille farineuse et mosaïque"]	Plante de 60-150 cm, feuilles palmatisées denses, tige verte.
151	28	\N	4	Tubérisation active	120	240	Accumulation intense d'amidon dans les racines tubéreuses.	["Maintenir humidité régulière en saison sèche", "Surveiller et traiter si nécessaire la cochenille", "Éviter tout stress qui ralentit la tubérisation"]	Racines tubéreuses gonflées visibles au collet, plant compact.
152	28	\N	5	Maturation	240	330	Ralentissement de la croissance foliaire, concentration maximale d'amidon.	["Arrêt de l'irrigation 30 jours avant récolte", "Surveiller la bactériose si zone humide", "Planifier la récolte et la commercialisation"]	Feuilles basales jaunissant, écorce des racines légèrement brunissante.
153	28	\N	6	Récolte	270	365	Arrachage des racines manuellement ou mécaniquement.	["Couper la tige à 30 cm pour faciliter l'arrachage", "Arracher manuellement ou à la charrue", "Transformer rapidement (24-48h) ou stocker entier dans sol"]	Racines bien gonflées de 30-60 cm, chair blanche ou jaune selon variété.
154	29	\N	1	Pépinière	0	25	Semis en pépinière, repiquage en motte à 3-4 feuilles vraies.	["Semer en mini-sillon à 1 cm de profondeur", "Désinfection substrat (Dazomet ou solarisation)", "Traitement préventif contre fonte des semis (Metalaxyl)"]	Plants de 10-15 cm, 3-4 feuilles vraies, tiges droites.
155	29	\N	2	Repiquage / Reprise	25	40	Transplantation en planche, irrigation abondante pour la reprise.	["Repiquer le soir ou par temps couvert", "Densité : 40 000-50 000 plants/ha (50×50 cm)", "Apport DAP en fond de trou (5 g/plant)"]	Plants redressés, nouvelles feuilles vertes = bonne reprise.
156	29	\N	3	Croissance végétative	40	60	Développement rapide du feuillage, taille et palissage.	["Tuteurage / palissage des plants", "Pincement des gourmands (variétés indéterminées)", "Apport NPK 15-15-15 (200 kg/ha)"]	Tiges fortes, feuilles vert foncé, premières fleurs jaunes.
157	29	\N	4	Floraison	60	80	Fleurs jaunes, pollinisation ; stade critique pour la nouaison.	["Surveiller Tuta absoluta (mineuse)", "Apport de calcium folaire (Ca-B) 1 L/ha", "Ne pas stresser en eau"]	Boutons floraux jaunes, puis chute des pétales avec nouaison visible.
158	29	\N	5	Fructification / Grossissement	80	110	Grossissement des fruits, alternance irrigation-fertilisation.	["Irrigation régulière (éviter alternance humidité/sécheresse = BER)", "Apport KNO3 (potasse-azote) 200 kg/ha", "Traitements fongicides hebdomadaires"]	Fruits en croissance, stade vert puis virage couleur selon variété.
159	29	\N	6	Récolte	110	150	Récoltes successives tous les 3-5 jours sur variétés indéterminées.	["Récolter au stade brécheux (virage) pour export", "Récolter bien mûr pour marché local et transformation", "Trier et conditionner en caisses ventilées"]	Fruits colorés (rouge/orange selon variété), peau lisse et ferme.
160	30	\N	1	Pépinière	0	45	Semis dense en pépinière irriguée, plants repiqués à 3-4 feuilles.	["Semer à la volée 8-10 g graines/m² de pépinière", "Ombrage 30% les 10 premiers jours", "Traitement fongicide préventif (Iprodione) contre la fonte"]	Plants de 15-20 cm, diamètre 6-8 mm, 4-6 feuilles tubulaires.
161	30	\N	2	Repiquage / Reprise	45	60	Transplantation en billons ou planches à 10×15 cm, arrosage copieux.	["Couper 1/3 des feuilles et des racines avant repiquage", "Repiquer en ligne, 2-3 cm de profondeur", "Apport NPK 15-15-15 (200 kg/ha) en fond"]	Plants debout, nouvelles feuilles en 7-10 jours.
162	30	\N	3	Croissance végétative	60	100	Développement feuillaire intense, apport azoté fractionné.	["Apport urée (100 kg/ha) à J70", "Désherbage manuel ou herbicide (Métribuzine)", "Surveiller thrips sur les feuilles"]	Feuilles tubulaires dressées, 6-8 feuilles, tige bien formée.
163	30	\N	4	Formation du bulbe	100	135	Transfert des assimilats vers le bulbe ; réduire l'azote et augmenter le K.	["Apport KCl (100 kg/ha)", "Réduire les irrigations", "Stopper l'azote pour éviter le retard de maturation"]	Renflement visible à la base, feuilles commençant à verser.
164	30	\N	5	Maturation / Récolte	135	150	Feuilles versées, col mou, bulbe bien formé ; arrêt irrigation 10 jours avant.	["Arrêter l'irrigation 10-15 jours avant récolte", "Récolter quand 70-80% des feuilles sont versées", "Sécher en andains 7-10 jours avant stockage"]	Feuilles tombées, col du bulbe mou et fermé, bulbe ferme.
165	31	\N	1	Pépinière	0	30	Semis en pépinière, germination lente (10-15 jours), repiquage à 3-4 feuilles.	["Semer en ligne à 1 cm de profondeur", "Maintenir humidité constante", "Ombrage 30% contre la chaleur excessive"]	Plants de 10-12 cm, 3-4 feuilles, tiges droites.
166	31	\N	2	Repiquage / Reprise	30	45	Transplantation en champ, arrosage copieux pour la reprise.	["Densité : 40×40 cm (60 000 plants/ha)", "Apport DAP en fond de trou", "Arrosage matin et soir pendant 5 jours"]	Plants redressés, feuilles brillantes, nouvelles pousses.
167	31	\N	3	Croissance végétative	45	70	Développement de la tige et des ramifications ; formation du squelette.	["Apport NPK 15-15-15 (150 kg/ha)", "Désherbage", "Surveiller pucerons et thrips"]	Tige ramifiée, feuilles vert foncé, sans déformation.
168	31	\N	4	Floraison	70	90	Fleurs blanches pendantes ; autofécondation facilitée.	["Apport urée folaire (1%) pour favoriser la nouaison", "Traitement insecticide contre thrips et acariens", "Ne pas stresser en eau"]	Fleurs blanches, chute des pétales avec petit fruit vert visible.
169	31	\N	5	Fructification et récolte continue	90	150	Récoltes successives de fruits verts (frais) ou laissés à maturité (rouge/séché).	["Récolter tous les 7-10 jours (fruits verts) ou 14-21 jours (fruits rouges)", "Apport KNO3 (150 kg/ha) en fertigation pour prolonger la production", "Traitement contre anthracnose sur fruits"]	Fruits verts brillants ou rouges mûrs selon la destination.
170	32	\N	1	Semis	0	7	Semis direct en poquet, 3-4 grains par poquet, éclaircissage à 2 plants.	["Trempage des graines 12-24h avant semis", "3-4 grains par poquet à 3 cm de profondeur", "Apport DAP en fond de poquet (5 g/poquet)"]	Graines gonflées et germes visibles en 5-7 jours.
171	32	\N	2	Levée / Croissance initiale	7	25	Développement des premières feuilles ; démariage à 1-2 plants/poquet.	["Démariage à 2 plants par poquet (V2-V3)", "Désherbage manuel", "Arrosage tous les 3-4 jours"]	2-4 feuilles vraies lobées, plants vigoureux.
172	32	\N	3	Croissance végétative	25	50	Forte croissance ; apport NPK.	["Apport NPK 15-15-15 (150 kg/ha) à J30", "Buttage léger pour soutenir les tiges", "Surveiller jassides et pucerons"]	Plants de 50-80 cm, feuilles larges et lobées, tiges épaisses.
173	32	\N	4	Floraison et fructification	50	120	Floraison continue axillaire ; récolte des fruits tous les 3-4 jours.	["Récolter à 5-8 cm de longueur (avant lignification)", "Apport urée (50 kg/ha) pour prolonger la production", "Traitement contre jassides si nécessaire"]	Grandes fleurs jaunes à cœur rouge, fruits verts tendres.
174	33	\N	1	Pépinière	0	25	Semis en pépinière ; germination en 7-10 jours.	["Substrat stérile (terreau + compost)", "Ombrage 30% les 2 premières semaines", "Traitement préventif fonte des semis"]	Plants de 12-15 cm, 3-4 feuilles vraies.
175	33	\N	2	Repiquage / Reprise	25	45	Transplantation à 60×50 cm, arrosage immédiat.	["Densité 30 000-35 000 plants/ha", "DAP (5 g) en fond de trou", "Ombrage léger les 3 premiers jours"]	Plants repris, nouvelles feuilles en 7 jours.
176	33	\N	3	Croissance végétative	45	70	Développement rapide ; pincement de l'apex pour ramification.	["NPK 15-15-15 (150 kg/ha) à J55", "Pincement optionnel pour plus de ramifications", "Surveiller acariens et doryphore"]	Tiges épaisses, feuilles larges et pubescentes, vert foncé.
177	33	\N	4	Floraison / Fructification	70	140	Fleurs violettes, fruits en développement continu.	["Récolter dès que le fruit atteint la taille commerciale", "Urée (50 kg/ha) à J90 pour prolonger production", "Traitement insecticide contre doryphore africain"]	Fleurs violettes pendantes, fruits brillants violets.
178	34	\N	1	Pépinière	0	20	Semis en pépinière ; repiquage à 4-6 feuilles.	["Substrat stérile et bien drainé", "Semer à 1 cm de profondeur", "Température optimale 15-20°C en pépinière"]	Plants de 10-12 cm, 4-5 feuilles vraies.
179	34	\N	2	Repiquage / Reprise	20	35	Transplantation à 40×50 cm sur planches préparées avec compost.	["Densité 50 000 plants/ha", "NPK 15-15-15 (200 kg/ha) en fond de planche", "Arrosage copieux après repiquage"]	Plants debout, nouvelles feuilles en 5-7 jours.
180	34	\N	3	Croissance feuillaire	35	60	Développement intensif du feuillage extérieur.	["Urée (100 kg/ha) à J45", "Désherbage", "Surveiller teigne du chou et pucerons"]	Feuilles larges et ondulées, vert foncé brillant.
181	34	\N	4	Formation de la pomme	60	90	Enroulement progressif des feuilles pour former la pomme.	["KCl (100 kg/ha) à J65", "Surveiller la teigne du chou dans le cœur", "Réduire les irrigations progressivement"]	Feuilles internes se repliant, pomme compacte et dense.
182	34	\N	5	Récolte	90	110	Pomme ferme et dense ; récolter avant éclatement.	["Couper la tige à la base, laisser 2-3 feuilles protectrices", "Récolter tôt le matin pour la fraîcheur", "Stocker à l'ombre et au frais"]	Pomme ferme au toucher, feuilles serrées et brillantes.
183	35	\N	1	Semis	0	5	Semis direct en poquet (2-3 graines), germination en 3-5 jours.	["2-3 graines/poquet à 2 cm de profondeur", "Espacement 100×50 cm", "DAP (5 g) en fond de poquet"]	Graines germées, cotylédons sortant.
184	35	\N	2	Croissance végétative	5	30	Développement rapide des tiges rampantes et installation des vrilles.	["Démariage à 1 plant/poquet à V2", "NPK 15-15-15 (150 kg/ha) à J15", "Installer des tuteurs ou filets si culture palissée"]	Tiges rampantes, feuilles lobées vert foncé, vrilles actives.
185	35	\N	3	Floraison	30	45	Fleurs mâles apparaissent d'abord, puis femelles (ovaire visible).	["Apport urée (50 kg/ha) à J35", "Présence d'abeilles pour pollinisation", "Surveiller mouche des cucurbitacées"]	Fleurs jaunes, fleurs femelles avec mini-concombre à la base.
186	35	\N	4	Fructification / Récolte	45	75	Croissance rapide des fruits ; récolter avant surgrossissement.	["Récolter tous les 2-3 jours (avant que les fruits jaunissent)", "KCl (50 kg/ha) à J55 pour prolonger la fructification", "Traitement contre oïdium si nécessaire"]	Fruits verts fermes, 15-25 cm de longueur selon variété.
187	36	\N	1	Semis	0	7	Semis direct en poquet (2-3 graines) sur sol chaud.	["2-3 graines/poquet à 3 cm de profondeur", "Espacement 200×100 cm (5 000 plants/ha)", "DAP (10 g) + compost (500 g) en fond de poquet"]	Germination en 5-7 jours, cotylédons vigoureux.
188	36	\N	2	Croissance végétative	7	35	Développement des tiges rampantes longues.	["Démariage à 1-2 plants/poquet à V2", "NPK 15-15-15 (150 kg/ha) à J20", "Orienter les tiges pour faciliter la circulation"]	Longues tiges rampantes, feuilles profondément lobées.
189	36	\N	3	Floraison	35	55	Fleurs mâles puis femelles ; pollinisation par insectes.	["Urée (80 kg/ha) à J40", "Ne pas traiter pendant la floraison (abeilles)", "Surveiller mouche des cucurbitacées"]	Fleurs jaunes, femelles reconnaissables au mini-fruit à la base.
190	36	\N	4	Grossissement des fruits	55	85	Croissance rapide des fruits ; 1-3 fruits par plant selon la variété.	["KCl (80 kg/ha) à J60 pour améliorer le sucre", "Mettre une planche sous les fruits pour éviter les pourritures", "Réduire l'irrigation à l'approche de la maturité"]	Fruits grossissant rapidement, sarment adjacent à la vrille se desséchant.
191	36	\N	5	Maturité / Récolte	85	100	Fruits mûrs ; reconnaître la maturité par plusieurs signes.	["Vérifier : vrille proche du fruit sèche + son creux = mûr", "Récolter sans blesser le fruit", "Stocker à l'ombre ; bon transport si croûte épaisse"]	Vrille adjacente sèche, face ventrale jaune, son creux à la percussion.
192	37	\N	1	Floraison	0	30	Induction et sortie florale (décembre à février selon zone).	["Favoriser le stress hydrique pré-floraison (arrêt irrigation en novembre)", "Apport de KNO3 foliaire pour induire la floraison", "Traitement préventif anthracnose (cuivre) sur panicules"]	Panicules florales rougeâtres sortant des bourgeons terminaux.
193	37	\N	2	Nouaison	30	60	Fécondation des fleurs et formation des jeunes fruits.	["Traitement insecticide contre les cécidomyies et thrips floraux", "Traitement fongicide contre oïdium (soufre)", "Favoriser la pollinisation (présence d'abeilles)"]	Petits fruits verts (olive) de 1-2 cm après chute des pétales.
194	37	\N	3	Croissance des fruits	60	120	Grossissement progressif des fruits sur 60-70 jours.	["Irrigation si déficit hydrique (mars-avril = saison sèche)", "Apport NPK (200 g/arbre) à J75", "Surveillance mouche des fruits (pièges McPhail)"]	Fruits de 5-10 cm, bien formés, couleur verte.
195	37	\N	4	Maturité / Récolte	120	150	Fruits mûrs selon variété (mai-juillet) ; récolte manuelle avec perche.	["Récolter au stade brécheux pour export (légère teinture jaune-orange)", "Trier, calibrer et emballer rapidement", "Conservation à 12-13°C en chambre froide"]	Fruits lourds, arôme caractéristique, légère coloration selon variété.
196	37	\N	5	Post-récolte / Entretien	150	365	Taille post-récolte, fertilisation et préparation pour la prochaine campagne.	["Taille pour aérer le houppier et réguler la charge", "Apport NPK complet (500 g/arbre) en saison des pluies", "Traitement cuivre préventif en début de saison des pluies"]	Repousse des rameaux feuillés verts après la récolte.
197	38	\N	1	Floraison	0	30	Panicules florales d'octobre à janvier selon la zone.	["Traitement préventif anthracnose sur panicules (cuivre)", "Lutte contre Helopeltis dès apparition des panicules", "Pas d'irrigation (stimule la floraison)"]	Panicules blanches-roses à l'extrémité des rameaux.
198	38	\N	2	Nouaison	30	60	Fructification ; noix et pomme cajou en développement.	["Traitement insecticide contre Helopeltis (piqueur des fruits)", "Traitement fongicide si humidité", "Surveiller oïdium sur jeunes fruits"]	Noix réniforme verte avec pomme cajou (faux-fruit) orangeâtre.
199	38	\N	3	Maturité / Récolte	60	90	Noix mûres tombent naturellement au sol ; ramassage quotidien.	["Ramasser les noix tombées quotidiennement (éviter détérioration)", "Sécher les noix 3-5 jours au soleil", "Stocker dans des sacs aérés à l'abri de l'humidité"]	Pomme cajou rouge-jaune, noix gris-beige, chute naturelle au sol.
200	38	\N	4	Post-récolte / Entretien	90	365	Taille légère, fertilisation en début de saison des pluies.	["Taille légère : supprimer branches mortes et bois parasité", "Fertilisation NPK (200 g/arbre) en juillet", "Entretien sol (désherbage, travail superficiel)"]	Rameaux en repousse végétative verts pendant l'hivernage.
201	39	\N	1	Plantation / Levée	0	30	Plantation par rejets (œilletons) ou vitroplants ; enracinement.	["Choisir des rejets épée de 50-80 cm ou vitroplants sains", "Trou de plantation 60×60×60 cm avec 20 kg compost", "Espacement 2,5×2,5 m à 2,5×3 m"]	Rejet debout, feuilles déployées, pas de jaunissement.
202	39	\N	2	Croissance végétative	30	150	Développement du pseudo-tronc et des feuilles ; tallage sélectif.	["Conserver 1 rejet de succession par plant", "Apport urée (100 g/plant) à J60 et J120", "Irrigation au goutte-à-goutte tous les 2-3 jours"]	Pseudo-tronc épais, 8-10 feuilles ouvertes, rejet de succession visible.
203	39	\N	3	Induction florale / Montaison	150	220	L'apex végétatif se transforme ; hampe florale en cours de formation.	["KCl (200 g/plant) pour soutenir la montaison", "Supprimer les rejets excédentaires", "Vérifier l'état sanitaire (cercosporiose)"]	Gonflement de la gaine supérieure = montaison imminente.
204	39	\N	4	Floraison / Formation du régime	220	270	Sortie du régime et des mains de bananes.	["Tuteurage ou haubanage pour éviter la verse", "Supprimer l'extrémité de la hampe (clocheton) après 6-8 mains", "Envelopper le régime dans un sac plastique bleu (protection et calibrage)"]	Hampe florale sortant, mains de bananes en développement.
205	39	\N	5	Maturité / Récolte	270	365	Récolte du régime vert (stade 3/4 de maturité) avant jaunissement.	["Couper le régime à 3/4 de rondeur des doigts", "Traitement post-récolte : sulfate d'aluminium contre Colletotrichum", "Mûrissage contrôlé à l'éthylène si besoin"]	Doigts bien ronds (3/4), quelques doigts légèrement jaunes.
206	40	\N	1	Pépinière	0	45	Semis en sachets, repiquage à 4 feuilles vraies.	["Semer 2-3 graines par sachet, démarier à 1 plant", "Substrat : terreau + compost (1:1)", "Arrosage modéré pour éviter la fonte des semis"]	Plants de 20-25 cm, 4-6 feuilles, tige droite et robuste.
207	40	\N	2	Plantation / Reprise	45	75	Transplantation sur billons (indispensable) ; reprise en 2-3 semaines.	["Billons de 30-40 cm de hauteur (drainage crucial)", "Espacement 2×2 m à 2,5×2,5 m", "Compost (10 kg/trou) + NPK 15-15-15 (200 g/plant)"]	Plants repris, nouvelles feuilles déployées.
208	40	\N	3	Croissance végétative	75	180	Développement rapide du tronc et des feuilles.	["Urée (50 g/plant) à J90 et J150", "Irrigation au goutte-à-goutte tous les 2-3 jours", "Surveiller Tetranychus et pucerons"]	Tronc de 1-1,5 m, grandes feuilles palmées, pas de jaunissement.
209	40	\N	4	Floraison / Fructification	180	300	Fleurs axillaires ; pour les hermaphrodites, tous les fruits sont fertiles.	["Sur plants dioïques : identifier et conserver 1 plant mâle pour 10 femelles", "KNO3 (100 g/plant) à la floraison", "Surveiller PRSV (pucerons vecteurs)"]	Fruits en spirale sur le tronc, grossissant progressivement.
210	40	\N	5	Récolte continue	300	730	Récolte des fruits mûrs ou verts selon la destination ; production continue.	["Récolter fruits mûrs (jaunes) pour marché local", "Récolter fruits verts pour export/transformation", "Maintenir la fertilisation mensuelle"]	Fruits mûrs : jaune-orange, légèrement mous au toucher.
\.


--
-- Data for Name: agro_varietes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agro_varietes (id, culture_id, nom, origine, cycle_min_jours, cycle_max_jours, precocite, tolerance_secheresse, tolerance_salinite, zones_adaptees, rendement_potentiel_t_ha, notes) FROM stdin;
78	21	Sahel 108	ISRA / ADRAO	100	110	hative	f	f	["vallee_fleuve"]	7.00	Variété irriguée dominante de la Vallée du Fleuve ; deux cycles par an possibles.
79	21	Sahel 201	ISRA / ADRAO	115	125	semi-tardive	f	t	["vallee_fleuve"]	8.00	Tolérance modérée à la salinité ; adapté aux périmètres irrigués du Delta.
80	21	CG 14	CGIAR / AfricaRice	90	105	hative	t	f	["casamance", "senegal_oriental"]	5.00	Riz pluvial tolérant à la sécheresse ; adapté aux bas-fonds de Casamance.
81	21	Jaya	IRRI / ISRA	110	120	semi-tardive	f	f	["vallee_fleuve", "casamance"]	6.50	Bonne qualité gustative ; appréciée des consommateurs locaux.
82	22	SAMAZ 13	ISRA	90	100	hative	t	f	["bassin_arachidier", "casamance", "senegal_oriental"]	5.00	Variété améliorée ISRA adaptée aux zones semi-arides ; bonne tolérance à la sécheresse.
83	22	APEX 836	SeedCo / importé	100	115	semi-tardive	f	f	["casamance", "senegal_oriental", "vallee_fleuve"]	8.00	Hybride à haut rendement utilisé en culture intensive et irriguée.
84	22	ZM 521	CIMMYT / CGIAR	95	110	semi-tardive	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	6.00	Variété DTMA (Drought Tolerant Maize for Africa) adaptée au stress hydrique.
85	22	Population locale Thiès	local	100	120	semi-tardive	f	f	["bassin_arachidier", "niayes"]	3.00	Variété paysanne à qualité gustative appréciée mais faible rendement.
86	23	55-437	ISRA	90	100	hative	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.50	Variété hâtive ISRA la plus répandue ; adaptée aux zones à pluviométrie incertaine.
87	23	73-33	ISRA	100	110	semi-tardive	f	f	["bassin_arachidier", "casamance", "senegal_oriental"]	3.00	Bonne teneur en huile (48%) ; utilisée pour la confiserie et l'huilerie.
88	23	Fleur 11	ISRA	90	100	hative	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.20	Très bonne tolérance à la sécheresse terminale ; adoptée par les petits producteurs.
89	23	GH 119-20	ICRISAT / ISRA	105	115	semi-tardive	f	f	["casamance", "senegal_oriental"]	3.50	Haut potentiel de rendement pour les zones à pluviométrie suffisante.
90	24	Souna 3	ISRA	75	85	hative	t	f	["bassin_arachidier", "zone_sylvopastorale", "senegal_oriental"]	2.00	Variété hâtive ISRA la plus cultivée ; adaptée à la Sahelisation du bassin arachidier.
91	24	IBV 8004	ICRISAT / ISRA	80	90	hative	t	f	["zone_sylvopastorale", "bassin_arachidier"]	2.50	Variété améliorée ICRISAT ; bonne tolérance mildiou.
92	24	Sanio local	local	120	150	tardive	f	f	["casamance", "senegal_oriental"]	1.50	Variété paysanne tardive (Sanio) ; cycle long adapté aux zones plus humides.
93	24	ICMV IS 89305	ICRISAT	85	95	semi-tardive	t	f	["bassin_arachidier", "zone_sylvopastorale"]	2.80	Bonne résistance au mildiou et à la striga ; utilisée dans les programmes ISRA-ICRISAT.
94	25	CE 145-66	ISRA	100	110	semi-tardive	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	3.50	Variété améliorée ISRA à grain blanc ; appréciée pour l'alimentation humaine.
95	25	S 35	ISRA / ICRISAT	95	105	hative	t	f	["zone_sylvopastorale", "bassin_arachidier"]	2.50	Variété hâtive adaptée aux zones à courte saison pluvieuse.
96	25	IRAT 204	CIRAD / ISRA	110	120	semi-tardive	f	f	["casamance", "senegal_oriental"]	4.00	Fort potentiel en zones humides ; utilisation possible pour fourrage.
97	25	Sorgho local Casamance	local	130	160	tardive	f	f	["casamance"]	2.00	Variétés photopériodiques locales à grain rouge ; valeur culturelle forte.
98	26	Melakh	ISRA	58	65	hative	t	f	["bassin_arachidier", "zone_sylvopastorale", "niayes"]	1.50	Variété très hâtive ISRA (60 jours) adaptée aux zones sahéliennes sèches.
99	26	Mouride	ISRA	60	68	hative	t	f	["bassin_arachidier", "senegal_oriental"]	1.80	Bonne tolérance à la sécheresse ; grain blanc apprécié du marché local.
100	26	Ndiambour	ISRA	65	75	semi-tardive	f	f	["bassin_arachidier", "casamance", "senegal_oriental"]	2.00	Bon rendement en grains secs ; résistance aux maladies.
101	26	58-74 (Bambey 21)	ISRA Bambey	70	80	semi-tardive	f	f	["bassin_arachidier", "casamance"]	2.50	Variété ancienne mais encore cultivée pour ses fanes fourragères abondantes.
102	27	Yannik	ISRA	90	100	hative	t	f	["bassin_arachidier", "senegal_oriental", "casamance"]	1.00	Variété blanche améliorée ISRA ; teneur en huile élevée (50%). Appréciée à l'export.
103	27	Pakao	ISRA / local	90	105	semi-tardive	t	f	["casamance", "senegal_oriental"]	0.90	Variété adaptée à la Casamance et au Sénégal Oriental ; capsules semi-indéhiscentes.
104	27	Local blanc	local	95	110	semi-tardive	t	f	["bassin_arachidier", "zone_sylvopastorale", "senegal_oriental"]	0.60	Variété paysanne non sélectionnée mais rustique et largement répandue.
105	27	NRCSS 2001	ISRA / ICAR Inde	85	95	hative	t	f	["bassin_arachidier", "senegal_oriental"]	1.20	Variété introduite à haut potentiel ; résistance partielle au flétrissement fusarien.
106	28	TME 419	IITA / ISRA	270	360	semi-tardive	t	f	["casamance", "senegal_oriental"]	25.00	Variété améliorée IITA résistante à la mosaïque africaine ; fort potentiel de rendement.
107	28	TMS 30572	IITA	270	360	semi-tardive	f	f	["casamance", "senegal_oriental"]	30.00	Haut rendement en racines tubéreuses ; bonne tolérance à la mosaïque.
108	28	Kibondondo	local / Casamance	300	365	tardive	f	f	["casamance"]	15.00	Variété locale de Casamance à faible teneur en cyanure ; feuilles très consommées.
109	28	Bocou 1	ISRA / CNRA Côte d'Ivoire	270	330	semi-tardive	t	f	["casamance", "senegal_oriental", "bassin_arachidier"]	20.00	Bonne tolérance à la sécheresse ; adaptée aux zones à pluviométrie variable.
110	29	Mongal F1	Nunhems / importé	70	85	hative	f	f	["niayes", "vallee_fleuve"]	60.00	Hybride F1 très cultivé dans les Niayes ; tolérant TYLCV et mildiou.
111	29	Padma F1	Clause / importé	75	90	hative	f	f	["niayes", "vallee_fleuve", "casamance"]	55.00	Bonne tenue post-récolte ; adapté à l'exportation.
112	29	Caraïbe	Vilmorin / importé	80	95	semi-tardive	f	f	["niayes", "vallee_fleuve"]	50.00	Très cultivé pour la transformation industrielle (concentré de tomate).
113	29	Power Ranger F1	East-West Seed / importé	70	80	hative	f	f	["niayes", "casamance"]	65.00	Tolérant à Tuta absoluta et TYLCV ; haut rendement.
114	30	Violet de Galmi	Niger / ISRA	120	150	semi-tardive	f	f	["vallee_fleuve", "bassin_arachidier"]	25.00	Variété africaine la plus adaptée ; bonne conservation (4-6 mois). Bulbe rouge-violet.
115	30	Bawku	Ghana / local	110	130	hative	f	f	["vallee_fleuve", "niayes"]	20.00	Adapté aux fortes températures ; bonne conservation.
116	30	Gandiol	ISRA / local Saint-Louis	115	135	hative	f	t	["vallee_fleuve"]	22.00	Sélection locale ISRA Saint-Louis ; bonne tolérance à la salinité des sols du delta.
117	30	Wartanieen	Holland / importé	100	115	hative	f	f	["niayes", "vallee_fleuve"]	35.00	Hybride F1 à haut rendement ; mauvaise conservation en condition tropicale.
118	31	Dibangor	local Sénégal	75	90	hative	t	f	["niayes", "bassin_arachidier", "casamance"]	15.00	Variété locale très piquante, très prisée au Sénégal ; bonne adaptation.
119	31	Yolo Wonder	USA / importé	80	95	semi-tardive	f	f	["niayes", "vallee_fleuve"]	25.00	Piment doux gros fruit ; utilisé pour la consommation fraîche en salade.
120	31	Tabasco local	local	90	110	semi-tardive	t	f	["casamance", "bassin_arachidier"]	10.00	Très piquant, fruits rouges utilisés séchés ou en sauce.
121	31	Djakato	Casamance / local	100	120	tardive	f	f	["casamance", "senegal_oriental"]	20.00	Piment de Casamance à fruit moyen, rouge vif, utilisé frais et séché.
122	32	Clemson Spineless	USA / importé	55	65	hative	t	f	["niayes", "vallee_fleuve", "bassin_arachidier"]	12.00	Variété la plus cultivée ; fruits lisses sans épines, facile à récolter.
123	32	Kirikou	local / Afrique de l'Ouest	50	60	hative	t	f	["bassin_arachidier", "casamance", "senegal_oriental"]	8.00	Petits fruits ronds très appréciés en cuisine locale ; bonne adaptation.
124	32	Parbhani Kranti	ICRISAT / Inde	50	60	hative	t	f	["vallee_fleuve", "niayes"]	14.00	Résistant au virus de la mosaïque jaune ; fort potentiel de rendement.
125	32	Local rouge	local	60	75	semi-tardive	t	t	["casamance", "bassin_arachidier"]	7.00	Variété paysanne rustique ; fruits rouges utilisés séchés.
126	33	Longue violette locale	local Sénégal	70	85	hative	t	f	["niayes", "casamance", "bassin_arachidier"]	20.00	Variété locale la plus appréciée ; fruit long violet, chair ferme.
127	33	African Beauty F1	East-West Seed	65	80	hative	f	f	["niayes", "vallee_fleuve"]	35.00	Hybride F1 très productif ; résistant aux nématodes.
128	33	Kalenda F1	Syngenta / importé	70	85	hative	f	f	["niayes", "casamance"]	30.00	Fruit ovale violet foncé brillant ; bonne tenue post-récolte.
129	34	Tropicana F1	Nunhems / importé	70	85	hative	f	f	["niayes", "vallee_fleuve"]	40.00	Hybride F1 tolérant à la chaleur ; adapté au Sénégal.
130	34	Grenadier F1	Clause / importé	80	95	semi-tardive	f	f	["niayes"]	45.00	Pomme dense et lourde ; bonne tenue après récolte.
131	34	Bol d'Or	local / acclimate	85	100	semi-tardive	f	f	["niayes"]	30.00	Pomme ronde jaune-vert ; saveur douce appréciée.
132	35	Marketmore	USA / importé	60	70	hative	f	f	["niayes", "vallee_fleuve"]	25.00	Variété standard très cultivée ; fruits longs vert foncé.
133	35	Poinsett 76	USA / importé	65	75	hative	f	f	["niayes", "casamance"]	22.00	Résistant à l'anthracnose et à l'oïdium ; adapté aux zones humides.
134	35	Ashley	USA / importé	65	75	hative	f	f	["vallee_fleuve", "bassin_arachidier"]	20.00	Tolérant à la chaleur ; bon pour les zones à températures élevées.
135	36	Charleston Grey	USA / importé	85	95	semi-tardive	t	f	["vallee_fleuve", "niayes", "bassin_arachidier"]	30.00	Gros fruits (8-15 kg), très populaire ; tolérant à l'anthracnose.
136	36	Sugar Baby	USA / importé	75	85	hative	t	f	["niayes", "vallee_fleuve", "bassin_arachidier"]	25.00	Petits fruits ronds (3-5 kg) ; chair rouge sucrée, très commercialisable.
137	36	Crimson Sweet	USA / importé	80	90	semi-tardive	f	f	["vallee_fleuve", "niayes"]	35.00	Chair rouge très sucrée ; bonne conservation pour l'export.
138	36	Koloss	Nunhems / importé	80	90	semi-tardive	f	f	["vallee_fleuve"]	45.00	Hybride F1 très productif ; fruits lourds jusqu'à 20 kg.
139	37	Kent	USA / importé	100	120	tardive	t	f	["casamance", "senegal_oriental"]	15.00	Variété export n°1 du Sénégal ; gros fruit orange, chair ferme, peu de fibres.
140	37	Keitt	USA / importé	110	130	tardive	t	f	["casamance", "senegal_oriental"]	18.00	Deuxième variété export ; fruit vert même à maturité, très bonne conservation.
141	37	Amélie	Afrique de l'Ouest / acclimate	80	100	hative	t	f	["casamance", "senegal_oriental", "bassin_arachidier"]	12.00	Première à mûrir (avril-mai) ; marché local, fruit jaune sucré.
142	37	Valencia	Afrique de l'Ouest	90	110	semi-tardive	t	f	["casamance", "bassin_arachidier"]	10.00	Fruit rouge-vert, fibres moyennes, bonne productivité ; marché local.
143	38	Jumbo 1	ISRA	60	75	hative	t	f	["casamance", "senegal_oriental"]	2.50	Sélection ISRA Djibélor ; grosse noix (> 7 g), rendement élevé.
144	38	50-04	ISRA	65	80	semi-tardive	t	f	["casamance", "senegal_oriental"]	2.00	Sélection ISRA adaptée à la Casamance ; bonne tolérance à Helopeltis.
145	38	B11	ISRA Djibélor	65	80	semi-tardive	t	f	["casamance"]	2.20	Clone ISRA à forte productivité ; production régulière sur plusieurs années.
146	38	Local sélectionné	local Casamance	70	90	semi-tardive	t	f	["casamance", "senegal_oriental"]	1.20	Variété paysanne rustique ; noix petite mais adaptée aux conditions locales.
147	39	Grande Naine	Canaries / importé	300	360	semi-tardive	f	f	["niayes", "casamance", "vallee_fleuve"]	40.00	Variété commerciale dominante ; petit régime dense, bonne conservation.
148	39	Williams	Australie / importé	290	340	hative	f	f	["niayes", "casamance"]	45.00	Très productif ; fruits sucrés et aromatiques.
149	39	Gros Michel	Amérique centrale / acclimate	320	380	tardive	f	f	["casamance"]	30.00	Excellent goût mais très sensible à la maladie de Panama (Fusarium).
150	39	Laïtan	local Casamance	280	320	hative	t	f	["casamance", "senegal_oriental"]	20.00	Variété locale résistante ; petit fruit sucré, bonne adaptation.
151	40	Solo Sunrise	Hawaï / importé	270	330	semi-tardive	f	f	["niayes", "casamance", "vallee_fleuve"]	60.00	Variété hermaphrodite (dioïque) ; petits fruits orange intérieur, très sucrés.
152	40	Maradol	Cuba / importé	240	300	hative	f	f	["niayes", "vallee_fleuve", "casamance"]	80.00	Gros fruits (1,5-3 kg), chair orange, très productive ; dominante au Sénégal.
153	40	Red Lady F1	Taiwan / importé	240	280	hative	f	f	["niayes", "casamance"]	100.00	Hybride F1 très productif ; résistant au PRSV (ringspot) ; plant compact.
154	40	Tainung 1	Taiwan / importé	240	290	hative	f	f	["niayes", "vallee_fleuve"]	90.00	Tolérant au PRSV ; fruits ovales, chair ferme pour le transport.
\.


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analyses (id, org_id, user_id, farm_id, culture, region, measurements, score, verdict, advanced, created_at) FROM stdin;
1	1	1	\N	Tomate	THIES	{"Temp\\u00e9rature": 45.0, "Humidit\\u00e9": 14.0, "CE": 23.0, "pH": 6.0, "Azote": 56.0, "Phosphore": 34.0, "Potassium": 40.0, "Salinit\\u00e9": 3.0}	2	À corriger	f	2026-05-31 17:08:33.591079
2	1	1	\N	Piment		{"Temp\\u00e9rature": 34.0, "Humidit\\u00e9": 45.0, "CE": 0.15, "pH": 7.0, "Azote": 56.0, "Phosphore": 67.0, "Potassium": 56.0, "Salinit\\u00e9": 34.0}	3	À corriger	t	2026-06-03 07:24:28.302279
\.


--
-- Data for Name: champ_cartographies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_cartographies (id, parcelle_id, type_geometrie, coordonnees, projection, source_mesure, precision_m, date_mesure, actif, created_at) FROM stdin;
3	3	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.1215, "lon": -16.89}, {"lat": 15.1215, "lon": -16.8882}, {"lat": 15.12, "lon": -16.8882}]	WGS84	GPS_TERRAIN	3	2026-06-01	f	2026-06-09 17:08:35.821894+00
4	3	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.122, "lon": -16.89}, {"lat": 15.122, "lon": -16.8875}, {"lat": 15.12, "lon": -16.8875}, {"lat": 15.12, "lon": -16.89}]	WGS84	\N	\N	\N	t	2026-06-09 17:08:35.834877+00
5	4	POLYGON	[{"lat": 15.12, "lon": -16.89}, {"lat": 15.121, "lon": -16.89}, {"lat": 15.121, "lon": -16.8885}, {"lat": 15.12, "lon": -16.8885}]	WGS84	GPS_TERRAIN	\N	\N	t	2026-06-09 17:11:02.849603+00
6	5	POLYGON	[{"lat": 12.567, "lon": -16.2715}, {"lat": 12.5676, "lon": -16.2715}, {"lat": 12.5676, "lon": -16.2723}, {"lat": 12.567, "lon": -16.2723}, {"lat": 12.567, "lon": -16.2715}]	WGS84	\N	3	\N	t	2026-06-10 05:41:56.268073+00
7	6	POLYGON	[{"lat": 12.5518, "lon": -12.1742}, {"lat": 12.5524, "lon": -12.1742}, {"lat": 12.5524, "lon": -12.1748}, {"lat": 12.5518, "lon": -12.1748}, {"lat": 12.5518, "lon": -12.1742}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.839055+00
8	7	POLYGON	[{"lat": 16.0175, "lon": -16.489}, {"lat": 16.0183, "lon": -16.489}, {"lat": 16.0183, "lon": -16.4902}, {"lat": 16.0175, "lon": -16.4902}, {"lat": 16.0175, "lon": -16.489}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.851136+00
9	8	POLYGON	[{"lat": 13.7703, "lon": -13.667}, {"lat": 13.7711, "lon": -13.667}, {"lat": 13.7711, "lon": -13.6678}, {"lat": 13.7703, "lon": -13.6678}, {"lat": 13.7703, "lon": -13.667}]	WGS84	\N	3	\N	t	2026-06-10 06:10:27.859664+00
\.


--
-- Data for Name: champ_infrastructures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_infrastructures (id, parcelle_id, type, nom, description, longueur_m, superficie_m2, capacite, unite_capacite, etat, annee_construction, localisation, created_at) FROM stdin;
3	3	HANGAR	Hangar Principal (révisé)	\N	\N	150	\N	\N	MOYEN	2022	{"lat": 15.1208, "lon": -16.8891}	2026-06-09 17:08:35.855581+00
4	4	CLOTURE	Clôture périmètre	\N	544.4	\N	\N	\N	BON	\N	\N	2026-06-09 17:11:02.858196+00
\.


--
-- Data for Name: champ_parcelles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_parcelles (id, org_id, nom, code_parcelle, type_culture, culture_id, zone_agro, region, localite, statut, description, superficie_m2, superficie_ha, perimetre_m, centre_lat, centre_lon, score_completude, score_detail, created_at, updated_at) FROM stdin;
5	3	Parcelle Basse Casamance — Riz	PARC-003-001	\N	21	casamance	\N	\N	ACTIVE	Rizière en basse Casamance, sol hydromorphe, irrigation naturelle hivernage	5792.7	0.5793	307.1	12.5673	-16.2719	65	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 65, "manquants": ["Source d'eau", "Infrastructures", "Région", "Localité"], "sources_eau": {"max": 15, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune source d'eau renseignée"}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Manquant : Région, Localité"}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 05:41:17.568573+00	2026-06-10 05:42:52.983132+00
3	1	Parcelle Validation Complète	PARC-VALID-001	Oignon	\N	vallee_fleuve	Saint-Louis	Podor Centre	ARCHIVE	Parcelle principale de validation V1	32227.8	5.9681	981.5	15.12075	-16.8891	0	\N	2026-06-09 17:08:35.797083+00	2026-06-09 17:08:35.900766+00
8	6	Champ Mais Tambacounda	PARC-006-001	\N	22	senegal_oriental	Tambacounda	Koumpentoum	ACTIVE	Mais hybride BHSO2 hivernage 2026, sol ferrugineux tropical	7685.7	0.7686	350.7	13.7707	-13.6674	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:10:12.216962+00	2026-06-10 06:56:46.526471+00
4	1	Test Persistance Redémarrage	PARC-PERSIST-01	Mil	\N	bassin_arachidier	Kaolack	Nioro du Rip	ACTIVE	\N	17904.4	1.7904	544.4	15.1205	-16.88925	100	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 100, "manquants": [], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}}	2026-06-09 17:11:02.835261+00	2026-06-09 17:11:02.886981+00
7	4	Parcelle Oignon Vallee du Fleuve	PARC-004-001	\N	30	vallee_fleuve	Saint-Louis	Podor	ACTIVE	Oignon violet de Galmi contre-saison froide, irrigation fleuve Senegal	11408.9	1.1409	434.4	16.0179	-16.4896	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:10:12.101432+00	2026-06-10 06:56:46.510494+00
6	5	Verger Papaye — Kédougou	PARC-005-001	\N	40	senegal_oriental	Kédougou	Saraya	ACTIVE	Verger de papayers Maradol en plein hivernage, sol ferrallitique, irrigation par pompe solaire	4344.8	0.4345	263.7	12.5521	-12.1745	90	{"sol": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "total": 90, "manquants": ["Infrastructures"], "sources_eau": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "cartographie": {"max": 25, "pct": 100.0, "score": 25, "complete": true, "manquant": null}, "culture_zone": {"max": 15, "pct": 100.0, "score": 15, "complete": true, "manquant": null}, "localisation": {"max": 10, "pct": 100.0, "score": 10, "complete": true, "manquant": null}, "infrastructures": {"max": 10, "pct": 0.0, "score": 0, "complete": false, "manquant": "Aucune infrastructure renseignée"}}	2026-06-10 06:09:46.624223+00	2026-06-10 06:56:46.488347+00
\.


--
-- Data for Name: champ_sols; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_sols (id, parcelle_id, date_analyse, texture, profondeur_labour_cm, pierrosite_pct, erosion, "pH_eau", "pH_kcl", matiere_organique, azote_total, phosphore_assim, potassium_echang, calcium, magnesium, sodium, cec, conductivite_ds_m, methode_analyse, laboratoire, reference_labo, observations, created_at) FROM stdin;
3	3	2026-04-15	ARGILO_LIMONEUX	\N	\N	FAIBLE	6.8	\N	2.3	1.1	18	0.6	\N	\N	\N	\N	0.4	\N	\N	\N	\N	2026-06-09 17:08:35.842386+00
4	3	2026-01-10	\N	\N	\N	\N	6.2	\N	\N	0.7	10	0.35	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-09 17:08:35.850823+00
5	4	\N	\N	\N	\N	\N	6.5	\N	\N	0.85	11	0.42	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-09 17:11:02.855305+00
6	5	2026-06-01	ARGILO_LIMONEUX	\N	\N	\N	5.8	\N	2.4	1.8	18.5	0.35	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 05:42:52.971809+00
7	8	2026-05-28	SABLO_LIMONEUX	\N	\N	\N	6.2	\N	1.2	0.9	12.5	0.25	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:44.593279+00
8	7	2026-04-10	LIMONEUX	\N	\N	\N	7.1	\N	3.9	2.8	35	0.72	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:44.594496+00
9	6	2026-05-15	\N	\N	\N	\N	5.3	\N	1.8	1.1	8.2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:10:53.290619+00
10	6	2026-06-01	SABLO_LIMONEUX	\N	\N	\N	5.3	\N	1.8	1.1	8.2	0.18	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-10 06:11:34.238522+00
\.


--
-- Data for Name: champ_sources_eau; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.champ_sources_eau (id, parcelle_id, type, nom, debit_m3h, profondeur_m, "pH_eau", conductivite_ds_m, qualite, disponibilite, partage, superficie_m2, localisation, created_at) FROM stdin;
3	3	FORAGE	Forage FP1 (calibré)	25	45	7.1	0.5	BONNE	PERMANENTE	f	\N	{"lat": 15.1205, "lon": -16.8895}	2026-06-09 17:08:35.868393+00
4	4	PUITS_TRADITIONNEL	Puits central	5	\N	\N	\N	ACCEPTABLE	SAISONNIERE	f	\N	\N	2026-06-09 17:11:02.860649+00
5	6	FORAGE	Forage solaire Saraya	2.5	\N	\N	\N	BONNE	PERMANENTE	f	\N	\N	\N
6	7	CANAL_IRRIGATION	Canal vallée du fleuve Sénégal	15	\N	\N	\N	ACCEPTABLE	PERMANENTE	t	\N	\N	\N
7	8	EAU_DE_PLUIE	Mare temporaire Koumpentoum	8	\N	\N	\N	ACCEPTABLE	SAISONNIERE	t	\N	\N	\N
\.


--
-- Data for Name: credit_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_ledger (id, user_id, delta, motif, solde_apres, service_request_id, meta, cree_le) FROM stdin;
1	1	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-03 16:40:49.739664+00
2	2	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-10 05:30:50.575811+00
3	3	30	bonus	30	\N	{"raison": "essai_inscription"}	2026-06-10 05:54:09.234435+00
\.


--
-- Data for Name: credit_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_purchases (id, user_id, credits, montant_fcfa, fournisseur, reference, statut, ledger_id, cree_le, paye_le) FROM stdin;
\.


--
-- Data for Name: farms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.farms (id, org_id, name, region, locality, latitude, longitude, area_ha, created_at) FROM stdin;
\.


--
-- Data for Name: gf_activites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_activites (id, org_id, parcelle_id, culture_id, consultation_id, type, statut, titre, description, date_prevue, date_debut, date_fin, duree_minutes, stade_culture, surface_traitee_ha, conditions_meteo, localisation_debut, details, note, created_by, created_at, updated_at) FROM stdin;
3	1	\N	21	\N	RECOLTE	PLANIFIE	Récolte riz hivernage	\N	2026-11-20	\N	\N	\N	\N	\N	{}	{}	{"qualite": "A", "destination": "marché local", "rendement_kg_ha": 4200, "quantite_totale_kg": 10500}	\N	1	2026-06-09 18:36:28.183674	2026-06-09 18:36:28.183676
1	1	\N	21	\N	SEMIS	TERMINE	Semis riz hivernage 2026	Semis direct sur sol préparé 2 semaines avant	2026-07-01	2026-06-09 18:36:28.402298	2026-06-09 18:36:28.439552	240	pré-germination	2.5	{"vent": 5, "temp_air": 28, "pluie_24h": 0, "humidite_rel": 75}	{"lat": 15.553, "lon": -14.213, "precision_m": 5.0}	{"methode": "manuel", "variete": "Sahel 108", "densite_kg_ha": 120, "profondeur_cm": 3}	Semis terminé. Sol bien humide.	1	2026-06-09 18:36:27.991041	2026-06-09 18:36:28.439552
2	1	\N	21	\N	FERTILISATION	ANNULE	Apport urée tallage	\N	2026-08-15	\N	\N	\N	\N	\N	{}	{}	{"K": 0, "N": 46, "P": 0, "methode": "épandage manuel", "produit": "Urée 46%", "dose_kg_ha": 100}	\N	1	2026-06-09 18:36:28.160815	2026-06-09 18:36:28.692481
4	2	\N	\N	\N	AUTRE	PLANIFIE	Test upload	\N	2026-06-10	\N	\N	\N	\N	\N	{}	{}	{}	\N	2	2026-06-10 05:31:46.726671	2026-06-10 05:31:46.726693
5	3	5	\N	\N	SEMIS	PLANIFIE	Semis riz hivernage 2026	Variété Sahel 108, semis direct à la volée, 80 kg/ha	2026-06-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:45:12.001726	2026-06-10 05:45:12.00173
6	3	5	\N	\N	FERTILISATION	PLANIFIE	Apport urée au tallage	Urée 46% à 100 kg/ha en couverture	2026-07-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:45:12.124922	2026-06-10 05:45:12.124926
7	3	5	\N	\N	TRAITEMENT	PLANIFIE	Traitement pyriculariose (tricyclazole)	Tricyclazole 75 WP 0.6 kg/ha, pulvérisation foliaire	2026-06-25	\N	\N	\N	\N	\N	{}	{}	{}	\N	3	2026-06-10 05:46:20.599207	2026-06-10 05:46:20.599211
8	5	6	\N	\N	PLANTATION	PLANIFIE	Plantation papayers Maradol	Repiquage plants 4 mois, espacement 3x3m, 180 plants/ha	2026-04-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.702455	2026-06-10 06:11:49.702458
9	5	6	\N	\N	FERTILISATION	PLANIFIE	Fumure de fond NPK 15-15-15	250 kg/ha NPK 15-15-15 en fond de fosse	2026-04-10	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.837214	2026-06-10 06:11:49.837219
10	5	6	\N	\N	IRRIGATION	PLANIFIE	Irrigation pompe solaire	Irrigation goutte-a-goutte 4L/pied/jour pendant floraison	2026-06-08	\N	\N	\N	\N	\N	{}	{}	{}	\N	4	2026-06-10 06:11:49.954664	2026-06-10 06:11:49.954667
11	4	7	\N	\N	SEMIS	PLANIFIE	Semis oignon violet Galmi	Semis en pepiniere, 3 kg semences/ha, irrigation quotidienne	2026-01-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	5	2026-06-10 06:12:59.868601	2026-06-10 06:12:59.868603
12	4	7	\N	\N	PLANTATION	PLANIFIE	Repiquage oignon	Repiquage plants 40-45j, espacement 15x20cm, 330000 plants/ha	2026-02-15	\N	\N	\N	\N	\N	{}	{}	{}	\N	5	2026-06-10 06:12:59.975114	2026-06-10 06:12:59.975116
14	6	8	\N	\N	SEMIS	PLANIFIE	Semis mais BHSO2	Semis poquet 3 graines, espacement 80x40cm, 62500 pieds/ha	2026-06-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.221932	2026-06-10 06:13:00.221935
15	6	8	\N	\N	TRAITEMENT	PLANIFIE	Herbicide pre-levee	Atrazine 500 SC, 2L/ha en pre-levee dans les 3j apres semis	2026-06-22	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.357082	2026-06-10 06:13:00.357086
16	6	8	\N	\N	FERTILISATION	PLANIFIE	Engrais starter DAP	DAP 18-46-0, 150 kg/ha au semis en microdose	2026-06-20	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.471319	2026-06-10 06:13:00.471322
13	4	7	\N	\N	DESHERBAGE	PLANIFIE	Desherbage manuel 1er passage	Sarclage inter-rang, eliminer concurrence hydrique	2026-03-05	\N	\N	\N	\N	\N	{}	{}	{}	\N	6	2026-06-10 06:13:00.090963	2026-06-10 06:13:00.090966
\.


--
-- Data for Name: gf_couts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_couts (id, activite_id, org_id, categorie, sous_categorie, description, quantite, unite, prix_unitaire_fcfa, montant_total_fcfa, fournisseur, date_achat, recu, note, created_at) FROM stdin;
2	1	1	MATERIEL	\N	Location tracteur	\N	\N	\N	45000	\N	\N	f	\N	2026-06-09 18:36:28.488513
3	5	3	INTRANT	\N	Semences riz Sahel 108 — 46 kg	46	kg	800	36800	\N	\N	f	\N	2026-06-10 05:46:42.535997
4	6	3	INTRANT	\N	Urée 46% — 58 kg	58	kg	500	29000	\N	\N	f	\N	2026-06-10 05:46:42.649516
5	7	3	INTRANT	\N	Tricyclazole 75 WP — 0.35 kg	0.35	kg	12000	4200	\N	\N	f	\N	2026-06-10 05:46:42.777729
6	12	4	PRESTATION	\N	Main oeuvre repiquage 10 personnes 2 jours	20	jour-personne	3000	60000	\N	\N	f	\N	2026-06-10 06:13:32.084257
7	9	5	INTRANT	\N	NPK 15-15-15	109	kg	450	49050	\N	\N	f	\N	2026-06-10 06:13:32.104613
8	8	5	INTRANT	\N	Plants papayers Maradol 4 mois	80	pieds	500	40000	\N	\N	f	\N	2026-06-10 06:13:32.123455
9	14	6	INTRANT	\N	Semences mais BHSO2 certifiees	25	kg	1200	30000	\N	\N	f	\N	2026-06-10 06:13:32.178252
10	11	4	INTRANT	\N	Semences oignon Galmi certifiees	3.4	kg	8500	28900	\N	\N	f	\N	2026-06-10 06:13:32.184408
11	16	6	INTRANT	\N	DAP 18-46-0	115	kg	600	69000	\N	\N	f	\N	2026-06-10 06:13:32.197031
\.


--
-- Data for Name: gf_journal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_journal (id, org_id, parcelle_id, activite_id, date_entree, type, titre, contenu, created_by, created_at) FROM stdin;
1	1	\N	1	2026-07-01	OBSERVATION	Humidité sol satisfaisante	Sol à 70% capacité au champ. Levée prévue J+7. Pas de signe de stress hydrique.	1	2026-06-09 18:36:28.590259
2	1	\N	\N	2026-07-05	ALERTE	Risque foreur de tige	Observation de papillons Chilo suppressalis sur parcelle voisine. Surveillance renforcée.	1	2026-06-09 18:36:28.606082
\.


--
-- Data for Name: gf_main_oeuvre; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_main_oeuvre (id, activite_id, org_id, type, description, nb_personnes, duree_jours, taux_journalier_fcfa, montant_total_fcfa, note, created_at) FROM stdin;
1	1	1	SALARIALE	Semeurs journaliers	8	2	3500	56000	\N	2026-06-09 18:36:28.544326
2	1	1	FAMILIALE	Aide famille	3	1	0	0	\N	2026-06-09 18:36:28.561852
\.


--
-- Data for Name: gf_preuves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gf_preuves (id, activite_id, org_id, type, filename, url, thumbnail_url, duree_secondes, taille_ko, source, localisation, horodatage_terrain, photo_meta, uploaded_at) FROM stdin;
1	4	2	PHOTO	d34fd65cb16d42bf84a07373314c27f6.jpg	/uploads/activites/d34fd65cb16d42bf84a07373314c27f6.jpg	\N	\N	0	SMARTPHONE	{}	\N	{"taille_b": 11, "mime_type": "image/jpeg", "hash_sha256": "e854cd7df58701513873cd64d87128f98ee0acac31d340e09fde7cad4e69cdb1", "original_name": "hostname"}	2026-06-10 05:31:46.819066
\.


--
-- Data for Name: ia_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_config (id, org_id, langue, ton, focus_cultures, inclure_meteo, inclure_regles, inclure_historique_sante, inclure_couts, updated_at) FROM stdin;
1	1	fr	PEDAGOGIQUE	{arachide,mil}	t	t	t	t	2026-06-09 19:31:44.933023
2	3	fr	SIMPLE	\N	t	t	t	t	2026-06-10 05:52:08.293929
3	5	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:27.763651
4	4	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:43.467496
5	6	fr	SIMPLE	\N	t	t	t	t	2026-06-10 06:14:43.934825
\.


--
-- Data for Name: ia_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_conversations (id, org_id, user_id, parcelle_id, culture_id, titre, statut, mode, nb_messages, tokens_total, contexte_init, mois_periode, created_at, updated_at) FROM stdin;
2	1	1	4	\N	Test avec parcelle active	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-09 19:31:02.169189	2026-06-09 19:31:02.551231
3	1	1	4	\N	Analyse — Test Persistance Redémarrage	ACTIVE	ANALYSE_PARCELLE	2	0	\N	2026-06	2026-06-09 19:31:28.525996	2026-06-09 19:31:28.582734
1	1	1	3	\N	Test IA	ARCHIVEE	LIBRE	2	0	\N	2026-06	2026-06-09 19:29:34.3245	2026-06-09 19:31:58.485214
4	3	3	5	\N	Conseil riz hivernage 2026	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 05:52:08.126028	2026-06-10 05:53:09.860942
5	3	3	5	\N	Conseil riz hivernage 2026 — V2	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 05:53:41.220799	2026-06-10 05:53:41.417615
6	5	4	6	\N	Taches jaunes sur papaye Kedougou	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:27.631831	2026-06-10 06:14:27.82357
7	4	5	7	\N	Thrips oignon Saint-Louis	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:43.363019	2026-06-10 06:14:43.706365
8	6	6	8	\N	Fertilisation mais hivernage Tambacounda	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 06:14:43.835284	2026-06-10 06:14:43.981166
9	5	4	6	\N	Analyse complète verger papaye Kedougou	ACTIVE	LIBRE	2	0	\N	2026-06	2026-06-10 06:30:05.451556	2026-06-10 06:30:05.860506
\.


--
-- Data for Name: ia_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_feedback (id, org_id, conversation_id, message_id, recommandation_id, note, utile, commentaire, amelioration, created_at) FROM stdin;
1	1	2	4	\N	4	t	Bonne analyse du sol	Ajouter des recommandations engrais spécifiques	2026-06-09 19:31:44.81985
\.


--
-- Data for Name: ia_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_messages (id, conversation_id, org_id, role, contenu, tokens_in, tokens_out, modele, duree_ms, contexte_inject, regles_codes, created_at) FROM stdin;
1	1	1	USER	Quelle est la situation de ma parcelle et que dois-je faire en priorité ?	\N	\N	\N	\N	\N	\N	2026-06-09 19:29:45.420493
2	1	1	ASSISTANT	Je n'ai pas accès à vos données de parcelles pour générer des recommandations. Ajoutez une parcelle dans Mon Champ pour des conseils personnalisés.	0	0	fallback_rules	16	{"regles": 0, "alertes": 0, "parcelles": 0}	\N	2026-06-09 19:29:45.43603
3	2	1	USER	Quelle est la situation de ma parcelle et quelles sont mes priorités ?	\N	\N	\N	\N	\N	\N	2026-06-09 19:31:02.432741
4	2	1	ASSISTANT	**Analyse agronomique pour Test Persistance Redémarrage ()**\n\nZone : bassin_arachidier | Sol : pH 6.5, azote_g_kg 0.8, phosphore_mg_kg 11.0\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	116	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-09 19:31:02.547307
5	3	1	USER	Fais une analyse complète de la parcelle Test Persistance Redémarrage. Identifie les problèmes actuels et donne 3 à 5 recommandations prioritaires.	\N	\N	\N	\N	\N	\N	2026-06-09 19:31:28.540332
6	3	1	ASSISTANT	**Analyse agronomique pour Test Persistance Redémarrage ()**\n\nZone : bassin_arachidier | Sol : pH 6.5, azote_g_kg 0.8, phosphore_mg_kg 11.0\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	41	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-09 19:31:28.581931
8	4	3	USER	Mon riz présente des taches brunes sur les feuilles depuis 10 jours. Environ 20% des plants sont touchés. Que faire ?	\N	\N	\N	\N	\N	\N	2026-06-10 05:53:09.778619
9	4	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\n⚠ **[RAV-RIZ-001] Foreur de tige riz — Conditions favorables tallage** (elevee)\n  • {'titre': 'Risque Foreur tige riz', 'niveau': 'elevee', 'message': 'Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts.'}	0	0	fallback_rules	82	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 05:53:09.860036
10	5	3	USER	Mon riz présente des taches brunes sur les feuilles depuis 10 jours. Environ 20% des plants sont touchés. Que faire ?	\N	\N	\N	\N	\N	\N	2026-06-10 05:53:41.339018
11	5	3	ASSISTANT	**Analyse agronomique pour Parcelle Basse Casamance — Riz (Riz)**\n\nZone : casamance | Sol : pH 5.8, azote_g_kg 1.8, phosphore_mg_kg 18.5, texture argilo_limoneux, matiere_organique_pct 2.4\n\n\n⚠ **[RAV-RIZ-001] Foreur de tige riz — Conditions favorables tallage** (elevee)\n  • Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts.\n\nRECOMMANDATION : Granulés insecticides au tallage\nACTION : Appliquer : Granulés insecticides au tallage\nPOURQUOI : Règle agronomique RAV-RIZ-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	78	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 05:53:41.41678
12	6	5	USER	Mes papayers ont des taches jaunes sur les feuilles et les fruits sont deformes. 35% des plants sont touches. Cest grave ?	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:27.77246
13	6	5	ASSISTANT	**Analyse agronomique pour Verger Papaye — Kédougou (Papaye)**\n\nZone : senegal_oriental | Sol : pH 5.3, azote_g_kg 1.1, phosphore_mg_kg 8.2, texture sablo_limoneux, matiere_organique_pct 1.8\n\n\nAucune alerte agronomique critique détectée pour vos parcelles actuelles. Continuez vos activités selon le plan prévu.	0	0	fallback_rules	50	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-10 06:14:27.822741
14	7	4	USER	Jai des thrips sur mon oignon, les feuilles sont trouees et argentees. Comment traiter ? Jai 1.1 ha en bulbaison.	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:43.482275
15	7	4	ASSISTANT	**Analyse agronomique pour Parcelle Oignon Vallee du Fleuve (Oignon)**\n\nZone : vallee_fleuve | Sol : pH 7.1, azote_g_kg 2.8, phosphore_mg_kg 35.0, texture limoneux, matiere_organique_pct 3.9\n\n\n⚠ **[FER-OIG-001] Oignon — Carence N croissance-bulbaison** (elevee)\n  • N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite.\n\nRECOMMANDATION : Urée fractionné + arrêt 4 semaines avant récolte\nACTION : Appliquer : Urée fractionné + arrêt 4 semaines avant récolte\nPOURQUOI : Règle agronomique FER-OIG-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	223	{"regles": 0, "alertes": 2, "parcelles": 1}	\N	2026-06-10 06:14:43.705313
16	8	6	USER	Mon sol a peu dazote (0.9 g/kg) et peu de matiere organique (1.2%). Quel programme de fertilisation pour le mais BHSO2 en hivernage ? Budget 150000 FCFA pour 0.77 ha.	\N	\N	\N	\N	\N	\N	2026-06-10 06:14:43.939303
17	8	6	ASSISTANT	**Analyse agronomique pour Champ Mais Tambacounda (Maïs)**\n\nZone : senegal_oriental | Sol : pH 6.2, azote_g_kg 0.9, phosphore_mg_kg 12.5, texture sablo_limoneux, matiere_organique_pct 1.2\n\n\n⚠ **[FER-MAI-001] Maïs — Carence N critique levée** (elevee)\n  • N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé.\n\nRECOMMANDATION : Programme NPK maïs\nACTION : Appliquer : Programme NPK maïs\nPOURQUOI : Règle agronomique FER-MAI-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	40	{"regles": 0, "alertes": 1, "parcelles": 1}	\N	2026-06-10 06:14:43.980351
18	9	5	USER	Quels sont les principaux risques pour mon verger de papaye en ce moment ?	\N	\N	\N	\N	\N	\N	2026-06-10 06:30:05.75678
19	9	5	ASSISTANT	**Analyse agronomique pour Verger Papaye — Kédougou (Papaye)**\n\nZone : senegal_oriental | Sol : pH 5.3, azote_g_kg 1.1, phosphore_mg_kg 8.2, texture sablo_limoneux, matiere_organique_pct 1.8\n\n\n⚠ **[MAL-PAP-003] Anthracnose papaye — Humidité maturité fruits** (elevee)\n  • Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte.\n\nRECOMMANDATION : Carbendazime précolte\nACTION : Appliquer : Carbendazime précolte\nPOURQUOI : Règle agronomique MAL-PAP-003 déclenchée\nDÉLAI : 7 jours\n\nRECOMMANDATION : Trempage eau chaude 50°C 20min\nACTION : Appliquer : Trempage eau chaude 50°C 20min\nPOURQUOI : Règle agronomique MAL-PAP-003 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[RAV-PAP-001] Mouche des fruits papaye — Maturation** (elevee)\n  • Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées.\n\nRECOMMANDATION : Appât protéiné GF-120\nACTION : Appliquer : Appât protéiné GF-120\nPOURQUOI : Règle agronomique RAV-PAP-001 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[SOL-PAP-002] Papaye — Carence matière organique** (elevee)\n  • MO 1.8% < seuil 2.0%. Rétention eau et nutrition minérale insuffisantes pour papaye.\n\nRECOMMANDATION : Apport compost mature + fumier\nACTION : Appliquer : Apport compost mature + fumier\nPOURQUOI : Règle agronomique SOL-PAP-002 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[FER-PAP-001] Papaye — Carence N croissance** (elevee)\n  • N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification.\n\nRECOMMANDATION : NPK + Urée mensuel\nACTION : Appliquer : NPK + Urée mensuel\nPOURQUOI : Règle agronomique FER-PAP-001 déclenchée\nDÉLAI : 7 jours\n\n⚠ **[SOL-PAP-001] Papaye — Sol acide pH critique** (elevee)\n  • pH 5.3 < seuil optimal 5.5-7.0. Toxicité Al/Mn, carence Ca-Mg, croissance ralentie.\n\nRECOMMANDATION : Chaulage correctif calcaire dolomitique\nACTION : Appliquer : Chaulage correctif calcaire dolomitique\nPOURQUOI : Règle agronomique SOL-PAP-001 déclenchée\nDÉLAI : 7 jours	0	0	fallback_rules	103	{"regles": 0, "alertes": 0, "parcelles": 1}	\N	2026-06-10 06:30:05.859049
\.


--
-- Data for Name: ia_recommandations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ia_recommandations (id, org_id, conversation_id, message_id, parcelle_id, culture_id, categorie, priorite, titre, action, justification, sources, echeance_jours, statut, confiance, created_at) FROM stdin;
\.


--
-- Data for Name: mt_alertes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_alertes (id, org_id, parcelle_id, culture_id, type_alerte, sous_type, niveau, titre, message, details, regle_code, valable_du, valable_au, lu, lu_le, action_prise, created_at) FROM stdin;
1	3	5	21	RAVAGEUR	insecte	AVERTISSEMENT	Foreur de tige riz — Conditions favorables tallage	Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts. — Recommandation : Granulés insecticides au tallage	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.78, "contexte_meteo": {"temp": 24.2, "humidite": 89, "pluie_mm": 0.0}, "recommandations": ["Granulés insecticides au tallage"]}	RAV-RIZ-001	2026-06-10 05:50:57.905347	\N	f	\N	f	2026-06-10 05:50:57.919745
2	5	6	40	FERTILISATION	azote	INFO	Papaye — Carence N croissance	N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification. — Recommandation : NPK + Urée mensuel	{"gravite": "moyenne", "categorie": "fertilisation", "confiance": 0.72, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["NPK + Urée mensuel"]}	FER-PAP-001	2026-06-10 06:14:14.566158	\N	f	\N	f	2026-06-10 06:14:14.572496
3	4	7	30	METEO	secheresse	AVERTISSEMENT	Risque sécheresse : 7 jours sans pluie prévus	7 jours sans précipitations prévues. Surveiller humidité sol.	{"seuil": 7, "jours_sans_pluie": 7}	\N	2026-06-10 06:14:14.801177	\N	f	\N	f	2026-06-10 06:14:14.801704
4	4	7	30	FERTILISATION	azote	AVERTISSEMENT	Oignon — Carence N croissance-bulbaison	N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite. — Recommandation : Urée fractionné + arrêt 4 semaines avant récolte	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.85, "contexte_meteo": {"temp": 22.6, "humidite": 89, "pluie_mm": 0.0}, "recommandations": ["Urée fractionné + arrêt 4 semaines avant récolte"]}	FER-OIG-001	2026-06-10 06:14:14.838352	\N	f	\N	f	2026-06-10 06:14:14.843392
5	6	8	22	FERTILISATION	azote	AVERTISSEMENT	Maïs — Carence N critique levée	N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé. — Recommandation : Programme NPK maïs	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.9, "contexte_meteo": {"temp": 24.9, "humidite": 96, "pluie_mm": 0.3}, "recommandations": ["Programme NPK maïs"]}	FER-MAI-001	2026-06-10 06:14:15.112528	\N	f	\N	f	2026-06-10 06:14:15.116662
6	5	6	40	MALADIE	fongique	AVERTISSEMENT	Anthracnose papaye — Humidité maturité fruits	Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte. — Recommandation : Carbendazime précolte	{"gravite": "elevee", "categorie": "maladie", "confiance": 0.78, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Carbendazime précolte", "Trempage eau chaude 50°C 20min"]}	MAL-PAP-003	2026-06-10 06:58:47.54582	\N	f	\N	f	2026-06-10 06:58:47.569417
7	5	6	40	RAVAGEUR	insecte	AVERTISSEMENT	Mouche des fruits papaye — Maturation	Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées. — Recommandation : Appât protéiné GF-120	{"gravite": "elevee", "categorie": "ravageur", "confiance": 0.85, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Appât protéiné GF-120"]}	RAV-PAP-001	2026-06-10 06:58:47.554003	\N	f	\N	f	2026-06-10 06:58:47.569422
8	5	6	40	FERTILISATION	amendement	AVERTISSEMENT	Papaye — Sol acide pH critique	pH 5.3 < seuil optimal 5.5-7.0. Toxicité Al/Mn, carence Ca-Mg, croissance ralentie. — Recommandation : Chaulage correctif calcaire dolomitique	{"gravite": "elevee", "categorie": "fertilisation", "confiance": 0.85, "contexte_meteo": {"temp": 24.9, "humidite": 88, "pluie_mm": 0.0}, "recommandations": ["Chaulage correctif calcaire dolomitique"]}	SOL-PAP-001	2026-06-10 06:58:47.561997	\N	f	\N	f	2026-06-10 06:58:47.569423
\.


--
-- Data for Name: mt_conditions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_conditions (id, org_id, parcelle_id, lat, lon, zone_agro, source, temp_actuelle, temp_min, temp_max, humidite_rel, pluie_mm, vent_kmh, direction_vent, etp_mm, code_meteo, description_fr, date_releve, heure_releve, expire_le, created_at) FROM stdin;
1	1	4	15.1205	-16.88925	bassin_arachidier	OPEN_METEO	23.7	\N	\N	83	0	14.2	292	0	2	Partiellement nuageux	2026-06-09	2026-06-09 19:02:47.657371	2026-06-09 20:02:47.657371	2026-06-09 19:02:47.775847
2	1	3	15.12075	-16.8891	vallee_fleuve	CAPTEUR	32.5	\N	\N	65	0	8	292	0	2	Partiellement nuageux	2026-06-09	2026-06-09 19:04:26.480724	2026-06-09 20:03:57.603161	2026-06-09 19:03:57.716268
3	3	5	12.5673	-16.2719	casamance	OPEN_METEO	24.2	\N	\N	89	0	4.8	347	0	3	Couvert	2026-06-10	2026-06-10 05:47:21.851261	2026-06-10 06:47:21.851261	2026-06-10 05:47:21.973771
4	5	6	12.5521	-12.1745	senegal_oriental	OPEN_METEO	24.9	\N	\N	88	0	3.1	121	0	3	Couvert	2026-06-10	2026-06-10 06:14:13.727248	2026-06-10 07:14:13.727248	2026-06-10 06:14:13.850136
5	4	7	16.0179	-16.4896	vallee_fleuve	OPEN_METEO	22.6	\N	\N	89	0	10.6	294	0	0	Ciel dégagé	2026-06-10	2026-06-10 06:14:13.951119	2026-06-10 07:14:13.951119	2026-06-10 06:14:14.066022
6	6	8	13.7707	-13.6674	senegal_oriental	OPEN_METEO	24.9	\N	\N	96	0.3	7.1	207	0	55	Bruine dense	2026-06-10	2026-06-10 06:14:14.161085	2026-06-10 07:14:14.161085	2026-06-10 06:14:14.27567
\.


--
-- Data for Name: mt_config_alertes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_config_alertes (id, org_id, seuils, alertes_meteo_actives, alertes_maladies_actives, alertes_ravageurs_actives, alertes_fertilisation_actives, alertes_irrigation_actives, alertes_planificateur_actives, heure_envoi_alertes, updated_at) FROM stdin;
1	1	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 25, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-09 19:04:10.578432
2	3	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 05:47:30.222442
3	5	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.396585
4	4	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.680832
5	6	{"chaleur_max_c": 38, "etp_elevee_mm": 8, "vent_fort_kmh": 40, "pluie_forte_mm": 30, "pluie_extreme_mm": 60, "secheresse_jours": 7, "vent_extreme_kmh": 70, "chaleur_extreme_c": 42, "secheresse_critique_jours": 14}	t	t	t	t	t	t	\N	2026-06-10 06:14:14.966644
\.


--
-- Data for Name: mt_planificateur; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_planificateur (id, org_id, parcelle_id, culture_id, activite_id, date_recommandee, type_activite, titre, priorite, raison, fenetre_debut, fenetre_fin, conditions_ok, detail_conditions, statut, source, genere_le, expire_le) FROM stdin;
\.


--
-- Data for Name: mt_previsions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mt_previsions (id, org_id, parcelle_id, lat, lon, zone_agro, source, horizon_jours, donnees, genere_le, expire_le) FROM stdin;
1	1	\N	14.7	-17.43	niayes	open_meteo	7	[{"date": "2026-06-09", "etp_mm": 4.4, "pluie_mm": 0.0, "temp_max": 26.5, "temp_min": 22.4, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 88, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-10", "etp_mm": 4.72, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.8, "vent_kmh": 16.9, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.1, "temp_min": 23.5, "vent_kmh": 14.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-12", "etp_mm": 4.88, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.2, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 8}, {"date": "2026-06-13", "etp_mm": 4.91, "pluie_mm": 0.0, "temp_max": 27.3, "temp_min": 23.9, "vent_kmh": 16.9, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.4, "temp_min": 23.6, "vent_kmh": 16.8, "code_meteo": 3, "humidite_pct": 84, "description_fr": "Couvert", "pluie_proba_pct": 3}, {"date": "2026-06-15", "etp_mm": 4.7, "pluie_mm": 1.2, "temp_max": 28.3, "temp_min": 24.8, "vent_kmh": 24.4, "code_meteo": 51, "humidite_pct": 87, "description_fr": "Bruine légère", "pluie_proba_pct": 8}]	2026-06-09 19:02:48.077902	2026-06-10 01:02:48.077902
2	1	4	15.1205	-16.88925	bassin_arachidier	open_meteo	16	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-23", "etp_mm": 5.18, "pluie_mm": 0.0, "temp_max": 30.6, "temp_min": 24.2, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-24", "etp_mm": 5.67, "pluie_mm": 0.0, "temp_max": 30.6, "temp_min": 23.3, "vent_kmh": 23.1, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 6}]	2026-06-09 19:03:20.341509	2026-06-10 01:03:20.341509
3	1	3	15.12075	-16.8891	vallee_fleuve	open_meteo	7	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}]	2026-06-09 19:03:57.775427	2026-06-10 01:03:57.775427
4	1	3	15.12075	-16.8891	vallee_fleuve	open_meteo	14	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}]	2026-06-09 19:04:10.221305	2026-06-10 01:04:10.221305
5	1	4	15.1205	-16.88925	bassin_arachidier	open_meteo	14	[{"date": "2026-06-09", "etp_mm": 4.29, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 22.1, "vent_kmh": 17.4, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 6}, {"date": "2026-06-10", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 26.9, "temp_min": 22.6, "vent_kmh": 16.3, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.5, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.2, "vent_kmh": 16.5, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 28.8, "temp_min": 24.0, "vent_kmh": 17.9, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 7}, {"date": "2026-06-13", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 23.3, "vent_kmh": 16.2, "code_meteo": 3, "humidite_pct": 91, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 4.9, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.1, "vent_kmh": 23.2, "code_meteo": 3, "humidite_pct": 87, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-15", "etp_mm": 3.8, "pluie_mm": 7.2, "temp_max": 27.3, "temp_min": 24.2, "vent_kmh": 13.6, "code_meteo": 55, "humidite_pct": 90, "description_fr": "Bruine dense", "pluie_proba_pct": 12}, {"date": "2026-06-16", "etp_mm": 4.61, "pluie_mm": 0.0, "temp_max": 28.0, "temp_min": 23.7, "vent_kmh": 13.6, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-17", "etp_mm": 4.56, "pluie_mm": 0.0, "temp_max": 27.4, "temp_min": 22.9, "vent_kmh": 14.8, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-18", "etp_mm": 4.66, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 23.3, "vent_kmh": 14.7, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-19", "etp_mm": 4.99, "pluie_mm": 0.0, "temp_max": 29.8, "temp_min": 23.8, "vent_kmh": 21.3, "code_meteo": 1, "humidite_pct": 94, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-20", "etp_mm": 4.57, "pluie_mm": 0.0, "temp_max": 28.4, "temp_min": 23.8, "vent_kmh": 15.0, "code_meteo": 0, "humidite_pct": 95, "description_fr": "Ciel dégagé", "pluie_proba_pct": 4}, {"date": "2026-06-21", "etp_mm": 4.64, "pluie_mm": 0.0, "temp_max": 27.9, "temp_min": 23.3, "vent_kmh": 14.9, "code_meteo": 1, "humidite_pct": 98, "description_fr": "Principalement dégagé", "pluie_proba_pct": 2}, {"date": "2026-06-22", "etp_mm": 5.17, "pluie_mm": 0.0, "temp_max": 30.2, "temp_min": 23.6, "vent_kmh": 16.4, "code_meteo": 1, "humidite_pct": 92, "description_fr": "Principalement dégagé", "pluie_proba_pct": 4}]	2026-06-09 19:04:10.383501	2026-06-10 01:04:10.383501
6	3	5	12.5673	-16.2719	casamance	open_meteo	3	[{"date": "2026-06-10", "etp_mm": 5.09, "pluie_mm": 0.7, "temp_max": 35.5, "temp_min": 24.2, "vent_kmh": 13.9, "code_meteo": 51, "humidite_pct": 89, "description_fr": "Bruine légère", "pluie_proba_pct": 55}, {"date": "2026-06-11", "etp_mm": 3.66, "pluie_mm": 17.7, "temp_max": 32.1, "temp_min": 24.0, "vent_kmh": 9.2, "code_meteo": 81, "humidite_pct": 96, "description_fr": "Averses modérées", "pluie_proba_pct": 64}, {"date": "2026-06-12", "etp_mm": 3.75, "pluie_mm": 1.2, "temp_max": 33.2, "temp_min": 24.6, "vent_kmh": 14.3, "code_meteo": 53, "humidite_pct": 96, "description_fr": "Bruine modérée", "pluie_proba_pct": 43}]	2026-06-10 05:47:22.077444	2026-06-10 11:47:22.077444
7	3	5	12.5673	-16.2719	casamance	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 5.09, "pluie_mm": 0.7, "temp_max": 35.5, "temp_min": 24.2, "vent_kmh": 13.9, "code_meteo": 51, "humidite_pct": 89, "description_fr": "Bruine légère", "pluie_proba_pct": 55}, {"date": "2026-06-11", "etp_mm": 3.66, "pluie_mm": 17.7, "temp_max": 32.1, "temp_min": 24.0, "vent_kmh": 9.2, "code_meteo": 81, "humidite_pct": 96, "description_fr": "Averses modérées", "pluie_proba_pct": 64}, {"date": "2026-06-12", "etp_mm": 3.75, "pluie_mm": 1.2, "temp_max": 33.2, "temp_min": 24.6, "vent_kmh": 14.3, "code_meteo": 53, "humidite_pct": 96, "description_fr": "Bruine modérée", "pluie_proba_pct": 43}, {"date": "2026-06-13", "etp_mm": 5.46, "pluie_mm": 0.6, "temp_max": 34.4, "temp_min": 24.6, "vent_kmh": 12.6, "code_meteo": 53, "humidite_pct": 93, "description_fr": "Bruine modérée", "pluie_proba_pct": 12}, {"date": "2026-06-14", "etp_mm": 4.89, "pluie_mm": 0.0, "temp_max": 32.7, "temp_min": 23.8, "vent_kmh": 14.0, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 20}, {"date": "2026-06-15", "etp_mm": 2.63, "pluie_mm": 3.5, "temp_max": 29.3, "temp_min": 25.0, "vent_kmh": 10.1, "code_meteo": 51, "humidite_pct": 95, "description_fr": "Bruine légère", "pluie_proba_pct": 55}, {"date": "2026-06-16", "etp_mm": 3.38, "pluie_mm": 0.7, "temp_max": 31.6, "temp_min": 24.7, "vent_kmh": 15.6, "code_meteo": 51, "humidite_pct": 100, "description_fr": "Bruine légère", "pluie_proba_pct": 33}]	2026-06-10 05:47:30.23127	2026-06-10 11:47:30.23127
8	5	6	12.5521	-12.1745	senegal_oriental	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 3.54, "pluie_mm": 10.3, "temp_max": 32.1, "temp_min": 24.6, "vent_kmh": 18.7, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 66}, {"date": "2026-06-11", "etp_mm": 4.19, "pluie_mm": 6.3, "temp_max": 32.4, "temp_min": 25.1, "vent_kmh": 10.2, "code_meteo": 81, "humidite_pct": 96, "description_fr": "Averses modérées", "pluie_proba_pct": 77}, {"date": "2026-06-12", "etp_mm": 3.78, "pluie_mm": 0.5, "temp_max": 32.1, "temp_min": 24.6, "vent_kmh": 15.5, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 43}, {"date": "2026-06-13", "etp_mm": 5.17, "pluie_mm": 1.0, "temp_max": 33.3, "temp_min": 24.9, "vent_kmh": 15.9, "code_meteo": 95, "humidite_pct": 91, "description_fr": "Orage", "pluie_proba_pct": 37}, {"date": "2026-06-14", "etp_mm": 3.98, "pluie_mm": 4.5, "temp_max": 32.8, "temp_min": 25.2, "vent_kmh": 9.1, "code_meteo": 95, "humidite_pct": 92, "description_fr": "Orage", "pluie_proba_pct": 56}, {"date": "2026-06-15", "etp_mm": 4.08, "pluie_mm": 0.0, "temp_max": 33.0, "temp_min": 24.8, "vent_kmh": 11.7, "code_meteo": 95, "humidite_pct": 94, "description_fr": "Orage", "pluie_proba_pct": 47}, {"date": "2026-06-16", "etp_mm": 4.19, "pluie_mm": 0.0, "temp_max": 31.5, "temp_min": 23.6, "vent_kmh": 11.2, "code_meteo": 3, "humidite_pct": 96, "description_fr": "Couvert", "pluie_proba_pct": 25}]	2026-06-10 06:14:14.404192	2026-06-10 12:14:14.404192
9	4	7	16.0179	-16.4896	vallee_fleuve	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.77, "pluie_mm": 0.0, "temp_max": 27.5, "temp_min": 22.6, "vent_kmh": 15.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 0}, {"date": "2026-06-11", "etp_mm": 4.58, "pluie_mm": 0.0, "temp_max": 27.8, "temp_min": 23.4, "vent_kmh": 16.1, "code_meteo": 3, "humidite_pct": 94, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-12", "etp_mm": 4.59, "pluie_mm": 0.0, "temp_max": 28.9, "temp_min": 23.9, "vent_kmh": 18.3, "code_meteo": 3, "humidite_pct": 93, "description_fr": "Couvert", "pluie_proba_pct": 10}, {"date": "2026-06-13", "etp_mm": 5.2, "pluie_mm": 0.0, "temp_max": 28.2, "temp_min": 23.7, "vent_kmh": 20.3, "code_meteo": 1, "humidite_pct": 88, "description_fr": "Principalement dégagé", "pluie_proba_pct": 0}, {"date": "2026-06-14", "etp_mm": 5.04, "pluie_mm": 0.0, "temp_max": 29.4, "temp_min": 23.6, "vent_kmh": 17.5, "code_meteo": 3, "humidite_pct": 89, "description_fr": "Couvert", "pluie_proba_pct": 2}, {"date": "2026-06-15", "etp_mm": 4.63, "pluie_mm": 0.0, "temp_max": 28.6, "temp_min": 24.2, "vent_kmh": 17.8, "code_meteo": 3, "humidite_pct": 90, "description_fr": "Couvert", "pluie_proba_pct": 4}, {"date": "2026-06-16", "etp_mm": 3.43, "pluie_mm": 0.0, "temp_max": 26.7, "temp_min": 24.0, "vent_kmh": 15.0, "code_meteo": 3, "humidite_pct": 92, "description_fr": "Couvert", "pluie_proba_pct": 0}]	2026-06-10 06:14:14.68837	2026-06-10 12:14:14.68837
10	6	8	13.7707	-13.6674	senegal_oriental	open_meteo	7	[{"date": "2026-06-10", "etp_mm": 4.67, "pluie_mm": 13.0, "temp_max": 34.2, "temp_min": 24.6, "vent_kmh": 21.7, "code_meteo": 95, "humidite_pct": 96, "description_fr": "Orage", "pluie_proba_pct": 57}, {"date": "2026-06-11", "etp_mm": 4.42, "pluie_mm": 1.3, "temp_max": 35.0, "temp_min": 25.6, "vent_kmh": 17.7, "code_meteo": 95, "humidite_pct": 93, "description_fr": "Orage", "pluie_proba_pct": 34}, {"date": "2026-06-12", "etp_mm": 5.35, "pluie_mm": 0.0, "temp_max": 35.4, "temp_min": 27.3, "vent_kmh": 22.7, "code_meteo": 95, "humidite_pct": 84, "description_fr": "Orage", "pluie_proba_pct": 33}, {"date": "2026-06-13", "etp_mm": 6.79, "pluie_mm": 0.0, "temp_max": 36.2, "temp_min": 25.7, "vent_kmh": 21.5, "code_meteo": 3, "humidite_pct": 79, "description_fr": "Couvert", "pluie_proba_pct": 10}, {"date": "2026-06-14", "etp_mm": 5.47, "pluie_mm": 0.0, "temp_max": 34.9, "temp_min": 26.4, "vent_kmh": 18.4, "code_meteo": 3, "humidite_pct": 83, "description_fr": "Couvert", "pluie_proba_pct": 18}, {"date": "2026-06-15", "etp_mm": 4.89, "pluie_mm": 5.5, "temp_max": 34.8, "temp_min": 25.6, "vent_kmh": 15.8, "code_meteo": 55, "humidite_pct": 87, "description_fr": "Bruine dense", "pluie_proba_pct": 24}, {"date": "2026-06-16", "etp_mm": 5.08, "pluie_mm": 1.1, "temp_max": 34.5, "temp_min": 24.3, "vent_kmh": 12.6, "code_meteo": 55, "humidite_pct": 100, "description_fr": "Bruine dense", "pluie_proba_pct": 18}]	2026-06-10 06:14:14.974393	2026-06-10 12:14:14.974393
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, is_cooperative, created_at) FROM stdin;
1	Compte de Khadim thiam	f	2026-05-31 17:07:05.547071
2	Compte de Test User	f	2026-06-09 20:10:05.745357
3	Exploitation Diallo — Casamance	f	2026-06-10 05:40:50.088466
4	Maraîchage Sarr — Vallée du Fleuve	f	2026-06-10 06:09:03.175233
5	Ferme Diallo — Kédougou	f	2026-06-10 06:09:03.176598
6	Exploitation Ndiaye — Tambacounda	f	2026-06-10 06:09:03.199343
\.


--
-- Data for Name: parcelles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parcelles (id, user_id, nom, culture, superficie_ha, superficie_m2, centre_lat, centre_lng, contour, created_at, precision_m, methode) FROM stdin;
5	1	Ma parcelle	Tomate	0.058	579.00	12.63310439142857	-12.817889054285718	[[12.633003, -12.8177447], [12.6330231, -12.8177351], [12.6330503, -12.8177362], [12.6330748, -12.8177406], [12.6330974, -12.8177502], [12.6331156, -12.817758], [12.6331376, -12.8177688], [12.6331598, -12.817784], [12.6331791, -12.817804], [12.6331943, -12.8178303], [12.6332023, -12.8178507], [12.633206, -12.817872], [12.6332115, -12.8178901], [12.6332159, -12.8179115], [12.6332158, -12.8179394], [12.6332108, -12.8179656], [12.6332034, -12.8179927], [12.6331889, -12.8180146], [12.6331706, -12.8180322], [12.6331525, -12.8180388], [12.633134, -12.8180343], [12.6331136, -12.8180256], [12.6330962, -12.8180094], [12.6330798, -12.8179965], [12.63306, -12.8179888], [12.6330418, -12.8179812], [12.6330238, -12.8179715], [12.6330071, -12.8179514], [12.6329979, -12.8179292], [12.632997, -12.8179006], [12.6330079, -12.8178773], [12.6330156, -12.8178541], [12.6330178, -12.8178323], [12.6330217, -12.8178121], [12.6330268, -12.8177931]]	2026-06-04 13:10:13.696021+00	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, subscription_id, provider, provider_ref, amount_ht, vat, amount_ttc, status, created_at) FROM stdin;
1	1	manuel	TEST-REF-001	5000	900	5900	paid	2026-05-31 17:09:27.756072
2	1	paydunya	PAYDUNYA-IPN-TOKEN-XYZ	5000	900	5900	paid	2026-06-09 15:42:52.449068
3	1	manuel	\N	5000	900	5900	pending	2026-06-09 20:09:57.1702
\.


--
-- Data for Name: re_declenchements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_declenchements (id, regle_id, org_id, parcelle_id, analyse_id, contexte_entree, resultat, score_confiance, declenche_le, acquitte, acquitte_le) FROM stdin;
\.


--
-- Data for Name: re_parametres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_parametres (id, cle, valeur, categorie, description, modifiable_admin, updated_at) FROM stdin;
\.


--
-- Data for Name: re_regles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles (id, code, categorie, sous_categorie, nom, description, zones_applicables, stades_applicables, mois_applicables, conditions, actions, gravite, priorite, confiance, plan_requis, active, source, version, created_at, updated_at) FROM stdin;
237	FER-PAP-001	fertilisation	azote	Papaye — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.72, "libelle": "Carence N papaye"}, "alertes": [{"titre": "Carence azote papaye", "niveau": "moyenne", "message": "N <60 mg/kg : croissance lente, fruits tardifs, baisse fructification."}], "recommandations": [{"dose": "150 g NPK + 100 g Urée/plant/mois", "type": "fertilisation", "titre": "NPK + Urée mensuel", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	elevee	2	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	2026-06-10 06:28:01.808606+00
154	MAL-PAP-001	maladie	viral	PRSV papaye — Vecteur puceron ou symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "ringspot"}, {"op": "contains", "field": "obs.symptomes", "value": "mosaique_papaye"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_jaunes"}, {"op": "contains", "field": "obs.symptomes", "value": "deformation_fruits"}, {"op": "contains", "field": "obs.symptomes", "value": "chlorose"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "PRSV"}, "alertes": [{"titre": "PRSV papaye détecté", "niveau": "critique", "message": "Papaya Ringspot Virus transmis par pucerons. Peut détruire 100% production."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés IMMÉDIATEMENT", "detail": "Source virale à éliminer avant spread. Ne pas replanter papaye 3 ans.", "priorite": 1, "urgence_jours": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron vecteur", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 2, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Utiliser variétés tolérantes", "detail": "Maradol, Sunrise Solo tolerantes PRSV.", "priorite": 3}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	2026-06-10 06:28:01.841254+00
199	RAV-PAP-001	ravageur	insecte	Mouche des fruits papaye — Maturation	\N	null	["maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Bactrocera dorsalis"}, "alertes": [{"titre": "Risque Mouche des fruits papaye", "niveau": "elevee", "message": "Bactrocera dorsalis : ponte fruits mûrissants. Pertes post-récolte élevées."}], "recommandations": [{"dose": "3 L/ha dilué", "type": "traitement_phyto", "titre": "Appât protéiné GF-120", "produit": "GF-120 NF", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	2026-06-10 06:28:01.844313+00
332	SOL-PAP-001	fertilisation	amendement	Papaye — Sol acide pH critique	pH < 5.5 : toxicité aluminium et manganèse, carence calcium-magnésium. Papaye très sensible acidité.	\N	\N	\N	{"op": "lte", "field": "sol.pH", "value": 5.5}	{"risque": {"score": 0.82, "libelle": "Acidité sol critique papaye"}, "alertes": [{"titre": "Sol trop acide pour papaye", "niveau": "elevee", "message": "pH 5.3 < seuil optimal 5.5-7.0. Toxicité Al/Mn, carence Ca-Mg, croissance ralentie."}], "recommandations": [{"dose": "1.5 t/ha", "type": "amendement", "titre": "Chaulage correctif calcaire dolomitique", "produit": "Calcaire dolomitique 85% CaCO3", "priorite": 1, "urgence_jours": 14}]}	elevee	2	0.85	gratuit	t	agroscan_pilote	1.0	2026-06-10 06:29:17.152899+00	2026-06-10 06:29:17.152899+00
333	SOL-PAP-002	fertilisation	matiere_organique	Papaye — Carence matière organique	MO < 2% : rétention eau insuffisante, activité biologique faible, nutrition perturbée.	\N	\N	\N	{"op": "lte", "field": "sol.matiere_organique", "value": 2.0}	{"risque": {"score": 0.72, "libelle": "Carence MO sol papaye"}, "alertes": [{"titre": "Carence matière organique", "niveau": "elevee", "message": "MO 1.8% < seuil 2.0%. Rétention eau et nutrition minérale insuffisantes pour papaye."}], "recommandations": [{"dose": "15-20 t/ha compost + 5 t/ha fumier", "type": "amendement_organique", "titre": "Apport compost mature + fumier", "produit": "Compost mature 6 mois + fumier bovin", "priorite": 2, "urgence_jours": 30}]}	elevee	3	0.72	gratuit	t	agroscan_pilote	1.0	2026-06-10 06:29:17.160933+00	2026-06-10 06:29:17.160933+00
327	REN-PAP-001	rendement	risque_rendement	Papaye — PRSV = perte totale production	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "ringspot"}, {"op": "contains", "field": "obs.symptomes", "value": "mosaique_papaye"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_jaunes"}, {"op": "contains", "field": "obs.symptomes", "value": "deformation_fruits"}], "operator": "OR"}	{"risque": {"score": 0.98, "libelle": "Perte totale production papaye"}, "alertes": [{"titre": "PRSV papaye — Perte production totale", "niveau": "critique", "message": "PRSV actif : production nulle sur plants infectés. Contamination rapide voisins."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher TOUS les plants infectés", "detail": "Quarantaine parcelle. Informer producteurs voisins.", "priorite": 1, "urgence_jours": 1}, {"type": "planification", "titre": "Replanter variétés tolérantes PRSV", "detail": "Maradol rouge, Sunrise Solo si disponibles.", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	2026-06-10 06:29:17.165403+00
209	FER-SOR-001	fertilisation	azote	Sorgho — Carence N levée-tallage	\N	null	["levee", "tallage"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.82, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote sorgho", "niveau": "elevee", "message": "N <60 mg/kg : jaunissement feuilles basses, tallage réduit, perte rendement."}], "recommandations": [{"dose": "50 kg N/ha en 2 fractions", "type": "fertilisation", "titre": "Urée fractionnée", "produit": "Urée 46%", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
210	FER-SOR-002	fertilisation	phosphore	Sorgho — Carence P sol acide	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 12}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore sorgho", "niveau": "elevee", "message": "P <12 mg/kg : coloration pourpre feuilles, racines peu développées."}], "recommandations": [{"dose": "40 kg P₂O₅/ha au semis", "type": "fertilisation", "titre": "TSP au semis", "produit": "TSP 46%", "priorite": 1}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
211	FER-MAI-001	fertilisation	azote	Maïs — Carence N critique levée	\N	null	["levee", "croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.9, "libelle": "Carence azote maïs"}, "alertes": [{"titre": "Carence azote maïs", "niveau": "elevee", "message": "N <80 mg/kg : Symptôme V en feuille. Pertes 30-60% si non corrigé."}], "recommandations": [{"dose": "200 kg NPK/ha + 100 kg Urée/ha fractionné", "type": "fertilisation", "titre": "Programme NPK maïs", "detail": "NPK au semis + Urée ⅓ au tallage + ⅔ à la montaison.", "produit": "NPK 14-18-18 + Urée 46%", "priorite": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
212	FER-MAI-002	fertilisation	potassium	Maïs — Carence K sol sableux épuisé	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 60}	{"risque": {"score": 0.82, "libelle": "Carence K maïs"}, "alertes": [{"titre": "Carence potassium maïs", "niveau": "elevee", "message": "K <60 mg/kg : brûlures bordures feuilles, verse accrue, grains mal formés."}], "recommandations": [{"dose": "50-80 kg K₂O/ha", "type": "fertilisation", "titre": "KCl au semis", "produit": "KCl 60%", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
213	FER-MAI-003	fertilisation	pH	Maïs — pH bas — toxicité aluminium	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.5}	{"risque": {"score": 0.88, "libelle": "Acidité toxique Al"}, "alertes": [{"titre": "Sol acide maïs — toxicité Al", "niveau": "elevee", "message": "pH <5.5 : Al³⁺ toxique → racines courtes, nanisme. Chaulage urgence."}], "recommandations": [{"dose": "2-3 t/ha", "type": "amendement_sol", "titre": "Chaulage + attendre 6 semaines", "produit": "Chaux vive ou calcaire broyé", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
214	FER-ARA-001	fertilisation	phosphore	Arachide — Carence P nodulation	\N	null	null	null	{"op": "lte", "field": "sol.phosphore", "value": 10}	{"risque": {"score": 0.85, "libelle": "Carence P + nodulation faible"}, "alertes": [{"titre": "Carence phosphore arachide", "niveau": "elevee", "message": "P <10 mg/kg : nodulation rhizobium insuffisante + fixation N2 limitée."}], "recommandations": [{"dose": "30 kg P₂O₅/ha + inoculant 5 g/kg semences", "type": "fertilisation", "titre": "TSP au semis + inoculant Rhizobium", "produit": "TSP 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
215	FER-ARA-002	fertilisation	calcium	Arachide — Carence calcium — pH bas gousses vides	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.8}, {"op": "lte", "field": "sol.conductivite", "value": 100}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Carence calcium gousses"}, "alertes": [{"titre": "Carence calcium arachide — gousses vides", "niveau": "elevee", "message": "pH <5.8 + Ca faible : syndrome 'pops' (gousses vides). Gypse agricole indispensable."}], "recommandations": [{"dose": "500 kg/ha à la floraison", "type": "fertilisation", "titre": "Gypse agricole à la floraison", "detail": "Épandre au sol autour des plants en floraison. Critique pour remplissage gousses.", "produit": "Gypse agricole (CaSO₄)", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
216	FER-NIE-001	fertilisation	phosphore	Niébé — Carence P — nodulation faible	\N	null	null	null	{"op": "lte", "field": "sol.phosphore", "value": 8}	{"risque": {"score": 0.82, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore niébé", "niveau": "elevee", "message": "P <8 mg/kg : nodulation Rhizobium faible, fixation N2 réduite."}], "recommandations": [{"dose": "20 kg P₂O₅/ha + inoculant Bradyrhizobium", "type": "fertilisation", "titre": "TSP + inoculant semences", "produit": "TSP 46%", "priorite": 1}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
217	FER-NIE-002	fertilisation	azote	Niébé — Faible azote starter à levée	\N	null	["levee"]	null	{"op": "lte", "field": "sol.azote", "value": 40}	{"risque": {"score": 0.65, "libelle": "Carence N starter"}, "alertes": [{"titre": "Faible N starter niébé", "niveau": "moyenne", "message": "N <40 mg/kg : dose starter avant établissement nodules."}], "recommandations": [{"dose": "22-32 kg/ha", "type": "fertilisation", "titre": "Urée starter 10-15 kg N/ha au semis uniquement", "detail": "Ne pas dépasser 15 kg N/ha : excès azote inhibe nodulation.", "produit": "Urée 46%", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
218	FER-SES-001	fertilisation	azote	Sésame — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.72, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote sésame", "niveau": "moyenne", "message": "N <60 mg/kg : tiges fines, feuilles pâles. Rendement <500 kg/ha."}], "recommandations": [{"dose": "50 kg/ha au semis + 30 kg Urée à 21 jours", "type": "fertilisation", "titre": "Urée + DAP au semis + 21 jours", "produit": "DAP (18-46-0)", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
79	MAL-RIZ-001	maladie	fongique	Risque Pyriculariose — Conditions météo favorables	\N	null	["tallage", "montaison", "epiaison"]	[6, 7, 8, 9, 10]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 90}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pyriculariose"}, "alertes": [{"titre": "Risque Pyriculariose élevé", "niveau": "elevee", "message": "Température 24-28°C + HR >90% + pluie : conditions optimales pour Magnaporthe oryzae."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Traitement fongicide préventif Pyriculariose", "produit": "Tricyclazole 75WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 21}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
80	MAL-RIZ-002	maladie	fongique	Pyriculariose — Symptômes observés sur feuilles/cou	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "pyriculariose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_oeil_losange"}, {"op": "contains", "field": "obs.symptomes", "value": "cou_casse"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Pyriculariose"}, "alertes": [{"titre": "Pyriculariose confirmée", "niveau": "critique", "message": "Symptômes actifs détectés. Intervention curative urgente requise."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Traitement curatif Pyriculariose", "produit": "Isoprothiolane 40EC", "priorite": 1, "urgence_jours": 1, "delai_carence_jours": 28}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
81	MAL-RIZ-003	maladie	bacterien	Risque Bactériose — Chaleur + humidité post-pluie	\N	null	["tallage", "montaison", "epiaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Bactériose vasculaire"}, "alertes": [{"titre": "Risque Bactériose du riz", "niveau": "elevee", "message": "Chaleur >28°C + forte humidité + pluies récentes favorisent Xanthomonas oryzae."}], "recommandations": [{"type": "mesure_culturale", "titre": "Réduire azote + éviter blessures mécaniques", "detail": "Éviter excès N. Drainer si possible. Surveiller tallage.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
82	MAL-RIZ-004	maladie	bacterien	Bactériose riz — Symptômes flétrissement	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_bords_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Xanthomonas oryzae"}, "alertes": [{"titre": "Bactériose riz confirmée", "niveau": "critique", "message": "Flétrissement bactérien détecté. Aucun traitement curatif — mesures culturales urgentes."}], "recommandations": [{"type": "mesure_culturale", "titre": "Éliminer plants malades", "detail": "Arracher et bruler plants atteints. Ne pas irriguer par submersion totale.", "priorite": 1}, {"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif sur parcelles voisines", "produit": "Bouillie bordelaise", "priorite": 2, "urgence_jours": 2}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
83	MAL-RIZ-005	maladie	fongique	Risque Helminthosporiose — Humidité prolongée	\N	null	["tallage", "montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose", "niveau": "moyenne", "message": "Humidité élevée prolongée favorise Bipolaris oryzae. Surveiller taches brunes."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide préventif Helminthosporiose", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
84	MAL-RIZ-006	maladie	fongique	Rhizoctoniose — Sol humide + températures chaudes	\N	null	["tallage", "montaison"]	[7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "sol.humidite", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Rhizoctoniose"}, "alertes": [{"titre": "Risque Rhizoctoniose de la gaine", "niveau": "elevee", "message": "Conditions chaudes et humides favorisent Rhizoctonia solani sur gaines."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Fongicide systémique gaine", "produit": "Validamycine 3SL", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
85	MAL-RIZ-007	maladie	fongique	Charbon des balles — Risque floraison humide	\N	null	["epiaison", "floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "meteo.pluie_24h", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Charbon des balles"}, "alertes": [{"titre": "Risque Charbon des balles", "niveau": "moyenne", "message": "Floraison sous pluie et humidité élevée : risque Tilletia barclayana."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller épis à maturité", "detail": "Inspecter coloration épis. Traitement semences saison suivante.", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
86	MAL-MIL-001	maladie	fongique	Risque Mildiou du mil — Levée + pluies	\N	null	["levee", "tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Mildiou du mil"}, "alertes": [{"titre": "Risque Mildiou du mil", "niveau": "elevee", "message": "Pluies fréquentes + humidité >85% : risque élevé Sclerospora graminicola."}], "recommandations": [{"dose": "6 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Métalaxyl", "produit": "Métalaxyl 35FS", "priorite": 1, "urgence_jours": 0}, {"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Pulvérisation Métalaxyl", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 5}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
110	MAL-SES-004	maladie	fongique	Cercosporiose sésame — Humidité fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose sésame", "niveau": "moyenne", "message": "Cercospora sesami favorisé en humidité soutenue à fructification."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
87	MAL-MIL-002	maladie	fongique	Mildiou mil — Symptômes chlorose/sporulation	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mildiou"}, {"op": "contains", "field": "obs.symptomes", "value": "sporulation_blanche"}, {"op": "contains", "field": "obs.symptomes", "value": "chlorose_mildiou"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Mildiou du mil"}, "alertes": [{"titre": "Mildiou mil confirmé", "niveau": "critique", "message": "Sporulation active détectée. Arracher plants malades immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés", "detail": "Éliminer et enfouir ou bruler. Ne pas composter.", "priorite": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Traitement plants sains voisins", "produit": "Métalaxyl + Mancozèbe", "priorite": 2, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
88	MAL-MIL-003	maladie	fongique	Risque Ergot mil — Floraison humide	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Ergot du mil"}, "alertes": [{"titre": "Risque Ergot du mil", "niveau": "moyenne", "message": "Floraison sous pluie : Claviceps fusiformis peut contaminer fleurs ouvertes."}], "recommandations": [{"type": "surveillance", "titre": "Inspecter épis floraison", "detail": "Rechercher exsudat mielleux. Détruire épis ergotés.", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
89	MAL-MIL-004	maladie	fongique	Risque Charbon mil — Floraison	\N	null	["floraison", "maturation"]	[8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 75}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Charbon du mil"}, "alertes": [{"titre": "Risque Charbon du mil", "niveau": "moyenne", "message": "Tokilosporium penicillariae actif en floraison chaude et humide."}], "recommandations": [{"dose": "3 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Thirame saison suivante", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
90	MAL-MIL-005	maladie	fongique	Rouille mil — Surveillance montaison-maturité	\N	null	["montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 28}], "operator": "AND"}	{"risque": {"score": 0.45, "libelle": "Rouille du mil"}, "alertes": [{"titre": "Risque faible Rouille du mil", "niveau": "faible", "message": "Conditions légèrement favorables à Puccinia penniseti. Surveillance recommandée."}], "recommandations": [{"type": "surveillance", "titre": "Inspecter feuilles pour pustules orangées", "priorite": 1}]}	faible	3	0.55	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
91	MAL-SOR-001	maladie	fongique	Risque Anthracnose sorgho — Chaleur humide	\N	null	["tallage", "montaison", "floraison", "maturation"]	[7, 8, 9, 10]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose"}, "alertes": [{"titre": "Risque Anthracnose du sorgho", "niveau": "elevee", "message": "Colletotrichum sublineolum actif : chaleur 25-35°C + humidité + pluies récentes."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose sorgho", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
92	MAL-SOR-002	maladie	fongique	Anthracnose sorgho — Symptômes taches foliaires	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "anthracnose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_rouges_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Anthracnose"}, "alertes": [{"titre": "Anthracnose sorgho confirmée", "niveau": "elevee", "message": "Taches caractéristiques détectées. Traitement curatif rapide."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Traitement curatif Carbendazime", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
93	MAL-SOR-003	maladie	fongique	Risque Mildiou sorgho — Levée humide	\N	null	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Mildiou du sorgho"}, "alertes": [{"titre": "Risque Mildiou du sorgho", "niveau": "moyenne", "message": "Conditions humides à levée : risque Peronosclerospora sorghi."}], "recommandations": [{"dose": "6 g/kg semences", "type": "traitement_semences", "titre": "Traitement semences Métalaxyl", "produit": "Métalaxyl 35FS", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
94	MAL-SOR-004	maladie	fongique	Helminthosporiose sorgho — Chaleur humide montaison	\N	null	["montaison", "floraison", "maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose sorgho", "niveau": "moyenne", "message": "Exserohilum turcicum favorisé par chaleur + humidité. Surveiller feuilles inférieures."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
95	MAL-MAI-001	maladie	fongique	Risque Fusariose épi maïs — Humidité floraison	\N	null	["floraison", "remplissage_grains"]	[8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fusariose + mycotoxines"}, "alertes": [{"titre": "Risque Fusariose épi maïs", "niveau": "elevee", "message": "Fusarium moniliforme / verticillioides : conditions humides à floraison = risque élevé de mycotoxines."}], "recommandations": [{"dose": "0,75 L/ha", "type": "traitement_phyto", "titre": "Fongicide soie/épi", "produit": "Tebuconazole 25EC", "priorite": 1, "urgence_jours": 5}, {"type": "mesure_culturale", "titre": "Récolte rapide à maturité", "detail": "Éviter séchage lent au champ. Stocker <14% humidité.", "priorite": 2}]}	elevee	9	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
96	MAL-MAI-002	maladie	viral	Striure maïs — Détection précoce levée à V6	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "striure"}, {"op": "contains", "field": "obs.symptomes", "value": "stries_jaunes_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Striure virale"}, "alertes": [{"titre": "Striure du maïs détectée", "niveau": "elevee", "message": "MSRV transmis par cicadelles. Aucun traitement curatif disponible."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants infectés", "detail": "Éliminer immédiatement pour réduire source virale.", "priorite": 1}, {"dose": "4 g/kg", "type": "traitement_phyto", "titre": "Contrôle vecteur cicadelles", "produit": "Imidaclopride 70WS (semences)", "priorite": 2, "urgence_jours": 0}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
97	MAL-MAI-003	maladie	fongique	Helminthosporiose maïs — Risque chaleur humide	\N	null	["floraison", "remplissage_grains"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 27}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Helminthosporiose"}, "alertes": [{"titre": "Risque Helminthosporiose maïs", "niveau": "moyenne", "message": "Exserohilum turcicum actif en conditions fraîches-humides."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Fongicide foliaire préventif", "produit": "Propiconazole 25EC", "priorite": 1, "urgence_jours": 7}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
98	MAL-MAI-004	maladie	fongique	Charbon commun maïs — Risque blessures floraison	\N	null	["floraison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 34}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.58, "libelle": "Charbon commun"}, "alertes": [{"titre": "Risque Charbon commun maïs", "niveau": "moyenne", "message": "Ustilago maydis favorisé par chaleur et écarts de temp. Éviter blessures mécaniques."}], "recommandations": [{"type": "mesure_culturale", "titre": "Enlever galles avant sporulation", "detail": "Couper et enfouir les galles noires avant qu'elles n'éclatent.", "priorite": 1}]}	moyenne	5	0.6	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
99	MAL-ARA-001	maladie	fongique	Risque Cercosporiose arachide — Chaleur humide végétation	\N	null	["croissance_vegetative", "floraison", "fructification"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose arachide", "niveau": "elevee", "message": "Cercospora arachidicola favorisé. Risque de 30-50% perte si non traité."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Cercosporiose arachide", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5, "delai_carence_jours": 14}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
100	MAL-ARA-002	maladie	fongique	Cercosporiose arachide — Taches foliaires observées	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "cercosporiose"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_cercospora"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Cercosporiose arachide confirmée", "niveau": "elevee", "message": "Taches confirmées. Traiter immédiatement + programmer 2 applications supplémentaires."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Programme 3 applications Mancozèbe", "detail": "J0 + J14 + J28. Alterner avec Chlorothalonil.", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
101	MAL-ARA-003	maladie	viral	Rosette arachide — Vecteur puceron + symptômes	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "rosette"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Rosette virale"}, "alertes": [{"titre": "Risque Rosette arachide", "niveau": "elevee", "message": "Virus GRAV transmis par Aphis craccivora. Contrôle vecteur urgent."}], "recommandations": [{"dose": "4 g/kg semences", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Imidaclopride 70WS", "priorite": 1, "urgence_jours": 0}, {"type": "mesure_culturale", "titre": "Semis précoce + variétés tolérantes", "detail": "Semis avant pic puceron. Variétés RMP 12 ou ICG 12991.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
134	MAL-OIG-003	maladie	fongique	Fonte de semis oignon — Pépinière humide	\N	null	["pepiniere", "levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis oignon", "niveau": "moyenne", "message": "Sol engorgé en pépinière : Pythium/Fusarium peuvent décimer plantules."}], "recommandations": [{"dose": "1 g/L eau arrosage", "type": "traitement_phyto", "titre": "Arrosage Métalaxyl pépinière", "produit": "Métalaxyl 25WP", "priorite": 1, "urgence_jours": 3}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
102	MAL-ARA-004	maladie	fongique	Pourriture gousses arachide — Sol humide fructification	\N	null	["fructification", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 75}, {"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Pourriture + aflatoxine"}, "alertes": [{"titre": "Risque Pourriture des gousses", "niveau": "elevee", "message": "Sol saturé en fructification : Aspergillus/Pythium peuvent coloniser gousses."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte précoce si pluies continues", "detail": "Ne pas laisser gousses matures dans sol détrempé >2 semaines.", "priorite": 1}, {"type": "mesure_post_recolte", "titre": "Séchage rapide <12% humidité", "detail": "Sécher 3-5 jours au soleil avant stockage pour prévenir aflatoxines.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
103	MAL-NIE-001	maladie	viral	Mosaïque niébé — Vecteur puceron détecté	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Mosaïque virale"}, "alertes": [{"titre": "Risque Mosaïque du niébé", "niveau": "elevee", "message": "CABMV transmis par pucerons. Pas de traitement curatif. Contrôle vecteur immédiat."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Arracher plants malades", "priorite": 2, "urgence_jours": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
104	MAL-NIE-002	maladie	fongique	Anthracnose niébé — Humidité fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose"}, "alertes": [{"titre": "Risque Anthracnose du niébé", "niveau": "moyenne", "message": "Colletotrichum lindemuthianum favorisé à fructification humide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose niébé", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
105	MAL-NIE-003	maladie	fongique	Fonte de semis niébé — Sol humide à levée	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis niébé", "niveau": "moyenne", "message": "Sol détrempé à levée : Pythium/Rhizoctonia peuvent provoquer fonte."}], "recommandations": [{"dose": "3 g/kg", "type": "traitement_semences", "titre": "Traitement semences Thirame", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
106	MAL-NIE-004	maladie	fongique	Cercosporiose niébé — Humidité floraison	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Cercosporiose"}, "alertes": [{"titre": "Risque Cercosporiose niébé", "niveau": "moyenne", "message": "Cercospora canescens favorisé en conditions humides à floraison."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil préventif", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
107	MAL-SES-001	maladie	fongique	Flétrissement fusarien sésame — Sol humide chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Flétrissement fusarien sésame", "niveau": "elevee", "message": "Fusarium oxysporum f.sp. sesami actif : sol acide et humide >28°C."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage si pH <6", "detail": "Apporter chaux agricole pour relever pH >6.5.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation 3 ans minimum", "detail": "Éviter retour sésame sur même parcelle <3 ans.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
108	MAL-SES-002	maladie	fongique	Flétrissement fusarien sésame — Symptômes observés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_fusarien"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_base"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Fusariose"}, "alertes": [{"titre": "Fusariose sésame confirmée", "niveau": "critique", "message": "Flétrissement vasculaire irréversible. Aucun traitement curatif."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire plants infectés", "priorite": 1, "urgence_jours": 1}]}	critique	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
109	MAL-SES-003	maladie	fongique	Phytophtora sésame — Excès eau sol lourd	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Phytophtora"}, "alertes": [{"titre": "Risque Phytophtora sésame", "niveau": "elevee", "message": "Engorgement sol : Phytophthora parasitica peut causer pourriture collet."}], "recommandations": [{"type": "mesure_culturale", "titre": "Drainer immédiatement", "priorite": 1, "urgence_jours": 1}, {"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Métalaxyl en préventif", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 3}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
111	MAL-MAN-001	maladie	viral	Mosaïque africaine manioc — Détection symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_manioc"}, {"op": "contains", "field": "obs.symptomes", "value": "deformation_feuilles"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Mosaïque africaine (CMD)"}, "alertes": [{"titre": "Mosaïque africaine manioc détectée", "niveau": "critique", "message": "CMD transmise par Bemisia tabaci. Variétés sensibles perdent 20-95% rendement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Utiliser boutures saines certifiées", "detail": "Ne jamais replanter boutures issues de plants malades.", "priorite": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Contrôle mouche blanche", "produit": "Imidaclopride 200SL", "priorite": 2, "urgence_jours": 3}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
112	MAL-MAN-002	maladie	bacterien	Bactériose vasculaire manioc — Saison humide	\N	null	["croissance_vegetative"]	[6, 7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 34}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Bactériose vasculaire"}, "alertes": [{"titre": "Risque Bactériose manioc", "niveau": "elevee", "message": "Saison humide : Xanthomonas axonopodis pv. manihotis actif. Surveiller chancres tiges."}], "recommandations": [{"type": "mesure_culturale", "titre": "Désinfecter outils de coupe", "detail": "Hypochlorite 0,5% entre chaque plant. Ne pas couper par temps de pluie.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Boutures saines + variétés résistantes", "detail": "TMS 30572, TMS 92/0326 tolérantes CBB.", "priorite": 2}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
113	MAL-MAN-003	maladie	fongique	Pourriture brune racines manioc — Sol lourd engorgé	\N	null	["tuberisation", "maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pourriture racinaire"}, "alertes": [{"titre": "Risque Pourriture brune racines manioc", "niveau": "elevee", "message": "Sol saturé : Phytophthora drechsleri peut coloniser racines."}], "recommandations": [{"type": "mesure_culturale", "titre": "Billonner + drainer urgence", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Récolte anticipée si >12 mois", "detail": "Manioc >12 mois en sol hydromorphe : récolter avant pourriture totale.", "priorite": 2}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
114	MAL-MAN-004	maladie	fongique	Taches brunes foliaires manioc — Surveillance	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_7j", "value": 35}], "operator": "AND"}	{"risque": {"score": 0.45, "libelle": "Taches brunes foliaires"}, "alertes": [{"titre": "Risque Taches brunes foliaires manioc", "niveau": "faible", "message": "Cercospora henningsii favorisé par humidité. Impact limité si plante vigoureuse."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller défoliation", "detail": "Traitement justifié si >30% feuillage atteint.", "priorite": 1}]}	faible	3	0.55	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
115	MAL-TOM-001	maladie	fongique	Risque Mildiou tomate — Nuits fraîches humides	\N	["niayes"]	["croissance_vegetative", "floraison", "fructification"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Mildiou tomate"}, "alertes": [{"titre": "Risque Mildiou tomate élevé", "niveau": "elevee", "message": "Phytophthora infestans : T°<22°C + HR>88% + rosée. Traitement préventif obligatoire."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Fongicide systémique Mildiou tomate", "produit": "Métalaxyl-M + Mancozèbe (Ridomil Gold)", "priorite": 1, "urgence_jours": 2, "delai_carence_jours": 14}]}	elevee	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
116	MAL-TOM-002	maladie	fongique	Mildiou tomate — Symptômes actifs	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mildiou"}, {"op": "contains", "field": "obs.symptomes", "value": "taches_huileuses_feuilles"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Mildiou tomate"}, "alertes": [{"titre": "Mildiou tomate confirmé", "niveau": "critique", "message": "Mildiou actif détecté. Intervention curative d'urgence."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe curatif", "produit": "Cymoxanil 4% + Mancozèbe 40% (Curzate-M)", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
117	MAL-TOM-003	maladie	fongique	Alternariose tomate — Chaleur humide floraison-récolte	\N	null	["floraison", "fructification", "maturation"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Alternariose"}, "alertes": [{"titre": "Risque Alternariose tomate", "niveau": "moyenne", "message": "Alternaria solani favorisé en chaleur humide. Surveiller feuilles basses."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil + effeuillage bas", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
143	MAL-PAS-003	maladie	fongique	Anthracnose cucurbitacées — Pastèque fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose pastèque", "niveau": "moyenne", "message": "Taches noires sur fruits matures sous pluie. Récolte précoce si possible."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Chlorothalonil sur fruits", "produit": "Chlorothalonil 75WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
118	MAL-TOM-004	maladie	bacterien	Flétrissement bactérien tomate — Sol chaud blessures	\N	null	["croissance_vegetative", "floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "sol.temperature", "value": 25}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Ralstonia solanacearum"}, "alertes": [{"titre": "Risque Flétrissement bactérien tomate", "niveau": "elevee", "message": "Ralstonia solanacearum race 1 : sol chaud et humide optimal. Inspecter collets."}], "recommandations": [{"type": "mesure_culturale", "titre": "Test flétrissement rapide", "detail": "Couper tige : exsudat laiteux = Ralstonia confirmé. Arracher immédiatement.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation 3 ans + pH sol >6.5", "detail": "Solanacées à risque : tomate, piment, aubergine, pomme de terre.", "priorite": 2}]}	elevee	9	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
119	MAL-TOM-005	maladie	bacterien	Flétrissement bactérien tomate — Symptômes confirmés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "exsudat_laiteux"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Ralstonia solanacearum"}, "alertes": [{"titre": "Flétrissement bactérien tomate confirmé", "niveau": "critique", "message": "Ralstonia confirmé. Aucun traitement curatif. Quarantaine parcelle."}], "recommandations": [{"type": "mesure_culturale", "titre": "ARRACHER tous plants malades — urgence", "detail": "Enfouir profondément ou bruler. Ne pas composter.", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Jachère 2 ans + solarisation sol", "detail": "Couvrir sol film plastique transparent 6 semaines saison sèche.", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
120	MAL-TOM-006	maladie	viral	TYLCV tomate — Vecteur aleurode détecté	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "tylcv"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_cuillere"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "TYLCV"}, "alertes": [{"titre": "Risque TYLCV tomate", "niveau": "elevee", "message": "Bemisia tabaci vecteur TYLCV. Contrôle urgent vecteur + filets anti-insectes."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide systémique aleurode", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Filets insect-proof pépinière", "detail": "Mailles 50 mesh. Utiliser variétés Ty1/Ty3 résistantes.", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
121	MAL-TOM-007	maladie	fongique	Fusariose vasculaire tomate — Sol acide chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose vasculaire tomate", "niveau": "elevee", "message": "pH <5.5 + chaleur : conditions optimales Fusarium oxysporum f.sp. lycopersici."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage urgence", "detail": "Porter pH à 6.5-7. Réduire risque Fusarium de 60%.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Variétés résistantes (race 1+2)", "detail": "Chercher mention 'F' (Fusarium) sur sachet semences.", "priorite": 2}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
122	MAL-PIM-001	maladie	fongique	Anthracnose piment — Humidité fructification	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose piment", "niveau": "elevee", "message": "Colletotrichum capsici actif sur fruits humides. Récolte rapide + traitement."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime sur fruits", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
123	MAL-PIM-002	maladie	bacterien	Flétrissement bactérien piment — Sol chaud	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "fletrissement_piment"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Ralstonia"}, "alertes": [{"titre": "Flétrissement bactérien piment confirmé", "niveau": "critique", "message": "Ralstonia solanacearum. Aucun traitement curatif. Arracher immédiatement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire — urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
124	MAL-PIM-003	maladie	fongique	Phytophthora piment — Excès eau collet	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Phytophthora capsici"}, "alertes": [{"titre": "Risque Phytophthora du collet piment", "niveau": "elevee", "message": "Sol engorgé : Phytophthora capsici cause pourriture collet et racines."}], "recommandations": [{"type": "mesure_culturale", "titre": "Drainage immédiat", "priorite": 1, "urgence_jours": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fosetyl-Al en préventif", "produit": "Fosetyl-Al 80WP", "priorite": 2, "urgence_jours": 3}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
125	MAL-PIM-004	maladie	viral	Mosaïque piment — Vecteur puceron ou symptômes	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_piment"}, {"op": "contains", "field": "obs.ravageurs", "value": "puceron"}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Virus mosaïque"}, "alertes": [{"titre": "Risque Mosaïque piment", "niveau": "moyenne", "message": "CMV/PVY transmis par pucerons. Contrôle vecteur + plants malades à éliminer."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Insecticide anti-puceron", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
126	MAL-AUB-001	maladie	fongique	Verticilliose aubergine — Sol contaminé chaud	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "between", "field": "sol.temperature", "value": 20, "value2": 25}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Verticilliose"}, "alertes": [{"titre": "Risque Verticilliose aubergine", "niveau": "elevee", "message": "Verticillium dahliae actif en sol frais-humide 20-25°C. Surveiller flétrissement diurne."}], "recommandations": [{"type": "mesure_culturale", "titre": "Solarisation sol avant plantation", "detail": "Film plastique transparent 6 semaines. Réduit Verticillium >80%.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Greffe sur porte-greffe résistant", "detail": "Solanum torvum ou S. sisymbriifolium comme porte-greffe.", "priorite": 2}]}	elevee	7	0.72	premium	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
127	MAL-AUB-002	maladie	bacterien	Flétrissement bactérien aubergine — Chaleur sol humide	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fletrissement_bacterien"}, {"op": "contains", "field": "obs.symptomes", "value": "fletrissement_aubergine"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Ralstonia"}, "alertes": [{"titre": "Flétrissement bactérien aubergine", "niveau": "critique", "message": "Ralstonia confirmé. Quarantaine parcelle. Élimination immédiate."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher et détruire — urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
128	MAL-AUB-003	maladie	fongique	Alternariose aubergine — Chaleur humide fruits	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 33}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Alternariose"}, "alertes": [{"titre": "Risque Alternariose aubergine", "niveau": "moyenne", "message": "Alternaria alternata favorisé. Surveiller taches nécrotiques fruits."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
129	MAL-CHO-001	maladie	bacterien	Pourriture noire Brassicacées — Chaleur humide	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Pourriture noire"}, "alertes": [{"titre": "Risque Pourriture noire chou", "niveau": "elevee", "message": "Xanthomonas campestris pv. campestris : chaleur-humidité-blessures."}], "recommandations": [{"type": "mesure_culturale", "titre": "Désinfecter outils", "priorite": 1, "urgence_jours": 1}, {"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif", "produit": "Oxychlorure de cuivre 50WP", "priorite": 2, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
130	MAL-CHO-002	maladie	fongique	Alternariose Brassicacées — Conditions chaudes humides	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Alternariose Brassicacées"}, "alertes": [{"titre": "Risque Alternariose chou", "niveau": "elevee", "message": "Alternaria brassicae : taches noires sur feuilles et pommes."}], "recommandations": [{"dose": "1,5 kg/ha", "type": "traitement_phyto", "titre": "Iprodione ou Tebuconazole", "produit": "Iprodione 50WP", "priorite": 1, "urgence_jours": 5}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
131	MAL-CHO-003	maladie	parasitaire	Hernie du chou — Sol acide humide repiquage	\N	null	["repiquage", "croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.5}, {"op": "gte", "field": "sol.humidite", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Hernie du chou"}, "alertes": [{"titre": "Risque Hernie du chou", "niveau": "elevee", "message": "Plasmodiophora brassicae : pH <6.5 + humidité élevée = risque critique."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage urgence avant plantation", "detail": "Porter pH >7.0 avec chaux vive. Réduire risque >70%.", "priorite": 1}, {"dose": "Trempage racines 0,5 L/100L eau", "type": "traitement_phyto", "titre": "Cyazofamide en trempage racines", "produit": "Cyazofamide 10SC", "priorite": 2, "urgence_jours": 0}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
132	MAL-OIG-001	maladie	fongique	Mildiou oignon — Nuits fraîches humides	\N	null	["croissance_vegetative", "bulbaison"]	[12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 12, "value2": 20}, {"op": "gte", "field": "meteo.humidite_rel", "value": 90}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mildiou oignon"}, "alertes": [{"titre": "Risque Mildiou oignon", "niveau": "elevee", "message": "Peronospora destructor : fraîcheur + HR>90% = sporulation nocturne active."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe préventif", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
133	MAL-OIG-002	maladie	fongique	Botrytis oignon — Humidité maturité	\N	null	["maturation", "recolte"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 25}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pourriture du col"}, "alertes": [{"titre": "Risque Botrytis oignon", "niveau": "elevee", "message": "Botrytis allii actif. Récolter par temps sec. Séchage urgence."}], "recommandations": [{"type": "mesure_culturale", "titre": "Récolte immédiate si pluies prolongées", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_post_recolte", "titre": "Séchage 2-3 semaines avant stockage", "priorite": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
135	MAL-GOM-001	maladie	viral	Mosaïque jaune gombo — Vecteur mouche blanche	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_jaune"}, {"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Mosaïque YVMV"}, "alertes": [{"titre": "Risque Mosaïque jaune gombo", "niveau": "elevee", "message": "YVMV transmis par Bemisia tabaci. Contrôle vecteur urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride anti-aleurode", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 2}, {"type": "mesure_culturale", "titre": "Arracher plants jaunes", "detail": "Source virale à éliminer immédiatement.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
136	MAL-GOM-002	maladie	fongique	Fusariose gombo — Sol acide humide	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.0}, {"op": "gte", "field": "sol.humidite", "value": 75}, {"op": "gte", "field": "meteo.temp_air", "value": 28}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose gombo", "niveau": "elevee", "message": "Fusarium solani actif en sol acide chaud saturé."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage + drainage", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Rotation avec graminées 2 ans", "priorite": 2}]}	elevee	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
137	MAL-GOM-003	maladie	fongique	Fonte de semis gombo — Levée sol humide	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fonte des semis"}, "alertes": [{"titre": "Risque Fonte des semis gombo", "niveau": "moyenne", "message": "Sol saturé à levée : Rhizoctonia/Pythium actifs."}], "recommandations": [{"dose": "3 g/kg", "type": "traitement_semences", "titre": "Thirame sur semences", "produit": "Thirame 80WP", "priorite": 1}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
138	MAL-CON-001	maladie	fongique	Mildiou cucurbitacées — Concombre fraîcheur humide	\N	null	["croissance_vegetative", "floraison", "fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mildiou cucurbitacées"}, "alertes": [{"titre": "Risque Mildiou cucurbitacées", "niveau": "elevee", "message": "Pseudoperonospora cubensis : fraîcheur + HR>88% = sporulation rapide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Cymoxanil + Mancozèbe préventif", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
139	MAL-CON-002	maladie	fongique	Oïdium concombre — Chaleur sèche	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Oïdium"}, "alertes": [{"titre": "Risque Oïdium concombre", "niveau": "moyenne", "message": "Sphaerotheca fuliginea : chaleur + humidité modérée. Surveiller face inférieure feuilles."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable ou Myclobutanil", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
140	MAL-CON-003	maladie	fongique	Anthracnose cucurbitacées — Fruits humides	\N	null	["fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose fruits"}, "alertes": [{"titre": "Risque Anthracnose cucurbitacées", "niveau": "moyenne", "message": "Colletotrichum orbiculare : fruits mouillés = taches déprimées noires."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Mancozèbe préventif", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
141	MAL-PAS-001	maladie	fongique	Fusariose vasculaire pastèque — Sol acide	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "lte", "field": "sol.pH", "value": 6.0}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fusariose vasculaire"}, "alertes": [{"titre": "Risque Fusariose vasculaire pastèque", "niveau": "elevee", "message": "Fusarium oxysporum f.sp. niveum : sol acide + chaleur. Pas de traitement curatif."}], "recommandations": [{"type": "amendement_sol", "titre": "Chaulage avant plantation", "detail": "pH cible 6.5-7.0. Critique pour prévenir FON.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Greffage sur Cucurbita maxima", "detail": "Porte-greffe résistant Fusarium. Technique recommandée production intensive.", "priorite": 2}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
142	MAL-PAS-002	maladie	fongique	Mildiou cucurbitacées — Pastèque humidité	\N	null	["croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 88}, {"op": "between", "field": "meteo.temp_air", "value": 15, "value2": 22}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Mildiou cucurbitacées"}, "alertes": [{"titre": "Risque Mildiou pastèque", "niveau": "moyenne", "message": "Pseudoperonospora cubensis actif en fraîcheur humide."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide systémique Mildiou", "produit": "Métalaxyl-M + Mancozèbe", "priorite": 1, "urgence_jours": 4}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
144	MAL-MAG-001	maladie	fongique	Anthracnose mangue — Humidité floraison-récolte	\N	null	["floraison", "fructification", "maturation"]	[3, 4, 5, 6]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.pluie_24h", "value": 5}, {"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Anthracnose mangue"}, "alertes": [{"titre": "Risque Anthracnose mangue", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : pluie à floraison = pertes post-récolte élevées."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Anthracnose mangue", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3, "delai_carence_jours": 14}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
145	MAL-MAG-002	maladie	fongique	Oïdium mangue — Chaleur sèche floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 75}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Oïdium mangue"}, "alertes": [{"titre": "Risque Oïdium mangue à floraison", "niveau": "elevee", "message": "Oidium mangiferae peut détruire 20-80% fleurs. Traitement préventif urgent."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable ou Triadimefon floraison", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 2}]}	elevee	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
146	MAL-MAG-003	maladie	fongique	Dieback mangue — Saison sèche stress	\N	null	null	[1, 2, 3, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Dieback (Lasiodiplodia)"}, "alertes": [{"titre": "Risque Dieback mangue", "niveau": "elevee", "message": "Lasiodiplodia theobromae : stress hydrique + chaleur = infection blessures/taille."}], "recommandations": [{"type": "mesure_culturale", "titre": "Badigeonner cicatrices taille", "detail": "Pâte bordelaise sur toute coupe >2cm de diamètre.", "priorite": 1}, {"dose": "5 g/L application locale", "type": "traitement_phyto", "titre": "Trichoderma bio-fongicide", "produit": "Trichoderma harzianum", "priorite": 2, "urgence_jours": 7}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
147	MAL-MAG-004	maladie	bacterien	Bactériose angulaire mangue — Pluie vent	\N	null	null	[6, 7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 15}, {"op": "gte", "field": "meteo.vent", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Bactériose angulaire"}, "alertes": [{"titre": "Risque Bactériose angulaire mangue", "niveau": "moyenne", "message": "Xanthomonas campestris pv. mangiferaeindicae propagé par pluie + vent."}], "recommandations": [{"dose": "4 kg/ha", "type": "traitement_phyto", "titre": "Cuivre préventif après pluie", "produit": "Oxychlorure de cuivre 50WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
148	MAL-ANA-001	maladie	fongique	Anthracnose anacarde — Pluie floraison-nouaison	\N	null	["floraison", "nouaison"]	[2, 3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Anthracnose anacarde"}, "alertes": [{"titre": "Risque Anthracnose anacarde", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : pluie à floraison = chute inflorescences et pommes."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Fongicide Carbendazime anacarde", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
149	MAL-ANA-002	maladie	fongique	Oïdium anacarde — Floraison saison sèche	\N	null	["floraison"]	[1, 2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 50, "value2": 78}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Oïdium anacarde"}, "alertes": [{"titre": "Risque Oïdium anacarde", "niveau": "moyenne", "message": "Oidium anacardii : fin de saison sèche + début pluies = risque élevé."}], "recommandations": [{"dose": "3 kg/ha", "type": "traitement_phyto", "titre": "Soufre mouillable 2 applications", "produit": "Soufre 80WP", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
150	MAL-ANA-003	maladie	fongique	Dieback anacarde — Stress saison sèche	\N	null	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Dieback"}, "alertes": [{"titre": "Risque Dieback anacarde", "niveau": "elevee", "message": "Lasiodiplodia theobromae sur blessures taille en saison sèche."}], "recommandations": [{"type": "mesure_culturale", "titre": "Protéger cicatrices taille", "detail": "Pâte bordelaise ou mastic de jardinage sur coupes.", "priorite": 1}]}	elevee	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
151	MAL-BAN-001	maladie	fongique	Sigatoka noire banane — Pluies prolongées	\N	["casamance"]	null	[6, 7, 8, 9, 10]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 60}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Sigatoka noire"}, "alertes": [{"titre": "Risque Sigatoka noire élevé", "niveau": "critique", "message": "Mycosphaerella fijiensis : saison pluies + HR>85% = défoliation rapide. Traitement aérien/pulvérisation urgente."}], "recommandations": [{"dose": "0,8 L/ha", "type": "traitement_phyto", "titre": "Programme fongicide Sigatoka noire", "produit": "Propiconazole 25EC alternance Triadimefon", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
152	MAL-BAN-002	maladie	fongique	Fusariose Panama banane — Sol acide contaminé	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "fusariose_panama"}, {"op": "contains", "field": "obs.symptomes", "value": "jaunissement_feuilles_banane"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Fusariose Panama (FOC)"}, "alertes": [{"titre": "Maladie de Panama banane suspectée", "niveau": "critique", "message": "Fusarium oxysporum f.sp. cubense. Irréversible. Contamination sol permanente."}], "recommandations": [{"type": "mesure_culturale", "titre": "QUARANTAINE parcelle immédiate", "detail": "Ne pas déplacer matériel végétal ni terre. Alerter services phytosanitaires.", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Transition vers variétés résistantes TR4", "detail": "FHIA-01, FHIA-02 ou Grande Naine pour zones non infestées.", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
153	MAL-BAN-003	maladie	fongique	Anthracnose post-récolte banane — Humidité récolte	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "gte", "field": "meteo.temp_air", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Anthracnose post-récolte"}, "alertes": [{"titre": "Risque Anthracnose post-récolte banane", "niveau": "moyenne", "message": "Colletotrichum musae : récolte sous chaleur humide = noircissement rapide."}], "recommandations": [{"type": "mesure_post_recolte", "titre": "Réfrigération rapide 13°C", "detail": "Chaîne froide maintenir <14°C. Thiabendazole en trempage 200 ppm si export.", "priorite": 1}]}	moyenne	5	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
155	MAL-PAP-002	maladie	fongique	Pythium papaye — Sol engorgé plantation	\N	null	["plantation", "croissance_vegetative"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pythium fonte collet"}, "alertes": [{"titre": "Risque Pythium papaye — fonte du collet", "niveau": "elevee", "message": "Sol saturé : Pythium aphanidermatum cause pourriture collet fatale en 3-5 jours."}], "recommandations": [{"type": "mesure_culturale", "titre": "Planter sur buttes 30-40cm hauteur", "detail": "Drainage collet critique. Ne jamais planter en zone plate sans billons.", "priorite": 1}, {"dose": "2 g/L arrosage collet", "type": "traitement_phyto", "titre": "Métalaxyl préventif au collet", "produit": "Métalaxyl 25WP", "priorite": 2, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	\N
157	RAV-RIZ-001	ravageur	insecte	Foreur de tige riz — Conditions favorables tallage	\N	null	["tallage", "montaison"]	[6, 7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige riz", "niveau": "elevee", "message": "Scirpophaga incertulas actif : T° 24-32°C + HR>75%. Surveiller cœurs morts."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides au tallage", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
158	RAV-RIZ-002	ravageur	insecte	Foreur de tige riz — Cœurs morts observés	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "foreur_tige"}, {"op": "contains", "field": "obs.symptomes", "value": "coeurs_morts"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Foreur tige riz confirmé", "niveau": "critique", "message": "Cœurs morts : dommages irréversibles. Traitement curatif urgent."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos foliaire", "produit": "Chlorpyrifos 48EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
219	FER-MAN-001	fertilisation	potassium	Manioc — Carence K forte — épuisement sol	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 50}	{"risque": {"score": 0.85, "libelle": "Carence K manioc"}, "alertes": [{"titre": "Carence potassium manioc critique", "niveau": "elevee", "message": "K <50 mg/kg : manioc exigeant en K (export >200 kg K₂O/ha récolte). Sols épuisés."}], "recommandations": [{"dose": "80-120 kg K₂O/ha en 2-3 apports", "type": "fertilisation", "titre": "KCl apport fractionné", "detail": "KCl épuise sols sableux. Compléter avec fumier.", "produit": "KCl 60%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
156	MAL-PAP-003	maladie	fongique	Anthracnose papaye — Humidité maturité fruits	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "gte", "field": "meteo.temp_air", "value": 24}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Anthracnose papaye"}, "alertes": [{"titre": "Risque Anthracnose papaye", "niveau": "elevee", "message": "Colletotrichum gloeosporioides : fruits mûrs sous chaleur humide = pertes post-récolte."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime précolte", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 5, "delai_carence_jours": 7}, {"type": "mesure_post_recolte", "titre": "Trempage eau chaude 50°C 20min", "detail": "Traitement post-récolte pour export sans résidus chimiques.", "priorite": 2}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.404423+00	2026-06-10 06:28:01.843278+00
159	RAV-RIZ-003	ravageur	insecte	Hispe du riz — Chaleur humide végétation	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Hispe"}, "alertes": [{"titre": "Risque Hispe du riz", "niveau": "moyenne", "message": "Dicladispa armigera : larves minent feuilles, adultes raclent surface."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Monocrotophos ou Lambda-cyhalothrine", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
160	RAV-RIZ-004	ravageur	oiseau	Quelea riz — Alerte épiaison	\N	null	["epiaison", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "quelea"}, {"op": "contains", "field": "obs.ravageurs", "value": "oiseaux_granivores"}], "operator": "OR"}	{"risque": {"score": 0.9, "libelle": "Quelea"}, "alertes": [{"titre": "Quelea détecté — épis à risque", "niveau": "elevee", "message": "Quelea quelea en nuées : 1 oiseau consomme son poids/jour. Pertes jusqu'à 100%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Effaroucheurs acoustiques + visuels", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Gardiennage parcelles 6h-18h", "priorite": 2}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
161	RAV-MIL-001	ravageur	insecte	Foreur tiges/panicules mil — Tallage à montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur mil", "niveau": "elevee", "message": "Coniesta ignefusalis + Eldana saccharina : surveillance cœurs morts obligatoire."}], "recommandations": [{"dose": "10 kg/ha", "type": "traitement_phyto", "titre": "Insecticide systémique tallage", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
162	RAV-MIL-002	ravageur	plante_parasite	Striga mil — Détection précoce levée	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "striga"}, {"op": "contains", "field": "obs.symptomes", "value": "plante_parasite"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Striga"}, "alertes": [{"titre": "Striga détecté", "niveau": "critique", "message": "Striga hermonthica : parasite racinaire. Arracher avant floraison Striga."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher Striga AVANT floraison (fleurs violettes)", "detail": "Enfouir profond. 1 plant grainé = 50 000 graines → 20 ans infestation.", "priorite": 1, "urgence_jours": 3}, {"dose": "100 mL/kg semences", "type": "traitement_semences", "titre": "Imazapyr Clearfield (variétés tolérantes uniquement)", "produit": "Imazapyr 0.5FS", "priorite": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
163	RAV-MIL-003	ravageur	oiseau	Quelea mil — Alerte épiaison	\N	null	["epiaison", "maturation"]	[9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "quelea"}, {"op": "contains", "field": "obs.ravageurs", "value": "mange_mil"}], "operator": "OR"}	{"risque": {"score": 0.92, "libelle": "Quelea"}, "alertes": [{"titre": "Quelea — épiaison mil à risque", "niveau": "elevee", "message": "Nuées Quelea quelea : défoliation totale panicules possible en 48h."}], "recommandations": [{"type": "mesure_culturale", "titre": "Gardiennage + effaroucheurs acoustiques", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
164	RAV-SOR-001	ravageur	insecte	Cécidomyie sorgho — Floraison humide	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Cécidomyie"}, "alertes": [{"titre": "Risque Cécidomyie sorgho", "niveau": "elevee", "message": "Stenodiplosis sorghicola : floraison humide = infestation rapide ovaires."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Malathion à début floraison", "produit": "Malathion 57EC", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
165	RAV-SOR-002	ravageur	insecte	Foreur tige sorgho — Tallage-montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 26, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige sorgho", "niveau": "elevee", "message": "Busseola fusca + Sesamia calamistis actifs en chaleur humide."}], "recommandations": [{"dose": "12 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides verticille", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
166	RAV-SOR-003	ravageur	insecte	Noctuelle américaine sorgho — Helicoverpa	\N	null	["floraison", "maturation"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.ravageurs", "value": "noctuelle"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Helicoverpa"}, "alertes": [{"titre": "Helicoverpa armigera sorgho", "niveau": "elevee", "message": "Larves perforantes dans panicules. Seuil : 2 larves/plant."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Chlorpyrifos", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
167	RAV-SOR-004	ravageur	insecte	Cochenille sorgho — Saison sèche stress	\N	null	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Cochenille"}, "alertes": [{"titre": "Risque Cochenille sorgho", "niveau": "moyenne", "message": "Saccharicoccus sacchari prolifère en stress hydrique."}], "recommandations": [{"dose": "3 L/ha huile", "type": "traitement_phyto", "titre": "Huile minérale + insecticide", "produit": "Huile minérale 80% + Malathion", "priorite": 1, "urgence_jours": 7}]}	moyenne	5	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
168	RAV-MAI-001	ravageur	insecte	Chenille légionnaire d'automne maïs — Détection précoce	\N	null	["levee", "croissance_vegetative"]	[6, 7, 8, 9]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "chenille_legionnaire"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_cornet"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Spodoptera frugiperda"}, "alertes": [{"titre": "Chenille légionnaire d'automne détectée", "niveau": "critique", "message": "Spodoptera frugiperda : 1 larve/plant = 20-30% rendement perdu. Traitement immédiat."}], "recommandations": [{"dose": "0,15 kg/ha", "type": "traitement_phyto", "titre": "Emamectine benzoate dans cornet", "produit": "Emamectine benzoate 5SG", "priorite": 1, "urgence_jours": 1}, {"dose": "0,2 L/ha", "type": "traitement_phyto", "titre": "Chlorantraniliprole en alternative", "produit": "Chlorantraniliprole 200SC", "priorite": 2}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
169	RAV-MAI-002	ravageur	insecte	Chenille légionnaire — Conditions météo favorables	\N	null	["levee", "croissance_vegetative"]	[6, 7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 85}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Spodoptera frugiperda"}, "alertes": [{"titre": "Conditions favorables S. frugiperda", "niveau": "elevee", "message": "T° 22-32°C + HR 60-85% : cycle 30 jours. Surveiller cornets 2x/semaine."}], "recommandations": [{"type": "surveillance", "titre": "Piège phéromone + inspection cornet", "detail": "Seuil intervention : 1 larve/5 plants OU 20% plants infestés.", "priorite": 1}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
170	RAV-MAI-003	ravageur	insecte	Foreur de tige maïs — Tallage-montaison	\N	null	["tallage", "montaison"]	[7, 8, 9]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Foreur de tige"}, "alertes": [{"titre": "Risque Foreur tige maïs", "niveau": "elevee", "message": "Sesamia calamistis + Busseola fusca : surveillance cœurs morts."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Granulés insecticides verticille", "produit": "Carbofuran 3G", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
171	RAV-MAI-004	ravageur	insecte	Cicadelle MSV maïs — Détection vecteur	\N	null	["levee", "croissance_vegetative"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "cicadelle"}, {"op": "contains", "field": "obs.symptomes", "value": "striure"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "MSV via cicadelle"}, "alertes": [{"titre": "Cicadelle vectrice MSV détectée", "niveau": "elevee", "message": "Cicadulina mbila transmet Maize Streak Virus. Traitement urgence."}], "recommandations": [{"dose": "4 g/kg semences", "type": "traitement_semences", "titre": "Imidaclopride semences", "produit": "Imidaclopride 70WS", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
172	RAV-ARA-001	ravageur	insecte	Puceron noir arachide — Rosette + vecteur	\N	null	["levee", "croissance_vegetative"]	[7, 8]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 25}, {"op": "lte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Puceron noir + Rosette"}, "alertes": [{"titre": "Conditions favorables Puceron noir arachide", "niveau": "elevee", "message": "Aphis craccivora se multiplie en temps sec chaud. Vecteur Rosette."}], "recommandations": [{"dose": "4 g/kg", "type": "traitement_semences", "titre": "Imidaclopride semences anti-puceron", "produit": "Imidaclopride 70WS", "priorite": 1, "urgence_jours": 0}]}	elevee	9	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
173	RAV-ARA-002	ravageur	insecte	Termites arachide — Sol sec profondeur	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "lte", "field": "sol.humidite", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Termites"}, "alertes": [{"titre": "Risque Termites arachide", "niveau": "moyenne", "message": "Sol sec : Macrotermes/Microtermes attaquent racines et gousses en saison sèche."}], "recommandations": [{"dose": "10 kg/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos en sillon de semis", "produit": "Chlorpyrifos 10G", "priorite": 1, "urgence_jours": 0}]}	moyenne	6	0.65	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
174	RAV-ARA-003	ravageur	insecte	Ver blanc arachide — Sol humide fructification	\N	null	["fructification"]	[8, 9, 10]	{"clauses": [{"op": "between", "field": "sol.humidite", "value": 40, "value2": 70}], "operator": "AND"}	{"risque": {"score": 0.62, "libelle": "Ver blanc"}, "alertes": [{"titre": "Risque Ver blanc / Hanneton", "niveau": "moyenne", "message": "Larves Holotrichia/Sophrops attaquent gousses en fructification."}], "recommandations": [{"dose": "15 kg/ha", "type": "traitement_phyto", "titre": "Chlorpyrifos en sol à l'installation", "produit": "Chlorpyrifos 10G", "priorite": 1}]}	moyenne	5	0.62	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
220	FER-MAN-002	fertilisation	azote	Manioc — Carence N croissance vegetative	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 50}	{"risque": {"score": 0.72, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote manioc", "niveau": "moyenne", "message": "N <50 mg/kg : feuillage pâle, croissance lente, tubercules petits."}], "recommandations": [{"dose": "40-60 kg N/ha en 2 apports", "type": "fertilisation", "titre": "Urée fractionné 2-3 mois", "produit": "Urée 46%", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
175	RAV-NIE-001	ravageur	insecte	Helicoverpa niébé — Floraison-fructification	\N	null	["floraison", "fructification"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_gousse"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Helicoverpa armigera"}, "alertes": [{"titre": "Helicoverpa niébé confirmé", "niveau": "elevee", "message": "H. armigera perfore gousses. Seuil : 5% fleurs/gousses attaquées."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad à floraison", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
176	RAV-NIE-002	ravageur	insecte	Punaise niébé — Fructification	\N	null	["floraison", "fructification"]	[8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "punaise"}, {"op": "contains", "field": "obs.symptomes", "value": "sucion_gousses"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Punaise de gousse"}, "alertes": [{"titre": "Punaise niébé détectée", "niveau": "elevee", "message": "Clavigralla/Riptortus : succion gousses = graines avortées. Traitement urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine floraison-début gousses", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
177	RAV-NIE-003	ravageur	insecte	Thrips niébé — Floraison sèche chaude	\N	null	["floraison"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Thrips fleurs"}, "alertes": [{"titre": "Risque Thrips niébé", "niveau": "moyenne", "message": "Megalurothrips sjostedti : temps sec chaud → prolifération rapide dans fleurs."}], "recommandations": [{"dose": "1 L/ha", "type": "traitement_phyto", "titre": "Dimethoate ou Lambda floraison", "produit": "Dimethoate 40EC", "priorite": 1, "urgence_jours": 3}]}	moyenne	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
178	RAV-NIE-004	ravageur	insecte	Bruche niébé — Stockage graines	\N	null	["maturation", "recolte"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Bruche stockage"}, "alertes": [{"titre": "Risque Bruche niébé stockage", "niveau": "elevee", "message": "Callosobruchus maculatus : conditions chaudes favorables. Traitement post-récolte urgent."}], "recommandations": [{"type": "mesure_post_recolte", "titre": "Poudre de neem ou huile végétale sur graines", "detail": "Huile arachide 5 mL/kg ou poudre neem 20 g/kg. Stocker en sacs hermétiques.", "priorite": 1}, {"dose": "3 comprimés/tonne", "type": "mesure_post_recolte", "titre": "Phosphine fumigation silo", "produit": "Phosphure d'aluminium (Phostoxin)", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
179	RAV-TOM-001	ravageur	insecte	Mineuse tomate — Conditions chaleur modérée	\N	null	["croissance_vegetative", "floraison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 20, "value2": 30}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 85}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Tuta absoluta"}, "alertes": [{"titre": "Risque Tuta absoluta tomate", "niveau": "elevee", "message": "Tuta absoluta : galeries foliaires + perforation fruits. 1 larve/plant = traitement."}], "recommandations": [{"dose": "0,15 kg/ha", "type": "traitement_phyto", "titre": "Emamectine ou Chlorantraniliprole", "produit": "Emamectine benzoate 5SG", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Pièges phéromone (1/500m²)", "detail": "Monitoring obligatoire.", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
180	RAV-TOM-002	ravageur	insecte	Mineuse tomate — Symptômes actifs	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "mineuse"}, {"op": "contains", "field": "obs.symptomes", "value": "galeries_foliaires"}], "operator": "OR"}	{"risque": {"score": 0.95, "libelle": "Tuta absoluta"}, "alertes": [{"titre": "Tuta absoluta confirmée", "niveau": "critique", "message": "Infestation active. Programme 3 traitements rotatifs obligatoires."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Rotation : Spinosad J0 → Emamectine J7 → Chlorantraniliprole J14", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.93	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
181	RAV-TOM-003	ravageur	insecte	Helicoverpa tomate — Fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "helicoverpa"}, {"op": "contains", "field": "obs.symptomes", "value": "perforation_fruit"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Helicoverpa armigera"}, "alertes": [{"titre": "Helicoverpa tomate", "niveau": "elevee", "message": "Helicoverpa armigera perfore fruits. Seuil : 1 larve/10 plants."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Chlorantraniliprole", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
182	RAV-TOM-004	ravageur	insecte	Thrips tomate — TSWV vecteur chaleur sèche	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Thrips + TSWV"}, "alertes": [{"titre": "Risque Thrips tomate — vecteur TSWV", "niveau": "moyenne", "message": "Frankliniella occidentalis : temps sec chaud, vecteur Tomato Spotted Wilt Virus."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
183	RAV-PIM-001	ravageur	acarien	Acarien rouge piment — Chaleur sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge piment", "niveau": "elevee", "message": "Tetranychus urticae : temps sec chaud = multiplication explosive (7j/génération)."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide systémique", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
184	RAV-PIM-002	ravageur	insecte	Thrips piment — Saison sèche	\N	null	["floraison", "fructification"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Thrips piment"}, "alertes": [{"titre": "Risque Thrips piment", "niveau": "moyenne", "message": "Thrips palmi en saison sèche. Surveiller déformation fleurs."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
185	RAV-AUB-001	ravageur	insecte	Doryphore africain aubergine — Observation	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "doryphore"}, {"op": "contains", "field": "obs.symptomes", "value": "defoliation_aubergine"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Doryphore africain"}, "alertes": [{"titre": "Doryphore africain aubergine détecté", "niveau": "elevee", "message": "Leptinotarsa decemlineata var. africaine : défoliation rapide. Traitement urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine ou Deltamethrине", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
186	RAV-CHO-001	ravageur	insecte	Teigne du chou — Conditions sèches chaudes	\N	null	["croissance_vegetative", "pommaison"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "lte", "field": "meteo.humidite_rel", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Plutella xylostella"}, "alertes": [{"titre": "Risque Teigne du chou", "niveau": "elevee", "message": "Plutella xylostella : résistances multiples. Rotation insecticides obligatoire."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "BT ou Emamectine (rotation avec Spinosad)", "produit": "Bacillus thuringiensis", "priorite": 1, "urgence_jours": 3}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
187	RAV-CHO-002	ravageur	insecte	Pucerons chou — Vecteur maladies virales	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "puceron"}, {"op": "contains", "field": "obs.symptomes", "value": "miellat_chou"}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Pucerons"}, "alertes": [{"titre": "Pucerons chou détectés", "niveau": "moyenne", "message": "Brevicoryne brassicae : miellat + fumagine + vecteur TuMV."}], "recommandations": [{"dose": "0,5 kg/ha", "type": "traitement_phyto", "titre": "Imidaclopride ou Pirimicarbe", "produit": "Pirimicarbe 50WG", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
188	RAV-OIG-001	ravageur	insecte	Thrips oignon — Saison sèche feuilles	\N	null	["croissance_vegetative", "bulbaison"]	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "lte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Thrips oignon"}, "alertes": [{"titre": "Risque Thrips oignon", "niveau": "elevee", "message": "Thrips tabaci : saison sèche. Silvering feuilles + vecteur IYSV."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Spinosad ou Abamectine anti-thrips", "produit": "Spinosad 480SC", "priorite": 1, "urgence_jours": 4}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
189	RAV-OIG-002	ravageur	insecte	Mouche de l'oignon — Levée-repiquage	\N	null	["levee", "repiquage"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 28}, {"op": "gte", "field": "sol.humidite", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.68, "libelle": "Delia antiqua"}, "alertes": [{"titre": "Risque Mouche de l'oignon", "niveau": "moyenne", "message": "Delia antiqua : larves dans bulbe au repiquage. Protection semences/plants."}], "recommandations": [{"dose": "1,5 L/ha en incorporation", "type": "traitement_phyto", "titre": "Chlorpyrifos arrosage au sol", "produit": "Chlorpyrifos 48EC", "priorite": 1}]}	moyenne	6	0.68	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
190	RAV-GOM-001	ravageur	insecte	Jassides gombo — Chaleur sèche	\N	null	null	[3, 4, 5, 11, 12]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Jassides"}, "alertes": [{"titre": "Risque Jassides gombo", "niveau": "moyenne", "message": "Empoasca spp. : crispation feuilles (hopperburn). Temps sec."}], "recommandations": [{"dose": "0,25 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride foliaire", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
191	RAV-CON-001	ravageur	insecte	Mouche cucurbitacées — Fruits jeunes	\N	null	["fructification"]	[9, 10, 11, 12, 1, 2, 3]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Mouche cucurbitacées"}, "alertes": [{"titre": "Risque Mouche cucurbitacées", "niveau": "elevee", "message": "Dacus/Bactrocera cucurbitae : ponte dans jeunes fruits. Pertes 50-100%."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné empoisonné (GF-120)", "produit": "GF-120 NF Naturalyte", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Récolte fréquente fruits verts + enfouir fruits tombés", "priorite": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
192	RAV-MAN-001	ravageur	acarien	Acarien vert manioc — Saison sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Acarien vert"}, "alertes": [{"titre": "Risque Acarien vert manioc", "niveau": "elevee", "message": "Mononychellus tanajoa : épidémies en saison sèche. Défoliation sévère possible."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine ou lâcher Phytoseiidae", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
193	RAV-MAN-002	ravageur	insecte	Mouche blanche manioc — Vecteur CMD	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "mouche_blanche"}, {"op": "contains", "field": "obs.ravageurs", "value": "bemisia"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Bemisia tabaci + CMD"}, "alertes": [{"titre": "Mouche blanche manioc — Vecteur CMD", "niveau": "elevee", "message": "Bemisia tabaci biotype B : vecteur Mosaïque africaine. Contrôle urgent."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Imidaclopride systémique", "produit": "Imidaclopride 200SL", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
194	RAV-SES-001	ravageur	acarien	Acarien rouge sésame — Saison sèche	\N	null	null	[11, 12, 1, 2]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge sésame", "niveau": "moyenne", "message": "Tetranychus urticae : décoloration feuilles + toiles. Traitement préventif."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide Abamectine ou soufre", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
195	RAV-MAG-001	ravageur	insecte	Mouche des fruits mangue — Maturation	\N	null	["fructification", "maturation"]	[4, 5, 6, 7]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 60}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Ceratitis cosyra"}, "alertes": [{"titre": "Risque Mouche des fruits mangue", "niveau": "elevee", "message": "Ceratitis cosyra : ponte dans fruits mûrissants. Pertes 50-90% sans traitement."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné GF-120 hebdomadaire", "produit": "GF-120 NF Naturalyte", "priorite": 1, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Ramasser et enterrer fruits tombés quotidiennement", "priorite": 2}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
196	RAV-MAG-002	ravageur	insecte	Cécidomyie mangue — Floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 22, "value2": 32}, {"op": "gte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Cécidomyie"}, "alertes": [{"titre": "Risque Cécidomyie mangue", "niveau": "elevee", "message": "Procontarinia matteiana : larves dans fleurs. Chute inflorescences."}], "recommandations": [{"dose": "1 L/ha", "type": "traitement_phyto", "titre": "Dimethoate à début floraison", "produit": "Dimethoate 40EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
197	RAV-ANA-001	ravageur	insecte	Hélopelte anacarde — Jeunes pousses	\N	null	["floraison", "croissance_vegetative"]	[2, 3, 4, 5]	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 24, "value2": 34}, {"op": "gte", "field": "meteo.humidite_rel", "value": 65}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Hélopelte"}, "alertes": [{"titre": "Risque Hélopelte anacarde", "niveau": "elevee", "message": "Helopeltis anacardii : piqûres nécrotiques sur jeunes pousses et noix."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Lambda-cyhalothrine ou Dimethoate", "produit": "Lambda-cyhalothrine 2.5EC", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
198	RAV-BAN-001	ravageur	insecte	Charançon bananier — Sol humide plantation	\N	["casamance"]	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "charancon"}, {"op": "contains", "field": "obs.symptomes", "value": "galeries_pseudotronc"}], "operator": "OR"}	{"risque": {"score": 0.88, "libelle": "Cosmopolites sordidus"}, "alertes": [{"titre": "Charançon du bananier détecté", "niveau": "elevee", "message": "Cosmopolites sordidus : galeries rhizome. Peut tuer le plant."}], "recommandations": [{"type": "mesure_culturale", "titre": "Pièges pseudotronc + feromon", "detail": "1 piège/100m². Inspecter hebdo.", "priorite": 1}, {"dose": "20 g/pied", "type": "traitement_phyto", "titre": "Chlorpyrifos au sol", "produit": "Chlorpyrifos 10G", "priorite": 2, "urgence_jours": 5}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
200	RAV-PAS-001	ravageur	insecte	Mouche cucurbitacées — Pastèque fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "between", "field": "meteo.temp_air", "value": 25, "value2": 35}, {"op": "gte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mouche cucurbitacées"}, "alertes": [{"titre": "Risque Mouche cucurbitacées pastèque", "niveau": "elevee", "message": "Dacus cucurbitae : pertes importantes en fructification."}], "recommandations": [{"dose": "3 L/ha dilué 4x", "type": "traitement_phyto", "titre": "Appât protéiné empoisonné GF-120", "produit": "GF-120 NF", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
201	RAV-PAP-002	ravageur	acarien	Acarien rouge papaye — Saison sèche	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "lte", "field": "meteo.humidite_rel", "value": 55}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Acarien rouge"}, "alertes": [{"titre": "Risque Acarien rouge papaye", "niveau": "moyenne", "message": "T. urticae prolifère en saison sèche. Jaunissement feuilles."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine ou soufre mouillable", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.760209+00	\N
202	FER-RIZ-001	fertilisation	azote	Riz — Carence azote tallage	\N	null	["tallage", "montaison"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 80}, {"op": "in", "field": "culture.stade", "value": ["tallage", "montaison"]}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote riz — tallage", "niveau": "elevee", "message": "N <80 mg/kg : risque tallage insuffisant et rendement réduit de 20-40%."}], "recommandations": [{"dose": "60 kg N/ha", "type": "fertilisation", "titre": "Apport urée tallage", "detail": "Fractionner : 30 kg N au tallage + 30 kg N à la montaison.", "produit": "Urée 46%", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
203	FER-RIZ-002	fertilisation	phosphore	Riz — Carence phosphore pH acide	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 10}, {"clauses": [{"op": "lte", "field": "sol.phosphore", "value": 20}, {"op": "lte", "field": "sol.pH", "value": 5.5}], "operator": "AND"}], "operator": "OR"}	{"risque": {"score": 0.82, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore riz", "niveau": "elevee", "message": "P <10 mg/kg ou pH<5.5 bloque assimilation P. Racines courtes, tallage faible."}], "recommandations": [{"dose": "40-60 kg P₂O₅/ha", "type": "fertilisation", "titre": "TSP à l'installation", "produit": "Triple Superphosphate (TSP 46%)", "priorite": 1, "urgence_jours": 0}, {"type": "amendement_sol", "titre": "Chaulage si pH <5.5", "detail": "Porter pH >6.0 pour débloquer P natif du sol.", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
204	FER-RIZ-003	fertilisation	pH	Riz — Sol acide fort blocage nutriments	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.0}	{"risque": {"score": 0.9, "libelle": "Acidité sol toxique"}, "alertes": [{"titre": "Sol très acide riz — pH critique", "niveau": "elevee", "message": "pH <5.0 : toxicité Al/Mn + blocage P, Ca, Mg. Productivité limitée à 30-50%."}], "recommandations": [{"dose": "2-4 t/ha", "type": "amendement_sol", "titre": "Chaulage correctif", "detail": "Appliquer 6 semaines avant plantation. pH cible 6.0-6.5.", "produit": "Chaux agricole (CaCO₃)", "priorite": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
205	FER-RIZ-004	fertilisation	matiere_organique	Riz — Matière organique faible — sol dégradé	\N	null	null	null	{"op": "lte", "field": "sol.matiere_organique", "value": 1.0}	{"risque": {"score": 0.72, "libelle": "Sol dégradé MO"}, "alertes": [{"titre": "Sol pauvre en matière organique — Riz", "niveau": "moyenne", "message": "MO <1% : faible CEC, mauvaise rétention eau/nutriments. Fertilité structurelle faible."}], "recommandations": [{"dose": "5-10 t/ha", "type": "amendement_organique", "titre": "Compost ou fumier incorporé", "detail": "Incorporer 30 jours avant plantation.", "produit": "Fumier bovin composté", "priorite": 1}]}	moyenne	6	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
206	FER-MIL-001	fertilisation	azote	Mil — Carence azote levée-tallage	\N	null	["levee", "tallage"]	null	{"op": "lte", "field": "sol.azote", "value": 60}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote mil", "niveau": "elevee", "message": "N <60 mg/kg : jaunissement précoce + tallage faible. Pertes 30-50%."}], "recommandations": [{"dose": "40 kg N/ha", "type": "fertilisation", "titre": "Urée ou sulfate d'ammonium", "detail": "Microdosage : 2 g/poquet à 21 jours après semis. Technique ISSATROP.", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
207	FER-MIL-002	fertilisation	phosphore	Mil — Carence phosphore — sol ferrugineux	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"op": "lte", "field": "sol.phosphore", "value": 10}	{"risque": {"score": 0.82, "libelle": "Carence phosphore"}, "alertes": [{"titre": "Carence phosphore mil", "niveau": "elevee", "message": "P <10 mg/kg sur sol ferrugineux : racines courtes, système racinaire peu développé."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "DAP ou TSP au semis", "detail": "Placer en sillon 5cm sous la graine.", "produit": "DAP (18-46-0)", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
208	FER-MIL-003	fertilisation	potassium	Mil — Carence potassium — sol sableux	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 50}, {"op": "lte", "field": "sol.pH", "value": 6.0}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Carence potassium"}, "alertes": [{"titre": "Carence potassium mil", "niveau": "moyenne", "message": "K <50 mg/kg : sensibilité aux maladies accrue + grains peu denses."}], "recommandations": [{"dose": "30-40 kg K₂O/ha", "type": "fertilisation", "titre": "KCl ou K2SO4", "produit": "Chlorure de potasse (KCl 60%)", "priorite": 1}]}	moyenne	6	0.7	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
221	FER-TOM-001	fertilisation	azote	Tomate — Carence N croissance-floraison	\N	null	["croissance_vegetative", "floraison"]	null	{"op": "lte", "field": "sol.azote", "value": 100}	{"risque": {"score": 0.85, "libelle": "Carence azote"}, "alertes": [{"titre": "Carence azote tomate", "niveau": "elevee", "message": "N <100 mg/kg : feuilles vert pâle, floraison réduite, fruits petits."}], "recommandations": [{"dose": "120-150 kg N/ha total", "type": "fertilisation", "titre": "Fertigation N ou apport sol", "detail": "Fractionner toutes les 2 semaines. En fertigation : 4-6 kg N/ha/semaine.", "produit": "Nitrate de calcium ou Urée", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
222	FER-TOM-002	fertilisation	potassium	Tomate — Carence K fructification	\N	null	["fructification", "maturation"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.85, "libelle": "Carence K + nécrose apicale"}, "alertes": [{"titre": "Carence potassium tomate — qualité fruits", "niveau": "elevee", "message": "K <80 mg/kg en fructification : nécrose apicale + coloration irrégulière fruits."}], "recommandations": [{"dose": "80-100 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ + nitrate de calcium", "detail": "Ajouter Ca via nitrate de calcium pour prévenir Blossom End Rot.", "produit": "Sulfate de potasse (K₂SO₄)", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
223	FER-TOM-003	fertilisation	pH	Tomate — pH très acide blocage Ca/Mg	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 5.5}	{"risque": {"score": 0.88, "libelle": "Sol acide"}, "alertes": [{"titre": "Sol acide tomate — pH critique", "niveau": "elevee", "message": "pH <5.5 : blocage Ca, Mg, B. Aggrave Fusariose + Rhizoctone."}], "recommandations": [{"dose": "2-3 t/ha", "type": "amendement_sol", "titre": "Chaulage avant plantation", "detail": "pH cible 6.2-6.8 pour tomate.", "produit": "Dolomie (Ca+Mg)", "priorite": 1}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
224	FER-TOM-004	fertilisation	phosphore	Tomate — Carence P repiquage-floraison	\N	null	["repiquage", "croissance_vegetative"]	null	{"op": "lte", "field": "sol.phosphore", "value": 15}	{"risque": {"score": 0.82, "libelle": "Carence P"}, "alertes": [{"titre": "Carence phosphore tomate", "niveau": "elevee", "message": "P <15 mg/kg : couleur pourpre face inférieure feuilles, floraison retardée."}], "recommandations": [{"dose": "60-80 kg P₂O₅/ha", "type": "fertilisation", "titre": "TSP ou DAP au repiquage", "produit": "TSP 46%", "priorite": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
225	FER-PIM-001	fertilisation	azote	Piment — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.75, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote piment", "niveau": "moyenne", "message": "N <80 mg/kg : croissance lente, feuilles pâles, fruits petits."}], "recommandations": [{"dose": "100-120 kg N/ha total", "type": "fertilisation", "titre": "Urée + NPK fractionné", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
226	FER-AUB-001	fertilisation	azote	Aubergine — Carence N forte	\N	null	["croissance_vegetative", "floraison"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote aubergine", "niveau": "moyenne", "message": "N <80 mg/kg : production limitée."}], "recommandations": [{"dose": "150-200 kg NPK/ha + 80 kg Urée/ha fractionné", "type": "fertilisation", "titre": "Programme NPK aubergine", "produit": "NPK 12-12-17 + Urée", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
227	FER-CHO-001	fertilisation	azote	Chou — Carence N critique pommaison	\N	null	["croissance_vegetative", "pommaison"]	null	{"op": "lte", "field": "sol.azote", "value": 100}	{"risque": {"score": 0.85, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote chou", "niveau": "elevee", "message": "N <100 mg/kg : pommes lâches, jaunissement précoce."}], "recommandations": [{"dose": "150-200 kg N/ha total en 3 fractions", "type": "fertilisation", "titre": "Urée + sulfate d'ammonium fractionné", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
228	FER-CHO-002	fertilisation	pH	Chou — pH acide Hernie du chou	\N	null	null	null	{"op": "lte", "field": "sol.pH", "value": 6.5}	{"risque": {"score": 0.85, "libelle": "pH + Hernie du chou"}, "alertes": [{"titre": "pH acide chou — Risque Hernie", "niveau": "elevee", "message": "pH <6.5 : Plasmodiophora brassicae active. Chaulage obligatoire avant Brassicacées."}], "recommandations": [{"dose": "3-5 t/ha", "type": "amendement_sol", "titre": "Chaulage fort avant plantation", "detail": "pH cible ≥7.0.", "produit": "Chaux vive", "priorite": 1}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
229	FER-OIG-001	fertilisation	azote	Oignon — Carence N croissance-bulbaison	\N	null	["croissance_vegetative", "bulbaison"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.85, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote oignon", "niveau": "elevee", "message": "N <80 mg/kg : feuilles droites pâles, bulbes petits, conservation réduite."}], "recommandations": [{"dose": "80-120 kg N/ha", "type": "fertilisation", "titre": "Urée fractionné + arrêt 4 semaines avant récolte", "detail": "Arrêter N 30 jours avant récolte pour bonne conservation.", "produit": "Urée 46%", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
230	FER-OIG-002	fertilisation	potassium	Oignon — Carence K conservation bulbes	\N	null	["bulbaison", "maturation"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.75, "libelle": "Carence K conservation"}, "alertes": [{"titre": "Carence potassium oignon", "niveau": "moyenne", "message": "K <80 mg/kg : bulbes mous, conservation réduite, pertes stockage élevées."}], "recommandations": [{"dose": "80-100 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ à la bulbaison", "produit": "Sulfate de potasse 50%", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
290	CAL-SOR-001	calendrier	semis	Sorgho — Fenêtre semis hivernage	\N	null	null	[6, 7]	{"op": "in", "field": "culture.mois", "value": [6, 7]}	{"risque": {"score": 0.5, "libelle": "Fenêtre semis"}, "alertes": [{"titre": "Fenêtre semis sorgho", "niveau": "faible", "message": "Juin-juillet : semis optimal. Variétés photosensibles après 15 juillet OK."}], "recommandations": [{"type": "semis", "titre": "Semer après cumul 20mm", "detail": "CE 145-66, Framida ou Faourou selon zone.", "priorite": 1}]}	faible	5	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
231	FER-MAG-001	fertilisation	NPK	Mangue — Carence nutritionnelle post-récolte	\N	null	null	[7, 8, 9]	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 50}, {"op": "lte", "field": "sol.phosphore", "value": 8}, {"op": "lte", "field": "sol.potassium", "value": 60}], "operator": "OR"}	{"risque": {"score": 0.72, "libelle": "Carence NPK mangue"}, "alertes": [{"titre": "Carence nutriments mangue post-récolte", "niveau": "moyenne", "message": "Sol épuisé après récolte. Fertilisation post-récolte pour recharger arbre."}], "recommandations": [{"dose": "1-3 kg/arbre selon âge", "type": "fertilisation", "titre": "NPK arbres fruitiers post-récolte", "detail": "Incorporer sous frondaison. Arroser si saison sèche.", "produit": "NPK 10-10-20", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
232	FER-ANA-001	fertilisation	NPK	Anacarde — Fertilisation jeunes plants	\N	null	null	[7, 8]	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 40}, {"op": "lte", "field": "sol.phosphore", "value": 8}], "operator": "OR"}	{"risque": {"score": 0.7, "libelle": "Sol pauvre anacarde"}, "alertes": [{"titre": "Sol pauvre — Fertilisation anacarde", "niveau": "moyenne", "message": "Sol très pauvre : fertilisation de fond indispensable pour jeunes plants."}], "recommandations": [{"dose": "200 g NPK/fosse + 50 g Urée à 3 mois", "type": "fertilisation", "titre": "NPK fosse plantation + urée 1ère année", "produit": "NPK 15-15-15 + Urée 46%", "priorite": 1}]}	moyenne	5	0.7	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
233	FER-GOM-001	fertilisation	azote	Gombo — Carence N croissance	\N	null	["croissance_vegetative"]	null	{"op": "lte", "field": "sol.azote", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence N"}, "alertes": [{"titre": "Carence azote gombo", "niveau": "moyenne", "message": "N <80 mg/kg : croissance lente, fruits petits."}], "recommandations": [{"dose": "40 kg N/ha en 2 apports", "type": "fertilisation", "titre": "Urée à 21 jours", "produit": "Urée 46%", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
234	FER-CON-001	fertilisation	potassium	Concombre — Carence K fructification	\N	null	["fructification"]	null	{"op": "lte", "field": "sol.potassium", "value": 80}	{"risque": {"score": 0.72, "libelle": "Carence K"}, "alertes": [{"titre": "Carence K concombre", "niveau": "moyenne", "message": "K <80 mg/kg en fructification : fruits courbés + saveur acide."}], "recommandations": [{"dose": "60-80 kg K₂O/ha", "type": "fertilisation", "titre": "K₂SO₄ à la fructification", "produit": "Sulfate de potasse", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
235	FER-PAS-001	fertilisation	NPK	Pastèque — Déficit NPK fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 80}, {"op": "lte", "field": "sol.azote", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Carence NPK qualité"}, "alertes": [{"titre": "Carence NPK pastèque fructification", "niveau": "moyenne", "message": "Déficit K+N : fruits petits, chair peu colorée, teneur sucre réduite."}], "recommandations": [{"dose": "50 kg/ha", "type": "fertilisation", "titre": "Fertigation NK fructification", "produit": "Nitrate de potasse (NOP 13-0-46)", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
236	FER-BAN-001	fertilisation	potassium	Banane — Forte exigence K croissance	\N	null	null	null	{"op": "lte", "field": "sol.potassium", "value": 100}	{"risque": {"score": 0.88, "libelle": "Carence K banane"}, "alertes": [{"titre": "Carence potassium banane critique", "niveau": "elevee", "message": "Banane exige 300-400 kg K₂O/ha/an. K <100 : régimes petits, maturation irrégulière."}], "recommandations": [{"dose": "300-400 kg K₂O/ha/an fractionné mensuellement", "type": "fertilisation", "titre": "KCl ou K₂SO₄ mensuel", "produit": "KCl 60%", "priorite": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
238	FER-GEN-001	fertilisation	pH	Sol très alcalin — Blocage micronutriments	\N	null	null	null	{"op": "gte", "field": "sol.pH", "value": 8.0}	{"risque": {"score": 0.85, "libelle": "Alcalinité toxique"}, "alertes": [{"titre": "Sol très alcalin — pH >8.0", "niveau": "elevee", "message": "pH >8.0 : blocage Fe, Mn, Zn, B. Chlorose ferrique + déficiences multiples."}], "recommandations": [{"dose": "200-500 kg/ha", "type": "amendement_sol", "titre": "Soufre agricole pour acidifier", "detail": "Résultat en 3-6 mois. Compléter par sulfate de fer.", "produit": "Soufre élémentaire S", "priorite": 1}, {"dose": "5-10 kg/ha en fertirrigation", "type": "fertilisation", "titre": "Chélates Fe, Mn, Zn foliaires", "produit": "Chélate EDDHA 6%", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
239	FER-GEN-002	fertilisation	matiere_organique	Sol très dégradé MO — Toutes cultures	\N	null	null	null	{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}	{"risque": {"score": 0.88, "libelle": "Dégradation sol sévère"}, "alertes": [{"titre": "Sol très pauvre en matière organique", "niveau": "elevee", "message": "MO <0.5% : sol mort, efficience engrais très faible, érosion forte."}], "recommandations": [{"dose": "10-15 t/ha/an", "type": "amendement_organique", "titre": "Compost + restitution pailles", "detail": "Programme pluriannuel. Incorporer résidus de récolte au sol.", "produit": "Compost ou fumier", "priorite": 1}, {"type": "mesure_culturale", "titre": "Rotation avec légumineuses", "detail": "Niébé, arachide ou mucuna comme précédent cultural.", "priorite": 2}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:45.948831+00	\N
240	IRR-RIZ-001	irrigation	stress_hydrique	Riz — Stress hydrique tallage — irrigation urgente	\N	["vallee_fleuve"]	["tallage", "montaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Stress hydrique"}, "alertes": [{"titre": "Stress hydrique riz — tallage", "niveau": "elevee", "message": "Sol humidité <50% + ETP élevée : risque sévère si >3j sans eau."}], "recommandations": [{"dose": "50-60 mm", "type": "irrigation", "titre": "Irrigation submersion 5-8 cm", "detail": "Maintenir lame d'eau 5 cm au tallage. Critique pour nombre de talles.", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
241	IRR-RIZ-002	irrigation	engorgement	Riz — Excès eau — drainage nécessaire	\N	null	["levee", "tallage"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 60}, {"op": "gte", "field": "sol.humidite", "value": 95}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Asphyxie racinaire"}, "alertes": [{"titre": "Excès eau riz — drainage recommandé", "niveau": "moyenne", "message": "Submersion >15 cm à levée : asphyxie jeunes plants possible."}], "recommandations": [{"type": "drainage", "titre": "Ouvrir drain si lame >15 cm", "priorite": 1, "urgence_jours": 1}]}	moyenne	7	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
242	IRR-RIZ-003	irrigation	stress_hydrique	Riz — Stress épiaison-floraison critique	\N	null	["epiaison", "floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 60}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Stérilité épillets"}, "alertes": [{"titre": "Stress hydrique riz à épiaison — CRITIQUE", "niveau": "critique", "message": "Épiaison = stade le plus sensible. 3j de stress = 30-50% stérilité épillets."}], "recommandations": [{"dose": "60 mm", "type": "irrigation", "titre": "Irrigation immédiate — maintenir lame 5-8 cm", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
243	IRR-MIL-001	irrigation	stress_hydrique	Mil — Stress hydrique levée-tallage	\N	null	["levee", "tallage"]	[7, 8]	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 30}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Stress hydrique levée"}, "alertes": [{"titre": "Stress hydrique mil levée", "niveau": "elevee", "message": "Humidité sol <30% : levée irrégulière + mortalité plantules."}], "recommandations": [{"dose": "20 mm", "type": "irrigation", "titre": "Irrigation légère 20 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
244	IRR-MIL-002	irrigation	stress_hydrique	Mil — Stress floraison critique	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Avortement panicules"}, "alertes": [{"titre": "Stress hydrique mil floraison", "niveau": "critique", "message": "Floraison = stade le plus sensible mil. Stress → avortement panicules."}], "recommandations": [{"dose": "30 mm", "type": "irrigation", "titre": "Irrigation 30 mm d'urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
245	IRR-MAI-001	irrigation	stress_hydrique	Maïs — Stress hydrique floraison — pollinisation	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}, {"op": "gte", "field": "meteo.temp_air", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Avortement floraison maïs"}, "alertes": [{"titre": "Stress hydrique maïs floraison", "niveau": "critique", "message": "Stress à floraison = asynchronie fleurs + pollinisation ratée → épis vides."}], "recommandations": [{"dose": "40-50 mm", "type": "irrigation", "titre": "Irrigation 40-50 mm urgence", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
246	IRR-MAI-002	irrigation	stress_hydrique	Maïs — Stress remplissage grains	\N	null	["remplissage_grains"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Grains petits"}, "alertes": [{"titre": "Stress hydrique maïs remplissage", "niveau": "elevee", "message": "Remplissage grains exige besoins max. Stress → grains petits + légers."}], "recommandations": [{"dose": "30-40 mm", "type": "irrigation", "titre": "Irrigation 30-40 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
247	IRR-ARA-001	irrigation	stress_hydrique	Arachide — Stress fructification-remplissage gousses	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Gousses vides"}, "alertes": [{"titre": "Stress hydrique arachide fructification", "niveau": "elevee", "message": "Sol sec à fructification : gousses vides + avortement gynophores."}], "recommandations": [{"dose": "25-30 mm", "type": "irrigation", "titre": "Irrigation 25-30 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
248	IRR-SOR-001	irrigation	stress_hydrique	Sorgho — Stress floraison-remplissage	\N	null	["floraison", "maturation"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 30}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Stress floraison"}, "alertes": [{"titre": "Stress hydrique sorgho floraison", "niveau": "elevee", "message": "Sorgho tolérant sécheresse mais stress floraison réduit rendement 20-40%."}], "recommandations": [{"dose": "20-25 mm", "type": "irrigation", "titre": "Irrigation d'appoint 20-25 mm", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
249	IRR-TOM-001	irrigation	stress_hydrique	Tomate — Stress hydrique floraison-nouaison	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Chute fleurs + BER"}, "alertes": [{"titre": "Stress hydrique tomate floraison", "niveau": "elevee", "message": "Stress à nouaison = chute fleurs + fruits mal formés (blossom end rot)."}], "recommandations": [{"dose": "30-40 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière — maintenir 70-80% RFU", "detail": "Éviter alternance sec/humide : aggrave BER.", "priorite": 1, "urgence_jours": 1}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
250	IRR-TOM-002	irrigation	engorgement	Tomate — Excès eau — Phytophthora + Fusariose	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 90}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pathogènes sol engorgement"}, "alertes": [{"titre": "Engorgement tomate — risque pathogènes sol", "niveau": "elevee", "message": "Sol saturé : Phytophthora + Fusariose + pourriture collet en 48h."}], "recommandations": [{"type": "drainage", "titre": "Drainer immédiatement", "priorite": 1, "urgence_jours": 1}, {"dose": "1 kg/ha arrosage sol", "type": "traitement_phyto", "titre": "Métalaxyl préventif", "produit": "Métalaxyl 25WP", "priorite": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
251	IRR-OIG-001	irrigation	stress_hydrique	Oignon — Stress bulbaison critique	\N	null	["bulbaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Bulbes petits"}, "alertes": [{"titre": "Stress hydrique oignon bulbaison", "niveau": "elevee", "message": "Stress à bulbaison = bulbes petits + doubles (ciboule). Besoin max 4-5 mm/j."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
252	IRR-OIG-002	irrigation	gestion	Oignon — Arrêt irrigation maturité	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 60}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Mauvaise conservation"}, "alertes": [{"titre": "Excès eau oignon maturité", "niveau": "moyenne", "message": "Irrigation/pluie à maturité : col épais, mauvaise conservation, Botrytis aggravé."}], "recommandations": [{"type": "gestion_eau", "titre": "ARRÊTER irrigation 4 semaines avant récolte", "detail": "Sol doit être sec 3-4 semaines avant arrachage.", "priorite": 1}]}	moyenne	7	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
253	IRR-CHO-001	irrigation	stress_hydrique	Chou — Stress hydrique pommaison	\N	null	["pommaison"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pommaison échouée"}, "alertes": [{"titre": "Stress hydrique chou pommaison", "niveau": "elevee", "message": "Stress à pommaison = pommes lâches + montée en graines précoce."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
254	IRR-PIM-001	irrigation	stress_hydrique	Piment — Stress hydrique floraison-fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Chute fleurs + BER"}, "alertes": [{"titre": "Stress hydrique piment", "niveau": "elevee", "message": "Piment très sensible stress : chute fleurs + brûlure collet fruits (BER)."}], "recommandations": [{"dose": "25-30 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière — éviter à-coups", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
255	IRR-CON-001	irrigation	stress_hydrique	Concombre — Stress fructification — fruits amers	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 50}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Fruits amers"}, "alertes": [{"titre": "Stress hydrique concombre", "niveau": "elevee", "message": "Stress en fructification : fruits amers (cucurbitacine) + croissance tordue."}], "recommandations": [{"dose": "4-6 mm/j", "type": "irrigation", "titre": "Irrigation goutte-à-goutte régulière", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
256	IRR-PAS-001	irrigation	gestion	Pastèque — Réduction eau maturité	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.pluie_7j", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.78, "libelle": "Qualité réduite fruits"}, "alertes": [{"titre": "Excès eau pastèque maturité", "niveau": "moyenne", "message": "Trop d'eau à maturité : fruits aqueux, fade, éclatement, Anthracnose."}], "recommandations": [{"type": "gestion_eau", "titre": "Réduire irrigation 50% à 2 semaines avant récolte", "detail": "Stress léger augmente teneur sucre (°Brix) de 1-2 points.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
257	IRR-GOM-001	irrigation	stress_hydrique	Gombo — Stress hydrique fructification	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Stress fructification"}, "alertes": [{"titre": "Stress hydrique gombo fructification", "niveau": "moyenne", "message": "Stress en fructification : capsules dures + arrêt production."}], "recommandations": [{"dose": "25 mm/semaine", "type": "irrigation", "titre": "Irrigation 3-4 mm/j goutte-à-goutte", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
258	IRR-MAG-001	irrigation	stress_hydrique	Mangue — Stress floraison-nouaison	\N	null	["floraison", "nouaison"]	[2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 32}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Chute fleurs mangue"}, "alertes": [{"titre": "Stress hydrique mangue floraison", "niveau": "elevee", "message": "Sécheresse + chaleur à floraison : chute fleurs et avortement jeunes fruits."}], "recommandations": [{"dose": "50-60 L/arbre", "type": "irrigation", "titre": "Irrigation localisée 50-60 L/arbre/semaine", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
259	IRR-MAG-002	irrigation	gestion	Mangue — Stress sec induit floraison	\N	null	null	[11, 12, 1]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "lte", "field": "meteo.temp_air", "value": 24}], "operator": "AND"}	{"risque": {"score": 0.5, "libelle": "Induction florale"}, "alertes": [{"titre": "Conditions induction florale mangue", "niveau": "moyenne", "message": "Nuits fraîches + sécheresse : conditions idéales induction florale. NE PAS irriguer."}], "recommandations": [{"type": "gestion_eau", "titre": "SUSPENDRE irrigation 6-8 semaines (induction florale)", "detail": "Stress sec volontaire déclenche floraison. Reprendre à apparition des panicules.", "priorite": 1}]}	faible	5	0.75	premium	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
260	IRR-BAN-001	irrigation	stress_hydrique	Banane — Stress hydrique croissance	\N	null	null	[11, 12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "gte", "field": "meteo.etp", "value": 5}, {"op": "lte", "field": "sol.humidite", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Stress hydrique"}, "alertes": [{"titre": "Stress hydrique banane saison sèche", "niveau": "elevee", "message": "Banane exige 1500-2000 mm/an. Stress en saison sèche : régimes petits."}], "recommandations": [{"dose": "20-25 L/plant/jour", "type": "irrigation", "titre": "Irrigation goutte-à-goutte 20-25 L/plant/j", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
261	IRR-PAP-001	irrigation	gestion	Papaye — Engorgement sol collet mortel	\N	null	null	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Mortalité Pythium"}, "alertes": [{"titre": "Engorgement sol papaye — MORTEL", "niveau": "critique", "message": "Papaye = 0 tolérance asphyxie racinaire. 48h engorgé = Pythium → mort."}], "recommandations": [{"type": "drainage", "titre": "Drainage d'urgence immédiat", "priorite": 1, "urgence_jours": 1}, {"dose": "2 g/L arrosage collet", "type": "traitement_phyto", "titre": "Métalaxyl préventif collet", "produit": "Métalaxyl 25WP", "priorite": 2}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
262	IRR-ANA-001	irrigation	gestion	Anacarde — Irrigation jeunes plants saison sèche	\N	null	null	[12, 1, 2, 3, 4]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.temp_air", "value": 30}, {"op": "lte", "field": "sol.humidite", "value": 25}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Mortalité jeunes plants"}, "alertes": [{"titre": "Stress hydrique anacarde saison sèche", "niveau": "moyenne", "message": "Jeunes plants (<3 ans) : mortalité si stress prolongé >3 semaines."}], "recommandations": [{"dose": "20-30 L/arbre/semaine", "type": "irrigation", "titre": "Arrosage hebdomadaire 20-30 L/arbre", "priorite": 1, "urgence_jours": 5}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
263	IRR-NIE-001	irrigation	stress_hydrique	Niébé — Stress floraison-fructification	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Avortement fleurs"}, "alertes": [{"titre": "Stress hydrique niébé floraison", "niveau": "elevee", "message": "Stress à floraison = chute fleurs + avortement gousses."}], "recommandations": [{"dose": "20-25 mm", "type": "irrigation", "titre": "Irrigation 20-25 mm", "priorite": 1, "urgence_jours": 2}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
264	IRR-SES-001	irrigation	gestion	Sésame — Excès eau collet levée	\N	null	["levee"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_24h", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Phytophtora engorgement"}, "alertes": [{"titre": "Excès eau sésame — Phytophthora", "niveau": "elevee", "message": "Sésame = 0 tolérance engorgement. Phytophtora actif sol saturé."}], "recommandations": [{"type": "drainage", "titre": "Drainage immédiat", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
265	IRR-MAN-001	irrigation	gestion	Manioc — Engorgement persistant pourriture racines	\N	null	["tuberisation", "maturation"]	null	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 85}, {"op": "gte", "field": "meteo.pluie_7j", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pourriture racinaire"}, "alertes": [{"titre": "Engorgement sol manioc — pourriture", "niveau": "elevee", "message": "Sol engorgé en tubérisation : Phytophthora + bactéries pourrissant les racines."}], "recommandations": [{"type": "drainage", "titre": "Billonnage + drainage urgence", "priorite": 1, "urgence_jours": 1}, {"type": "mesure_culturale", "titre": "Récolte anticipée >12 mois", "detail": "Manioc mûr en sol détrempé : récolter avant pourriture totale.", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
266	IRR-AUB-001	irrigation	stress_hydrique	Aubergine — Stress fructification qualité fruits	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.etp", "value": 6}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Qualité fruits dégradée"}, "alertes": [{"titre": "Stress hydrique aubergine fructification", "niveau": "moyenne", "message": "Stress = fruits petits, amers, pépins nombreux, couleur terne."}], "recommandations": [{"dose": "30-35 mm/semaine", "type": "irrigation", "titre": "Irrigation régulière 4-5 mm/j", "priorite": 1, "urgence_jours": 2}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.066807+00	\N
267	MET-GEN-001	meteo	chaleur	Chaleur extrême >38°C — Cultures légumières	\N	null	null	[4, 5, 6, 10, 11]	{"op": "gte", "field": "meteo.temp_air", "value": 38}	{"risque": {"score": 0.92, "libelle": "Stress thermique critique"}, "alertes": [{"titre": "Chaleur extrême >38°C — cultures légumières", "niveau": "critique", "message": "T° >38°C : avortement fleurs, coup de soleil fruits, arrêt photosynthèse."}], "recommandations": [{"type": "protection", "titre": "Ombrage 30-50% si disponible", "detail": "Filet ombrage ou paillage blanc pour réfléchir chaleur.", "priorite": 1}, {"dose": "15-20 mm", "type": "irrigation", "titre": "Irrigation matin avant 8h", "detail": "Éviter irrigation en pleine chaleur — brûlures.", "priorite": 2, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
268	MET-GEN-002	meteo	chaleur	Chaleur >35°C — Grandes cultures céréales	\N	null	["floraison", "epiaison"]	null	{"op": "gte", "field": "meteo.temp_air", "value": 35}	{"risque": {"score": 0.85, "libelle": "Stress thermique floraison"}, "alertes": [{"titre": "Chaleur >35°C à floraison céréales", "niveau": "elevee", "message": "T° >35°C à floraison : stérilité pollinique + dommages protéines grains."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller taux de remplissage des épis/panicules", "detail": "Si >30% stérilité : noter pour choix variété saison prochaine.", "priorite": 1}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
269	MET-GEN-003	meteo	chaleur	Vague chaleur prolongée >3j >36°C	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 36}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}, {"op": "gte", "field": "meteo.etp", "value": 8}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Stress hydro-thermique"}, "alertes": [{"titre": "Vague de chaleur prolongée", "niveau": "critique", "message": "Chaleur + sécheresse + ETP élevée : stress hydro-thermique combiné. Pertes 30-60%."}], "recommandations": [{"type": "irrigation", "titre": "Irrigations fréquentes matin/soir", "priorite": 1, "urgence_jours": 1}, {"type": "protection", "titre": "Paillage mulch pour refroidir sol", "detail": "Paille 10 cm réduit T° sol de 5-8°C.", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
270	MET-SEC-001	meteo	secheresse	Sécheresse prolongée — Grandes cultures pluviales	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[7, 8, 9]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 10}, {"op": "lte", "field": "meteo.pluie_24h", "value": 2}, {"op": "gte", "field": "meteo.temp_air", "value": 32}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Sécheresse hivernage"}, "alertes": [{"titre": "Sécheresse prolongée — cultures pluviales", "niveau": "elevee", "message": ">10j sans pluie significative en hivernage : stress sévère. Surveiller flétrissement."}], "recommandations": [{"type": "mesure_culturale", "titre": "Sarclage pour réduire concurrence herbes", "detail": "Sarclage conserve 20-30% humidité sol supplémentaire.", "priorite": 1}, {"type": "mesure_culturale", "titre": "Paillage inter-rangs", "detail": "Tiges de mil ou paille : réduit évaporation 30-40%.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
271	MET-SEC-002	meteo	secheresse	Sécheresse saison sèche — Arbres fruitiers	\N	null	null	[1, 2, 3, 4, 11, 12]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 2}, {"op": "gte", "field": "meteo.temp_air", "value": 33}, {"op": "gte", "field": "meteo.etp", "value": 7}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Stress hydrique arboriculture"}, "alertes": [{"titre": "Sécheresse saison sèche arbres fruitiers", "niveau": "elevee", "message": "ETP >7mm/j sans pluie : besoins en eau non couverts. Stress durable."}], "recommandations": [{"dose": "30-80 L/arbre/semaine selon âge", "type": "irrigation", "titre": "Irrigation localisée goutte-à-goutte", "priorite": 1}, {"type": "mesure_culturale", "titre": "Paillage organique pied d'arbre", "detail": "Couche 15 cm rayon 1 m autour du tronc.", "priorite": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
272	MET-SEC-003	meteo	secheresse	Début saison sèche — Alerte cultures sensibles	\N	null	null	[10, 11]	{"clauses": [{"op": "lte", "field": "meteo.pluie_7j", "value": 15}, {"op": "lte", "field": "meteo.pluie_24h", "value": 3}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Fin saison pluies"}, "alertes": [{"titre": "Début saison sèche — surveillance récolte", "niveau": "moyenne", "message": "Transition vers saison sèche. Planifier récolte cultures arrivant à maturité."}], "recommandations": [{"type": "planification", "titre": "Estimer date maturité + planifier récolte", "detail": "Arachide : arracher avant sol trop sec (risque gousses cassées).", "priorite": 1}]}	moyenne	5	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
273	MET-PLU-001	meteo	inondation	Pluies torrentielles >80mm/24h — Alerte inondation	\N	null	null	null	{"op": "gte", "field": "meteo.pluie_24h", "value": 80}	{"risque": {"score": 0.92, "libelle": "Inondation + pathogènes sol"}, "alertes": [{"titre": "Pluies torrentielles — risque inondation", "niveau": "critique", "message": ">80mm/24h : asphyxie racinaire, lessivage engrais, maladies fongiques explosives."}], "recommandations": [{"type": "drainage", "titre": "Drainage urgence avant 24h", "priorite": 1, "urgence_jours": 1}, {"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Fongicide sol préventif après submersion", "produit": "Métalaxyl 25WP", "priorite": 2}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
274	MET-PLU-002	meteo	inondation	Pluies abondantes 7j — Risque maladies fongiques généralisé	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 100}, {"op": "gte", "field": "meteo.humidite_rel", "value": 88}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Épidémie fongique multi-maladies"}, "alertes": [{"titre": "Pluies prolongées — Risque épidémie fongique", "niveau": "elevee", "message": "100mm+/7j + HR>88% : conditions épidémiques Mildiou, Phytophthora, Anthracnose."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Programme fongicide préventif multi-cibles", "produit": "Mancozèbe 80WP + Cymoxanil 4%", "priorite": 1, "urgence_jours": 2}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
275	MET-PLU-003	meteo	pluie	Pluie >30mm — Lessivage engrais récents	\N	null	null	null	{"op": "gte", "field": "meteo.pluie_24h", "value": 30}	{"risque": {"score": 0.72, "libelle": "Lessivage N"}, "alertes": [{"titre": "Lessivage engrais après forte pluie", "niveau": "moyenne", "message": ">30mm : lixiviation N (nitrate) + perte 30-50% fertilisants récents."}], "recommandations": [{"type": "fertilisation", "titre": "Réapplication N fractionnée après drainage", "detail": "Attendre 3-5j drainage sol. Réapporter 30-50% dose N initiale.", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
276	MET-VEN-001	meteo	vent	Vent fort >40 km/h — Maïs verse	\N	null	["montaison", "floraison", "remplissage_grains"]	null	{"op": "gte", "field": "meteo.vent", "value": 40}	{"risque": {"score": 0.8, "libelle": "Verse céréales"}, "alertes": [{"titre": "Vent fort — Risque verse céréales", "niveau": "elevee", "message": "Vent >40km/h à montaison : verse possible si tiges faibles (excès azote)."}], "recommandations": [{"type": "mesure_culturale", "titre": "Inspecter après passage vent fort", "detail": "Redresser plants versés dans 24h si encore verts.", "priorite": 1}, {"type": "surveillance", "titre": "Réduire N si tallage excessif pour la suite", "priorite": 2}]}	elevee	7	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
277	MET-VEN-002	meteo	vent	Vent fort >50 km/h — Arbres fruitiers bris branches	\N	null	null	null	{"op": "gte", "field": "meteo.vent", "value": 50}	{"risque": {"score": 0.82, "libelle": "Bris mécaniques + infections"}, "alertes": [{"titre": "Vent violent — Bris branches fruitiers", "niveau": "elevee", "message": "Vent >50km/h : bris branches, chute fruits prématurés, blessures entrées maladies."}], "recommandations": [{"type": "mesure_post_vent", "titre": "Inspecter + protéger blessures", "detail": "Couper bords nets + mastic cicatrisant sur toute coupe.", "priorite": 1, "urgence_jours": 1}, {"dose": "1% badigeon", "type": "traitement_phyto", "titre": "Cuivre sur blessures", "produit": "Bouillie bordelaise", "priorite": 2}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
278	MET-VEN-003	meteo	vent	Harmattan — Stress combiné vent sec froid	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[12, 1, 2]	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 20}, {"op": "lte", "field": "meteo.humidite_rel", "value": 30}, {"op": "lte", "field": "meteo.temp_air", "value": 22}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Stress harmattan"}, "alertes": [{"titre": "Harmattan — Dessèchement cultures", "niveau": "moyenne", "message": "Vent sec froid <30% HR : dessèchement foliaire rapide + évaporation accrue."}], "recommandations": [{"type": "irrigation", "titre": "Augmenter fréquence irrigation", "detail": "Arroser matin. ETP peut doubler avec harmattan.", "priorite": 1}, {"type": "protection", "titre": "Brise-vent naturel ou filet", "detail": "Rangées sorgho ou branchages en barrière vent dominant.", "priorite": 2}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
279	MET-FRO-001	meteo	froid	Nuits fraîches <15°C — Cultures tropicales	\N	null	null	[12, 1, 2]	{"op": "lte", "field": "meteo.temp_air", "value": 15}	{"risque": {"score": 0.72, "libelle": "Stress froid cultures tropicales"}, "alertes": [{"titre": "Nuits froides <15°C — cultures tropicales", "niveau": "moyenne", "message": "T° <15°C la nuit : fructification ralentie, noircissement Papaye, stress Piment."}], "recommandations": [{"type": "protection", "titre": "Voile de forçage si T° <12°C", "detail": "Agrotextile P17 sur arceaux. Protège jusqu'à -3°C.", "priorite": 1}, {"dose": "3 kg/ha foliaire", "type": "fertilisation", "titre": "Apport potassium + calcium pour renforcer parois cellulaires", "produit": "Nitrate de calcium", "priorite": 2}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
280	MET-FRO-002	meteo	froid	Nuits fraîches <12°C — Favorise Mildiou maraîchage	\N	["niayes"]	null	[12, 1, 2, 3]	{"clauses": [{"op": "lte", "field": "meteo.temp_air", "value": 12}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Sporulation nocturne Mildiou"}, "alertes": [{"titre": "Nuit froide humide — Mildiou favori", "niveau": "elevee", "message": "Nuit <12°C + HR>85% : sporulation Phytophthora/Peronospora maximale."}], "recommandations": [{"dose": "2 kg/ha", "type": "traitement_phyto", "titre": "Traitement anti-mildiou le matin", "produit": "Cymoxanil 4% + Mancozèbe 40%", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
281	MET-HUM-001	meteo	humidite	Humidité très élevée >92% — Alerte maladies fongiques généralisée	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 92}, {"op": "between", "field": "meteo.temp_air", "value": 18, "value2": 32}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Conditions épidémiques"}, "alertes": [{"titre": "Humidité >92% — Alerte fongique généralisée", "niveau": "elevee", "message": "HR >92% prolongée : sporulation active pour tous pathogènes fongiques présents."}], "recommandations": [{"dose": "2,5 kg/ha", "type": "traitement_phyto", "titre": "Programme fongique préventif d'urgence", "produit": "Mancozèbe 80WP", "priorite": 1, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
282	MET-HUM-002	meteo	humidite	Humidité très basse <30% — Acariens + stress	\N	null	null	[12, 1, 2, 3]	{"op": "lte", "field": "meteo.humidite_rel", "value": 30}	{"risque": {"score": 0.85, "libelle": "Stress hydrique + acariens"}, "alertes": [{"titre": "Air très sec <30% HR — Acariens + stress hydrique", "niveau": "elevee", "message": "HR <30% : explosions acariens rouges + dessèchement foliaire + ETP doublée."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Acaricide préventif", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 5}, {"type": "irrigation", "titre": "Augmenter fréquence irrigation 20-30%", "priorite": 2, "urgence_jours": 2}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
283	MET-ETP-001	meteo	etp	ETP très élevée >8mm/j — Stress toutes cultures	\N	null	null	null	{"clauses": [{"op": "gte", "field": "meteo.etp", "value": 8}, {"op": "lte", "field": "meteo.pluie_24h", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Déficit hydrique rapide"}, "alertes": [{"titre": "ETP très élevée >8mm/j", "niveau": "elevee", "message": "Demande évaporatoire >8mm/j sans pluie : déficit hydrique 1-2 jours max."}], "recommandations": [{"dose": "6-8 mm/j", "type": "irrigation", "titre": "Irrigation compensatoire 0.8 × ETP", "detail": "Coeff. cultural 0.8-1.1 selon stade.", "priorite": 1, "urgence_jours": 1}]}	elevee	8	0.85	premium	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
284	MET-ETP-002	meteo	etp	ETP modérée + sol sec — Alerte précautionnelle	\N	null	["floraison", "remplissage_grains"]	null	{"clauses": [{"op": "between", "field": "meteo.etp", "value": 5, "value2": 8}, {"op": "lte", "field": "sol.humidite", "value": 35}, {"op": "lte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.75, "libelle": "Stress hydrique imminent"}, "alertes": [{"titre": "ETP + sol sec — Stress imminent céréales", "niveau": "moyenne", "message": "Bilan hydrique négatif 3-5 jours. Surveiller signes flétrissement."}], "recommandations": [{"type": "surveillance", "titre": "Surveiller flétrissement matinal", "detail": "Si flétrissement à 8h : intervention immédiate.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
285	MET-HIV-001	meteo	saison	Premières pluies hivernage — Alerte Pythium et fonte semis	\N	null	["semis", "levee"]	[6, 7]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 20}, {"op": "gte", "field": "sol.humidite", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Fonte semis début hivernage"}, "alertes": [{"titre": "Premières pluies — Risque fonte semis", "niveau": "moyenne", "message": "Premières pluies intenses : sol froid puis chaud + humide = Pythium/Rhizoctonia actifs."}], "recommandations": [{"dose": "3 g Thirame + 2 g Métalaxyl / kg semences", "type": "traitement_semences", "titre": "Traitement semences préventif obligatoire", "produit": "Thirame 80WP + Métalaxyl 35FS", "priorite": 1}]}	moyenne	7	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.148444+00	\N
286	CAL-RIZ-001	calendrier	semis	Riz — Fenêtre de semis vallee du fleuve	\N	["vallee_fleuve"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.6, "libelle": "Décalage calendrier"}, "alertes": [{"titre": "Fenêtre semis riz hivernage", "niveau": "moyenne", "message": "Juin-juillet : période optimale semis riz hivernage. Viser avant 15 juillet."}], "recommandations": [{"type": "planification", "titre": "Semis avant 15 juillet", "detail": "Semis tardif >15 juillet : récolte sous pluies + risque Pyriculariose épiaison.", "priorite": 1}, {"type": "semis", "titre": "Variétés 90-110 jours recommandées", "detail": "Sahel 108, Sahel 305 (IR), NERICA L34.", "priorite": 2}]}	moyenne	7	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
287	CAL-RIZ-002	calendrier	recolte	Riz — Alerte récolte retardée — risque pertes	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pertes récolte retardée"}, "alertes": [{"titre": "Riz mûr — Récolte urgente avant pluies", "niveau": "elevee", "message": "Riz à maturité sous pluies : égrenage, germination sur pied, Fusariose épis."}], "recommandations": [{"type": "recolte", "titre": "Récolter dans les 5-7 jours", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
288	CAL-MIL-001	calendrier	semis	Mil — Fenêtre semis hivernage	\N	["bassin_arachidier", "senegal_oriental", "zone_sylvopastorale"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Décalage semis"}, "alertes": [{"titre": "Fenêtre semis mil", "niveau": "moyenne", "message": "Juillet : après première pluie ≥20mm. Semis tardif >31 juillet réduit rendement 30%."}], "recommandations": [{"type": "semis", "titre": "Semer 48h après première pluie ≥20mm", "detail": "Densité 1-2 graines/poquet, écartement 1m×1m. Démariage à 3 plants.", "priorite": 1}, {"type": "planification", "titre": "Variété Souna 3 ou IBV8004 recommandée", "priorite": 2}]}	moyenne	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
289	CAL-MIL-002	calendrier	fertilisation	Mil — Fenêtre apport urée microdosage J21	\N	null	["levee"]	[7, 8]	{"clauses": [{"op": "between", "field": "culture.jours_semis", "value": 18, "value2": 25}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Fenêtre fertilisation manquée"}, "alertes": [{"titre": "J21 mil — Apport urée microdosage", "niveau": "moyenne", "message": "21 jours après semis : fenêtre critique apport urée microdosage (2g/poquet)."}], "recommandations": [{"dose": "2 g/poquet = 17 kg/ha", "type": "fertilisation", "titre": "Microdosage urée 2g/poquet maintenant", "detail": "Appliquer dans le poquet après pluie. Technique ISSATROP validée ICRISAT.", "produit": "Urée 46%", "priorite": 1}]}	moyenne	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
291	CAL-MAI-001	calendrier	semis	Maïs — Semis précoce recommandé	\N	null	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Calendrier semis"}, "alertes": [{"titre": "Fenêtre semis maïs — semis précoce", "niveau": "moyenne", "message": "Maïs : floraison doit éviter pic chaleur août. Semis juin idéal."}], "recommandations": [{"type": "semis", "titre": "Semer fin juin - début juillet", "detail": "Éviter semis après 20 juillet : floraison tombera en pic chaleur-sécheresse août.", "priorite": 1}]}	moyenne	6	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
292	CAL-MAI-002	calendrier	recolte	Maïs — Récolte et séchage rapide mycotoxines	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.humidite_rel", "value": 75}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Mycotoxines"}, "alertes": [{"titre": "Maïs mûr — Risque mycotoxines si séchage tardif", "niveau": "elevee", "message": "Humidité élevée à récolte : Fusarium + Aspergillus = aflatoxines + fumonisines."}], "recommandations": [{"type": "recolte", "titre": "Récolter à 20-25% humidité grain", "priorite": 1, "urgence_jours": 5}, {"type": "post_recolte", "titre": "Sécher sous 14% humidité en 48h", "priorite": 2}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
293	CAL-ARA-001	calendrier	semis	Arachide — Fenêtre semis critique	\N	["bassin_arachidier"]	null	[6, 7]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [6, 7]}, {"op": "gte", "field": "meteo.pluie_24h", "value": 20}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Calendrier semis"}, "alertes": [{"titre": "Fenêtre semis arachide", "niveau": "moyenne", "message": "Semis idéal après 20mm. Arachide 90j : semis avant 10 juillet nécessaire."}], "recommandations": [{"type": "semis", "titre": "Semer sous 48h après pluie ≥20mm", "detail": "Préparer semences traitées (Thirame + Rhizobium). Densité 15kg/ha gousses décortiquées.", "priorite": 1}]}	moyenne	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
294	CAL-ARA-002	calendrier	recolte	Arachide — Maturité arracher avant sol trop sec	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}	{"risque": {"score": 0.8, "libelle": "Pertes arrachage sol sec"}, "alertes": [{"titre": "Arachide mûre — Arracher avant sol trop sec", "niveau": "elevee", "message": "Sol sec = gousses se détachent au sol = pertes arrachage 15-25%."}], "recommandations": [{"type": "recolte", "titre": "Arracher dans 7-10 jours", "detail": "Sol doit être légèrement humide. Ramasser immédiatement les gousses tombées.", "priorite": 1, "urgence_jours": 7}]}	elevee	8	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
295	CAL-TOM-001	calendrier	semis	Tomate — Fenêtre semis pépinière Niayes	\N	["niayes"]	null	[9, 10, 11]	{"op": "in", "field": "culture.mois", "value": [9, 10, 11]}	{"risque": {"score": 0.45, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis tomate Niayes", "niveau": "faible", "message": "Sept-nov : température optimale pour pépinière tomate. Repiquage 30j après semis."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 25-30 jours avant repiquage", "detail": "Substrat stérilisé. Traitement semences Thirame. Filet 50 mesh TYLCV.", "priorite": 1}]}	faible	5	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
296	CAL-TOM-002	calendrier	fertilisation	Tomate — Fenêtre apport K fructification	\N	null	["floraison"]	null	{"op": "eq", "field": "culture.stade", "value": "floraison"}	{"risque": {"score": 0.65, "libelle": "Fertilisation non adaptée stade"}, "alertes": [{"titre": "Tomate floraison — Augmenter K dès maintenant", "niveau": "moyenne", "message": "À floraison : passer ratio N:K de 2:1 à 1:2. Qualité et conservation fruits."}], "recommandations": [{"dose": "80 kg K₂O/ha restant + réduction N 50%", "type": "fertilisation", "titre": "Augmenter K — réduire N", "produit": "Sulfate de potasse K₂SO₄ 50%", "priorite": 1}]}	moyenne	7	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
297	CAL-TOM-003	calendrier	recolte	Tomate — Récolte précoce si forte pluie	\N	null	["fructification", "maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 60}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}, {"op": "in", "field": "culture.stade", "value": ["fructification", "maturation"]}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Pertes pluie récolte"}, "alertes": [{"titre": "Tomate mûrissante — Récolte avant pourriture", "niveau": "elevee", "message": "Pluies + humidité : fissuration fruits + Botrytis + Anthracnose accélérés."}], "recommandations": [{"type": "recolte", "titre": "Récolter fruits mûrs dans 3-5 jours", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
298	CAL-OIG-001	calendrier	semis	Oignon — Semis pépinière optimal	\N	["niayes", "vallee_fleuve"]	null	[10, 11]	{"op": "in", "field": "culture.mois", "value": [10, 11]}	{"risque": {"score": 0.45, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis oignon en pépinière", "niveau": "faible", "message": "Oct-nov : période optimale pépinière oignon pour culture jan-avril."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 40-45 jours", "detail": "Semer dense 1 g/m² pépinière. Repiquage plants 3 feuilles. Densité 500 000 plants/ha.", "priorite": 1}]}	faible	4	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
299	CAL-OIG-002	calendrier	recolte	Oignon — Maturité — épiderme couché	\N	null	["maturation"]	[3, 4, 5]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "lte", "field": "meteo.pluie_7j", "value": 5}], "operator": "AND"}	{"risque": {"score": 0.7, "libelle": "Fenêtre récolte"}, "alertes": [{"titre": "Oignon mûr — Récolte dans fenêtre optimale", "niveau": "moyenne", "message": "Épiderme couché >70% : récolter en 7-10 jours par temps sec."}], "recommandations": [{"type": "recolte", "titre": "Arracher + sécher 3 semaines au champ", "detail": "Laisser en andains 15-20 jours. Sol sec. Conservation >6 mois.", "priorite": 1}]}	moyenne	6	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
300	CAL-CHO-001	calendrier	semis	Chou — Fenêtre semis saison fraîche	\N	["niayes"]	null	[10, 11, 12]	{"op": "in", "field": "culture.mois", "value": [10, 11, 12]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis chou — saison fraîche", "niveau": "faible", "message": "Oct-déc : T° optimale Brassicacées. Repiquage 30j après semis pépinière."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière + repiquage 4-6 feuilles", "detail": "Variétés Gloria, Copenhagen. Densité 40 000 plants/ha.", "priorite": 1}]}	faible	4	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
301	CAL-PIM-001	calendrier	semis	Piment — Pépinière saison fraîche Niayes	\N	["niayes"]	null	[9, 10, 11]	{"op": "in", "field": "culture.mois", "value": [9, 10, 11]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre pépinière piment", "niveau": "faible", "message": "Sept-nov : T° favorable piment. Cycle 75-90 jours. Repiquage 6-8 feuilles."}], "recommandations": [{"type": "semis_pepiniere", "titre": "Pépinière 35-40 jours sous filet anti-insectes", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
302	CAL-CON-001	calendrier	semis	Concombre — Semis début saison froide	\N	["niayes"]	null	[10, 11, 12, 1, 2]	{"op": "in", "field": "culture.mois", "value": [10, 11, 12, 1, 2]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis concombre Niayes", "niveau": "faible", "message": "Oct-fév : T° 20-28°C optimale concombre. Cycle 50-60 jours."}], "recommandations": [{"type": "semis", "titre": "Semis en place après préparation sol", "detail": "2 graines/poquet 2cm profondeur. Démarier à 1 plant. Paillage plastique noir recommandé.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
303	CAL-PAS-001	calendrier	semis	Pastèque — Fenêtre semis optimale	\N	["niayes", "vallee_fleuve"]	null	[11, 12, 1, 2]	{"op": "in", "field": "culture.mois", "value": [11, 12, 1, 2]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis pastèque", "niveau": "faible", "message": "Nov-fév : T° 22-30°C idéale. Cycle 75-90 jours. Éviter pluies à maturité."}], "recommandations": [{"type": "semis", "titre": "2-3 graines/poquet + retrait à 1 plant", "detail": "Paillage plastique + drip recommandé production intensive.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
304	CAL-GOB-001	calendrier	semis	Gombo — Semis double saison possible	\N	null	null	[4, 5, 9, 10]	{"op": "in", "field": "culture.mois", "value": [4, 5, 9, 10]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis gombo", "niveau": "faible", "message": "Avr-mai (irrigué) ou sept-oct : deux fenêtres possibles. Cycle 60-75j."}], "recommandations": [{"type": "semis", "titre": "Tremper graines 24h avant semis", "detail": "Accélère germination 30-40%. Densité 25 000 plants/ha.", "priorite": 1}]}	faible	4	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
305	CAL-MAG-001	calendrier	taille	Mangue — Taille post-récolte recommandée	\N	null	null	[6, 7, 8]	{"op": "in", "field": "culture.mois", "value": [6, 7, 8]}	{"risque": {"score": 0.5, "libelle": "Fenêtre taille"}, "alertes": [{"titre": "Fenêtre taille post-récolte mangue", "niveau": "faible", "message": "Juillet-août : tailler immédiatement après récolte. Favorise végétation + floraison N+1."}], "recommandations": [{"type": "taille", "titre": "Taille d'éclaircissement + retrait bois mort", "detail": "Couper 20-30% de la couronne. Ouvrir vers l'intérieur. Protéger coupes.", "priorite": 1}, {"dose": "badigeon 1%", "type": "traitement_phyto", "titre": "Cuivre sur coupes fraîches", "produit": "Oxychlorure de cuivre", "priorite": 2}]}	faible	5	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
306	CAL-MAG-002	calendrier	fertilisation	Mangue — Fertilisation floraison J-30	\N	null	null	[1, 2]	{"op": "in", "field": "culture.mois", "value": [1, 2]}	{"risque": {"score": 0.65, "libelle": "Fertilisation manquée pré-floraison"}, "alertes": [{"titre": "Mangue — Fertilisation pré-floraison", "niveau": "moyenne", "message": "30j avant floraison : apport K + micronutriments pour qualité floraison."}], "recommandations": [{"dose": "2 kg/arbre sol + 3 L/ha foliaire", "type": "fertilisation", "titre": "NPK + micronutriments foliaires", "produit": "NPK 0-10-40 + bore 0.1%", "priorite": 1}]}	moyenne	6	0.75	premium	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
307	CAL-ANA-001	calendrier	recolte	Anacarde — Fenêtre récolte noix cajou	\N	null	null	[3, 4, 5]	{"op": "in", "field": "culture.mois", "value": [3, 4, 5]}	{"risque": {"score": 0.75, "libelle": "Perte qualité noix cajou"}, "alertes": [{"titre": "Récolte anacarde — Ramassage quotidien", "niveau": "moyenne", "message": "Mars-mai : ramasser noix TOUS LES JOURS. Noix au sol >48h perdent qualité."}], "recommandations": [{"type": "recolte", "titre": "Ramassage quotidien noix tombées", "detail": "Sécher sous 3% humidité dans 48h. Stocker en sacs aérés, lieu sec.", "priorite": 1}]}	moyenne	7	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
308	CAL-BAN-001	calendrier	recolte	Banane — Coupe régimes avant maturité terrain	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Perte post-récolte accélérée"}, "alertes": [{"titre": "Banane mûrissante — Couper régimes urgence", "niveau": "elevee", "message": "T° chaude + humidité : jaunissement rapide + Anthracnose post-récolte accéléré."}], "recommandations": [{"type": "recolte", "titre": "Couper régimes à 3/4 couleur jaune", "detail": "Mûrissage en chambre préférable. Chaîne froide 13°C si export.", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.8	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
309	CAL-PAP-001	calendrier	recolte	Papaye — Récolte fréquente continue	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.72, "libelle": "Surmaturation pertes"}, "alertes": [{"titre": "Papaye mûrissante — Récolte 3x/semaine", "niveau": "moyenne", "message": "En chaleur : papaye passe de verte à mûre en 2-3j. Pertes si non récoltée."}], "recommandations": [{"type": "recolte", "titre": "Récolter 3 fois par semaine minimum", "detail": "Cueillir à 10% jaune. Mûrir à l'ombre à température ambiante.", "priorite": 1}]}	moyenne	6	0.75	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
310	CAL-MAN-001	calendrier	recolte	Manioc — Récolte avant engorgement saison pluies	\N	null	null	[5, 6]	{"clauses": [{"op": "in", "field": "culture.mois", "value": [5, 6]}, {"op": "gte", "field": "culture.jours_semis", "value": 270}], "operator": "AND"}	{"risque": {"score": 0.65, "libelle": "Pourriture racines saison pluies"}, "alertes": [{"titre": "Manioc >9 mois — Récolter avant hivernage", "niveau": "moyenne", "message": "Manioc >9 mois : récolter avant retour pluies (pourriture) ou poursuivre jusqu'à 18 mois max."}], "recommandations": [{"type": "planification", "titre": "Décider : récolter mai-juin OU laisser jusqu'à 15-18 mois en sol drainé", "detail": "Sol hydromorphe : récolter impérativement avant pluies.", "priorite": 1}]}	moyenne	6	0.72	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
311	CAL-NIE-001	calendrier	semis	Niébé — Double semis possible	\N	null	null	[7, 8]	{"op": "in", "field": "culture.mois", "value": [7, 8]}	{"risque": {"score": 0.4, "libelle": "Calendrier"}, "alertes": [{"titre": "Fenêtre semis niébé", "niveau": "faible", "message": "Juil-août : semis principal. Variétés 60-75j recommandées pour double culture."}], "recommandations": [{"type": "semis", "titre": "Traitement semences Rhizobium + Thirame", "detail": "2-3 graines/poquet. Écartement 60×60cm. Inoculant Bradyrhizobium indispensable.", "priorite": 1}]}	faible	4	0.78	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
312	CAL-NIE-002	calendrier	recolte	Niébé — Récolte gousses sèches avant pluies	\N	null	["maturation"]	[10, 11]	{"clauses": [{"op": "eq", "field": "culture.stade", "value": "maturation"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 15}], "operator": "AND"}	{"risque": {"score": 0.82, "libelle": "Pertes récolte pluie"}, "alertes": [{"titre": "Niébé mûr — Récolter avant pluie", "niveau": "elevee", "message": "Gousses sèches sous pluie : égrenage + Bruche accélérée. Récolter immédiatement."}], "recommandations": [{"type": "recolte", "titre": "Récolter et battre dans 3-5 jours", "priorite": 1, "urgence_jours": 3}]}	elevee	7	0.82	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
313	CAL-SES-001	calendrier	recolte	Sésame — Récolte avant ouverture capsules	\N	null	["maturation"]	[10, 11]	{"op": "eq", "field": "culture.stade", "value": "maturation"}	{"risque": {"score": 0.88, "libelle": "Égrenage spontané = perte totale"}, "alertes": [{"titre": "Sésame mûr — Récolter avant égrenage", "niveau": "elevee", "message": "Capsules sésame s'ouvrent SPONTANÉMENT. Récolter quand 1/3 bas commence à jaunir."}], "recommandations": [{"type": "recolte", "titre": "Couper tiges + sécher en fagots retournés 7-10j", "detail": "Sécher debout en gerbes à l'ombre. Battre sur bâche.", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.282435+00	\N
314	REN-RIZ-001	rendement	risque_rendement	Riz — Risque rendement élevé — Multiple stress	\N	null	["tallage", "montaison", "epiaison"]	null	{"clauses": [{"clauses": [{"op": "lte", "field": "sol.pH", "value": 5.5}, {"op": "lte", "field": "sol.azote", "value": 80}], "operator": "AND"}, {"clauses": [{"op": "lte", "field": "sol.humidite", "value": 40}, {"op": "lte", "field": "meteo.pluie_7j", "value": 10}], "operator": "AND"}], "operator": "OR"}	{"risque": {"score": 0.85, "libelle": "Rendement réduit riz"}, "alertes": [{"titre": "Risque rendement riz — actions correctrices urgentes", "niveau": "elevee", "message": "Combinaison de facteurs limitants : rendement potentiel réduit de 30-50%."}], "recommandations": [{"type": "fertilisation", "titre": "Corriger N + chaulage si pH<5.5", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation d'urgence si stress hydrique", "priorite": 2}]}	elevee	9	0.82	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
315	REN-RIZ-002	rendement	optimisation	Riz — Conditions optimales rendement maximum	\N	null	["tallage", "montaison"]	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 6.0, "value2": 7.0}, {"op": "gte", "field": "sol.azote", "value": 100}, {"op": "gte", "field": "sol.phosphore", "value": 15}, {"op": "gte", "field": "sol.humidite", "value": 70}], "operator": "AND"}	{"risque": {"score": 0.2, "libelle": "Risque faible"}, "alertes": [{"titre": "Conditions optimales riz — Maintenir", "niveau": "faible", "message": "Sol et eau en conditions idéales. Maintenir programme actuel."}], "recommandations": [{"type": "surveillance", "titre": "Maintenir surveillance maladies uniquement", "detail": "Sol OK. Focus sur Pyriculariose en tallage.", "priorite": 1}]}	faible	3	0.85	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
316	REN-MAI-001	rendement	risque_rendement	Maïs — Risque rendement — Carence N + stress eau floraison	\N	null	["floraison"]	null	{"clauses": [{"op": "lte", "field": "sol.azote", "value": 80}, {"op": "lte", "field": "sol.humidite", "value": 45}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement maïs très bas"}, "alertes": [{"titre": "Double stress maïs floraison — Risque récolte très faible", "niveau": "critique", "message": "Carence N + stress hydrique simultanés à floraison : rendement <50% potentiel."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation immédiate 40-50mm", "priorite": 1, "urgence_jours": 1}, {"type": "fertilisation", "titre": "Urée foliaire 2% si sol trop sec pour incorporer", "priorite": 2}]}	critique	10	0.88	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
317	REN-MIL-001	rendement	risque_rendement	Mil — Risque rendement — Striga + sol pauvre	\N	["bassin_arachidier", "senegal_oriental"]	null	null	{"clauses": [{"op": "contains", "field": "obs.ravageurs", "value": "striga"}, {"op": "lte", "field": "sol.phosphore", "value": 8}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement quasi nul"}, "alertes": [{"titre": "Mil — Striga + carence P = récolte quasi nulle", "niveau": "critique", "message": "Striga + sol très pauvre : rendement <200 kg/ha possible. Intervention radicale."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher Striga AVANT floraison", "priorite": 1, "urgence_jours": 3}, {"dose": "1 cuillère/poquet", "type": "fertilisation", "titre": "DAP en microdosage urgence", "produit": "DAP 18-46-0", "priorite": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
318	REN-ARA-001	rendement	risque_rendement	Arachide — Risque rendement — Aflatoxine gousses	\N	null	["fructification", "maturation"]	[9, 10, 11]	{"clauses": [{"op": "gte", "field": "sol.humidite", "value": 70}, {"op": "gte", "field": "meteo.temp_air", "value": 28}, {"op": "gte", "field": "meteo.pluie_7j", "value": 30}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Aflatoxine rendement commercial"}, "alertes": [{"titre": "Arachide — Risque aflatoxine élevé", "niveau": "elevee", "message": "Chaud + humide à fructification : Aspergillus flavus produit aflatoxines. Valorisation commerciale à risque."}], "recommandations": [{"type": "recolte", "titre": "Récolter dès maturité sans délai", "priorite": 1, "urgence_jours": 7}, {"type": "post_recolte", "titre": "Séchage rapide <12% humidité", "detail": "Délai max 48h entre arrachage et séchage.", "priorite": 2}]}	elevee	9	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
319	REN-SOR-001	rendement	risque_rendement	Sorgho — Risque rendement — Cécidomyie + pluie floraison	\N	null	["floraison"]	[8, 9]	{"clauses": [{"op": "gte", "field": "meteo.humidite_rel", "value": 80}, {"op": "contains", "field": "obs.ravageurs", "value": "cecidomyie"}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Rendement grains nul"}, "alertes": [{"titre": "Cécidomyie + humidité floraison sorgho", "niveau": "elevee", "message": "Combinaison Cécidomyie + conditions humides : pertes grains jusqu'à 100% sur panicule."}], "recommandations": [{"dose": "1,5 L/ha", "type": "traitement_phyto", "titre": "Malathion début floraison urgence", "produit": "Malathion 57EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
320	REN-NIE-001	rendement	risque_rendement	Niébé — Risque rendement — Bruche + stockage	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 26}, {"op": "between", "field": "meteo.humidite_rel", "value": 60, "value2": 80}], "operator": "AND"}	{"risque": {"score": 0.9, "libelle": "Perte totale stockage"}, "alertes": [{"titre": "Risque Bruche niébé — Perte stockage", "niveau": "elevee", "message": "Callosobruchus maculatus : 100% graines trouées en 3 mois si non traité."}], "recommandations": [{"dose": "3 comprimés/tonne", "type": "post_recolte", "titre": "Traitement stockage Phosphine OU huile neem", "produit": "Phosphure d'aluminium", "priorite": 1, "urgence_jours": 5}]}	elevee	9	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
321	REN-TOM-001	rendement	risque_rendement	Tomate — Risque rendement — BER + Mildiou + stress eau	\N	null	["fructification"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 60}, {"op": "lte", "field": "sol.humidite", "value": 45}, {"op": "gte", "field": "meteo.humidite_rel", "value": 85}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Perte récolte tomate"}, "alertes": [{"titre": "Tomate — Triple stress fructification", "niveau": "critique", "message": "Carence K + stress hydrique + humidité élevée = BER + Mildiou + chute fleurs simultanés."}], "recommandations": [{"type": "irrigation", "titre": "Irrigation régulière urgence", "priorite": 1, "urgence_jours": 1}, {"type": "fertilisation", "titre": "K₂SO₄ + nitrate calcium foliaire", "priorite": 2}, {"type": "traitement_phyto", "titre": "Fongicide Mildiou", "priorite": 3, "urgence_jours": 2}]}	critique	10	0.88	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
322	REN-OIG-001	rendement	risque_rendement	Oignon — Risque rendement — Bulbes petits conservation faible	\N	null	["bulbaison"]	null	{"clauses": [{"op": "lte", "field": "sol.potassium", "value": 60}, {"op": "lte", "field": "sol.azote", "value": 60}, {"op": "lte", "field": "sol.humidite", "value": 45}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Faible rendement commercial oignon"}, "alertes": [{"titre": "Oignon — Carence NPK + stress hydrique bulbaison", "niveau": "elevee", "message": "Bulbaison compromettante : calibre réduit + conservation <2 mois."}], "recommandations": [{"type": "fertilisation", "titre": "K₂SO₄ + irrigation compensatoire urgence", "priorite": 1}, {"type": "irrigation", "titre": "Irrigation 4-5 mm/j maintenant", "priorite": 2, "urgence_jours": 1}]}	elevee	8	0.82	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
323	REN-PIM-001	rendement	risque_rendement	Piment — Risque rendement — Chaleur + Virus + Thrips	\N	null	["floraison", "fructification"]	null	{"clauses": [{"op": "gte", "field": "meteo.temp_air", "value": 35}, {"op": "contains", "field": "obs.ravageurs", "value": "thrips"}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Perte récolte piment"}, "alertes": [{"titre": "Piment — Chaleur + Thrips = chute récolte", "niveau": "elevee", "message": "Chaleur >35°C + Thrips : avortement fleurs + transmission TSWV. Risque zéro récolte."}], "recommandations": [{"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine anti-thrips urgent", "produit": "Abamectine 1.8EC", "priorite": 1, "urgence_jours": 2}, {"type": "irrigation", "titre": "Irrigation matin tôt pour rafraîchir", "priorite": 2, "urgence_jours": 1}]}	elevee	9	0.85	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
324	REN-MAG-001	rendement	risque_rendement	Mangue — Risque récolte faible — Oïdium + pluies floraison	\N	null	["floraison"]	[2, 3, 4]	{"clauses": [{"op": "gte", "field": "meteo.pluie_24h", "value": 10}, {"op": "contains", "field": "obs.symptomes", "value": "oidium"}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Perte récolte mangue"}, "alertes": [{"titre": "Mangue — Oïdium + pluies floraison = récolte compromise", "niveau": "critique", "message": "Oïdium actif + pluies à floraison : perte 50-80% inflorescences possible."}], "recommandations": [{"dose": "3 kg Soufre + 0,5 L Tebu/ha", "type": "traitement_phyto", "titre": "Soufre + fongicide curatif floraison", "produit": "Soufre 80WP + Tebuconazole 25EC", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.9	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
325	REN-ANA-001	rendement	risque_rendement	Anacarde — Risque rendement noix — Anthracnose + pluies	\N	null	["floraison", "nouaison"]	[3, 4, 5]	{"clauses": [{"op": "gte", "field": "meteo.pluie_7j", "value": 40}, {"op": "gte", "field": "meteo.humidite_rel", "value": 80}], "operator": "AND"}	{"risque": {"score": 0.85, "libelle": "Perte noix cajou"}, "alertes": [{"titre": "Anthracnose anacarde + pluies = pertes noix", "niveau": "elevee", "message": "Pluies prolongées à nouaison : Colletotrichum cause chute noix jusqu'à 60%."}], "recommandations": [{"dose": "1 kg/ha", "type": "traitement_phyto", "titre": "Carbendazime + cuivre anti-Anthracnose", "produit": "Carbendazime 50WP", "priorite": 1, "urgence_jours": 3}]}	elevee	8	0.85	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
326	REN-BAN-001	rendement	risque_rendement	Banane — Risque rendement — Sigatoka noire sévère	\N	["casamance"]	null	[7, 8, 9, 10]	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "sigatoka"}, {"op": "gte", "field": "meteo.pluie_7j", "value": 50}], "operator": "AND"}	{"risque": {"score": 0.92, "libelle": "Rendement commercial nul"}, "alertes": [{"titre": "Sigatoka noire active + pluies = mûrissement prématuré", "niveau": "critique", "message": "Sigatoka sévère : défoliation >50% = régimes mûrissent 4-6 semaines trop tôt."}], "recommandations": [{"dose": "0,8 L/ha", "type": "traitement_phyto", "titre": "Programme fongicide intensif", "produit": "Propiconazole 25EC", "priorite": 1, "urgence_jours": 2}]}	critique	10	0.9	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
328	REN-MAN-001	rendement	risque_rendement	Manioc — CMD + qualité tubercules	\N	null	null	null	{"clauses": [{"op": "contains", "field": "obs.symptomes", "value": "mosaique_manioc"}, {"op": "contains", "field": "obs.ravageurs", "value": "acarien_vert"}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Perte rendement manioc critique"}, "alertes": [{"titre": "Manioc — CMD + Acarien vert = rendement nul", "niveau": "critique", "message": "Mosaïque + Acarien vert simultanés : perte rendement 80-100%."}], "recommandations": [{"type": "mesure_culturale", "titre": "Arracher plants malades", "priorite": 1, "urgence_jours": 1}, {"dose": "0,5 L/ha", "type": "traitement_phyto", "titre": "Abamectine anti-acarien", "produit": "Abamectine 1.8EC", "priorite": 2, "urgence_jours": 3}, {"type": "mesure_culturale", "titre": "Replanter boutures certifiées CMD-résistantes", "priorite": 3}]}	critique	10	0.92	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
329	REN-SES-001	rendement	risque_rendement	Sésame — Risque rendement nul — égrenage avant récolte	\N	null	["maturation"]	null	{"clauses": [{"op": "gte", "field": "meteo.vent", "value": 30}, {"op": "eq", "field": "culture.stade", "value": "maturation"}], "operator": "AND"}	{"risque": {"score": 0.95, "libelle": "Perte totale égrenage"}, "alertes": [{"titre": "Sésame mûr + vent fort = RÉCOLTER IMMÉDIATEMENT", "niveau": "critique", "message": "Vent >30km/h sur sésame mûr : ouverture capsules + égrenage = pertes 100% en 1 jour."}], "recommandations": [{"type": "recolte", "titre": "Couper tiges AUJOURD'HUI — urgence absolue", "detail": "Couper à la base. Lier en gerbes immédiatement. Battre dans 48h.", "priorite": 1, "urgence_jours": 1}]}	critique	10	0.95	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
330	REN-GEN-001	rendement	optimisation	Conditions optimales sol — Rendement maximum possible	\N	null	null	null	{"clauses": [{"op": "between", "field": "sol.pH", "value": 6.0, "value2": 7.0}, {"op": "gte", "field": "sol.azote", "value": 100}, {"op": "gte", "field": "sol.phosphore", "value": 20}, {"op": "gte", "field": "sol.potassium", "value": 100}, {"op": "gte", "field": "sol.matiere_organique", "value": 2.0}], "operator": "AND"}	{"risque": {"score": 0.15, "libelle": "Risque rendement faible"}, "alertes": [{"titre": "Excellentes conditions sol — Rendement optimal", "niveau": "faible", "message": "Sol en conditions idéales. Facteur limitant = phytosanitaire uniquement."}], "recommandations": [{"type": "surveillance", "titre": "Programme prophylactique maladies/ravageurs uniquement", "detail": "Sol non limitant. Concentrer efforts sur protection phytosanitaire.", "priorite": 1}]}	faible	3	0.85	premium	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
331	REN-GEN-002	rendement	risque_rendement	Sol très dégradé — Rendement faible garanti	\N	null	null	null	{"clauses": [{"op": "lte", "field": "sol.matiere_organique", "value": 0.5}, {"op": "lte", "field": "sol.phosphore", "value": 6}, {"op": "lte", "field": "sol.azote", "value": 40}], "operator": "AND"}	{"risque": {"score": 0.88, "libelle": "Sol dégradé rendement bas"}, "alertes": [{"titre": "Sol très dégradé — Rendement <50% potentiel garanti", "niveau": "elevee", "message": "Triple carence P + N + MO <0.5% : même avec bonnes pluies, rendement sera faible."}], "recommandations": [{"dose": "10 t/ha", "type": "amendement_organique", "titre": "Compost 10t/ha avant plantation", "produit": "Fumier composté", "priorite": 1}, {"dose": "50 kg DAP + 40 kg Urée/ha fractionnés", "type": "fertilisation", "titre": "Programme NPK complet + microdosage", "produit": "DAP 18-46-0 + Urée 46%", "priorite": 2}]}	elevee	8	0.88	gratuit	t	\N	1.0	2026-06-09 11:56:46.391675+00	\N
\.


--
-- Data for Name: re_regles_cultures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles_cultures (id, regle_id, culture_id, notes) FROM stdin;
421	332	40	\N
422	333	40	\N
79	79	21	\N
80	80	21	\N
81	81	21	\N
82	82	21	\N
83	83	21	\N
84	84	21	\N
85	85	21	\N
86	86	24	\N
87	87	24	\N
88	88	24	\N
89	89	24	\N
90	90	24	\N
91	91	25	\N
92	92	25	\N
93	93	25	\N
94	94	25	\N
95	95	22	\N
96	96	22	\N
97	97	22	\N
98	98	22	\N
99	99	23	\N
100	100	23	\N
101	101	23	\N
102	102	23	\N
103	103	26	\N
104	104	26	\N
105	105	26	\N
106	106	26	\N
107	107	27	\N
108	108	27	\N
109	109	27	\N
110	110	27	\N
111	111	28	\N
112	112	28	\N
113	113	28	\N
114	114	28	\N
115	115	29	\N
116	116	29	\N
117	117	29	\N
118	118	29	\N
119	119	29	\N
120	120	29	\N
121	121	29	\N
122	122	31	\N
123	123	31	\N
124	124	31	\N
125	125	31	\N
126	126	33	\N
127	127	33	\N
128	128	33	\N
129	129	34	\N
130	130	34	\N
131	131	34	\N
132	132	30	\N
133	133	30	\N
134	134	30	\N
135	135	32	\N
136	136	32	\N
137	137	32	\N
138	138	35	\N
139	139	35	\N
140	140	35	\N
141	141	36	\N
142	142	36	\N
143	143	36	\N
144	144	37	\N
145	145	37	\N
146	146	37	\N
147	147	37	\N
148	148	38	\N
149	149	38	\N
150	150	38	\N
151	151	39	\N
152	152	39	\N
153	153	39	\N
154	154	40	\N
155	155	40	\N
156	156	40	\N
157	157	21	\N
158	158	21	\N
159	159	21	\N
160	160	21	\N
161	161	24	\N
162	162	24	\N
163	163	24	\N
164	164	25	\N
165	165	25	\N
166	166	25	\N
167	167	25	\N
168	168	22	\N
169	169	22	\N
170	170	22	\N
171	171	22	\N
172	172	23	\N
173	173	23	\N
174	174	23	\N
175	175	26	\N
176	176	26	\N
177	177	26	\N
178	178	26	\N
179	179	29	\N
180	180	29	\N
181	181	29	\N
182	182	29	\N
183	183	31	\N
184	184	31	\N
185	185	33	\N
186	186	34	\N
187	187	34	\N
188	188	30	\N
189	189	30	\N
190	190	32	\N
191	191	35	\N
192	192	28	\N
193	193	28	\N
194	194	27	\N
195	195	37	\N
196	196	37	\N
197	197	38	\N
198	198	39	\N
199	199	40	\N
200	200	36	\N
201	201	40	\N
202	202	21	\N
203	203	21	\N
204	204	21	\N
205	205	21	\N
206	206	24	\N
207	207	24	\N
208	208	24	\N
209	209	25	\N
210	210	25	\N
211	211	22	\N
212	212	22	\N
213	213	22	\N
214	214	23	\N
215	215	23	\N
216	216	26	\N
217	217	26	\N
218	218	27	\N
219	219	28	\N
220	220	28	\N
221	221	29	\N
222	222	29	\N
223	223	29	\N
224	224	29	\N
225	225	31	\N
226	226	33	\N
227	227	34	\N
228	228	34	\N
229	229	30	\N
230	230	30	\N
231	231	37	\N
232	232	38	\N
233	233	32	\N
234	234	35	\N
235	235	36	\N
236	236	39	\N
237	237	40	\N
238	238	29	\N
239	238	31	\N
240	238	33	\N
241	238	34	\N
242	238	30	\N
243	239	21	\N
244	239	22	\N
245	239	24	\N
246	239	25	\N
247	239	23	\N
248	240	21	\N
249	241	21	\N
250	242	21	\N
251	243	24	\N
252	244	24	\N
253	245	22	\N
254	246	22	\N
255	247	23	\N
256	248	25	\N
257	249	29	\N
258	250	29	\N
259	251	30	\N
260	252	30	\N
261	253	34	\N
262	254	31	\N
263	255	35	\N
264	256	36	\N
265	257	32	\N
266	258	37	\N
267	259	37	\N
268	260	39	\N
269	261	40	\N
270	262	38	\N
271	263	26	\N
272	264	27	\N
273	265	28	\N
274	266	33	\N
275	267	29	\N
276	267	31	\N
277	267	33	\N
278	267	32	\N
279	267	35	\N
280	268	21	\N
281	268	22	\N
282	268	24	\N
283	268	25	\N
284	269	29	\N
285	269	31	\N
286	269	34	\N
287	269	30	\N
288	269	36	\N
289	270	24	\N
290	270	25	\N
291	270	23	\N
292	270	26	\N
293	270	22	\N
294	271	37	\N
295	271	38	\N
296	271	39	\N
297	271	40	\N
298	272	28	\N
299	272	27	\N
300	272	23	\N
301	273	29	\N
302	273	31	\N
303	273	33	\N
304	273	40	\N
305	273	27	\N
306	274	21	\N
307	274	22	\N
308	274	29	\N
309	274	31	\N
310	274	33	\N
311	274	34	\N
312	275	29	\N
313	275	22	\N
314	275	30	\N
315	275	31	\N
316	275	34	\N
317	276	22	\N
318	276	25	\N
319	276	24	\N
320	277	37	\N
321	277	38	\N
322	277	39	\N
323	277	40	\N
324	278	29	\N
325	278	31	\N
326	278	30	\N
327	278	34	\N
328	278	32	\N
329	279	29	\N
330	279	31	\N
331	279	33	\N
332	279	40	\N
333	279	35	\N
334	280	29	\N
335	280	34	\N
336	280	30	\N
337	280	31	\N
338	281	21	\N
339	281	22	\N
340	281	29	\N
341	281	31	\N
342	281	34	\N
343	281	35	\N
344	281	36	\N
345	282	29	\N
346	282	31	\N
347	282	33	\N
348	282	28	\N
349	282	40	\N
350	282	36	\N
351	283	29	\N
352	283	22	\N
353	283	30	\N
354	283	21	\N
355	283	31	\N
356	283	34	\N
357	284	24	\N
358	284	25	\N
359	284	26	\N
360	284	23	\N
361	284	27	\N
362	285	24	\N
363	285	25	\N
364	285	22	\N
365	285	26	\N
366	285	23	\N
367	285	27	\N
368	286	21	\N
369	287	21	\N
370	288	24	\N
371	289	24	\N
372	290	25	\N
373	291	22	\N
374	292	22	\N
375	293	23	\N
376	294	23	\N
377	295	29	\N
378	296	29	\N
379	297	29	\N
380	298	30	\N
381	299	30	\N
382	300	34	\N
383	301	31	\N
384	302	35	\N
385	303	36	\N
386	304	32	\N
387	305	37	\N
388	306	37	\N
389	307	38	\N
390	308	39	\N
391	309	40	\N
392	310	28	\N
393	311	26	\N
394	312	26	\N
395	313	27	\N
396	314	21	\N
397	315	21	\N
398	316	22	\N
399	317	24	\N
400	318	23	\N
401	319	25	\N
402	320	26	\N
403	321	29	\N
404	322	30	\N
405	323	31	\N
406	324	37	\N
407	325	38	\N
408	326	39	\N
409	327	40	\N
410	328	28	\N
411	329	27	\N
412	330	29	\N
413	330	22	\N
414	330	21	\N
415	330	30	\N
416	331	24	\N
417	331	25	\N
418	331	23	\N
419	331	26	\N
420	331	22	\N
\.


--
-- Data for Name: re_regles_entites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_regles_entites (id, regle_id, entite_type, entite_id) FROM stdin;
79	79	maladie	66
80	80	maladie	66
81	81	maladie	68
82	82	maladie	68
83	83	maladie	67
84	84	maladie	70
85	85	maladie	69
86	86	maladie	79
87	87	maladie	79
88	88	maladie	81
89	89	maladie	80
90	90	maladie	82
91	91	maladie	83
92	92	maladie	83
93	93	maladie	85
94	94	maladie	86
95	95	maladie	72
96	96	maladie	73
97	97	maladie	71
98	98	maladie	74
99	99	maladie	75
100	100	maladie	75
101	101	maladie	76
102	102	maladie	78
103	103	maladie	89
104	104	maladie	90
105	105	maladie	87
106	106	maladie	88
107	107	maladie	91
108	108	maladie	91
109	109	maladie	93
110	110	maladie	92
111	111	maladie	94
112	112	maladie	95
113	113	maladie	96
114	114	maladie	97
115	115	maladie	98
116	116	maladie	98
117	117	maladie	99
118	118	maladie	102
119	119	maladie	102
120	120	maladie	100
121	121	maladie	101
122	122	maladie	106
123	123	maladie	102
124	124	maladie	107
125	125	maladie	108
126	126	maladie	112
127	127	maladie	102
128	128	maladie	99
129	129	maladie	115
130	130	maladie	113
131	131	maladie	114
132	132	maladie	103
133	133	maladie	104
134	134	maladie	105
135	135	maladie	110
136	136	maladie	109
137	137	maladie	111
138	138	maladie	116
139	139	maladie	117
140	140	maladie	118
141	141	maladie	119
142	142	maladie	116
143	143	maladie	118
144	144	maladie	120
145	145	maladie	121
146	146	maladie	123
147	147	maladie	122
148	148	maladie	124
149	149	maladie	125
150	150	maladie	123
151	151	maladie	127
152	152	maladie	126
153	153	maladie	128
154	154	maladie	129
155	155	maladie	131
156	156	maladie	130
157	157	ravageur	54
158	158	ravageur	54
159	159	ravageur	56
160	160	ravageur	55
161	161	ravageur	65
162	162	ravageur	64
163	163	ravageur	55
164	164	ravageur	68
165	165	ravageur	66
166	166	ravageur	69
167	167	ravageur	67
168	168	ravageur	58
169	169	ravageur	58
170	170	ravageur	59
171	171	ravageur	60
172	172	ravageur	61
173	173	ravageur	62
174	174	ravageur	63
175	175	ravageur	69
176	176	ravageur	72
177	177	ravageur	71
178	178	ravageur	70
179	179	ravageur	79
180	180	ravageur	79
181	181	ravageur	69
182	182	ravageur	80
183	183	ravageur	75
184	184	ravageur	84
185	185	ravageur	88
186	186	ravageur	89
187	187	ravageur	90
188	188	ravageur	81
189	189	ravageur	82
190	190	ravageur	86
191	191	ravageur	91
192	192	ravageur	78
193	193	ravageur	77
194	194	ravageur	75
195	195	ravageur	92
196	196	ravageur	94
197	197	ravageur	95
198	198	ravageur	97
199	199	ravageur	99
200	200	ravageur	91
201	201	ravageur	75
\.


--
-- Data for Name: re_sessions_evaluation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.re_sessions_evaluation (id, org_id, parcelle_id, contexte, regles_evaluees, regles_declenchees, duree_ms, created_at) FROM stdin;
\.


--
-- Data for Name: sc_consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_consultations (id, org_id, parcelle_id, culture_id, type, statut, contexte, resume, nb_photos, created_by, created_at, updated_at) FROM stdin;
4	1	\N	21	MALADIE	EN_COURS	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	\N	0	1	2026-06-09 17:49:31.454173	2026-06-09 17:49:31.454176
6	1	\N	22	FERTILISATION	EN_COURS	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	\N	0	1	2026-06-09 17:49:31.490661	2026-06-09 17:49:31.490665
5	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	\N	0	1	2026-06-09 17:49:31.47411	2026-06-09 17:49:31.922331
7	1	\N	21	MALADIE	EN_COURS	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	\N	0	1	2026-06-09 17:51:10.692098	2026-06-09 17:51:10.692101
9	1	\N	22	FERTILISATION	EN_COURS	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	\N	0	1	2026-06-09 17:51:10.717263	2026-06-09 17:51:10.717265
8	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	\N	0	1	2026-06-09 17:51:10.706094	2026-06-09 17:51:11.132809
10	1	\N	21	MALADIE	ANALYSE	{"mois": 8, "zone_agro": "bassin_arachidier", "culture_id": 21, "stade_actuel": "vegetatif"}	Aucun diagnostic établi. Ajouter des observations pour affiner l'analyse.	0	1	2026-06-09 18:16:40.654335	2026-06-09 18:16:41.344
12	1	\N	22	FERTILISATION	ANALYSE	{"mois": 9, "zone_agro": "bassin_arachidier", "culture_id": 22, "stade_actuel": "floraison"}	Carence probable : Carence Azote (N) (confiance 50%). Suivre le plan de correction fertilisation.	0	1	2026-06-09 18:16:41.109731	2026-06-09 18:16:41.535401
11	1	\N	21	RAVAGEUR	ARCHIVE	{"mois": 7, "zone_agro": "vallee_fleuve", "culture_id": 21, "stade_actuel": "tallage"}	Ravageur probable : Foreur de tige du riz (confiance 30%). Appliquer les mesures de lutte recommandées.	0	1	2026-06-09 18:16:40.890043	2026-06-09 18:16:41.707428
13	3	5	21	MALADIE	ANALYSE	{"culture_id": 21, "stade_actuel": "tallage"}	Aucun diagnostic établi. Ajouter des observations pour affiner l'analyse.	0	3	2026-06-10 05:43:55.32884	2026-06-10 05:44:54.72793
14	5	6	40	MALADIE	EN_COURS	{"culture_id": 40, "stade_actuel": "floraison"}	\N	0	4	2026-06-10 06:13:59.121661	2026-06-10 06:13:59.121665
15	4	7	30	RAVAGEUR	EN_COURS	{"culture_id": 30, "stade_actuel": "bulbaison"}	\N	0	5	2026-06-10 06:13:59.335383	2026-06-10 06:13:59.335387
16	6	8	22	MALADIE	EN_COURS	{"culture_id": 22, "stade_actuel": "levee"}	\N	0	6	2026-06-10 06:13:59.520994	2026-06-10 06:13:59.520997
\.


--
-- Data for Name: sc_diagnostics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_diagnostics (id, consultation_id, rang, entite_type, entite_id, entite_nom, score_confiance, score_rules, score_symptomes, regles_matches, methode, statut, confirme_par, confirme_le, note_expert, created_at) FROM stdin;
1	11	1	RAVAGEUR	54	Foreur de tige du riz	0.3	0	1	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.400991
2	12	1	CARENCE	0	Carence Azote (N)	0.5	0	0.5	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507211
3	12	2	CARENCE	0	Carence Phosphore (P)	0.467	0	0.467	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507216
4	12	3	CARENCE	0	Acidité/Alcalinité sol	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507217
5	12	4	CARENCE	0	Carence Potassium (K)	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507218
6	12	5	CARENCE	0	Faible matière organique	0.4	0	0.4	[]	SYMPTOMES	PROBABLE	\N	\N	\N	2026-06-09 18:16:41.507225
\.


--
-- Data for Name: sc_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_observations (id, consultation_id, type, partie_plante, valeur, note_terrain, created_at) FROM stdin;
1	4	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 17:49:31.565557
2	4	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 17:49:31.59924
3	4	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 17:49:31.618639
4	5	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 17:49:31.635743
5	6	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 17:49:31.74255
6	7	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 17:51:10.757838
7	7	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 17:51:10.77567
8	7	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 17:51:10.798524
9	8	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 17:51:10.816639
10	9	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 17:51:10.916168
11	10	SYMPTOME	FEUILLE	{"code": "taches_brunes", "intensite": "elevee"}	\N	2026-06-09 18:16:41.190088
12	10	SOL	\N	{"pH": 5.8, "azote": 60, "humidite": 65, "phosphore": 12, "potassium": 70}	\N	2026-06-09 18:16:41.227989
13	10	METEO	\N	{"temp_air": 29, "pluie_24h": 15, "humidite_rel": 88}	\N	2026-06-09 18:16:41.248872
14	11	RAVAGEUR_OBSERVE	\N	{"nom": "foreur de tige", "densite": "elevee"}	\N	2026-06-09 18:16:41.26791
15	12	SOL	\N	{"pH": 5.1, "azote": 40, "phosphore": 8, "potassium": 50, "matiere_organique": 0.7}	\N	2026-06-09 18:16:41.458126
16	13	SYMPTOME	FEUILLE	{"densite": "moderee", "description": "Taches brunes elliptiques avec halo jaune, caractéristiques pyriculariose", "localisation": "Tiers supérieur feuilles, bordure parcelle", "surface_touchee_pct": 20}	\N	2026-06-10 05:44:43.899326
17	14	SYMPTOME	FEUILLE	{"densite": "elevee", "description": "Taches chlorotiques jaune-vert sur feuilles, debut extrémités, typique PRSV (virus de la tachure annulaire papaye)", "localisation": "Toutes feuilles adultes, progression ascendante", "surface_touchee_pct": 35}	\N	2026-06-10 06:13:59.259005
18	15	RAVAGEUR_OBSERVE	FEUILLE	{"nom": "Thrips de loignon (Thrips tabaci)", "stade": "larves et adultes", "densite": "forte", "description": "Nombreuses thrips sur feuilles tubulaires, degats mecaniques et transmission virus"}	\N	2026-06-10 06:13:59.461568
19	16	SYMPTOME	RACINE	{"densite": "moderee", "description": "Racinelles brunes et nécrosées, collet mou, plants versent facilement. Typique Pythium ou Fusarium.", "localisation": "Zones basses parcelle, sol plus humide", "surface_touchee_pct": 15}	\N	2026-06-10 06:13:59.637996
\.


--
-- Data for Name: sc_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_photos (id, consultation_id, observation_id, source_photo, filename, url, thumbnail_url, taille_ko, photo_meta, uploaded_at) FROM stdin;
\.


--
-- Data for Name: sc_rapports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_rapports (id, consultation_id, org_id, type, titre, url, taille_ko, genere_par, genere_le, telechargements) FROM stdin;
\.


--
-- Data for Name: sc_suivis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_suivis (id, consultation_id, date_suivi, evolution, efficacite, note, photo_url, created_at) FROM stdin;
1	4	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 17:49:31.854882
2	7	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 17:51:11.037515
3	10	2026-06-16	AMELIORATION	4	60% régression	\N	2026-06-09 18:16:41.623724
\.


--
-- Data for Name: sc_traitements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sc_traitements (id, consultation_id, diagnostic_id, priorite, type, titre, produit, dose, frequence, delai_carence_jours, urgence_jours, detail, date_application, statut, applique_le, note) FROM stdin;
1	11	1	1	SURVEILLANCE	Surveiller évolution : Foreur de tige du riz	\N	\N	\N	\N	7	Diagnostic probable : Foreur de tige du riz (confiance 30%). Prendre photo et contacter technicien si aggravation.	2026-06-16	PLANIFIE	\N	\N
2	12	2	1	SURVEILLANCE	Surveiller évolution : Carence Azote (N)	\N	\N	\N	\N	7	Diagnostic probable : Carence Azote (N) (confiance 50%). Prendre photo et contacter technicien si aggravation.	2026-06-16	PLANIFIE	\N	\N
\.


--
-- Data for Name: service_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_requests (id, user_id, service_id, farm_id, statut, credits_debites, entree, resultat, erreur, cree_le, demarre_le, termine_le) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, code, nom, cout_credits, actif, cree_le) FROM stdin;
1	weather	Alertes meteo	0	t	2026-06-03 11:45:06.691033+00
2	area	Calcul de superficie	10	t	2026-06-03 11:45:06.691033+00
3	soil	Analyse de sol	10	t	2026-06-03 11:45:06.691033+00
4	ndvi	Suivi NDVI / NDRE	10	t	2026-06-03 11:45:06.691033+00
5	yield	Prevision de rendement	10	t	2026-06-03 11:45:06.691033+00
6	irrigation	Irrigation intelligente	10	t	2026-06-03 11:45:06.691033+00
7	disease	Detection de maladies	10	t	2026-06-03 11:45:06.691033+00
8	mapping	Cartographie de parcelle	10	t	2026-06-03 11:45:06.691033+00
9	farm_mgmt	Gestion d'exploitation	10	t	2026-06-03 11:45:06.691033+00
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, org_id, plan, status, started_at, current_period_end, seats, auto_renew) FROM stdin;
1	1	PREMIUM	PAST_DUE	2026-05-31 17:07:05.826261	2026-07-09 15:43:44.0149	1	f
2	2	GRATUIT	ACTIVE	2026-06-09 20:10:06.037836	\N	1	f
3	3	GRATUIT	ACTIVE	2026-06-10 05:40:50.371054	\N	1	f
4	5	GRATUIT	ACTIVE	2026-06-10 06:09:04.129887	\N	1	f
5	4	GRATUIT	ACTIVE	2026-06-10 06:09:04.131256	\N	1	f
6	6	GRATUIT	ACTIVE	2026-06-10 06:09:04.140443	\N	1	f
\.


--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_counters (id, org_id, period, analyses_count) FROM stdin;
1	1	2026-05	1
2	1	2026-06	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, org_id, full_name, email, phone, hashed_password, role, is_active, created_at, account_type) FROM stdin;
1	1	Khadim thiam	thiamkhadim304@gmail.com	784919011	$2b$12$8MqOI1WSkfm6MxaV034y5uhfpMaOim3PXN3cVvDwgKEKBgQ.zBGSW	OWNER	t	2026-05-31 17:07:05.817406	particulier
2	2	Test User	test@agroscan.sn	\N	$2b$12$9ZmItraEGBrO0VYVs0KRSOhvUSFuJtOJXU8ElKkER91VCd6IV9d5C	OWNER	t	2026-06-09 20:10:06.03008	particulier
3	3	Mamadou Diallo	producteur.demo@agroscanpro.com	+221 77 123 45 67	$2b$12$uzINUFVyZ1n4HRpyrSzsSuUISbQ/DCpBQh7.FxF3IywFrd/He36iC	OWNER	t	2026-06-10 05:40:50.361848	particulier
4	5	Ibrahima Diallo	ibrahima.kedougou@agroscanpro.com	+221 77 201 33 44	$2b$12$k9vJCNwQhd6/DhjqvgghqeyH7ISnxOAo5odyt2ie2QvAqNzci4Sr6	OWNER	t	2026-06-10 06:09:04.102932	particulier
5	4	Moussa Sarr	moussa.saintlouis@agroscanpro.com	+221 70 456 78 90	$2b$12$btMmRHbHkE4r1DruYCATM.SvzKt1m7JXtEWuIuL/tKLFfrsaFQPm.	OWNER	t	2026-06-10 06:09:04.106834	particulier
6	6	Fatou Ndiaye	fatou.tamba@agroscanpro.com	+221 76 345 67 89	$2b$12$DcPuCFIqZU/X3fB5Rwg8ouidGOrVI/80bvwXQ.cxNK.NoaJkNlySW	OWNER	t	2026-06-10 06:09:04.114661	particulier
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallets (user_id, solde, maj_le) FROM stdin;
1	30	2026-06-03 16:40:49.739664+00
2	30	2026-06-10 05:30:50.575811+00
3	30	2026-06-10 05:54:09.234435+00
\.


--
-- Name: agro_besoins_eau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_besoins_eau_id_seq', 184, true);


--
-- Name: agro_besoins_nutritionnels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_besoins_nutritionnels_id_seq', 120, true);


--
-- Name: agro_calendriers_culturaux_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_calendriers_culturaux_id_seq', 136, true);


--
-- Name: agro_culture_maladies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_culture_maladies_id_seq', 138, true);


--
-- Name: agro_culture_ravageurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_culture_ravageurs_id_seq', 122, true);


--
-- Name: agro_cultures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_cultures_id_seq', 40, true);


--
-- Name: agro_maladies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_maladies_id_seq', 131, true);


--
-- Name: agro_parametres_climatiques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_parametres_climatiques_id_seq', 40, true);


--
-- Name: agro_ravageurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_ravageurs_id_seq', 100, true);


--
-- Name: agro_recommandations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_recommandations_id_seq', 96, true);


--
-- Name: agro_rendements_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_rendements_reference_id_seq', 120, true);


--
-- Name: agro_stades_phenologiques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_stades_phenologiques_id_seq', 210, true);


--
-- Name: agro_varietes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agro_varietes_id_seq', 154, true);


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analyses_id_seq', 2, true);


--
-- Name: champ_cartographies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_cartographies_id_seq', 9, true);


--
-- Name: champ_infrastructures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_infrastructures_id_seq', 4, true);


--
-- Name: champ_parcelles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_parcelles_id_seq', 8, true);


--
-- Name: champ_sols_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_sols_id_seq', 10, true);


--
-- Name: champ_sources_eau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.champ_sources_eau_id_seq', 7, true);


--
-- Name: credit_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_ledger_id_seq', 3, true);


--
-- Name: credit_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_purchases_id_seq', 1, false);


--
-- Name: farms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.farms_id_seq', 1, false);


--
-- Name: gf_activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_activites_id_seq', 16, true);


--
-- Name: gf_couts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_couts_id_seq', 11, true);


--
-- Name: gf_journal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_journal_id_seq', 2, true);


--
-- Name: gf_main_oeuvre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_main_oeuvre_id_seq', 2, true);


--
-- Name: gf_preuves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gf_preuves_id_seq', 1, true);


--
-- Name: ia_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_config_id_seq', 5, true);


--
-- Name: ia_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_conversations_id_seq', 9, true);


--
-- Name: ia_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_feedback_id_seq', 1, true);


--
-- Name: ia_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_messages_id_seq', 19, true);


--
-- Name: ia_recommandations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ia_recommandations_id_seq', 1, false);


--
-- Name: mt_alertes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_alertes_id_seq', 8, true);


--
-- Name: mt_conditions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_conditions_id_seq', 6, true);


--
-- Name: mt_config_alertes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_config_alertes_id_seq', 5, true);


--
-- Name: mt_planificateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_planificateur_id_seq', 1, false);


--
-- Name: mt_previsions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mt_previsions_id_seq', 10, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organizations_id_seq', 6, true);


--
-- Name: parcelles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.parcelles_id_seq', 5, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 3, true);


--
-- Name: re_declenchements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_declenchements_id_seq', 1, false);


--
-- Name: re_parametres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_parametres_id_seq', 1, false);


--
-- Name: re_regles_cultures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_cultures_id_seq', 422, true);


--
-- Name: re_regles_entites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_entites_id_seq', 201, true);


--
-- Name: re_regles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_regles_id_seq', 333, true);


--
-- Name: re_sessions_evaluation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.re_sessions_evaluation_id_seq', 1, false);


--
-- Name: sc_consultations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_consultations_id_seq', 16, true);


--
-- Name: sc_diagnostics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_diagnostics_id_seq', 6, true);


--
-- Name: sc_observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_observations_id_seq', 19, true);


--
-- Name: sc_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_photos_id_seq', 1, false);


--
-- Name: sc_rapports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_rapports_id_seq', 1, false);


--
-- Name: sc_suivis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_suivis_id_seq', 3, true);


--
-- Name: sc_traitements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sc_traitements_id_seq', 2, true);


--
-- Name: service_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_requests_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 9, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 6, true);


--
-- Name: usage_counters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usage_counters_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: agro_besoins_eau agro_besoins_eau_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau
    ADD CONSTRAINT agro_besoins_eau_pkey PRIMARY KEY (id);


--
-- Name: agro_besoins_nutritionnels agro_besoins_nutritionnels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels
    ADD CONSTRAINT agro_besoins_nutritionnels_pkey PRIMARY KEY (id);


--
-- Name: agro_calendriers_culturaux agro_calendriers_culturaux_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT agro_calendriers_culturaux_pkey PRIMARY KEY (id);


--
-- Name: agro_culture_maladies agro_culture_maladies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_pkey PRIMARY KEY (id);


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_pkey PRIMARY KEY (id);


--
-- Name: agro_cultures agro_cultures_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures
    ADD CONSTRAINT agro_cultures_nom_key UNIQUE (nom);


--
-- Name: agro_cultures agro_cultures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_cultures
    ADD CONSTRAINT agro_cultures_pkey PRIMARY KEY (id);


--
-- Name: agro_maladies agro_maladies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_maladies
    ADD CONSTRAINT agro_maladies_pkey PRIMARY KEY (id);


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_culture_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_culture_id_key UNIQUE (culture_id);


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_pkey PRIMARY KEY (id);


--
-- Name: agro_ravageurs agro_ravageurs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_ravageurs
    ADD CONSTRAINT agro_ravageurs_pkey PRIMARY KEY (id);


--
-- Name: agro_recommandations agro_recommandations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations
    ADD CONSTRAINT agro_recommandations_pkey PRIMARY KEY (id);


--
-- Name: agro_rendements_reference agro_rendements_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_pkey PRIMARY KEY (id);


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_pkey PRIMARY KEY (id);


--
-- Name: agro_varietes agro_varietes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes
    ADD CONSTRAINT agro_varietes_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: champ_cartographies champ_cartographies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies
    ADD CONSTRAINT champ_cartographies_pkey PRIMARY KEY (id);


--
-- Name: champ_infrastructures champ_infrastructures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures
    ADD CONSTRAINT champ_infrastructures_pkey PRIMARY KEY (id);


--
-- Name: champ_parcelles champ_parcelles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_pkey PRIMARY KEY (id);


--
-- Name: champ_sols champ_sols_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols
    ADD CONSTRAINT champ_sols_pkey PRIMARY KEY (id);


--
-- Name: champ_sources_eau champ_sources_eau_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau
    ADD CONSTRAINT champ_sources_eau_pkey PRIMARY KEY (id);


--
-- Name: credit_ledger credit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_pkey PRIMARY KEY (id);


--
-- Name: credit_purchases credit_purchases_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_reference_key UNIQUE (reference);


--
-- Name: farms farms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms
    ADD CONSTRAINT farms_pkey PRIMARY KEY (id);


--
-- Name: gf_activites gf_activites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_pkey PRIMARY KEY (id);


--
-- Name: gf_couts gf_couts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_pkey PRIMARY KEY (id);


--
-- Name: gf_journal gf_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_pkey PRIMARY KEY (id);


--
-- Name: gf_main_oeuvre gf_main_oeuvre_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_pkey PRIMARY KEY (id);


--
-- Name: gf_preuves gf_preuves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_pkey PRIMARY KEY (id);


--
-- Name: ia_config ia_config_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_org_id_key UNIQUE (org_id);


--
-- Name: ia_config ia_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_pkey PRIMARY KEY (id);


--
-- Name: ia_conversations ia_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_pkey PRIMARY KEY (id);


--
-- Name: ia_feedback ia_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_pkey PRIMARY KEY (id);


--
-- Name: ia_messages ia_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_pkey PRIMARY KEY (id);


--
-- Name: ia_recommandations ia_recommandations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_pkey PRIMARY KEY (id);


--
-- Name: mt_alertes mt_alertes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_pkey PRIMARY KEY (id);


--
-- Name: mt_conditions mt_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_pkey PRIMARY KEY (id);


--
-- Name: mt_config_alertes mt_config_alertes_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_org_id_key UNIQUE (org_id);


--
-- Name: mt_config_alertes mt_config_alertes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_pkey PRIMARY KEY (id);


--
-- Name: mt_planificateur mt_planificateur_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_pkey PRIMARY KEY (id);


--
-- Name: mt_previsions mt_previsions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: parcelles parcelles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles
    ADD CONSTRAINT parcelles_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: re_declenchements re_declenchements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements
    ADD CONSTRAINT re_declenchements_pkey PRIMARY KEY (id);


--
-- Name: re_parametres re_parametres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_parametres
    ADD CONSTRAINT re_parametres_pkey PRIMARY KEY (id);


--
-- Name: re_regles_cultures re_regles_cultures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_pkey PRIMARY KEY (id);


--
-- Name: re_regles_cultures re_regles_cultures_regle_id_culture_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_regle_id_culture_id_key UNIQUE (regle_id, culture_id);


--
-- Name: re_regles_entites re_regles_entites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites
    ADD CONSTRAINT re_regles_entites_pkey PRIMARY KEY (id);


--
-- Name: re_regles re_regles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles
    ADD CONSTRAINT re_regles_pkey PRIMARY KEY (id);


--
-- Name: re_sessions_evaluation re_sessions_evaluation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_sessions_evaluation
    ADD CONSTRAINT re_sessions_evaluation_pkey PRIMARY KEY (id);


--
-- Name: sc_consultations sc_consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_pkey PRIMARY KEY (id);


--
-- Name: sc_diagnostics sc_diagnostics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_pkey PRIMARY KEY (id);


--
-- Name: sc_observations sc_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations
    ADD CONSTRAINT sc_observations_pkey PRIMARY KEY (id);


--
-- Name: sc_photos sc_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_pkey PRIMARY KEY (id);


--
-- Name: sc_rapports sc_rapports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_pkey PRIMARY KEY (id);


--
-- Name: sc_suivis sc_suivis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis
    ADD CONSTRAINT sc_suivis_pkey PRIMARY KEY (id);


--
-- Name: sc_traitements sc_traitements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_pkey PRIMARY KEY (id);


--
-- Name: service_requests service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_pkey PRIMARY KEY (id);


--
-- Name: services services_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_code_key UNIQUE (code);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_org_id_key UNIQUE (org_id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: agro_calendriers_culturaux uq_calendrier_culture_zone_saison; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT uq_calendrier_culture_zone_saison UNIQUE (culture_id, zone_agro, saison);


--
-- Name: agro_culture_maladies uq_culture_maladie; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT uq_culture_maladie UNIQUE (culture_id, maladie_id);


--
-- Name: agro_culture_ravageurs uq_culture_ravageur; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT uq_culture_ravageur UNIQUE (culture_id, ravageur_id);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (user_id);


--
-- Name: idx_ledger_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ledger_user_date ON public.credit_ledger USING btree (user_id, cree_le DESC);


--
-- Name: idx_purchases_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_user ON public.credit_purchases USING btree (user_id, cree_le DESC);


--
-- Name: idx_req_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_req_user_date ON public.service_requests USING btree (user_id, cree_le DESC);


--
-- Name: ix_agro_besoins_eau_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_besoins_eau_culture ON public.agro_besoins_eau USING btree (culture_id);


--
-- Name: ix_agro_cal_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cal_culture_zone ON public.agro_calendriers_culturaux USING btree (culture_id, zone_agro);


--
-- Name: ix_agro_cm_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cm_culture ON public.agro_culture_maladies USING btree (culture_id);


--
-- Name: ix_agro_cr_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cr_culture ON public.agro_culture_ravageurs USING btree (culture_id);


--
-- Name: ix_agro_cultures_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_cultures_categorie ON public.agro_cultures USING btree (categorie);


--
-- Name: ix_agro_reco_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_reco_categorie ON public.agro_recommandations USING btree (categorie_reco);


--
-- Name: ix_agro_reco_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_reco_culture_zone ON public.agro_recommandations USING btree (culture_id, zone_agro);


--
-- Name: ix_agro_rendements_culture_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_rendements_culture_zone ON public.agro_rendements_reference USING btree (culture_id, zone_agro, pratique);


--
-- Name: ix_agro_stades_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_stades_culture ON public.agro_stades_phenologiques USING btree (culture_id);


--
-- Name: ix_agro_varietes_culture; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agro_varietes_culture ON public.agro_varietes USING btree (culture_id);


--
-- Name: ix_champ_cartographies_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_cartographies_id ON public.champ_cartographies USING btree (id);


--
-- Name: ix_champ_cartographies_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_cartographies_parcelle_id ON public.champ_cartographies USING btree (parcelle_id);


--
-- Name: ix_champ_infrastructures_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_infrastructures_id ON public.champ_infrastructures USING btree (id);


--
-- Name: ix_champ_infrastructures_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_infrastructures_parcelle_id ON public.champ_infrastructures USING btree (parcelle_id);


--
-- Name: ix_champ_parcelles_code_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_champ_parcelles_code_parcelle ON public.champ_parcelles USING btree (code_parcelle);


--
-- Name: ix_champ_parcelles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_parcelles_id ON public.champ_parcelles USING btree (id);


--
-- Name: ix_champ_parcelles_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_parcelles_org_id ON public.champ_parcelles USING btree (org_id);


--
-- Name: ix_champ_sols_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sols_id ON public.champ_sols USING btree (id);


--
-- Name: ix_champ_sols_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sols_parcelle_id ON public.champ_sols USING btree (parcelle_id);


--
-- Name: ix_champ_sources_eau_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sources_eau_id ON public.champ_sources_eau USING btree (id);


--
-- Name: ix_champ_sources_eau_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_champ_sources_eau_parcelle_id ON public.champ_sources_eau USING btree (parcelle_id);


--
-- Name: ix_gf_activites_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_date ON public.gf_activites USING btree (date_prevue);


--
-- Name: ix_gf_activites_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_org ON public.gf_activites USING btree (org_id);


--
-- Name: ix_gf_activites_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_parcelle ON public.gf_activites USING btree (parcelle_id);


--
-- Name: ix_gf_activites_statut; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_statut ON public.gf_activites USING btree (statut);


--
-- Name: ix_gf_activites_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_activites_type ON public.gf_activites USING btree (type);


--
-- Name: ix_gf_couts_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_couts_activite ON public.gf_couts USING btree (activite_id);


--
-- Name: ix_gf_couts_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_couts_org ON public.gf_couts USING btree (org_id);


--
-- Name: ix_gf_journal_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_date ON public.gf_journal USING btree (date_entree);


--
-- Name: ix_gf_journal_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_org ON public.gf_journal USING btree (org_id);


--
-- Name: ix_gf_journal_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_journal_parcelle ON public.gf_journal USING btree (parcelle_id);


--
-- Name: ix_gf_mo_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_mo_activite ON public.gf_main_oeuvre USING btree (activite_id);


--
-- Name: ix_gf_preuves_activite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gf_preuves_activite ON public.gf_preuves USING btree (activite_id);


--
-- Name: ix_ia_conversations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_conversations_org_id ON public.ia_conversations USING btree (org_id);


--
-- Name: ix_ia_feedback_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_feedback_org_id ON public.ia_feedback USING btree (org_id);


--
-- Name: ix_ia_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_messages_conversation_id ON public.ia_messages USING btree (conversation_id);


--
-- Name: ix_ia_messages_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_messages_org_id ON public.ia_messages USING btree (org_id);


--
-- Name: ix_ia_recommandations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_recommandations_org_id ON public.ia_recommandations USING btree (org_id);


--
-- Name: ix_ia_recommandations_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ia_recommandations_parcelle_id ON public.ia_recommandations USING btree (parcelle_id);


--
-- Name: ix_mt_alertes_niveau; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_niveau ON public.mt_alertes USING btree (niveau);


--
-- Name: ix_mt_alertes_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_org_id ON public.mt_alertes USING btree (org_id);


--
-- Name: ix_mt_alertes_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_parcelle_id ON public.mt_alertes USING btree (parcelle_id);


--
-- Name: ix_mt_alertes_type_alerte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_alertes_type_alerte ON public.mt_alertes USING btree (type_alerte);


--
-- Name: ix_mt_conditions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_conditions_org_id ON public.mt_conditions USING btree (org_id);


--
-- Name: ix_mt_conditions_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_conditions_parcelle_id ON public.mt_conditions USING btree (parcelle_id);


--
-- Name: ix_mt_planificateur_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_planificateur_org_id ON public.mt_planificateur USING btree (org_id);


--
-- Name: ix_mt_planificateur_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_planificateur_parcelle_id ON public.mt_planificateur USING btree (parcelle_id);


--
-- Name: ix_mt_previsions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_previsions_org_id ON public.mt_previsions USING btree (org_id);


--
-- Name: ix_mt_previsions_parcelle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_mt_previsions_parcelle_id ON public.mt_previsions USING btree (parcelle_id);


--
-- Name: ix_re_decl_org_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_decl_org_date ON public.re_declenchements USING btree (org_id, declenche_le);


--
-- Name: ix_re_declenchements_acquitte; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_acquitte ON public.re_declenchements USING btree (acquitte);


--
-- Name: ix_re_declenchements_declenche_le; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_declenche_le ON public.re_declenchements USING btree (declenche_le);


--
-- Name: ix_re_declenchements_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_org_id ON public.re_declenchements USING btree (org_id);


--
-- Name: ix_re_declenchements_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_declenchements_regle_id ON public.re_declenchements USING btree (regle_id);


--
-- Name: ix_re_parametres_cle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_re_parametres_cle ON public.re_parametres USING btree (cle);


--
-- Name: ix_re_regles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_active ON public.re_regles USING btree (active);


--
-- Name: ix_re_regles_categorie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_categorie ON public.re_regles USING btree (categorie);


--
-- Name: ix_re_regles_categorie_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_categorie_active ON public.re_regles USING btree (categorie, active);


--
-- Name: ix_re_regles_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_re_regles_code ON public.re_regles USING btree (code);


--
-- Name: ix_re_regles_cultures_culture_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_cultures_culture_id ON public.re_regles_cultures USING btree (culture_id);


--
-- Name: ix_re_regles_cultures_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_cultures_regle_id ON public.re_regles_cultures USING btree (regle_id);


--
-- Name: ix_re_regles_entites_regle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_entites_regle_id ON public.re_regles_entites USING btree (regle_id);


--
-- Name: ix_re_regles_gravite; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_gravite ON public.re_regles USING btree (gravite);


--
-- Name: ix_re_regles_gravite_prio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_gravite_prio ON public.re_regles USING btree (gravite, priorite);


--
-- Name: ix_re_regles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_regles_id ON public.re_regles USING btree (id);


--
-- Name: ix_re_sessions_evaluation_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_re_sessions_evaluation_org_id ON public.re_sessions_evaluation USING btree (org_id);


--
-- Name: ix_sc_consultations_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_consultations_org ON public.sc_consultations USING btree (org_id);


--
-- Name: ix_sc_consultations_parcelle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_consultations_parcelle ON public.sc_consultations USING btree (parcelle_id);


--
-- Name: ix_sc_diag_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_diag_consultation ON public.sc_diagnostics USING btree (consultation_id);


--
-- Name: ix_sc_obs_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_obs_consultation ON public.sc_observations USING btree (consultation_id);


--
-- Name: ix_sc_photos_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_photos_consultation ON public.sc_photos USING btree (consultation_id);


--
-- Name: ix_sc_rapports_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_rapports_consultation ON public.sc_rapports USING btree (consultation_id);


--
-- Name: ix_sc_rapports_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_rapports_org ON public.sc_rapports USING btree (org_id);


--
-- Name: ix_sc_suivis_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_suivis_consultation ON public.sc_suivis USING btree (consultation_id);


--
-- Name: ix_sc_trait_consultation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_trait_consultation ON public.sc_traitements USING btree (consultation_id);


--
-- Name: ix_usage_counters_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_usage_counters_period ON public.usage_counters USING btree (period);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: uniq_service_actif; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_service_actif ON public.service_requests USING btree (user_id) WHERE (statut = ANY (ARRAY['en_attente'::public.service_statut, 'en_cours'::public.service_statut]));


--
-- Name: agro_besoins_eau agro_besoins_eau_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_eau
    ADD CONSTRAINT agro_besoins_eau_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_besoins_nutritionnels agro_besoins_nutritionnels_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_besoins_nutritionnels
    ADD CONSTRAINT agro_besoins_nutritionnels_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_calendriers_culturaux agro_calendriers_culturaux_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_calendriers_culturaux
    ADD CONSTRAINT agro_calendriers_culturaux_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_maladies agro_culture_maladies_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_maladies agro_culture_maladies_maladie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_maladies
    ADD CONSTRAINT agro_culture_maladies_maladie_id_fkey FOREIGN KEY (maladie_id) REFERENCES public.agro_maladies(id) ON DELETE CASCADE;


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_culture_ravageurs agro_culture_ravageurs_ravageur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_culture_ravageurs
    ADD CONSTRAINT agro_culture_ravageurs_ravageur_id_fkey FOREIGN KEY (ravageur_id) REFERENCES public.agro_ravageurs(id) ON DELETE CASCADE;


--
-- Name: agro_parametres_climatiques agro_parametres_climatiques_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_parametres_climatiques
    ADD CONSTRAINT agro_parametres_climatiques_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_recommandations agro_recommandations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_recommandations
    ADD CONSTRAINT agro_recommandations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_rendements_reference agro_rendements_reference_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_rendements_reference agro_rendements_reference_variete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_rendements_reference
    ADD CONSTRAINT agro_rendements_reference_variete_id_fkey FOREIGN KEY (variete_id) REFERENCES public.agro_varietes(id) ON DELETE SET NULL;


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: agro_stades_phenologiques agro_stades_phenologiques_variete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_stades_phenologiques
    ADD CONSTRAINT agro_stades_phenologiques_variete_id_fkey FOREIGN KEY (variete_id) REFERENCES public.agro_varietes(id) ON DELETE SET NULL;


--
-- Name: agro_varietes agro_varietes_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agro_varietes
    ADD CONSTRAINT agro_varietes_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE CASCADE;


--
-- Name: analyses analyses_farm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_farm_id_fkey FOREIGN KEY (farm_id) REFERENCES public.farms(id);


--
-- Name: analyses analyses_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: analyses analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: champ_cartographies champ_cartographies_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_cartographies
    ADD CONSTRAINT champ_cartographies_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_infrastructures champ_infrastructures_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_infrastructures
    ADD CONSTRAINT champ_infrastructures_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_parcelles champ_parcelles_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: champ_parcelles champ_parcelles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_parcelles
    ADD CONSTRAINT champ_parcelles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: champ_sols champ_sols_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sols
    ADD CONSTRAINT champ_sols_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: champ_sources_eau champ_sources_eau_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.champ_sources_eau
    ADD CONSTRAINT champ_sources_eau_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: credit_ledger credit_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: credit_purchases credit_purchases_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.credit_ledger(id);


--
-- Name: credit_purchases credit_purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_purchases
    ADD CONSTRAINT credit_purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: farms farms_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.farms
    ADD CONSTRAINT farms_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: credit_ledger fk_ledger_request; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT fk_ledger_request FOREIGN KEY (service_request_id) REFERENCES public.service_requests(id);


--
-- Name: gf_activites gf_activites_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE SET NULL;


--
-- Name: gf_activites gf_activites_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_activites gf_activites_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_activites
    ADD CONSTRAINT gf_activites_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: gf_couts gf_couts_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_couts gf_couts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_couts
    ADD CONSTRAINT gf_couts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_journal gf_journal_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE SET NULL;


--
-- Name: gf_journal gf_journal_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gf_journal gf_journal_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_journal gf_journal_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_journal
    ADD CONSTRAINT gf_journal_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: gf_main_oeuvre gf_main_oeuvre_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_main_oeuvre gf_main_oeuvre_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_main_oeuvre
    ADD CONSTRAINT gf_main_oeuvre_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gf_preuves gf_preuves_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id) ON DELETE CASCADE;


--
-- Name: gf_preuves gf_preuves_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gf_preuves
    ADD CONSTRAINT gf_preuves_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ia_config ia_config_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_config
    ADD CONSTRAINT ia_config_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_conversations ia_conversations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: ia_conversations ia_conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_conversations ia_conversations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: ia_conversations ia_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_conversations
    ADD CONSTRAINT ia_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ia_feedback ia_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id);


--
-- Name: ia_feedback ia_feedback_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.ia_messages(id);


--
-- Name: ia_feedback ia_feedback_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_feedback ia_feedback_recommandation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_feedback
    ADD CONSTRAINT ia_feedback_recommandation_id_fkey FOREIGN KEY (recommandation_id) REFERENCES public.ia_recommandations(id);


--
-- Name: ia_messages ia_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id) ON DELETE CASCADE;


--
-- Name: ia_messages ia_messages_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_messages
    ADD CONSTRAINT ia_messages_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_recommandations ia_recommandations_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ia_conversations(id);


--
-- Name: ia_recommandations ia_recommandations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: ia_recommandations ia_recommandations_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.ia_messages(id);


--
-- Name: ia_recommandations ia_recommandations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: ia_recommandations ia_recommandations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ia_recommandations
    ADD CONSTRAINT ia_recommandations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_alertes mt_alertes_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: mt_alertes mt_alertes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_alertes mt_alertes_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_alertes
    ADD CONSTRAINT mt_alertes_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_conditions mt_conditions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_conditions mt_conditions_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_conditions
    ADD CONSTRAINT mt_conditions_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_config_alertes mt_config_alertes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_config_alertes
    ADD CONSTRAINT mt_config_alertes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_planificateur mt_planificateur_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.gf_activites(id);


--
-- Name: mt_planificateur mt_planificateur_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: mt_planificateur mt_planificateur_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_planificateur mt_planificateur_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_planificateur
    ADD CONSTRAINT mt_planificateur_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: mt_previsions mt_previsions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: mt_previsions mt_previsions_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mt_previsions
    ADD CONSTRAINT mt_previsions_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id);


--
-- Name: parcelles parcelles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parcelles
    ADD CONSTRAINT parcelles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id);


--
-- Name: re_declenchements re_declenchements_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_declenchements
    ADD CONSTRAINT re_declenchements_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id);


--
-- Name: re_regles_cultures re_regles_cultures_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id);


--
-- Name: re_regles_cultures re_regles_cultures_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_cultures
    ADD CONSTRAINT re_regles_cultures_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id) ON DELETE CASCADE;


--
-- Name: re_regles_entites re_regles_entites_regle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.re_regles_entites
    ADD CONSTRAINT re_regles_entites_regle_id_fkey FOREIGN KEY (regle_id) REFERENCES public.re_regles(id) ON DELETE CASCADE;


--
-- Name: sc_consultations sc_consultations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_consultations sc_consultations_culture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_culture_id_fkey FOREIGN KEY (culture_id) REFERENCES public.agro_cultures(id) ON DELETE SET NULL;


--
-- Name: sc_consultations sc_consultations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sc_consultations sc_consultations_parcelle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_consultations
    ADD CONSTRAINT sc_consultations_parcelle_id_fkey FOREIGN KEY (parcelle_id) REFERENCES public.champ_parcelles(id) ON DELETE SET NULL;


--
-- Name: sc_diagnostics sc_diagnostics_confirme_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_confirme_par_fkey FOREIGN KEY (confirme_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_diagnostics sc_diagnostics_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_diagnostics
    ADD CONSTRAINT sc_diagnostics_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_observations sc_observations_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_observations
    ADD CONSTRAINT sc_observations_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_photos sc_photos_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_photos sc_photos_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_photos
    ADD CONSTRAINT sc_photos_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES public.sc_observations(id) ON DELETE SET NULL;


--
-- Name: sc_rapports sc_rapports_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_rapports sc_rapports_genere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_genere_par_fkey FOREIGN KEY (genere_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sc_rapports sc_rapports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_rapports
    ADD CONSTRAINT sc_rapports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: sc_suivis sc_suivis_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_suivis
    ADD CONSTRAINT sc_suivis_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_traitements sc_traitements_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.sc_consultations(id) ON DELETE CASCADE;


--
-- Name: sc_traitements sc_traitements_diagnostic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sc_traitements
    ADD CONSTRAINT sc_traitements_diagnostic_id_fkey FOREIGN KEY (diagnostic_id) REFERENCES public.sc_diagnostics(id) ON DELETE SET NULL;


--
-- Name: service_requests service_requests_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: service_requests service_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: usage_counters usage_counters_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT usage_counters_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict SeVbnvflmoAnL7Oh3sazUdc9NMWcl3ToYaMzLrMafciuM6bva8HNAj867WjrzH1

